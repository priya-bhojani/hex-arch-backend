export const getMessagesSchema = {
  type: "object",
  properties: {
    body: {},
  },
};
