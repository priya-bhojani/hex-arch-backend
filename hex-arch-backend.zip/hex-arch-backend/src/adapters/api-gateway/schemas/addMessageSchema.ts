export const addMessageSchema = {
  type: "object",
  properties: {
    body: {
      type: "object",
      additionalProperties: false,
      required: ["message"],
      properties: {
        message: { type: "string" },
      },
    },
  },
};
