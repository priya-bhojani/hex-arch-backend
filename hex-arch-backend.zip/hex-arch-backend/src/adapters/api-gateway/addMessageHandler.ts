import middy from "@middy/core";
import { APIGatewayProxyResult } from "aws-lambda";

import { lambdaMiddyWrapper } from "../../middyWrapper/middyWrapper";
import { addMessageCommand } from "../../use-cases/add-message/addMessageCommand";
import DynamoDbMessageRepository from "../message-repository/dynamoDbMessageRepository";
import { addMessageSchema } from "./schemas/addMessageSchema";
import { AddMessageRequest } from "./types/addMessageRequest";
import { AddMessageResponse } from "./types/addMessageResponse";

export const addMessage = async (
  addMessageRequest: AddMessageRequest
): Promise<AddMessageResponse> => {
  const { body } = addMessageRequest;

  const messageRepository = DynamoDbMessageRepository.instance();
  const command = addMessageCommand(messageRepository);

  await command(body.message);

  return {
    response: "Message added successfully.",
  };
};

export const addMessageHandler: middy.Middy<
  AddMessageRequest,
  APIGatewayProxyResult
> = lambdaMiddyWrapper({
  lambda: addMessage,
  inputSchema: addMessageSchema,
  statusCode: 200,
});
