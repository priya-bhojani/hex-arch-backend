import middy from "@middy/core";
import { APIGatewayProxyResult } from "aws-lambda";

import { lambdaMiddyWrapper } from "../../middyWrapper/middyWrapper";
import { getMessagesCommand } from "../../use-cases/get-messages/getMessagesCommand";
import DynamoDbMessageRepository from "../message-repository/dynamoDbMessageRepository";
import { getMessagesSchema } from "./schemas/getMessagesSchema";
import { GetMessagesRequest } from "./types/getMessagesRequest";
import { GetMessagesResponse } from "./types/getMessagesResponse";

export const getMessages = async (): Promise<GetMessagesResponse> => {
  const messageRepository = DynamoDbMessageRepository.instance();
  const command = getMessagesCommand(messageRepository);

  return await command();
};

export const getMessagesHandler: middy.Middy<
  GetMessagesRequest,
  APIGatewayProxyResult
> = lambdaMiddyWrapper({
  lambda: getMessages,
  inputSchema: getMessagesSchema,
  statusCode: 200,
});
