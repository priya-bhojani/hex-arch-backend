import { Context } from "aws-lambda";

import { MyExtendedEvent } from "../../helpers/observability/myExtendedEvent";

export interface GetMessagesRequest extends MyExtendedEvent {
  body: null;
  context: Context;
}
