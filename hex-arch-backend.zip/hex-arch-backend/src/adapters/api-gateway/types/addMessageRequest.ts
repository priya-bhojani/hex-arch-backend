import { Context } from "aws-lambda";

import { MyExtendedEvent } from "../../helpers/observability/myExtendedEvent";

export interface AddMessageRequest extends MyExtendedEvent {
  body: AddMessageBody;
  context: Context;
}

export interface AddMessageBody {
  message: string;
}
