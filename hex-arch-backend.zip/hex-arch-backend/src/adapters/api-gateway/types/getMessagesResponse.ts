export interface GetMessagesResponse {
  messages: string[];
}
