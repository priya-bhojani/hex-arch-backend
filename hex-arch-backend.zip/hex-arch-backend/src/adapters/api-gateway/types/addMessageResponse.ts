export interface AddMessageResponse {
  response: string;
}
