import { MessageRepository } from "./messageRepository";

export default class DynamoDbMessageRepository implements MessageRepository {
  public static instance(): DynamoDbMessageRepository {
    return new DynamoDbMessageRepository();
  }

  async store(message: string): Promise<void> {
    console.log(message + "stored successfully");
  }

  async get(): Promise<string[]> {
    return ["message1", "message2"];
  }
}
