export interface MessageRepository {
  store(message: string): Promise<void>;
  get(): Promise<string[]>;
}
