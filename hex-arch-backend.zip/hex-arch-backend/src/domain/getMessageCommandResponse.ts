export interface GetMessageCommandResponse {
  messages: string[];
}
