import { MessageRepository } from "../../adapters/message-repository/messageRepository";
import { GetMessageCommandResponse } from "../../domain/getMessageCommandResponse";

export const getMessagesCommand = (messageRepository: MessageRepository) => {
  return async (): Promise<GetMessageCommandResponse> => {
    const messagesFromDb = await messageRepository.get();

    return {
      messages: messagesFromDb,
    };
  };
};
