import { MessageRepository } from "../../adapters/message-repository/messageRepository";

export const addMessageCommand = (messageRepository: MessageRepository) => {
  return async (message: string): Promise<string> => {
    await messageRepository.store(message);

    return "Message stored successfully.";
  };
};
