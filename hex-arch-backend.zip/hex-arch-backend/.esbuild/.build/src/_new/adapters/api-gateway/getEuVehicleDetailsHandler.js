var __create = Object.create;
var __defProp = Object.defineProperty;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {enumerable: true, configurable: true, writable: true, value}) : obj[key] = value;
var __objSpread = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __markAsModule = (target) => __defProp(target, "__esModule", {value: true});
var __objRest = (source, exclude) => {
  var target = {};
  for (var prop in source)
    if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
      target[prop] = source[prop];
  if (source != null && __getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(source)) {
      if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
        target[prop] = source[prop];
    }
  return target;
};
var __commonJS = (cb, mod) => () => (mod || cb((mod = {exports: {}}).exports, mod), mod.exports);
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {get: all[name], enumerable: true});
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, {get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable});
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? {get: () => module2.default, enumerable: true} : {value: module2, enumerable: true})), module2);
};

// node_modules/@middy/core/isPromise.js
var require_isPromise = __commonJS((exports2, module2) => {
  module2.exports = (val) => {
    return val && typeof val.then === "function" && typeof val.catch === "function";
  };
});

// node_modules/wrappy/wrappy.js
var require_wrappy = __commonJS((exports2, module2) => {
  module2.exports = wrappy;
  function wrappy(fn, cb) {
    if (fn && cb)
      return wrappy(fn)(cb);
    if (typeof fn !== "function")
      throw new TypeError("need wrapper function");
    Object.keys(fn).forEach(function(k) {
      wrapper[k] = fn[k];
    });
    return wrapper;
    function wrapper() {
      var args = new Array(arguments.length);
      for (var i = 0; i < args.length; i++) {
        args[i] = arguments[i];
      }
      var ret = fn.apply(this, args);
      var cb2 = args[args.length - 1];
      if (typeof ret === "function" && ret !== cb2) {
        Object.keys(cb2).forEach(function(k) {
          ret[k] = cb2[k];
        });
      }
      return ret;
    }
  }
});

// node_modules/once/once.js
var require_once = __commonJS((exports2, module2) => {
  var wrappy = require_wrappy();
  module2.exports = wrappy(once);
  module2.exports.strict = wrappy(onceStrict);
  once.proto = once(function() {
    Object.defineProperty(Function.prototype, "once", {
      value: function() {
        return once(this);
      },
      configurable: true
    });
    Object.defineProperty(Function.prototype, "onceStrict", {
      value: function() {
        return onceStrict(this);
      },
      configurable: true
    });
  });
  function once(fn) {
    var f = function() {
      if (f.called)
        return f.value;
      f.called = true;
      return f.value = fn.apply(this, arguments);
    };
    f.called = false;
    return f;
  }
  function onceStrict(fn) {
    var f = function() {
      if (f.called)
        throw new Error(f.onceError);
      f.called = true;
      return f.value = fn.apply(this, arguments);
    };
    var name = fn.name || "Function wrapped with `once`";
    f.onceError = name + " shouldn't be called more than once";
    f.called = false;
    return f;
  }
});

// node_modules/@middy/core/index.js
var require_core = __commonJS((exports2, module2) => {
  var isPromise = require_isPromise();
  var once = require_once();
  var runMiddlewares = (middlewares, request, done) => {
    const stack = Array.from(middlewares);
    const runNext = (err) => {
      try {
        if (err) {
          return done(err);
        }
        const nextMiddleware = stack.shift();
        if (nextMiddleware) {
          const retVal = nextMiddleware(request, runNext);
          if (retVal) {
            if (!isPromise(retVal)) {
              throw new Error("Unexpected return value in middleware");
            }
            retVal.then(runNext).catch(done);
          }
          return;
        }
        return done();
      } catch (err2) {
        return done(err2);
      }
    };
    runNext();
  };
  var runErrorMiddlewares = (middlewares, request, done) => {
    const stack = Array.from(middlewares);
    request.__handledError = false;
    const runNext = (err) => {
      try {
        if (!err) {
          request.__handledError = true;
        }
        const nextMiddleware = stack.shift();
        if (nextMiddleware) {
          const retVal = nextMiddleware(request, runNext);
          if (retVal) {
            if (!isPromise(retVal)) {
              const invalidMiddlewareReturnError = new Error("Unexpected return value in onError middleware");
              invalidMiddlewareReturnError.originalError = err;
              throw invalidMiddlewareReturnError;
            }
            retVal.then(runNext).catch(done);
          }
          return;
        }
        return done(request.__handledError ? null : err);
      } catch (err2) {
        return done(err2);
      }
    };
    runNext(request.error);
  };
  var middy2 = (handler) => {
    const beforeMiddlewares = [];
    const afterMiddlewares = [];
    const errorMiddlewares = [];
    const instance = (event, context, callback) => {
      const request = {};
      request.event = event;
      request.context = context;
      request.callback = callback;
      request.response = null;
      request.error = null;
      const middyPromise = new Promise((resolve, reject) => {
        const terminate = (err) => {
          if (err) {
            return callback ? callback(err) : reject(err);
          }
          return callback ? callback(null, request.response) : resolve(request.response);
        };
        const errorHandler2 = (err) => {
          request.error = err;
          return runErrorMiddlewares(errorMiddlewares, request, terminate);
        };
        runMiddlewares(beforeMiddlewares, request, (err) => {
          if (err)
            return errorHandler2(err);
          const onHandlerError = once((err2) => {
            request.response = null;
            errorHandler2(err2);
          });
          const onHandlerSuccess = once((response) => {
            request.response = response;
            runMiddlewares(afterMiddlewares, request, (err2) => {
              if (err2)
                return errorHandler2(err2);
              terminate();
            });
          });
          const handlerReturnValue = handler.call(request, request.event, request.context, (err2, response) => {
            if (err2)
              return onHandlerError(err2);
            onHandlerSuccess(response);
          });
          if (handlerReturnValue) {
            if (!isPromise(handlerReturnValue)) {
              throw new Error("Unexpected return value in handler");
            }
            handlerReturnValue.then(onHandlerSuccess).catch(onHandlerError);
          }
        });
      });
      if (!request.callback)
        return middyPromise;
    };
    instance.use = (middlewares) => {
      if (Array.isArray(middlewares)) {
        middlewares.forEach((middleware) => instance.applyMiddleware(middleware));
        return instance;
      } else if (typeof middlewares === "object") {
        return instance.applyMiddleware(middlewares);
      } else {
        throw new Error("Middy.use() accepts an object or an array of objects");
      }
    };
    instance.applyMiddleware = (middleware) => {
      if (typeof middleware !== "object") {
        throw new Error("Middleware must be an object");
      }
      const {before, after, onError} = middleware;
      if (!before && !after && !onError) {
        throw new Error('Middleware must contain at least one key among "before", "after", "onError"');
      }
      if (before) {
        instance.before(before);
      }
      if (after) {
        instance.after(after);
      }
      if (onError) {
        instance.onError(onError);
      }
      return instance;
    };
    instance.before = (beforeMiddleware) => {
      beforeMiddlewares.push(beforeMiddleware);
      return instance;
    };
    instance.after = (afterMiddleware) => {
      afterMiddlewares.unshift(afterMiddleware);
      return instance;
    };
    instance.onError = (errorMiddleware) => {
      errorMiddlewares.push(errorMiddleware);
      return instance;
    };
    instance.__middlewares = {
      before: beforeMiddlewares,
      after: afterMiddlewares,
      onError: errorMiddlewares
    };
    return instance;
  };
  module2.exports = middy2;
});

// node_modules/@middy/http-header-normalizer/index.js
var require_http_header_normalizer = __commonJS((exports2, module2) => {
  module2.exports = (opts) => {
    const exceptionsList = [
      "ALPN",
      "C-PEP",
      "C-PEP-Info",
      "CalDAV-Timezones",
      "Content-ID",
      "Content-MD5",
      "DASL",
      "DAV",
      "DNT",
      "ETag",
      "GetProfile",
      "HTTP2-Settings",
      "Last-Event-ID",
      "MIME-Version",
      "Optional-WWW-Authenticate",
      "Sec-WebSocket-Accept",
      "Sec-WebSocket-Extensions",
      "Sec-WebSocket-Key",
      "Sec-WebSocket-Protocol",
      "Sec-WebSocket-Version",
      "SLUG",
      "TCN",
      "TE",
      "TTL",
      "WWW-Authenticate",
      "X-ATT-DeviceId",
      "X-DNSPrefetch-Control",
      "X-UIDH"
    ];
    const exceptions = exceptionsList.reduce((acc, curr) => {
      acc[curr.toLowerCase()] = curr;
      return acc;
    }, {});
    const normalizeHeaderKey = (key, canonical) => {
      if (exceptions[key.toLowerCase()]) {
        return exceptions[key.toLowerCase()];
      }
      if (!canonical) {
        return key.toLowerCase();
      }
      return key.split("-").map((text) => text.charAt(0).toUpperCase() + text.substr(1).toLowerCase()).join("-");
    };
    const defaults = {
      normalizeHeaderKey,
      canonical: false
    };
    const options = Object.assign({}, defaults, opts);
    return {
      before: (handler, next) => {
        if (handler.event.headers) {
          const rawHeaders = {};
          const headers = {};
          Object.keys(handler.event.headers).forEach((key) => {
            rawHeaders[key] = handler.event.headers[key];
            headers[options.normalizeHeaderKey(key, options.canonical)] = handler.event.headers[key];
          });
          handler.event.headers = headers;
          handler.event.rawHeaders = rawHeaders;
        }
        if (handler.event.multiValueHeaders) {
          const rawHeaders = {};
          const headers = {};
          Object.keys(handler.event.multiValueHeaders).forEach((key) => {
            rawHeaders[key] = handler.event.multiValueHeaders[key];
            headers[options.normalizeHeaderKey(key, options.canonical)] = handler.event.multiValueHeaders[key];
          });
          handler.event.multiValueHeaders = headers;
          handler.event.rawMultiValueHeaders = rawHeaders;
        }
        next();
      }
    };
  };
});

// node_modules/depd/lib/compat/callsite-tostring.js
var require_callsite_tostring = __commonJS((exports2, module2) => {
  /*!
   * depd
   * Copyright(c) 2014 Douglas Christopher Wilson
   * MIT Licensed
   */
  "use strict";
  module2.exports = callSiteToString2;
  function callSiteFileLocation(callSite) {
    var fileName;
    var fileLocation = "";
    if (callSite.isNative()) {
      fileLocation = "native";
    } else if (callSite.isEval()) {
      fileName = callSite.getScriptNameOrSourceURL();
      if (!fileName) {
        fileLocation = callSite.getEvalOrigin();
      }
    } else {
      fileName = callSite.getFileName();
    }
    if (fileName) {
      fileLocation += fileName;
      var lineNumber = callSite.getLineNumber();
      if (lineNumber != null) {
        fileLocation += ":" + lineNumber;
        var columnNumber = callSite.getColumnNumber();
        if (columnNumber) {
          fileLocation += ":" + columnNumber;
        }
      }
    }
    return fileLocation || "unknown source";
  }
  function callSiteToString2(callSite) {
    var addSuffix = true;
    var fileLocation = callSiteFileLocation(callSite);
    var functionName = callSite.getFunctionName();
    var isConstructor = callSite.isConstructor();
    var isMethodCall = !(callSite.isToplevel() || isConstructor);
    var line = "";
    if (isMethodCall) {
      var methodName = callSite.getMethodName();
      var typeName = getConstructorName(callSite);
      if (functionName) {
        if (typeName && functionName.indexOf(typeName) !== 0) {
          line += typeName + ".";
        }
        line += functionName;
        if (methodName && functionName.lastIndexOf("." + methodName) !== functionName.length - methodName.length - 1) {
          line += " [as " + methodName + "]";
        }
      } else {
        line += typeName + "." + (methodName || "<anonymous>");
      }
    } else if (isConstructor) {
      line += "new " + (functionName || "<anonymous>");
    } else if (functionName) {
      line += functionName;
    } else {
      addSuffix = false;
      line += fileLocation;
    }
    if (addSuffix) {
      line += " (" + fileLocation + ")";
    }
    return line;
  }
  function getConstructorName(obj) {
    var receiver = obj.receiver;
    return receiver.constructor && receiver.constructor.name || null;
  }
});

// node_modules/depd/lib/compat/event-listener-count.js
var require_event_listener_count = __commonJS((exports2, module2) => {
  /*!
   * depd
   * Copyright(c) 2015 Douglas Christopher Wilson
   * MIT Licensed
   */
  "use strict";
  module2.exports = eventListenerCount2;
  function eventListenerCount2(emitter, type) {
    return emitter.listeners(type).length;
  }
});

// node_modules/depd/lib/compat/index.js
var require_compat = __commonJS((exports2, module2) => {
  /*!
   * depd
   * Copyright(c) 2014-2015 Douglas Christopher Wilson
   * MIT Licensed
   */
  "use strict";
  var EventEmitter = require("events").EventEmitter;
  lazyProperty(module2.exports, "callSiteToString", function callSiteToString2() {
    var limit = Error.stackTraceLimit;
    var obj = {};
    var prep = Error.prepareStackTrace;
    function prepareObjectStackTrace2(obj2, stack2) {
      return stack2;
    }
    Error.prepareStackTrace = prepareObjectStackTrace2;
    Error.stackTraceLimit = 2;
    Error.captureStackTrace(obj);
    var stack = obj.stack.slice();
    Error.prepareStackTrace = prep;
    Error.stackTraceLimit = limit;
    return stack[0].toString ? toString : require_callsite_tostring();
  });
  lazyProperty(module2.exports, "eventListenerCount", function eventListenerCount2() {
    return EventEmitter.listenerCount || require_event_listener_count();
  });
  function lazyProperty(obj, prop, getter) {
    function get() {
      var val = getter();
      Object.defineProperty(obj, prop, {
        configurable: true,
        enumerable: true,
        value: val
      });
      return val;
    }
    Object.defineProperty(obj, prop, {
      configurable: true,
      enumerable: true,
      get
    });
  }
  function toString(obj) {
    return obj.toString();
  }
});

// node_modules/depd/index.js
var require_depd = __commonJS((exports, module) => {
  /*!
   * depd
   * Copyright(c) 2014-2017 Douglas Christopher Wilson
   * MIT Licensed
   */
  var callSiteToString = require_compat().callSiteToString;
  var eventListenerCount = require_compat().eventListenerCount;
  var relative = require("path").relative;
  module.exports = depd;
  var basePath = process.cwd();
  function containsNamespace(str, namespace) {
    var vals = str.split(/[ ,]+/);
    var ns = String(namespace).toLowerCase();
    for (var i = 0; i < vals.length; i++) {
      var val = vals[i];
      if (val && (val === "*" || val.toLowerCase() === ns)) {
        return true;
      }
    }
    return false;
  }
  function convertDataDescriptorToAccessor(obj, prop, message) {
    var descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    var value = descriptor.value;
    descriptor.get = function getter() {
      return value;
    };
    if (descriptor.writable) {
      descriptor.set = function setter(val) {
        return value = val;
      };
    }
    delete descriptor.value;
    delete descriptor.writable;
    Object.defineProperty(obj, prop, descriptor);
    return descriptor;
  }
  function createArgumentsString(arity) {
    var str = "";
    for (var i = 0; i < arity; i++) {
      str += ", arg" + i;
    }
    return str.substr(2);
  }
  function createStackString(stack) {
    var str = this.name + ": " + this.namespace;
    if (this.message) {
      str += " deprecated " + this.message;
    }
    for (var i = 0; i < stack.length; i++) {
      str += "\n    at " + callSiteToString(stack[i]);
    }
    return str;
  }
  function depd(namespace) {
    if (!namespace) {
      throw new TypeError("argument namespace is required");
    }
    var stack = getStack();
    var site = callSiteLocation(stack[1]);
    var file = site[0];
    function deprecate(message) {
      log.call(deprecate, message);
    }
    deprecate._file = file;
    deprecate._ignored = isignored(namespace);
    deprecate._namespace = namespace;
    deprecate._traced = istraced(namespace);
    deprecate._warned = Object.create(null);
    deprecate.function = wrapfunction;
    deprecate.property = wrapproperty;
    return deprecate;
  }
  function isignored(namespace) {
    if (process.noDeprecation) {
      return true;
    }
    var str = process.env.NO_DEPRECATION || "";
    return containsNamespace(str, namespace);
  }
  function istraced(namespace) {
    if (process.traceDeprecation) {
      return true;
    }
    var str = process.env.TRACE_DEPRECATION || "";
    return containsNamespace(str, namespace);
  }
  function log(message, site) {
    var haslisteners = eventListenerCount(process, "deprecation") !== 0;
    if (!haslisteners && this._ignored) {
      return;
    }
    var caller;
    var callFile;
    var callSite;
    var depSite;
    var i = 0;
    var seen = false;
    var stack = getStack();
    var file = this._file;
    if (site) {
      depSite = site;
      callSite = callSiteLocation(stack[1]);
      callSite.name = depSite.name;
      file = callSite[0];
    } else {
      i = 2;
      depSite = callSiteLocation(stack[i]);
      callSite = depSite;
    }
    for (; i < stack.length; i++) {
      caller = callSiteLocation(stack[i]);
      callFile = caller[0];
      if (callFile === file) {
        seen = true;
      } else if (callFile === this._file) {
        file = this._file;
      } else if (seen) {
        break;
      }
    }
    var key = caller ? depSite.join(":") + "__" + caller.join(":") : void 0;
    if (key !== void 0 && key in this._warned) {
      return;
    }
    this._warned[key] = true;
    var msg = message;
    if (!msg) {
      msg = callSite === depSite || !callSite.name ? defaultMessage(depSite) : defaultMessage(callSite);
    }
    if (haslisteners) {
      var err = DeprecationError(this._namespace, msg, stack.slice(i));
      process.emit("deprecation", err);
      return;
    }
    var format = process.stderr.isTTY ? formatColor : formatPlain;
    var output = format.call(this, msg, caller, stack.slice(i));
    process.stderr.write(output + "\n", "utf8");
  }
  function callSiteLocation(callSite) {
    var file = callSite.getFileName() || "<anonymous>";
    var line = callSite.getLineNumber();
    var colm = callSite.getColumnNumber();
    if (callSite.isEval()) {
      file = callSite.getEvalOrigin() + ", " + file;
    }
    var site = [file, line, colm];
    site.callSite = callSite;
    site.name = callSite.getFunctionName();
    return site;
  }
  function defaultMessage(site) {
    var callSite = site.callSite;
    var funcName = site.name;
    if (!funcName) {
      funcName = "<anonymous@" + formatLocation(site) + ">";
    }
    var context = callSite.getThis();
    var typeName = context && callSite.getTypeName();
    if (typeName === "Object") {
      typeName = void 0;
    }
    if (typeName === "Function") {
      typeName = context.name || typeName;
    }
    return typeName && callSite.getMethodName() ? typeName + "." + funcName : funcName;
  }
  function formatPlain(msg, caller, stack) {
    var timestamp = new Date().toUTCString();
    var formatted = timestamp + " " + this._namespace + " deprecated " + msg;
    if (this._traced) {
      for (var i = 0; i < stack.length; i++) {
        formatted += "\n    at " + callSiteToString(stack[i]);
      }
      return formatted;
    }
    if (caller) {
      formatted += " at " + formatLocation(caller);
    }
    return formatted;
  }
  function formatColor(msg, caller, stack) {
    var formatted = "[36;1m" + this._namespace + "[22;39m [33;1mdeprecated[22;39m [0m" + msg + "[39m";
    if (this._traced) {
      for (var i = 0; i < stack.length; i++) {
        formatted += "\n    [36mat " + callSiteToString(stack[i]) + "[39m";
      }
      return formatted;
    }
    if (caller) {
      formatted += " [36m" + formatLocation(caller) + "[39m";
    }
    return formatted;
  }
  function formatLocation(callSite) {
    return relative(basePath, callSite[0]) + ":" + callSite[1] + ":" + callSite[2];
  }
  function getStack() {
    var limit = Error.stackTraceLimit;
    var obj = {};
    var prep = Error.prepareStackTrace;
    Error.prepareStackTrace = prepareObjectStackTrace;
    Error.stackTraceLimit = Math.max(10, limit);
    Error.captureStackTrace(obj);
    var stack = obj.stack.slice(1);
    Error.prepareStackTrace = prep;
    Error.stackTraceLimit = limit;
    return stack;
  }
  function prepareObjectStackTrace(obj, stack) {
    return stack;
  }
  function wrapfunction(fn, message) {
    if (typeof fn !== "function") {
      throw new TypeError("argument fn must be a function");
    }
    var args = createArgumentsString(fn.length);
    var deprecate = this;
    var stack = getStack();
    var site = callSiteLocation(stack[1]);
    site.name = fn.name;
    var deprecatedfn = eval("(function (" + args + ') {\n"use strict"\nlog.call(deprecate, message, site)\nreturn fn.apply(this, arguments)\n})');
    return deprecatedfn;
  }
  function wrapproperty(obj, prop, message) {
    if (!obj || typeof obj !== "object" && typeof obj !== "function") {
      throw new TypeError("argument obj must be object");
    }
    var descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (!descriptor) {
      throw new TypeError("must call property on owner object");
    }
    if (!descriptor.configurable) {
      throw new TypeError("property must be configurable");
    }
    var deprecate = this;
    var stack = getStack();
    var site = callSiteLocation(stack[1]);
    site.name = prop;
    if ("value" in descriptor) {
      descriptor = convertDataDescriptorToAccessor(obj, prop, message);
    }
    var get = descriptor.get;
    var set = descriptor.set;
    if (typeof get === "function") {
      descriptor.get = function getter() {
        log.call(deprecate, message, site);
        return get.apply(this, arguments);
      };
    }
    if (typeof set === "function") {
      descriptor.set = function setter() {
        log.call(deprecate, message, site);
        return set.apply(this, arguments);
      };
    }
    Object.defineProperty(obj, prop, descriptor);
  }
  function DeprecationError(namespace, message, stack) {
    var error = new Error();
    var stackString;
    Object.defineProperty(error, "constructor", {
      value: DeprecationError
    });
    Object.defineProperty(error, "message", {
      configurable: true,
      enumerable: false,
      value: message,
      writable: true
    });
    Object.defineProperty(error, "name", {
      enumerable: false,
      configurable: true,
      value: "DeprecationError",
      writable: true
    });
    Object.defineProperty(error, "namespace", {
      configurable: true,
      enumerable: false,
      value: namespace,
      writable: true
    });
    Object.defineProperty(error, "stack", {
      configurable: true,
      enumerable: false,
      get: function() {
        if (stackString !== void 0) {
          return stackString;
        }
        return stackString = createStackString.call(this, stack);
      },
      set: function setter(val) {
        stackString = val;
      }
    });
    return error;
  }
});

// node_modules/setprototypeof/index.js
var require_setprototypeof = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = Object.setPrototypeOf || ({__proto__: []} instanceof Array ? setProtoOf : mixinProperties);
  function setProtoOf(obj, proto) {
    obj.__proto__ = proto;
    return obj;
  }
  function mixinProperties(obj, proto) {
    for (var prop in proto) {
      if (!Object.prototype.hasOwnProperty.call(obj, prop)) {
        obj[prop] = proto[prop];
      }
    }
    return obj;
  }
});

// node_modules/statuses/codes.json
var require_codes = __commonJS((exports2, module2) => {
  module2.exports = {
    "100": "Continue",
    "101": "Switching Protocols",
    "102": "Processing",
    "103": "Early Hints",
    "200": "OK",
    "201": "Created",
    "202": "Accepted",
    "203": "Non-Authoritative Information",
    "204": "No Content",
    "205": "Reset Content",
    "206": "Partial Content",
    "207": "Multi-Status",
    "208": "Already Reported",
    "226": "IM Used",
    "300": "Multiple Choices",
    "301": "Moved Permanently",
    "302": "Found",
    "303": "See Other",
    "304": "Not Modified",
    "305": "Use Proxy",
    "306": "(Unused)",
    "307": "Temporary Redirect",
    "308": "Permanent Redirect",
    "400": "Bad Request",
    "401": "Unauthorized",
    "402": "Payment Required",
    "403": "Forbidden",
    "404": "Not Found",
    "405": "Method Not Allowed",
    "406": "Not Acceptable",
    "407": "Proxy Authentication Required",
    "408": "Request Timeout",
    "409": "Conflict",
    "410": "Gone",
    "411": "Length Required",
    "412": "Precondition Failed",
    "413": "Payload Too Large",
    "414": "URI Too Long",
    "415": "Unsupported Media Type",
    "416": "Range Not Satisfiable",
    "417": "Expectation Failed",
    "418": "I'm a teapot",
    "421": "Misdirected Request",
    "422": "Unprocessable Entity",
    "423": "Locked",
    "424": "Failed Dependency",
    "425": "Unordered Collection",
    "426": "Upgrade Required",
    "428": "Precondition Required",
    "429": "Too Many Requests",
    "431": "Request Header Fields Too Large",
    "451": "Unavailable For Legal Reasons",
    "500": "Internal Server Error",
    "501": "Not Implemented",
    "502": "Bad Gateway",
    "503": "Service Unavailable",
    "504": "Gateway Timeout",
    "505": "HTTP Version Not Supported",
    "506": "Variant Also Negotiates",
    "507": "Insufficient Storage",
    "508": "Loop Detected",
    "509": "Bandwidth Limit Exceeded",
    "510": "Not Extended",
    "511": "Network Authentication Required"
  };
});

// node_modules/statuses/index.js
var require_statuses = __commonJS((exports2, module2) => {
  /*!
   * statuses
   * Copyright(c) 2014 Jonathan Ong
   * Copyright(c) 2016 Douglas Christopher Wilson
   * MIT Licensed
   */
  "use strict";
  var codes = require_codes();
  module2.exports = status;
  status.STATUS_CODES = codes;
  status.codes = populateStatusesMap(status, codes);
  status.redirect = {
    300: true,
    301: true,
    302: true,
    303: true,
    305: true,
    307: true,
    308: true
  };
  status.empty = {
    204: true,
    205: true,
    304: true
  };
  status.retry = {
    502: true,
    503: true,
    504: true
  };
  function populateStatusesMap(statuses, codes2) {
    var arr = [];
    Object.keys(codes2).forEach(function forEachCode(code) {
      var message = codes2[code];
      var status2 = Number(code);
      statuses[status2] = message;
      statuses[message] = status2;
      statuses[message.toLowerCase()] = status2;
      arr.push(status2);
    });
    return arr;
  }
  function status(code) {
    if (typeof code === "number") {
      if (!status[code])
        throw new Error("invalid status code: " + code);
      return code;
    }
    if (typeof code !== "string") {
      throw new TypeError("code must be a number or string");
    }
    var n = parseInt(code, 10);
    if (!isNaN(n)) {
      if (!status[n])
        throw new Error("invalid status code: " + n);
      return n;
    }
    n = status[code.toLowerCase()];
    if (!n)
      throw new Error('invalid status message: "' + code + '"');
    return n;
  }
});

// node_modules/inherits/inherits_browser.js
var require_inherits_browser = __commonJS((exports2, module2) => {
  if (typeof Object.create === "function") {
    module2.exports = function inherits(ctor, superCtor) {
      if (superCtor) {
        ctor.super_ = superCtor;
        ctor.prototype = Object.create(superCtor.prototype, {
          constructor: {
            value: ctor,
            enumerable: false,
            writable: true,
            configurable: true
          }
        });
      }
    };
  } else {
    module2.exports = function inherits(ctor, superCtor) {
      if (superCtor) {
        ctor.super_ = superCtor;
        var TempCtor = function() {
        };
        TempCtor.prototype = superCtor.prototype;
        ctor.prototype = new TempCtor();
        ctor.prototype.constructor = ctor;
      }
    };
  }
});

// node_modules/inherits/inherits.js
var require_inherits = __commonJS((exports2, module2) => {
  try {
    util = require("util");
    if (typeof util.inherits !== "function")
      throw "";
    module2.exports = util.inherits;
  } catch (e) {
    module2.exports = require_inherits_browser();
  }
  var util;
});

// node_modules/toidentifier/index.js
var require_toidentifier = __commonJS((exports2, module2) => {
  /*!
   * toidentifier
   * Copyright(c) 2016 Douglas Christopher Wilson
   * MIT Licensed
   */
  module2.exports = toIdentifier;
  function toIdentifier(str) {
    return str.split(" ").map(function(token) {
      return token.slice(0, 1).toUpperCase() + token.slice(1);
    }).join("").replace(/[^ _0-9a-z]/gi, "");
  }
});

// node_modules/http-errors/index.js
var require_http_errors = __commonJS((exports2, module2) => {
  /*!
   * http-errors
   * Copyright(c) 2014 Jonathan Ong
   * Copyright(c) 2016 Douglas Christopher Wilson
   * MIT Licensed
   */
  "use strict";
  var deprecate = require_depd()("http-errors");
  var setPrototypeOf = require_setprototypeof();
  var statuses = require_statuses();
  var inherits = require_inherits();
  var toIdentifier = require_toidentifier();
  module2.exports = createError;
  module2.exports.HttpError = createHttpErrorConstructor();
  module2.exports.isHttpError = createIsHttpErrorFunction(module2.exports.HttpError);
  populateConstructorExports(module2.exports, statuses.codes, module2.exports.HttpError);
  function codeClass(status) {
    return Number(String(status).charAt(0) + "00");
  }
  function createError() {
    var err;
    var msg;
    var status = 500;
    var props = {};
    for (var i = 0; i < arguments.length; i++) {
      var arg = arguments[i];
      if (arg instanceof Error) {
        err = arg;
        status = err.status || err.statusCode || status;
        continue;
      }
      switch (typeof arg) {
        case "string":
          msg = arg;
          break;
        case "number":
          status = arg;
          if (i !== 0) {
            deprecate("non-first-argument status code; replace with createError(" + arg + ", ...)");
          }
          break;
        case "object":
          props = arg;
          break;
      }
    }
    if (typeof status === "number" && (status < 400 || status >= 600)) {
      deprecate("non-error status code; use only 4xx or 5xx status codes");
    }
    if (typeof status !== "number" || !statuses[status] && (status < 400 || status >= 600)) {
      status = 500;
    }
    var HttpError = createError[status] || createError[codeClass(status)];
    if (!err) {
      err = HttpError ? new HttpError(msg) : new Error(msg || statuses[status]);
      Error.captureStackTrace(err, createError);
    }
    if (!HttpError || !(err instanceof HttpError) || err.status !== status) {
      err.expose = status < 500;
      err.status = err.statusCode = status;
    }
    for (var key in props) {
      if (key !== "status" && key !== "statusCode") {
        err[key] = props[key];
      }
    }
    return err;
  }
  function createHttpErrorConstructor() {
    function HttpError() {
      throw new TypeError("cannot construct abstract class");
    }
    inherits(HttpError, Error);
    return HttpError;
  }
  function createClientErrorConstructor(HttpError, name, code) {
    var className = toClassName(name);
    function ClientError(message) {
      var msg = message != null ? message : statuses[code];
      var err = new Error(msg);
      Error.captureStackTrace(err, ClientError);
      setPrototypeOf(err, ClientError.prototype);
      Object.defineProperty(err, "message", {
        enumerable: true,
        configurable: true,
        value: msg,
        writable: true
      });
      Object.defineProperty(err, "name", {
        enumerable: false,
        configurable: true,
        value: className,
        writable: true
      });
      return err;
    }
    inherits(ClientError, HttpError);
    nameFunc(ClientError, className);
    ClientError.prototype.status = code;
    ClientError.prototype.statusCode = code;
    ClientError.prototype.expose = true;
    return ClientError;
  }
  function createIsHttpErrorFunction(HttpError) {
    return function isHttpError(val) {
      if (!val || typeof val !== "object") {
        return false;
      }
      if (val instanceof HttpError) {
        return true;
      }
      return val instanceof Error && typeof val.expose === "boolean" && typeof val.statusCode === "number" && val.status === val.statusCode;
    };
  }
  function createServerErrorConstructor(HttpError, name, code) {
    var className = toClassName(name);
    function ServerError(message) {
      var msg = message != null ? message : statuses[code];
      var err = new Error(msg);
      Error.captureStackTrace(err, ServerError);
      setPrototypeOf(err, ServerError.prototype);
      Object.defineProperty(err, "message", {
        enumerable: true,
        configurable: true,
        value: msg,
        writable: true
      });
      Object.defineProperty(err, "name", {
        enumerable: false,
        configurable: true,
        value: className,
        writable: true
      });
      return err;
    }
    inherits(ServerError, HttpError);
    nameFunc(ServerError, className);
    ServerError.prototype.status = code;
    ServerError.prototype.statusCode = code;
    ServerError.prototype.expose = false;
    return ServerError;
  }
  function nameFunc(func, name) {
    var desc = Object.getOwnPropertyDescriptor(func, "name");
    if (desc && desc.configurable) {
      desc.value = name;
      Object.defineProperty(func, "name", desc);
    }
  }
  function populateConstructorExports(exports3, codes, HttpError) {
    codes.forEach(function forEachCode(code) {
      var CodeError;
      var name = toIdentifier(statuses[code]);
      switch (codeClass(code)) {
        case 400:
          CodeError = createClientErrorConstructor(HttpError, name, code);
          break;
        case 500:
          CodeError = createServerErrorConstructor(HttpError, name, code);
          break;
      }
      if (CodeError) {
        exports3[code] = CodeError;
        exports3[name] = CodeError;
      }
    });
    exports3["I'mateapot"] = deprecate.function(exports3.ImATeapot, `"I'mateapot"; use "ImATeapot" instead`);
  }
  function toClassName(name) {
    return name.substr(-5) !== "Error" ? name + "Error" : name;
  }
});

// node_modules/content-type/index.js
var require_content_type = __commonJS((exports2) => {
  /*!
   * content-type
   * Copyright(c) 2015 Douglas Christopher Wilson
   * MIT Licensed
   */
  "use strict";
  var PARAM_REGEXP = /; *([!#$%&'*+.^_`|~0-9A-Za-z-]+) *= *("(?:[\u000b\u0020\u0021\u0023-\u005b\u005d-\u007e\u0080-\u00ff]|\\[\u000b\u0020-\u00ff])*"|[!#$%&'*+.^_`|~0-9A-Za-z-]+) */g;
  var TEXT_REGEXP = /^[\u000b\u0020-\u007e\u0080-\u00ff]+$/;
  var TOKEN_REGEXP = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;
  var QESC_REGEXP = /\\([\u000b\u0020-\u00ff])/g;
  var QUOTE_REGEXP = /([\\"])/g;
  var TYPE_REGEXP = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+\/[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;
  exports2.format = format;
  exports2.parse = parse;
  function format(obj) {
    if (!obj || typeof obj !== "object") {
      throw new TypeError("argument obj is required");
    }
    var parameters = obj.parameters;
    var type = obj.type;
    if (!type || !TYPE_REGEXP.test(type)) {
      throw new TypeError("invalid type");
    }
    var string = type;
    if (parameters && typeof parameters === "object") {
      var param;
      var params = Object.keys(parameters).sort();
      for (var i = 0; i < params.length; i++) {
        param = params[i];
        if (!TOKEN_REGEXP.test(param)) {
          throw new TypeError("invalid parameter name");
        }
        string += "; " + param + "=" + qstring(parameters[param]);
      }
    }
    return string;
  }
  function parse(string) {
    if (!string) {
      throw new TypeError("argument string is required");
    }
    var header = typeof string === "object" ? getcontenttype(string) : string;
    if (typeof header !== "string") {
      throw new TypeError("argument string is required to be a string");
    }
    var index = header.indexOf(";");
    var type = index !== -1 ? header.substr(0, index).trim() : header.trim();
    if (!TYPE_REGEXP.test(type)) {
      throw new TypeError("invalid media type");
    }
    var obj = new ContentType(type.toLowerCase());
    if (index !== -1) {
      var key;
      var match;
      var value;
      PARAM_REGEXP.lastIndex = index;
      while (match = PARAM_REGEXP.exec(header)) {
        if (match.index !== index) {
          throw new TypeError("invalid parameter format");
        }
        index += match[0].length;
        key = match[1].toLowerCase();
        value = match[2];
        if (value[0] === '"') {
          value = value.substr(1, value.length - 2).replace(QESC_REGEXP, "$1");
        }
        obj.parameters[key] = value;
      }
      if (index !== header.length) {
        throw new TypeError("invalid parameter format");
      }
    }
    return obj;
  }
  function getcontenttype(obj) {
    var header;
    if (typeof obj.getHeader === "function") {
      header = obj.getHeader("content-type");
    } else if (typeof obj.headers === "object") {
      header = obj.headers && obj.headers["content-type"];
    }
    if (typeof header !== "string") {
      throw new TypeError("content-type header is missing from object");
    }
    return header;
  }
  function qstring(val) {
    var str = String(val);
    if (TOKEN_REGEXP.test(str)) {
      return str;
    }
    if (str.length > 0 && !TEXT_REGEXP.test(str)) {
      throw new TypeError("invalid parameter value");
    }
    return '"' + str.replace(QUOTE_REGEXP, "\\$1") + '"';
  }
  function ContentType(type) {
    this.parameters = Object.create(null);
    this.type = type;
  }
});

// node_modules/@middy/http-json-body-parser/index.js
var require_http_json_body_parser = __commonJS((exports2, module2) => {
  var createError = require_http_errors();
  var contentType = require_content_type();
  module2.exports = (opts) => ({
    before: (handler, next) => {
      opts = opts || {};
      if (handler.event.headers) {
        const contentTypeHeader = handler.event.headers["content-type"] || handler.event.headers["Content-Type"];
        if (contentTypeHeader) {
          const {type} = contentType.parse(contentTypeHeader);
          if (type.match(/^application\/(.*\+)?json$/)) {
            try {
              const data = handler.event.isBase64Encoded ? Buffer.from(handler.event.body, "base64").toString() : handler.event.body;
              handler.event.body = JSON.parse(data, opts.reviver);
            } catch (err) {
              throw new createError.UnprocessableEntity("Content type defined as JSON but an invalid JSON was provided");
            }
          }
        }
      }
      next();
    }
  });
});

// node_modules/uri-js/dist/es5/uri.all.js
var require_uri_all = __commonJS((exports2, module2) => {
  /** @license URI.js v4.4.1 (c) 2011 Gary Court. License: http://github.com/garycourt/uri-js */
  (function(global2, factory) {
    typeof exports2 === "object" && typeof module2 !== "undefined" ? factory(exports2) : typeof define === "function" && define.amd ? define(["exports"], factory) : factory(global2.URI = global2.URI || {});
  })(exports2, function(exports3) {
    "use strict";
    function merge() {
      for (var _len = arguments.length, sets = Array(_len), _key = 0; _key < _len; _key++) {
        sets[_key] = arguments[_key];
      }
      if (sets.length > 1) {
        sets[0] = sets[0].slice(0, -1);
        var xl = sets.length - 1;
        for (var x = 1; x < xl; ++x) {
          sets[x] = sets[x].slice(1, -1);
        }
        sets[xl] = sets[xl].slice(1);
        return sets.join("");
      } else {
        return sets[0];
      }
    }
    function subexp(str) {
      return "(?:" + str + ")";
    }
    function typeOf(o) {
      return o === void 0 ? "undefined" : o === null ? "null" : Object.prototype.toString.call(o).split(" ").pop().split("]").shift().toLowerCase();
    }
    function toUpperCase(str) {
      return str.toUpperCase();
    }
    function toArray(obj) {
      return obj !== void 0 && obj !== null ? obj instanceof Array ? obj : typeof obj.length !== "number" || obj.split || obj.setInterval || obj.call ? [obj] : Array.prototype.slice.call(obj) : [];
    }
    function assign(target, source) {
      var obj = target;
      if (source) {
        for (var key in source) {
          obj[key] = source[key];
        }
      }
      return obj;
    }
    function buildExps(isIRI2) {
      var ALPHA$$ = "[A-Za-z]", CR$ = "[\\x0D]", DIGIT$$ = "[0-9]", DQUOTE$$ = "[\\x22]", HEXDIG$$2 = merge(DIGIT$$, "[A-Fa-f]"), LF$$ = "[\\x0A]", SP$$ = "[\\x20]", PCT_ENCODED$2 = subexp(subexp("%[EFef]" + HEXDIG$$2 + "%" + HEXDIG$$2 + HEXDIG$$2 + "%" + HEXDIG$$2 + HEXDIG$$2) + "|" + subexp("%[89A-Fa-f]" + HEXDIG$$2 + "%" + HEXDIG$$2 + HEXDIG$$2) + "|" + subexp("%" + HEXDIG$$2 + HEXDIG$$2)), GEN_DELIMS$$ = "[\\:\\/\\?\\#\\[\\]\\@]", SUB_DELIMS$$ = "[\\!\\$\\&\\'\\(\\)\\*\\+\\,\\;\\=]", RESERVED$$ = merge(GEN_DELIMS$$, SUB_DELIMS$$), UCSCHAR$$ = isIRI2 ? "[\\xA0-\\u200D\\u2010-\\u2029\\u202F-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF]" : "[]", IPRIVATE$$ = isIRI2 ? "[\\uE000-\\uF8FF]" : "[]", UNRESERVED$$2 = merge(ALPHA$$, DIGIT$$, "[\\-\\.\\_\\~]", UCSCHAR$$), SCHEME$ = subexp(ALPHA$$ + merge(ALPHA$$, DIGIT$$, "[\\+\\-\\.]") + "*"), USERINFO$ = subexp(subexp(PCT_ENCODED$2 + "|" + merge(UNRESERVED$$2, SUB_DELIMS$$, "[\\:]")) + "*"), DEC_OCTET$ = subexp(subexp("25[0-5]") + "|" + subexp("2[0-4]" + DIGIT$$) + "|" + subexp("1" + DIGIT$$ + DIGIT$$) + "|" + subexp("[1-9]" + DIGIT$$) + "|" + DIGIT$$), DEC_OCTET_RELAXED$ = subexp(subexp("25[0-5]") + "|" + subexp("2[0-4]" + DIGIT$$) + "|" + subexp("1" + DIGIT$$ + DIGIT$$) + "|" + subexp("0?[1-9]" + DIGIT$$) + "|0?0?" + DIGIT$$), IPV4ADDRESS$ = subexp(DEC_OCTET_RELAXED$ + "\\." + DEC_OCTET_RELAXED$ + "\\." + DEC_OCTET_RELAXED$ + "\\." + DEC_OCTET_RELAXED$), H16$ = subexp(HEXDIG$$2 + "{1,4}"), LS32$ = subexp(subexp(H16$ + "\\:" + H16$) + "|" + IPV4ADDRESS$), IPV6ADDRESS1$ = subexp(subexp(H16$ + "\\:") + "{6}" + LS32$), IPV6ADDRESS2$ = subexp("\\:\\:" + subexp(H16$ + "\\:") + "{5}" + LS32$), IPV6ADDRESS3$ = subexp(subexp(H16$) + "?\\:\\:" + subexp(H16$ + "\\:") + "{4}" + LS32$), IPV6ADDRESS4$ = subexp(subexp(subexp(H16$ + "\\:") + "{0,1}" + H16$) + "?\\:\\:" + subexp(H16$ + "\\:") + "{3}" + LS32$), IPV6ADDRESS5$ = subexp(subexp(subexp(H16$ + "\\:") + "{0,2}" + H16$) + "?\\:\\:" + subexp(H16$ + "\\:") + "{2}" + LS32$), IPV6ADDRESS6$ = subexp(subexp(subexp(H16$ + "\\:") + "{0,3}" + H16$) + "?\\:\\:" + H16$ + "\\:" + LS32$), IPV6ADDRESS7$ = subexp(subexp(subexp(H16$ + "\\:") + "{0,4}" + H16$) + "?\\:\\:" + LS32$), IPV6ADDRESS8$ = subexp(subexp(subexp(H16$ + "\\:") + "{0,5}" + H16$) + "?\\:\\:" + H16$), IPV6ADDRESS9$ = subexp(subexp(subexp(H16$ + "\\:") + "{0,6}" + H16$) + "?\\:\\:"), IPV6ADDRESS$ = subexp([IPV6ADDRESS1$, IPV6ADDRESS2$, IPV6ADDRESS3$, IPV6ADDRESS4$, IPV6ADDRESS5$, IPV6ADDRESS6$, IPV6ADDRESS7$, IPV6ADDRESS8$, IPV6ADDRESS9$].join("|")), ZONEID$ = subexp(subexp(UNRESERVED$$2 + "|" + PCT_ENCODED$2) + "+"), IPV6ADDRZ$ = subexp(IPV6ADDRESS$ + "\\%25" + ZONEID$), IPV6ADDRZ_RELAXED$ = subexp(IPV6ADDRESS$ + subexp("\\%25|\\%(?!" + HEXDIG$$2 + "{2})") + ZONEID$), IPVFUTURE$ = subexp("[vV]" + HEXDIG$$2 + "+\\." + merge(UNRESERVED$$2, SUB_DELIMS$$, "[\\:]") + "+"), IP_LITERAL$ = subexp("\\[" + subexp(IPV6ADDRZ_RELAXED$ + "|" + IPV6ADDRESS$ + "|" + IPVFUTURE$) + "\\]"), REG_NAME$ = subexp(subexp(PCT_ENCODED$2 + "|" + merge(UNRESERVED$$2, SUB_DELIMS$$)) + "*"), HOST$ = subexp(IP_LITERAL$ + "|" + IPV4ADDRESS$ + "(?!" + REG_NAME$ + ")|" + REG_NAME$), PORT$ = subexp(DIGIT$$ + "*"), AUTHORITY$ = subexp(subexp(USERINFO$ + "@") + "?" + HOST$ + subexp("\\:" + PORT$) + "?"), PCHAR$ = subexp(PCT_ENCODED$2 + "|" + merge(UNRESERVED$$2, SUB_DELIMS$$, "[\\:\\@]")), SEGMENT$ = subexp(PCHAR$ + "*"), SEGMENT_NZ$ = subexp(PCHAR$ + "+"), SEGMENT_NZ_NC$ = subexp(subexp(PCT_ENCODED$2 + "|" + merge(UNRESERVED$$2, SUB_DELIMS$$, "[\\@]")) + "+"), PATH_ABEMPTY$ = subexp(subexp("\\/" + SEGMENT$) + "*"), PATH_ABSOLUTE$ = subexp("\\/" + subexp(SEGMENT_NZ$ + PATH_ABEMPTY$) + "?"), PATH_NOSCHEME$ = subexp(SEGMENT_NZ_NC$ + PATH_ABEMPTY$), PATH_ROOTLESS$ = subexp(SEGMENT_NZ$ + PATH_ABEMPTY$), PATH_EMPTY$ = "(?!" + PCHAR$ + ")", PATH$ = subexp(PATH_ABEMPTY$ + "|" + PATH_ABSOLUTE$ + "|" + PATH_NOSCHEME$ + "|" + PATH_ROOTLESS$ + "|" + PATH_EMPTY$), QUERY$ = subexp(subexp(PCHAR$ + "|" + merge("[\\/\\?]", IPRIVATE$$)) + "*"), FRAGMENT$ = subexp(subexp(PCHAR$ + "|[\\/\\?]") + "*"), HIER_PART$ = subexp(subexp("\\/\\/" + AUTHORITY$ + PATH_ABEMPTY$) + "|" + PATH_ABSOLUTE$ + "|" + PATH_ROOTLESS$ + "|" + PATH_EMPTY$), URI$ = subexp(SCHEME$ + "\\:" + HIER_PART$ + subexp("\\?" + QUERY$) + "?" + subexp("\\#" + FRAGMENT$) + "?"), RELATIVE_PART$ = subexp(subexp("\\/\\/" + AUTHORITY$ + PATH_ABEMPTY$) + "|" + PATH_ABSOLUTE$ + "|" + PATH_NOSCHEME$ + "|" + PATH_EMPTY$), RELATIVE$ = subexp(RELATIVE_PART$ + subexp("\\?" + QUERY$) + "?" + subexp("\\#" + FRAGMENT$) + "?"), URI_REFERENCE$ = subexp(URI$ + "|" + RELATIVE$), ABSOLUTE_URI$ = subexp(SCHEME$ + "\\:" + HIER_PART$ + subexp("\\?" + QUERY$) + "?"), GENERIC_REF$ = "^(" + SCHEME$ + ")\\:" + subexp(subexp("\\/\\/(" + subexp("(" + USERINFO$ + ")@") + "?(" + HOST$ + ")" + subexp("\\:(" + PORT$ + ")") + "?)") + "?(" + PATH_ABEMPTY$ + "|" + PATH_ABSOLUTE$ + "|" + PATH_ROOTLESS$ + "|" + PATH_EMPTY$ + ")") + subexp("\\?(" + QUERY$ + ")") + "?" + subexp("\\#(" + FRAGMENT$ + ")") + "?$", RELATIVE_REF$ = "^(){0}" + subexp(subexp("\\/\\/(" + subexp("(" + USERINFO$ + ")@") + "?(" + HOST$ + ")" + subexp("\\:(" + PORT$ + ")") + "?)") + "?(" + PATH_ABEMPTY$ + "|" + PATH_ABSOLUTE$ + "|" + PATH_NOSCHEME$ + "|" + PATH_EMPTY$ + ")") + subexp("\\?(" + QUERY$ + ")") + "?" + subexp("\\#(" + FRAGMENT$ + ")") + "?$", ABSOLUTE_REF$ = "^(" + SCHEME$ + ")\\:" + subexp(subexp("\\/\\/(" + subexp("(" + USERINFO$ + ")@") + "?(" + HOST$ + ")" + subexp("\\:(" + PORT$ + ")") + "?)") + "?(" + PATH_ABEMPTY$ + "|" + PATH_ABSOLUTE$ + "|" + PATH_ROOTLESS$ + "|" + PATH_EMPTY$ + ")") + subexp("\\?(" + QUERY$ + ")") + "?$", SAMEDOC_REF$ = "^" + subexp("\\#(" + FRAGMENT$ + ")") + "?$", AUTHORITY_REF$ = "^" + subexp("(" + USERINFO$ + ")@") + "?(" + HOST$ + ")" + subexp("\\:(" + PORT$ + ")") + "?$";
      return {
        NOT_SCHEME: new RegExp(merge("[^]", ALPHA$$, DIGIT$$, "[\\+\\-\\.]"), "g"),
        NOT_USERINFO: new RegExp(merge("[^\\%\\:]", UNRESERVED$$2, SUB_DELIMS$$), "g"),
        NOT_HOST: new RegExp(merge("[^\\%\\[\\]\\:]", UNRESERVED$$2, SUB_DELIMS$$), "g"),
        NOT_PATH: new RegExp(merge("[^\\%\\/\\:\\@]", UNRESERVED$$2, SUB_DELIMS$$), "g"),
        NOT_PATH_NOSCHEME: new RegExp(merge("[^\\%\\/\\@]", UNRESERVED$$2, SUB_DELIMS$$), "g"),
        NOT_QUERY: new RegExp(merge("[^\\%]", UNRESERVED$$2, SUB_DELIMS$$, "[\\:\\@\\/\\?]", IPRIVATE$$), "g"),
        NOT_FRAGMENT: new RegExp(merge("[^\\%]", UNRESERVED$$2, SUB_DELIMS$$, "[\\:\\@\\/\\?]"), "g"),
        ESCAPE: new RegExp(merge("[^]", UNRESERVED$$2, SUB_DELIMS$$), "g"),
        UNRESERVED: new RegExp(UNRESERVED$$2, "g"),
        OTHER_CHARS: new RegExp(merge("[^\\%]", UNRESERVED$$2, RESERVED$$), "g"),
        PCT_ENCODED: new RegExp(PCT_ENCODED$2, "g"),
        IPV4ADDRESS: new RegExp("^(" + IPV4ADDRESS$ + ")$"),
        IPV6ADDRESS: new RegExp("^\\[?(" + IPV6ADDRESS$ + ")" + subexp(subexp("\\%25|\\%(?!" + HEXDIG$$2 + "{2})") + "(" + ZONEID$ + ")") + "?\\]?$")
      };
    }
    var URI_PROTOCOL = buildExps(false);
    var IRI_PROTOCOL = buildExps(true);
    var slicedToArray = function() {
      function sliceIterator(arr, i) {
        var _arr = [];
        var _n = true;
        var _d = false;
        var _e = void 0;
        try {
          for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
            _arr.push(_s.value);
            if (i && _arr.length === i)
              break;
          }
        } catch (err) {
          _d = true;
          _e = err;
        } finally {
          try {
            if (!_n && _i["return"])
              _i["return"]();
          } finally {
            if (_d)
              throw _e;
          }
        }
        return _arr;
      }
      return function(arr, i) {
        if (Array.isArray(arr)) {
          return arr;
        } else if (Symbol.iterator in Object(arr)) {
          return sliceIterator(arr, i);
        } else {
          throw new TypeError("Invalid attempt to destructure non-iterable instance");
        }
      };
    }();
    var toConsumableArray = function(arr) {
      if (Array.isArray(arr)) {
        for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++)
          arr2[i] = arr[i];
        return arr2;
      } else {
        return Array.from(arr);
      }
    };
    var maxInt = 2147483647;
    var base = 36;
    var tMin = 1;
    var tMax = 26;
    var skew = 38;
    var damp = 700;
    var initialBias = 72;
    var initialN = 128;
    var delimiter = "-";
    var regexPunycode = /^xn--/;
    var regexNonASCII = /[^\0-\x7E]/;
    var regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g;
    var errors = {
      overflow: "Overflow: input needs wider integers to process",
      "not-basic": "Illegal input >= 0x80 (not a basic code point)",
      "invalid-input": "Invalid input"
    };
    var baseMinusTMin = base - tMin;
    var floor = Math.floor;
    var stringFromCharCode = String.fromCharCode;
    function error$1(type) {
      throw new RangeError(errors[type]);
    }
    function map(array, fn) {
      var result = [];
      var length = array.length;
      while (length--) {
        result[length] = fn(array[length]);
      }
      return result;
    }
    function mapDomain(string, fn) {
      var parts = string.split("@");
      var result = "";
      if (parts.length > 1) {
        result = parts[0] + "@";
        string = parts[1];
      }
      string = string.replace(regexSeparators, ".");
      var labels = string.split(".");
      var encoded = map(labels, fn).join(".");
      return result + encoded;
    }
    function ucs2decode(string) {
      var output = [];
      var counter = 0;
      var length = string.length;
      while (counter < length) {
        var value = string.charCodeAt(counter++);
        if (value >= 55296 && value <= 56319 && counter < length) {
          var extra = string.charCodeAt(counter++);
          if ((extra & 64512) == 56320) {
            output.push(((value & 1023) << 10) + (extra & 1023) + 65536);
          } else {
            output.push(value);
            counter--;
          }
        } else {
          output.push(value);
        }
      }
      return output;
    }
    var ucs2encode = function ucs2encode2(array) {
      return String.fromCodePoint.apply(String, toConsumableArray(array));
    };
    var basicToDigit = function basicToDigit2(codePoint) {
      if (codePoint - 48 < 10) {
        return codePoint - 22;
      }
      if (codePoint - 65 < 26) {
        return codePoint - 65;
      }
      if (codePoint - 97 < 26) {
        return codePoint - 97;
      }
      return base;
    };
    var digitToBasic = function digitToBasic2(digit, flag) {
      return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
    };
    var adapt = function adapt2(delta, numPoints, firstTime) {
      var k = 0;
      delta = firstTime ? floor(delta / damp) : delta >> 1;
      delta += floor(delta / numPoints);
      for (; delta > baseMinusTMin * tMax >> 1; k += base) {
        delta = floor(delta / baseMinusTMin);
      }
      return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
    };
    var decode = function decode2(input) {
      var output = [];
      var inputLength = input.length;
      var i = 0;
      var n = initialN;
      var bias = initialBias;
      var basic = input.lastIndexOf(delimiter);
      if (basic < 0) {
        basic = 0;
      }
      for (var j = 0; j < basic; ++j) {
        if (input.charCodeAt(j) >= 128) {
          error$1("not-basic");
        }
        output.push(input.charCodeAt(j));
      }
      for (var index = basic > 0 ? basic + 1 : 0; index < inputLength; ) {
        var oldi = i;
        for (var w = 1, k = base; ; k += base) {
          if (index >= inputLength) {
            error$1("invalid-input");
          }
          var digit = basicToDigit(input.charCodeAt(index++));
          if (digit >= base || digit > floor((maxInt - i) / w)) {
            error$1("overflow");
          }
          i += digit * w;
          var t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
          if (digit < t) {
            break;
          }
          var baseMinusT = base - t;
          if (w > floor(maxInt / baseMinusT)) {
            error$1("overflow");
          }
          w *= baseMinusT;
        }
        var out = output.length + 1;
        bias = adapt(i - oldi, out, oldi == 0);
        if (floor(i / out) > maxInt - n) {
          error$1("overflow");
        }
        n += floor(i / out);
        i %= out;
        output.splice(i++, 0, n);
      }
      return String.fromCodePoint.apply(String, output);
    };
    var encode = function encode2(input) {
      var output = [];
      input = ucs2decode(input);
      var inputLength = input.length;
      var n = initialN;
      var delta = 0;
      var bias = initialBias;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = void 0;
      try {
        for (var _iterator = input[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var _currentValue2 = _step.value;
          if (_currentValue2 < 128) {
            output.push(stringFromCharCode(_currentValue2));
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
      var basicLength = output.length;
      var handledCPCount = basicLength;
      if (basicLength) {
        output.push(delimiter);
      }
      while (handledCPCount < inputLength) {
        var m = maxInt;
        var _iteratorNormalCompletion2 = true;
        var _didIteratorError2 = false;
        var _iteratorError2 = void 0;
        try {
          for (var _iterator2 = input[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
            var currentValue = _step2.value;
            if (currentValue >= n && currentValue < m) {
              m = currentValue;
            }
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion2 && _iterator2.return) {
              _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }
        var handledCPCountPlusOne = handledCPCount + 1;
        if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
          error$1("overflow");
        }
        delta += (m - n) * handledCPCountPlusOne;
        n = m;
        var _iteratorNormalCompletion3 = true;
        var _didIteratorError3 = false;
        var _iteratorError3 = void 0;
        try {
          for (var _iterator3 = input[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
            var _currentValue = _step3.value;
            if (_currentValue < n && ++delta > maxInt) {
              error$1("overflow");
            }
            if (_currentValue == n) {
              var q = delta;
              for (var k = base; ; k += base) {
                var t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
                if (q < t) {
                  break;
                }
                var qMinusT = q - t;
                var baseMinusT = base - t;
                output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0)));
                q = floor(qMinusT / baseMinusT);
              }
              output.push(stringFromCharCode(digitToBasic(q, 0)));
              bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
              delta = 0;
              ++handledCPCount;
            }
          }
        } catch (err) {
          _didIteratorError3 = true;
          _iteratorError3 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion3 && _iterator3.return) {
              _iterator3.return();
            }
          } finally {
            if (_didIteratorError3) {
              throw _iteratorError3;
            }
          }
        }
        ++delta;
        ++n;
      }
      return output.join("");
    };
    var toUnicode = function toUnicode2(input) {
      return mapDomain(input, function(string) {
        return regexPunycode.test(string) ? decode(string.slice(4).toLowerCase()) : string;
      });
    };
    var toASCII = function toASCII2(input) {
      return mapDomain(input, function(string) {
        return regexNonASCII.test(string) ? "xn--" + encode(string) : string;
      });
    };
    var punycode = {
      version: "2.1.0",
      ucs2: {
        decode: ucs2decode,
        encode: ucs2encode
      },
      decode,
      encode,
      toASCII,
      toUnicode
    };
    var SCHEMES = {};
    function pctEncChar(chr) {
      var c = chr.charCodeAt(0);
      var e = void 0;
      if (c < 16)
        e = "%0" + c.toString(16).toUpperCase();
      else if (c < 128)
        e = "%" + c.toString(16).toUpperCase();
      else if (c < 2048)
        e = "%" + (c >> 6 | 192).toString(16).toUpperCase() + "%" + (c & 63 | 128).toString(16).toUpperCase();
      else
        e = "%" + (c >> 12 | 224).toString(16).toUpperCase() + "%" + (c >> 6 & 63 | 128).toString(16).toUpperCase() + "%" + (c & 63 | 128).toString(16).toUpperCase();
      return e;
    }
    function pctDecChars(str) {
      var newStr = "";
      var i = 0;
      var il = str.length;
      while (i < il) {
        var c = parseInt(str.substr(i + 1, 2), 16);
        if (c < 128) {
          newStr += String.fromCharCode(c);
          i += 3;
        } else if (c >= 194 && c < 224) {
          if (il - i >= 6) {
            var c2 = parseInt(str.substr(i + 4, 2), 16);
            newStr += String.fromCharCode((c & 31) << 6 | c2 & 63);
          } else {
            newStr += str.substr(i, 6);
          }
          i += 6;
        } else if (c >= 224) {
          if (il - i >= 9) {
            var _c = parseInt(str.substr(i + 4, 2), 16);
            var c3 = parseInt(str.substr(i + 7, 2), 16);
            newStr += String.fromCharCode((c & 15) << 12 | (_c & 63) << 6 | c3 & 63);
          } else {
            newStr += str.substr(i, 9);
          }
          i += 9;
        } else {
          newStr += str.substr(i, 3);
          i += 3;
        }
      }
      return newStr;
    }
    function _normalizeComponentEncoding(components, protocol) {
      function decodeUnreserved2(str) {
        var decStr = pctDecChars(str);
        return !decStr.match(protocol.UNRESERVED) ? str : decStr;
      }
      if (components.scheme)
        components.scheme = String(components.scheme).replace(protocol.PCT_ENCODED, decodeUnreserved2).toLowerCase().replace(protocol.NOT_SCHEME, "");
      if (components.userinfo !== void 0)
        components.userinfo = String(components.userinfo).replace(protocol.PCT_ENCODED, decodeUnreserved2).replace(protocol.NOT_USERINFO, pctEncChar).replace(protocol.PCT_ENCODED, toUpperCase);
      if (components.host !== void 0)
        components.host = String(components.host).replace(protocol.PCT_ENCODED, decodeUnreserved2).toLowerCase().replace(protocol.NOT_HOST, pctEncChar).replace(protocol.PCT_ENCODED, toUpperCase);
      if (components.path !== void 0)
        components.path = String(components.path).replace(protocol.PCT_ENCODED, decodeUnreserved2).replace(components.scheme ? protocol.NOT_PATH : protocol.NOT_PATH_NOSCHEME, pctEncChar).replace(protocol.PCT_ENCODED, toUpperCase);
      if (components.query !== void 0)
        components.query = String(components.query).replace(protocol.PCT_ENCODED, decodeUnreserved2).replace(protocol.NOT_QUERY, pctEncChar).replace(protocol.PCT_ENCODED, toUpperCase);
      if (components.fragment !== void 0)
        components.fragment = String(components.fragment).replace(protocol.PCT_ENCODED, decodeUnreserved2).replace(protocol.NOT_FRAGMENT, pctEncChar).replace(protocol.PCT_ENCODED, toUpperCase);
      return components;
    }
    function _stripLeadingZeros(str) {
      return str.replace(/^0*(.*)/, "$1") || "0";
    }
    function _normalizeIPv4(host, protocol) {
      var matches = host.match(protocol.IPV4ADDRESS) || [];
      var _matches = slicedToArray(matches, 2), address = _matches[1];
      if (address) {
        return address.split(".").map(_stripLeadingZeros).join(".");
      } else {
        return host;
      }
    }
    function _normalizeIPv6(host, protocol) {
      var matches = host.match(protocol.IPV6ADDRESS) || [];
      var _matches2 = slicedToArray(matches, 3), address = _matches2[1], zone = _matches2[2];
      if (address) {
        var _address$toLowerCase$ = address.toLowerCase().split("::").reverse(), _address$toLowerCase$2 = slicedToArray(_address$toLowerCase$, 2), last = _address$toLowerCase$2[0], first = _address$toLowerCase$2[1];
        var firstFields = first ? first.split(":").map(_stripLeadingZeros) : [];
        var lastFields = last.split(":").map(_stripLeadingZeros);
        var isLastFieldIPv4Address = protocol.IPV4ADDRESS.test(lastFields[lastFields.length - 1]);
        var fieldCount = isLastFieldIPv4Address ? 7 : 8;
        var lastFieldsStart = lastFields.length - fieldCount;
        var fields = Array(fieldCount);
        for (var x = 0; x < fieldCount; ++x) {
          fields[x] = firstFields[x] || lastFields[lastFieldsStart + x] || "";
        }
        if (isLastFieldIPv4Address) {
          fields[fieldCount - 1] = _normalizeIPv4(fields[fieldCount - 1], protocol);
        }
        var allZeroFields = fields.reduce(function(acc, field, index) {
          if (!field || field === "0") {
            var lastLongest = acc[acc.length - 1];
            if (lastLongest && lastLongest.index + lastLongest.length === index) {
              lastLongest.length++;
            } else {
              acc.push({index, length: 1});
            }
          }
          return acc;
        }, []);
        var longestZeroFields = allZeroFields.sort(function(a, b) {
          return b.length - a.length;
        })[0];
        var newHost = void 0;
        if (longestZeroFields && longestZeroFields.length > 1) {
          var newFirst = fields.slice(0, longestZeroFields.index);
          var newLast = fields.slice(longestZeroFields.index + longestZeroFields.length);
          newHost = newFirst.join(":") + "::" + newLast.join(":");
        } else {
          newHost = fields.join(":");
        }
        if (zone) {
          newHost += "%" + zone;
        }
        return newHost;
      } else {
        return host;
      }
    }
    var URI_PARSE = /^(?:([^:\/?#]+):)?(?:\/\/((?:([^\/?#@]*)@)?(\[[^\/?#\]]+\]|[^\/?#:]*)(?:\:(\d*))?))?([^?#]*)(?:\?([^#]*))?(?:#((?:.|\n|\r)*))?/i;
    var NO_MATCH_IS_UNDEFINED = "".match(/(){0}/)[1] === void 0;
    function parse(uriString) {
      var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      var components = {};
      var protocol = options.iri !== false ? IRI_PROTOCOL : URI_PROTOCOL;
      if (options.reference === "suffix")
        uriString = (options.scheme ? options.scheme + ":" : "") + "//" + uriString;
      var matches = uriString.match(URI_PARSE);
      if (matches) {
        if (NO_MATCH_IS_UNDEFINED) {
          components.scheme = matches[1];
          components.userinfo = matches[3];
          components.host = matches[4];
          components.port = parseInt(matches[5], 10);
          components.path = matches[6] || "";
          components.query = matches[7];
          components.fragment = matches[8];
          if (isNaN(components.port)) {
            components.port = matches[5];
          }
        } else {
          components.scheme = matches[1] || void 0;
          components.userinfo = uriString.indexOf("@") !== -1 ? matches[3] : void 0;
          components.host = uriString.indexOf("//") !== -1 ? matches[4] : void 0;
          components.port = parseInt(matches[5], 10);
          components.path = matches[6] || "";
          components.query = uriString.indexOf("?") !== -1 ? matches[7] : void 0;
          components.fragment = uriString.indexOf("#") !== -1 ? matches[8] : void 0;
          if (isNaN(components.port)) {
            components.port = uriString.match(/\/\/(?:.|\n)*\:(?:\/|\?|\#|$)/) ? matches[4] : void 0;
          }
        }
        if (components.host) {
          components.host = _normalizeIPv6(_normalizeIPv4(components.host, protocol), protocol);
        }
        if (components.scheme === void 0 && components.userinfo === void 0 && components.host === void 0 && components.port === void 0 && !components.path && components.query === void 0) {
          components.reference = "same-document";
        } else if (components.scheme === void 0) {
          components.reference = "relative";
        } else if (components.fragment === void 0) {
          components.reference = "absolute";
        } else {
          components.reference = "uri";
        }
        if (options.reference && options.reference !== "suffix" && options.reference !== components.reference) {
          components.error = components.error || "URI is not a " + options.reference + " reference.";
        }
        var schemeHandler = SCHEMES[(options.scheme || components.scheme || "").toLowerCase()];
        if (!options.unicodeSupport && (!schemeHandler || !schemeHandler.unicodeSupport)) {
          if (components.host && (options.domainHost || schemeHandler && schemeHandler.domainHost)) {
            try {
              components.host = punycode.toASCII(components.host.replace(protocol.PCT_ENCODED, pctDecChars).toLowerCase());
            } catch (e) {
              components.error = components.error || "Host's domain name can not be converted to ASCII via punycode: " + e;
            }
          }
          _normalizeComponentEncoding(components, URI_PROTOCOL);
        } else {
          _normalizeComponentEncoding(components, protocol);
        }
        if (schemeHandler && schemeHandler.parse) {
          schemeHandler.parse(components, options);
        }
      } else {
        components.error = components.error || "URI can not be parsed.";
      }
      return components;
    }
    function _recomposeAuthority(components, options) {
      var protocol = options.iri !== false ? IRI_PROTOCOL : URI_PROTOCOL;
      var uriTokens = [];
      if (components.userinfo !== void 0) {
        uriTokens.push(components.userinfo);
        uriTokens.push("@");
      }
      if (components.host !== void 0) {
        uriTokens.push(_normalizeIPv6(_normalizeIPv4(String(components.host), protocol), protocol).replace(protocol.IPV6ADDRESS, function(_, $1, $2) {
          return "[" + $1 + ($2 ? "%25" + $2 : "") + "]";
        }));
      }
      if (typeof components.port === "number" || typeof components.port === "string") {
        uriTokens.push(":");
        uriTokens.push(String(components.port));
      }
      return uriTokens.length ? uriTokens.join("") : void 0;
    }
    var RDS1 = /^\.\.?\//;
    var RDS2 = /^\/\.(\/|$)/;
    var RDS3 = /^\/\.\.(\/|$)/;
    var RDS5 = /^\/?(?:.|\n)*?(?=\/|$)/;
    function removeDotSegments(input) {
      var output = [];
      while (input.length) {
        if (input.match(RDS1)) {
          input = input.replace(RDS1, "");
        } else if (input.match(RDS2)) {
          input = input.replace(RDS2, "/");
        } else if (input.match(RDS3)) {
          input = input.replace(RDS3, "/");
          output.pop();
        } else if (input === "." || input === "..") {
          input = "";
        } else {
          var im = input.match(RDS5);
          if (im) {
            var s = im[0];
            input = input.slice(s.length);
            output.push(s);
          } else {
            throw new Error("Unexpected dot segment condition");
          }
        }
      }
      return output.join("");
    }
    function serialize(components) {
      var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      var protocol = options.iri ? IRI_PROTOCOL : URI_PROTOCOL;
      var uriTokens = [];
      var schemeHandler = SCHEMES[(options.scheme || components.scheme || "").toLowerCase()];
      if (schemeHandler && schemeHandler.serialize)
        schemeHandler.serialize(components, options);
      if (components.host) {
        if (protocol.IPV6ADDRESS.test(components.host)) {
        } else if (options.domainHost || schemeHandler && schemeHandler.domainHost) {
          try {
            components.host = !options.iri ? punycode.toASCII(components.host.replace(protocol.PCT_ENCODED, pctDecChars).toLowerCase()) : punycode.toUnicode(components.host);
          } catch (e) {
            components.error = components.error || "Host's domain name can not be converted to " + (!options.iri ? "ASCII" : "Unicode") + " via punycode: " + e;
          }
        }
      }
      _normalizeComponentEncoding(components, protocol);
      if (options.reference !== "suffix" && components.scheme) {
        uriTokens.push(components.scheme);
        uriTokens.push(":");
      }
      var authority = _recomposeAuthority(components, options);
      if (authority !== void 0) {
        if (options.reference !== "suffix") {
          uriTokens.push("//");
        }
        uriTokens.push(authority);
        if (components.path && components.path.charAt(0) !== "/") {
          uriTokens.push("/");
        }
      }
      if (components.path !== void 0) {
        var s = components.path;
        if (!options.absolutePath && (!schemeHandler || !schemeHandler.absolutePath)) {
          s = removeDotSegments(s);
        }
        if (authority === void 0) {
          s = s.replace(/^\/\//, "/%2F");
        }
        uriTokens.push(s);
      }
      if (components.query !== void 0) {
        uriTokens.push("?");
        uriTokens.push(components.query);
      }
      if (components.fragment !== void 0) {
        uriTokens.push("#");
        uriTokens.push(components.fragment);
      }
      return uriTokens.join("");
    }
    function resolveComponents(base2, relative2) {
      var options = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var skipNormalization = arguments[3];
      var target = {};
      if (!skipNormalization) {
        base2 = parse(serialize(base2, options), options);
        relative2 = parse(serialize(relative2, options), options);
      }
      options = options || {};
      if (!options.tolerant && relative2.scheme) {
        target.scheme = relative2.scheme;
        target.userinfo = relative2.userinfo;
        target.host = relative2.host;
        target.port = relative2.port;
        target.path = removeDotSegments(relative2.path || "");
        target.query = relative2.query;
      } else {
        if (relative2.userinfo !== void 0 || relative2.host !== void 0 || relative2.port !== void 0) {
          target.userinfo = relative2.userinfo;
          target.host = relative2.host;
          target.port = relative2.port;
          target.path = removeDotSegments(relative2.path || "");
          target.query = relative2.query;
        } else {
          if (!relative2.path) {
            target.path = base2.path;
            if (relative2.query !== void 0) {
              target.query = relative2.query;
            } else {
              target.query = base2.query;
            }
          } else {
            if (relative2.path.charAt(0) === "/") {
              target.path = removeDotSegments(relative2.path);
            } else {
              if ((base2.userinfo !== void 0 || base2.host !== void 0 || base2.port !== void 0) && !base2.path) {
                target.path = "/" + relative2.path;
              } else if (!base2.path) {
                target.path = relative2.path;
              } else {
                target.path = base2.path.slice(0, base2.path.lastIndexOf("/") + 1) + relative2.path;
              }
              target.path = removeDotSegments(target.path);
            }
            target.query = relative2.query;
          }
          target.userinfo = base2.userinfo;
          target.host = base2.host;
          target.port = base2.port;
        }
        target.scheme = base2.scheme;
      }
      target.fragment = relative2.fragment;
      return target;
    }
    function resolve(baseURI, relativeURI, options) {
      var schemelessOptions = assign({scheme: "null"}, options);
      return serialize(resolveComponents(parse(baseURI, schemelessOptions), parse(relativeURI, schemelessOptions), schemelessOptions, true), schemelessOptions);
    }
    function normalize(uri, options) {
      if (typeof uri === "string") {
        uri = serialize(parse(uri, options), options);
      } else if (typeOf(uri) === "object") {
        uri = parse(serialize(uri, options), options);
      }
      return uri;
    }
    function equal(uriA, uriB, options) {
      if (typeof uriA === "string") {
        uriA = serialize(parse(uriA, options), options);
      } else if (typeOf(uriA) === "object") {
        uriA = serialize(uriA, options);
      }
      if (typeof uriB === "string") {
        uriB = serialize(parse(uriB, options), options);
      } else if (typeOf(uriB) === "object") {
        uriB = serialize(uriB, options);
      }
      return uriA === uriB;
    }
    function escapeComponent(str, options) {
      return str && str.toString().replace(!options || !options.iri ? URI_PROTOCOL.ESCAPE : IRI_PROTOCOL.ESCAPE, pctEncChar);
    }
    function unescapeComponent(str, options) {
      return str && str.toString().replace(!options || !options.iri ? URI_PROTOCOL.PCT_ENCODED : IRI_PROTOCOL.PCT_ENCODED, pctDecChars);
    }
    var handler = {
      scheme: "http",
      domainHost: true,
      parse: function parse2(components, options) {
        if (!components.host) {
          components.error = components.error || "HTTP URIs must have a host.";
        }
        return components;
      },
      serialize: function serialize2(components, options) {
        var secure = String(components.scheme).toLowerCase() === "https";
        if (components.port === (secure ? 443 : 80) || components.port === "") {
          components.port = void 0;
        }
        if (!components.path) {
          components.path = "/";
        }
        return components;
      }
    };
    var handler$1 = {
      scheme: "https",
      domainHost: handler.domainHost,
      parse: handler.parse,
      serialize: handler.serialize
    };
    function isSecure(wsComponents) {
      return typeof wsComponents.secure === "boolean" ? wsComponents.secure : String(wsComponents.scheme).toLowerCase() === "wss";
    }
    var handler$2 = {
      scheme: "ws",
      domainHost: true,
      parse: function parse2(components, options) {
        var wsComponents = components;
        wsComponents.secure = isSecure(wsComponents);
        wsComponents.resourceName = (wsComponents.path || "/") + (wsComponents.query ? "?" + wsComponents.query : "");
        wsComponents.path = void 0;
        wsComponents.query = void 0;
        return wsComponents;
      },
      serialize: function serialize2(wsComponents, options) {
        if (wsComponents.port === (isSecure(wsComponents) ? 443 : 80) || wsComponents.port === "") {
          wsComponents.port = void 0;
        }
        if (typeof wsComponents.secure === "boolean") {
          wsComponents.scheme = wsComponents.secure ? "wss" : "ws";
          wsComponents.secure = void 0;
        }
        if (wsComponents.resourceName) {
          var _wsComponents$resourc = wsComponents.resourceName.split("?"), _wsComponents$resourc2 = slicedToArray(_wsComponents$resourc, 2), path = _wsComponents$resourc2[0], query = _wsComponents$resourc2[1];
          wsComponents.path = path && path !== "/" ? path : void 0;
          wsComponents.query = query;
          wsComponents.resourceName = void 0;
        }
        wsComponents.fragment = void 0;
        return wsComponents;
      }
    };
    var handler$3 = {
      scheme: "wss",
      domainHost: handler$2.domainHost,
      parse: handler$2.parse,
      serialize: handler$2.serialize
    };
    var O = {};
    var isIRI = true;
    var UNRESERVED$$ = "[A-Za-z0-9\\-\\.\\_\\~" + (isIRI ? "\\xA0-\\u200D\\u2010-\\u2029\\u202F-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF" : "") + "]";
    var HEXDIG$$ = "[0-9A-Fa-f]";
    var PCT_ENCODED$ = subexp(subexp("%[EFef]" + HEXDIG$$ + "%" + HEXDIG$$ + HEXDIG$$ + "%" + HEXDIG$$ + HEXDIG$$) + "|" + subexp("%[89A-Fa-f]" + HEXDIG$$ + "%" + HEXDIG$$ + HEXDIG$$) + "|" + subexp("%" + HEXDIG$$ + HEXDIG$$));
    var ATEXT$$ = "[A-Za-z0-9\\!\\$\\%\\'\\*\\+\\-\\^\\_\\`\\{\\|\\}\\~]";
    var QTEXT$$ = "[\\!\\$\\%\\'\\(\\)\\*\\+\\,\\-\\.0-9\\<\\>A-Z\\x5E-\\x7E]";
    var VCHAR$$ = merge(QTEXT$$, '[\\"\\\\]');
    var SOME_DELIMS$$ = "[\\!\\$\\'\\(\\)\\*\\+\\,\\;\\:\\@]";
    var UNRESERVED = new RegExp(UNRESERVED$$, "g");
    var PCT_ENCODED = new RegExp(PCT_ENCODED$, "g");
    var NOT_LOCAL_PART = new RegExp(merge("[^]", ATEXT$$, "[\\.]", '[\\"]', VCHAR$$), "g");
    var NOT_HFNAME = new RegExp(merge("[^]", UNRESERVED$$, SOME_DELIMS$$), "g");
    var NOT_HFVALUE = NOT_HFNAME;
    function decodeUnreserved(str) {
      var decStr = pctDecChars(str);
      return !decStr.match(UNRESERVED) ? str : decStr;
    }
    var handler$4 = {
      scheme: "mailto",
      parse: function parse$$1(components, options) {
        var mailtoComponents = components;
        var to = mailtoComponents.to = mailtoComponents.path ? mailtoComponents.path.split(",") : [];
        mailtoComponents.path = void 0;
        if (mailtoComponents.query) {
          var unknownHeaders = false;
          var headers = {};
          var hfields = mailtoComponents.query.split("&");
          for (var x = 0, xl = hfields.length; x < xl; ++x) {
            var hfield = hfields[x].split("=");
            switch (hfield[0]) {
              case "to":
                var toAddrs = hfield[1].split(",");
                for (var _x = 0, _xl = toAddrs.length; _x < _xl; ++_x) {
                  to.push(toAddrs[_x]);
                }
                break;
              case "subject":
                mailtoComponents.subject = unescapeComponent(hfield[1], options);
                break;
              case "body":
                mailtoComponents.body = unescapeComponent(hfield[1], options);
                break;
              default:
                unknownHeaders = true;
                headers[unescapeComponent(hfield[0], options)] = unescapeComponent(hfield[1], options);
                break;
            }
          }
          if (unknownHeaders)
            mailtoComponents.headers = headers;
        }
        mailtoComponents.query = void 0;
        for (var _x2 = 0, _xl2 = to.length; _x2 < _xl2; ++_x2) {
          var addr = to[_x2].split("@");
          addr[0] = unescapeComponent(addr[0]);
          if (!options.unicodeSupport) {
            try {
              addr[1] = punycode.toASCII(unescapeComponent(addr[1], options).toLowerCase());
            } catch (e) {
              mailtoComponents.error = mailtoComponents.error || "Email address's domain name can not be converted to ASCII via punycode: " + e;
            }
          } else {
            addr[1] = unescapeComponent(addr[1], options).toLowerCase();
          }
          to[_x2] = addr.join("@");
        }
        return mailtoComponents;
      },
      serialize: function serialize$$1(mailtoComponents, options) {
        var components = mailtoComponents;
        var to = toArray(mailtoComponents.to);
        if (to) {
          for (var x = 0, xl = to.length; x < xl; ++x) {
            var toAddr = String(to[x]);
            var atIdx = toAddr.lastIndexOf("@");
            var localPart = toAddr.slice(0, atIdx).replace(PCT_ENCODED, decodeUnreserved).replace(PCT_ENCODED, toUpperCase).replace(NOT_LOCAL_PART, pctEncChar);
            var domain = toAddr.slice(atIdx + 1);
            try {
              domain = !options.iri ? punycode.toASCII(unescapeComponent(domain, options).toLowerCase()) : punycode.toUnicode(domain);
            } catch (e) {
              components.error = components.error || "Email address's domain name can not be converted to " + (!options.iri ? "ASCII" : "Unicode") + " via punycode: " + e;
            }
            to[x] = localPart + "@" + domain;
          }
          components.path = to.join(",");
        }
        var headers = mailtoComponents.headers = mailtoComponents.headers || {};
        if (mailtoComponents.subject)
          headers["subject"] = mailtoComponents.subject;
        if (mailtoComponents.body)
          headers["body"] = mailtoComponents.body;
        var fields = [];
        for (var name in headers) {
          if (headers[name] !== O[name]) {
            fields.push(name.replace(PCT_ENCODED, decodeUnreserved).replace(PCT_ENCODED, toUpperCase).replace(NOT_HFNAME, pctEncChar) + "=" + headers[name].replace(PCT_ENCODED, decodeUnreserved).replace(PCT_ENCODED, toUpperCase).replace(NOT_HFVALUE, pctEncChar));
          }
        }
        if (fields.length) {
          components.query = fields.join("&");
        }
        return components;
      }
    };
    var URN_PARSE = /^([^\:]+)\:(.*)/;
    var handler$5 = {
      scheme: "urn",
      parse: function parse$$1(components, options) {
        var matches = components.path && components.path.match(URN_PARSE);
        var urnComponents = components;
        if (matches) {
          var scheme = options.scheme || urnComponents.scheme || "urn";
          var nid = matches[1].toLowerCase();
          var nss = matches[2];
          var urnScheme = scheme + ":" + (options.nid || nid);
          var schemeHandler = SCHEMES[urnScheme];
          urnComponents.nid = nid;
          urnComponents.nss = nss;
          urnComponents.path = void 0;
          if (schemeHandler) {
            urnComponents = schemeHandler.parse(urnComponents, options);
          }
        } else {
          urnComponents.error = urnComponents.error || "URN can not be parsed.";
        }
        return urnComponents;
      },
      serialize: function serialize$$1(urnComponents, options) {
        var scheme = options.scheme || urnComponents.scheme || "urn";
        var nid = urnComponents.nid;
        var urnScheme = scheme + ":" + (options.nid || nid);
        var schemeHandler = SCHEMES[urnScheme];
        if (schemeHandler) {
          urnComponents = schemeHandler.serialize(urnComponents, options);
        }
        var uriComponents = urnComponents;
        var nss = urnComponents.nss;
        uriComponents.path = (nid || options.nid) + ":" + nss;
        return uriComponents;
      }
    };
    var UUID = /^[0-9A-Fa-f]{8}(?:\-[0-9A-Fa-f]{4}){3}\-[0-9A-Fa-f]{12}$/;
    var handler$6 = {
      scheme: "urn:uuid",
      parse: function parse2(urnComponents, options) {
        var uuidComponents = urnComponents;
        uuidComponents.uuid = uuidComponents.nss;
        uuidComponents.nss = void 0;
        if (!options.tolerant && (!uuidComponents.uuid || !uuidComponents.uuid.match(UUID))) {
          uuidComponents.error = uuidComponents.error || "UUID is not valid.";
        }
        return uuidComponents;
      },
      serialize: function serialize2(uuidComponents, options) {
        var urnComponents = uuidComponents;
        urnComponents.nss = (uuidComponents.uuid || "").toLowerCase();
        return urnComponents;
      }
    };
    SCHEMES[handler.scheme] = handler;
    SCHEMES[handler$1.scheme] = handler$1;
    SCHEMES[handler$2.scheme] = handler$2;
    SCHEMES[handler$3.scheme] = handler$3;
    SCHEMES[handler$4.scheme] = handler$4;
    SCHEMES[handler$5.scheme] = handler$5;
    SCHEMES[handler$6.scheme] = handler$6;
    exports3.SCHEMES = SCHEMES;
    exports3.pctEncChar = pctEncChar;
    exports3.pctDecChars = pctDecChars;
    exports3.parse = parse;
    exports3.removeDotSegments = removeDotSegments;
    exports3.serialize = serialize;
    exports3.resolveComponents = resolveComponents;
    exports3.resolve = resolve;
    exports3.normalize = normalize;
    exports3.equal = equal;
    exports3.escapeComponent = escapeComponent;
    exports3.unescapeComponent = unescapeComponent;
    Object.defineProperty(exports3, "__esModule", {value: true});
  });
});

// node_modules/fast-deep-equal/index.js
var require_fast_deep_equal = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function equal(a, b) {
    if (a === b)
      return true;
    if (a && b && typeof a == "object" && typeof b == "object") {
      if (a.constructor !== b.constructor)
        return false;
      var length, i, keys;
      if (Array.isArray(a)) {
        length = a.length;
        if (length != b.length)
          return false;
        for (i = length; i-- !== 0; )
          if (!equal(a[i], b[i]))
            return false;
        return true;
      }
      if (a.constructor === RegExp)
        return a.source === b.source && a.flags === b.flags;
      if (a.valueOf !== Object.prototype.valueOf)
        return a.valueOf() === b.valueOf();
      if (a.toString !== Object.prototype.toString)
        return a.toString() === b.toString();
      keys = Object.keys(a);
      length = keys.length;
      if (length !== Object.keys(b).length)
        return false;
      for (i = length; i-- !== 0; )
        if (!Object.prototype.hasOwnProperty.call(b, keys[i]))
          return false;
      for (i = length; i-- !== 0; ) {
        var key = keys[i];
        if (!equal(a[key], b[key]))
          return false;
      }
      return true;
    }
    return a !== a && b !== b;
  };
});

// node_modules/ajv/lib/compile/ucs2length.js
var require_ucs2length = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function ucs2length(str) {
    var length = 0, len = str.length, pos = 0, value;
    while (pos < len) {
      length++;
      value = str.charCodeAt(pos++);
      if (value >= 55296 && value <= 56319 && pos < len) {
        value = str.charCodeAt(pos);
        if ((value & 64512) == 56320)
          pos++;
      }
    }
    return length;
  };
});

// node_modules/ajv/lib/compile/util.js
var require_util = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = {
    copy,
    checkDataType,
    checkDataTypes,
    coerceToTypes,
    toHash,
    getProperty,
    escapeQuotes,
    equal: require_fast_deep_equal(),
    ucs2length: require_ucs2length(),
    varOccurences,
    varReplace,
    schemaHasRules,
    schemaHasRulesExcept,
    schemaUnknownRules,
    toQuotedString,
    getPathExpr,
    getPath,
    getData,
    unescapeFragment,
    unescapeJsonPointer,
    escapeFragment,
    escapeJsonPointer
  };
  function copy(o, to) {
    to = to || {};
    for (var key in o)
      to[key] = o[key];
    return to;
  }
  function checkDataType(dataType, data, strictNumbers, negate) {
    var EQUAL = negate ? " !== " : " === ", AND = negate ? " || " : " && ", OK = negate ? "!" : "", NOT = negate ? "" : "!";
    switch (dataType) {
      case "null":
        return data + EQUAL + "null";
      case "array":
        return OK + "Array.isArray(" + data + ")";
      case "object":
        return "(" + OK + data + AND + "typeof " + data + EQUAL + '"object"' + AND + NOT + "Array.isArray(" + data + "))";
      case "integer":
        return "(typeof " + data + EQUAL + '"number"' + AND + NOT + "(" + data + " % 1)" + AND + data + EQUAL + data + (strictNumbers ? AND + OK + "isFinite(" + data + ")" : "") + ")";
      case "number":
        return "(typeof " + data + EQUAL + '"' + dataType + '"' + (strictNumbers ? AND + OK + "isFinite(" + data + ")" : "") + ")";
      default:
        return "typeof " + data + EQUAL + '"' + dataType + '"';
    }
  }
  function checkDataTypes(dataTypes, data, strictNumbers) {
    switch (dataTypes.length) {
      case 1:
        return checkDataType(dataTypes[0], data, strictNumbers, true);
      default:
        var code = "";
        var types = toHash(dataTypes);
        if (types.array && types.object) {
          code = types.null ? "(" : "(!" + data + " || ";
          code += "typeof " + data + ' !== "object")';
          delete types.null;
          delete types.array;
          delete types.object;
        }
        if (types.number)
          delete types.integer;
        for (var t in types)
          code += (code ? " && " : "") + checkDataType(t, data, strictNumbers, true);
        return code;
    }
  }
  var COERCE_TO_TYPES = toHash(["string", "number", "integer", "boolean", "null"]);
  function coerceToTypes(optionCoerceTypes, dataTypes) {
    if (Array.isArray(dataTypes)) {
      var types = [];
      for (var i = 0; i < dataTypes.length; i++) {
        var t = dataTypes[i];
        if (COERCE_TO_TYPES[t])
          types[types.length] = t;
        else if (optionCoerceTypes === "array" && t === "array")
          types[types.length] = t;
      }
      if (types.length)
        return types;
    } else if (COERCE_TO_TYPES[dataTypes]) {
      return [dataTypes];
    } else if (optionCoerceTypes === "array" && dataTypes === "array") {
      return ["array"];
    }
  }
  function toHash(arr) {
    var hash = {};
    for (var i = 0; i < arr.length; i++)
      hash[arr[i]] = true;
    return hash;
  }
  var IDENTIFIER = /^[a-z$_][a-z$_0-9]*$/i;
  var SINGLE_QUOTE = /'|\\/g;
  function getProperty(key) {
    return typeof key == "number" ? "[" + key + "]" : IDENTIFIER.test(key) ? "." + key : "['" + escapeQuotes(key) + "']";
  }
  function escapeQuotes(str) {
    return str.replace(SINGLE_QUOTE, "\\$&").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\f/g, "\\f").replace(/\t/g, "\\t");
  }
  function varOccurences(str, dataVar) {
    dataVar += "[^0-9]";
    var matches = str.match(new RegExp(dataVar, "g"));
    return matches ? matches.length : 0;
  }
  function varReplace(str, dataVar, expr) {
    dataVar += "([^0-9])";
    expr = expr.replace(/\$/g, "$$$$");
    return str.replace(new RegExp(dataVar, "g"), expr + "$1");
  }
  function schemaHasRules(schema, rules) {
    if (typeof schema == "boolean")
      return !schema;
    for (var key in schema)
      if (rules[key])
        return true;
  }
  function schemaHasRulesExcept(schema, rules, exceptKeyword) {
    if (typeof schema == "boolean")
      return !schema && exceptKeyword != "not";
    for (var key in schema)
      if (key != exceptKeyword && rules[key])
        return true;
  }
  function schemaUnknownRules(schema, rules) {
    if (typeof schema == "boolean")
      return;
    for (var key in schema)
      if (!rules[key])
        return key;
  }
  function toQuotedString(str) {
    return "'" + escapeQuotes(str) + "'";
  }
  function getPathExpr(currentPath, expr, jsonPointers, isNumber) {
    var path = jsonPointers ? "'/' + " + expr + (isNumber ? "" : ".replace(/~/g, '~0').replace(/\\//g, '~1')") : isNumber ? "'[' + " + expr + " + ']'" : "'[\\'' + " + expr + " + '\\']'";
    return joinPaths(currentPath, path);
  }
  function getPath(currentPath, prop, jsonPointers) {
    var path = jsonPointers ? toQuotedString("/" + escapeJsonPointer(prop)) : toQuotedString(getProperty(prop));
    return joinPaths(currentPath, path);
  }
  var JSON_POINTER = /^\/(?:[^~]|~0|~1)*$/;
  var RELATIVE_JSON_POINTER = /^([0-9]+)(#|\/(?:[^~]|~0|~1)*)?$/;
  function getData($data, lvl, paths) {
    var up, jsonPointer, data, matches;
    if ($data === "")
      return "rootData";
    if ($data[0] == "/") {
      if (!JSON_POINTER.test($data))
        throw new Error("Invalid JSON-pointer: " + $data);
      jsonPointer = $data;
      data = "rootData";
    } else {
      matches = $data.match(RELATIVE_JSON_POINTER);
      if (!matches)
        throw new Error("Invalid JSON-pointer: " + $data);
      up = +matches[1];
      jsonPointer = matches[2];
      if (jsonPointer == "#") {
        if (up >= lvl)
          throw new Error("Cannot access property/index " + up + " levels up, current level is " + lvl);
        return paths[lvl - up];
      }
      if (up > lvl)
        throw new Error("Cannot access data " + up + " levels up, current level is " + lvl);
      data = "data" + (lvl - up || "");
      if (!jsonPointer)
        return data;
    }
    var expr = data;
    var segments = jsonPointer.split("/");
    for (var i = 0; i < segments.length; i++) {
      var segment = segments[i];
      if (segment) {
        data += getProperty(unescapeJsonPointer(segment));
        expr += " && " + data;
      }
    }
    return expr;
  }
  function joinPaths(a, b) {
    if (a == '""')
      return b;
    return (a + " + " + b).replace(/([^\\])' \+ '/g, "$1");
  }
  function unescapeFragment(str) {
    return unescapeJsonPointer(decodeURIComponent(str));
  }
  function escapeFragment(str) {
    return encodeURIComponent(escapeJsonPointer(str));
  }
  function escapeJsonPointer(str) {
    return str.replace(/~/g, "~0").replace(/\//g, "~1");
  }
  function unescapeJsonPointer(str) {
    return str.replace(/~1/g, "/").replace(/~0/g, "~");
  }
});

// node_modules/ajv/lib/compile/schema_obj.js
var require_schema_obj = __commonJS((exports2, module2) => {
  "use strict";
  var util = require_util();
  module2.exports = SchemaObject;
  function SchemaObject(obj) {
    util.copy(obj, this);
  }
});

// node_modules/json-schema-traverse/index.js
var require_json_schema_traverse = __commonJS((exports2, module2) => {
  "use strict";
  var traverse = module2.exports = function(schema, opts, cb) {
    if (typeof opts == "function") {
      cb = opts;
      opts = {};
    }
    cb = opts.cb || cb;
    var pre = typeof cb == "function" ? cb : cb.pre || function() {
    };
    var post = cb.post || function() {
    };
    _traverse(opts, pre, post, schema, "", schema);
  };
  traverse.keywords = {
    additionalItems: true,
    items: true,
    contains: true,
    additionalProperties: true,
    propertyNames: true,
    not: true
  };
  traverse.arrayKeywords = {
    items: true,
    allOf: true,
    anyOf: true,
    oneOf: true
  };
  traverse.propsKeywords = {
    definitions: true,
    properties: true,
    patternProperties: true,
    dependencies: true
  };
  traverse.skipKeywords = {
    default: true,
    enum: true,
    const: true,
    required: true,
    maximum: true,
    minimum: true,
    exclusiveMaximum: true,
    exclusiveMinimum: true,
    multipleOf: true,
    maxLength: true,
    minLength: true,
    pattern: true,
    format: true,
    maxItems: true,
    minItems: true,
    uniqueItems: true,
    maxProperties: true,
    minProperties: true
  };
  function _traverse(opts, pre, post, schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex) {
    if (schema && typeof schema == "object" && !Array.isArray(schema)) {
      pre(schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex);
      for (var key in schema) {
        var sch = schema[key];
        if (Array.isArray(sch)) {
          if (key in traverse.arrayKeywords) {
            for (var i = 0; i < sch.length; i++)
              _traverse(opts, pre, post, sch[i], jsonPtr + "/" + key + "/" + i, rootSchema, jsonPtr, key, schema, i);
          }
        } else if (key in traverse.propsKeywords) {
          if (sch && typeof sch == "object") {
            for (var prop in sch)
              _traverse(opts, pre, post, sch[prop], jsonPtr + "/" + key + "/" + escapeJsonPtr(prop), rootSchema, jsonPtr, key, schema, prop);
          }
        } else if (key in traverse.keywords || opts.allKeys && !(key in traverse.skipKeywords)) {
          _traverse(opts, pre, post, sch, jsonPtr + "/" + key, rootSchema, jsonPtr, key, schema);
        }
      }
      post(schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex);
    }
  }
  function escapeJsonPtr(str) {
    return str.replace(/~/g, "~0").replace(/\//g, "~1");
  }
});

// node_modules/ajv/lib/compile/resolve.js
var require_resolve = __commonJS((exports2, module2) => {
  "use strict";
  var URI = require_uri_all();
  var equal = require_fast_deep_equal();
  var util = require_util();
  var SchemaObject = require_schema_obj();
  var traverse = require_json_schema_traverse();
  module2.exports = resolve;
  resolve.normalizeId = normalizeId;
  resolve.fullPath = getFullPath;
  resolve.url = resolveUrl;
  resolve.ids = resolveIds;
  resolve.inlineRef = inlineRef;
  resolve.schema = resolveSchema;
  function resolve(compile, root, ref) {
    var refVal = this._refs[ref];
    if (typeof refVal == "string") {
      if (this._refs[refVal])
        refVal = this._refs[refVal];
      else
        return resolve.call(this, compile, root, refVal);
    }
    refVal = refVal || this._schemas[ref];
    if (refVal instanceof SchemaObject) {
      return inlineRef(refVal.schema, this._opts.inlineRefs) ? refVal.schema : refVal.validate || this._compile(refVal);
    }
    var res = resolveSchema.call(this, root, ref);
    var schema, v, baseId;
    if (res) {
      schema = res.schema;
      root = res.root;
      baseId = res.baseId;
    }
    if (schema instanceof SchemaObject) {
      v = schema.validate || compile.call(this, schema.schema, root, void 0, baseId);
    } else if (schema !== void 0) {
      v = inlineRef(schema, this._opts.inlineRefs) ? schema : compile.call(this, schema, root, void 0, baseId);
    }
    return v;
  }
  function resolveSchema(root, ref) {
    var p = URI.parse(ref), refPath = _getFullPath(p), baseId = getFullPath(this._getId(root.schema));
    if (Object.keys(root.schema).length === 0 || refPath !== baseId) {
      var id = normalizeId(refPath);
      var refVal = this._refs[id];
      if (typeof refVal == "string") {
        return resolveRecursive.call(this, root, refVal, p);
      } else if (refVal instanceof SchemaObject) {
        if (!refVal.validate)
          this._compile(refVal);
        root = refVal;
      } else {
        refVal = this._schemas[id];
        if (refVal instanceof SchemaObject) {
          if (!refVal.validate)
            this._compile(refVal);
          if (id == normalizeId(ref))
            return {schema: refVal, root, baseId};
          root = refVal;
        } else {
          return;
        }
      }
      if (!root.schema)
        return;
      baseId = getFullPath(this._getId(root.schema));
    }
    return getJsonPointer.call(this, p, baseId, root.schema, root);
  }
  function resolveRecursive(root, ref, parsedRef) {
    var res = resolveSchema.call(this, root, ref);
    if (res) {
      var schema = res.schema;
      var baseId = res.baseId;
      root = res.root;
      var id = this._getId(schema);
      if (id)
        baseId = resolveUrl(baseId, id);
      return getJsonPointer.call(this, parsedRef, baseId, schema, root);
    }
  }
  var PREVENT_SCOPE_CHANGE = util.toHash(["properties", "patternProperties", "enum", "dependencies", "definitions"]);
  function getJsonPointer(parsedRef, baseId, schema, root) {
    parsedRef.fragment = parsedRef.fragment || "";
    if (parsedRef.fragment.slice(0, 1) != "/")
      return;
    var parts = parsedRef.fragment.split("/");
    for (var i = 1; i < parts.length; i++) {
      var part = parts[i];
      if (part) {
        part = util.unescapeFragment(part);
        schema = schema[part];
        if (schema === void 0)
          break;
        var id;
        if (!PREVENT_SCOPE_CHANGE[part]) {
          id = this._getId(schema);
          if (id)
            baseId = resolveUrl(baseId, id);
          if (schema.$ref) {
            var $ref = resolveUrl(baseId, schema.$ref);
            var res = resolveSchema.call(this, root, $ref);
            if (res) {
              schema = res.schema;
              root = res.root;
              baseId = res.baseId;
            }
          }
        }
      }
    }
    if (schema !== void 0 && schema !== root.schema)
      return {schema, root, baseId};
  }
  var SIMPLE_INLINED = util.toHash([
    "type",
    "format",
    "pattern",
    "maxLength",
    "minLength",
    "maxProperties",
    "minProperties",
    "maxItems",
    "minItems",
    "maximum",
    "minimum",
    "uniqueItems",
    "multipleOf",
    "required",
    "enum"
  ]);
  function inlineRef(schema, limit) {
    if (limit === false)
      return false;
    if (limit === void 0 || limit === true)
      return checkNoRef(schema);
    else if (limit)
      return countKeys(schema) <= limit;
  }
  function checkNoRef(schema) {
    var item;
    if (Array.isArray(schema)) {
      for (var i = 0; i < schema.length; i++) {
        item = schema[i];
        if (typeof item == "object" && !checkNoRef(item))
          return false;
      }
    } else {
      for (var key in schema) {
        if (key == "$ref")
          return false;
        item = schema[key];
        if (typeof item == "object" && !checkNoRef(item))
          return false;
      }
    }
    return true;
  }
  function countKeys(schema) {
    var count = 0, item;
    if (Array.isArray(schema)) {
      for (var i = 0; i < schema.length; i++) {
        item = schema[i];
        if (typeof item == "object")
          count += countKeys(item);
        if (count == Infinity)
          return Infinity;
      }
    } else {
      for (var key in schema) {
        if (key == "$ref")
          return Infinity;
        if (SIMPLE_INLINED[key]) {
          count++;
        } else {
          item = schema[key];
          if (typeof item == "object")
            count += countKeys(item) + 1;
          if (count == Infinity)
            return Infinity;
        }
      }
    }
    return count;
  }
  function getFullPath(id, normalize) {
    if (normalize !== false)
      id = normalizeId(id);
    var p = URI.parse(id);
    return _getFullPath(p);
  }
  function _getFullPath(p) {
    return URI.serialize(p).split("#")[0] + "#";
  }
  var TRAILING_SLASH_HASH = /#\/?$/;
  function normalizeId(id) {
    return id ? id.replace(TRAILING_SLASH_HASH, "") : "";
  }
  function resolveUrl(baseId, id) {
    id = normalizeId(id);
    return URI.resolve(baseId, id);
  }
  function resolveIds(schema) {
    var schemaId = normalizeId(this._getId(schema));
    var baseIds = {"": schemaId};
    var fullPaths = {"": getFullPath(schemaId, false)};
    var localRefs = {};
    var self2 = this;
    traverse(schema, {allKeys: true}, function(sch, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex) {
      if (jsonPtr === "")
        return;
      var id = self2._getId(sch);
      var baseId = baseIds[parentJsonPtr];
      var fullPath = fullPaths[parentJsonPtr] + "/" + parentKeyword;
      if (keyIndex !== void 0)
        fullPath += "/" + (typeof keyIndex == "number" ? keyIndex : util.escapeFragment(keyIndex));
      if (typeof id == "string") {
        id = baseId = normalizeId(baseId ? URI.resolve(baseId, id) : id);
        var refVal = self2._refs[id];
        if (typeof refVal == "string")
          refVal = self2._refs[refVal];
        if (refVal && refVal.schema) {
          if (!equal(sch, refVal.schema))
            throw new Error('id "' + id + '" resolves to more than one schema');
        } else if (id != normalizeId(fullPath)) {
          if (id[0] == "#") {
            if (localRefs[id] && !equal(sch, localRefs[id]))
              throw new Error('id "' + id + '" resolves to more than one schema');
            localRefs[id] = sch;
          } else {
            self2._refs[id] = fullPath;
          }
        }
      }
      baseIds[jsonPtr] = baseId;
      fullPaths[jsonPtr] = fullPath;
    });
    return localRefs;
  }
});

// node_modules/ajv/lib/compile/error_classes.js
var require_error_classes = __commonJS((exports2, module2) => {
  "use strict";
  var resolve = require_resolve();
  module2.exports = {
    Validation: errorSubclass(ValidationError4),
    MissingRef: errorSubclass(MissingRefError)
  };
  function ValidationError4(errors) {
    this.message = "validation failed";
    this.errors = errors;
    this.ajv = this.validation = true;
  }
  MissingRefError.message = function(baseId, ref) {
    return "can't resolve reference " + ref + " from id " + baseId;
  };
  function MissingRefError(baseId, ref, message) {
    this.message = message || MissingRefError.message(baseId, ref);
    this.missingRef = resolve.url(baseId, ref);
    this.missingSchema = resolve.normalizeId(resolve.fullPath(this.missingRef));
  }
  function errorSubclass(Subclass) {
    Subclass.prototype = Object.create(Error.prototype);
    Subclass.prototype.constructor = Subclass;
    return Subclass;
  }
});

// node_modules/fast-json-stable-stringify/index.js
var require_fast_json_stable_stringify = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function(data, opts) {
    if (!opts)
      opts = {};
    if (typeof opts === "function")
      opts = {cmp: opts};
    var cycles = typeof opts.cycles === "boolean" ? opts.cycles : false;
    var cmp = opts.cmp && function(f) {
      return function(node) {
        return function(a, b) {
          var aobj = {key: a, value: node[a]};
          var bobj = {key: b, value: node[b]};
          return f(aobj, bobj);
        };
      };
    }(opts.cmp);
    var seen = [];
    return function stringify(node) {
      if (node && node.toJSON && typeof node.toJSON === "function") {
        node = node.toJSON();
      }
      if (node === void 0)
        return;
      if (typeof node == "number")
        return isFinite(node) ? "" + node : "null";
      if (typeof node !== "object")
        return JSON.stringify(node);
      var i, out;
      if (Array.isArray(node)) {
        out = "[";
        for (i = 0; i < node.length; i++) {
          if (i)
            out += ",";
          out += stringify(node[i]) || "null";
        }
        return out + "]";
      }
      if (node === null)
        return "null";
      if (seen.indexOf(node) !== -1) {
        if (cycles)
          return JSON.stringify("__cycle__");
        throw new TypeError("Converting circular structure to JSON");
      }
      var seenIndex = seen.push(node) - 1;
      var keys = Object.keys(node).sort(cmp && cmp(node));
      out = "";
      for (i = 0; i < keys.length; i++) {
        var key = keys[i];
        var value = stringify(node[key]);
        if (!value)
          continue;
        if (out)
          out += ",";
        out += JSON.stringify(key) + ":" + value;
      }
      seen.splice(seenIndex, 1);
      return "{" + out + "}";
    }(data);
  };
});

// node_modules/ajv/lib/dotjs/validate.js
var require_validate = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_validate(it, $keyword, $ruleType) {
    var out = "";
    var $async = it.schema.$async === true, $refKeywords = it.util.schemaHasRulesExcept(it.schema, it.RULES.all, "$ref"), $id = it.self._getId(it.schema);
    if (it.opts.strictKeywords) {
      var $unknownKwd = it.util.schemaUnknownRules(it.schema, it.RULES.keywords);
      if ($unknownKwd) {
        var $keywordsMsg = "unknown keyword: " + $unknownKwd;
        if (it.opts.strictKeywords === "log")
          it.logger.warn($keywordsMsg);
        else
          throw new Error($keywordsMsg);
      }
    }
    if (it.isTop) {
      out += " var validate = ";
      if ($async) {
        it.async = true;
        out += "async ";
      }
      out += "function(data, dataPath, parentData, parentDataProperty, rootData) { 'use strict'; ";
      if ($id && (it.opts.sourceCode || it.opts.processCode)) {
        out += " " + ("/*# sourceURL=" + $id + " */") + " ";
      }
    }
    if (typeof it.schema == "boolean" || !($refKeywords || it.schema.$ref)) {
      var $keyword = "false schema";
      var $lvl = it.level;
      var $dataLvl = it.dataLevel;
      var $schema = it.schema[$keyword];
      var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
      var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
      var $breakOnError = !it.opts.allErrors;
      var $errorKeyword;
      var $data = "data" + ($dataLvl || "");
      var $valid = "valid" + $lvl;
      if (it.schema === false) {
        if (it.isTop) {
          $breakOnError = true;
        } else {
          out += " var " + $valid + " = false; ";
        }
        var $$outStack = $$outStack || [];
        $$outStack.push(out);
        out = "";
        if (it.createErrors !== false) {
          out += " { keyword: '" + ($errorKeyword || "false schema") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: {} ";
          if (it.opts.messages !== false) {
            out += " , message: 'boolean schema is false' ";
          }
          if (it.opts.verbose) {
            out += " , schema: false , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
          }
          out += " } ";
        } else {
          out += " {} ";
        }
        var __err = out;
        out = $$outStack.pop();
        if (!it.compositeRule && $breakOnError) {
          if (it.async) {
            out += " throw new ValidationError([" + __err + "]); ";
          } else {
            out += " validate.errors = [" + __err + "]; return false; ";
          }
        } else {
          out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
        }
      } else {
        if (it.isTop) {
          if ($async) {
            out += " return data; ";
          } else {
            out += " validate.errors = null; return true; ";
          }
        } else {
          out += " var " + $valid + " = true; ";
        }
      }
      if (it.isTop) {
        out += " }; return validate; ";
      }
      return out;
    }
    if (it.isTop) {
      var $top = it.isTop, $lvl = it.level = 0, $dataLvl = it.dataLevel = 0, $data = "data";
      it.rootId = it.resolve.fullPath(it.self._getId(it.root.schema));
      it.baseId = it.baseId || it.rootId;
      delete it.isTop;
      it.dataPathArr = [""];
      if (it.schema.default !== void 0 && it.opts.useDefaults && it.opts.strictDefaults) {
        var $defaultMsg = "default is ignored in the schema root";
        if (it.opts.strictDefaults === "log")
          it.logger.warn($defaultMsg);
        else
          throw new Error($defaultMsg);
      }
      out += " var vErrors = null; ";
      out += " var errors = 0;     ";
      out += " if (rootData === undefined) rootData = data; ";
    } else {
      var $lvl = it.level, $dataLvl = it.dataLevel, $data = "data" + ($dataLvl || "");
      if ($id)
        it.baseId = it.resolve.url(it.baseId, $id);
      if ($async && !it.async)
        throw new Error("async schema in sync schema");
      out += " var errs_" + $lvl + " = errors;";
    }
    var $valid = "valid" + $lvl, $breakOnError = !it.opts.allErrors, $closingBraces1 = "", $closingBraces2 = "";
    var $errorKeyword;
    var $typeSchema = it.schema.type, $typeIsArray = Array.isArray($typeSchema);
    if ($typeSchema && it.opts.nullable && it.schema.nullable === true) {
      if ($typeIsArray) {
        if ($typeSchema.indexOf("null") == -1)
          $typeSchema = $typeSchema.concat("null");
      } else if ($typeSchema != "null") {
        $typeSchema = [$typeSchema, "null"];
        $typeIsArray = true;
      }
    }
    if ($typeIsArray && $typeSchema.length == 1) {
      $typeSchema = $typeSchema[0];
      $typeIsArray = false;
    }
    if (it.schema.$ref && $refKeywords) {
      if (it.opts.extendRefs == "fail") {
        throw new Error('$ref: validation keywords used in schema at path "' + it.errSchemaPath + '" (see option extendRefs)');
      } else if (it.opts.extendRefs !== true) {
        $refKeywords = false;
        it.logger.warn('$ref: keywords ignored in schema at path "' + it.errSchemaPath + '"');
      }
    }
    if (it.schema.$comment && it.opts.$comment) {
      out += " " + it.RULES.all.$comment.code(it, "$comment");
    }
    if ($typeSchema) {
      if (it.opts.coerceTypes) {
        var $coerceToTypes = it.util.coerceToTypes(it.opts.coerceTypes, $typeSchema);
      }
      var $rulesGroup = it.RULES.types[$typeSchema];
      if ($coerceToTypes || $typeIsArray || $rulesGroup === true || $rulesGroup && !$shouldUseGroup($rulesGroup)) {
        var $schemaPath = it.schemaPath + ".type", $errSchemaPath = it.errSchemaPath + "/type";
        var $schemaPath = it.schemaPath + ".type", $errSchemaPath = it.errSchemaPath + "/type", $method = $typeIsArray ? "checkDataTypes" : "checkDataType";
        out += " if (" + it.util[$method]($typeSchema, $data, it.opts.strictNumbers, true) + ") { ";
        if ($coerceToTypes) {
          var $dataType = "dataType" + $lvl, $coerced = "coerced" + $lvl;
          out += " var " + $dataType + " = typeof " + $data + "; var " + $coerced + " = undefined; ";
          if (it.opts.coerceTypes == "array") {
            out += " if (" + $dataType + " == 'object' && Array.isArray(" + $data + ") && " + $data + ".length == 1) { " + $data + " = " + $data + "[0]; " + $dataType + " = typeof " + $data + "; if (" + it.util.checkDataType(it.schema.type, $data, it.opts.strictNumbers) + ") " + $coerced + " = " + $data + "; } ";
          }
          out += " if (" + $coerced + " !== undefined) ; ";
          var arr1 = $coerceToTypes;
          if (arr1) {
            var $type, $i = -1, l1 = arr1.length - 1;
            while ($i < l1) {
              $type = arr1[$i += 1];
              if ($type == "string") {
                out += " else if (" + $dataType + " == 'number' || " + $dataType + " == 'boolean') " + $coerced + " = '' + " + $data + "; else if (" + $data + " === null) " + $coerced + " = ''; ";
              } else if ($type == "number" || $type == "integer") {
                out += " else if (" + $dataType + " == 'boolean' || " + $data + " === null || (" + $dataType + " == 'string' && " + $data + " && " + $data + " == +" + $data + " ";
                if ($type == "integer") {
                  out += " && !(" + $data + " % 1)";
                }
                out += ")) " + $coerced + " = +" + $data + "; ";
              } else if ($type == "boolean") {
                out += " else if (" + $data + " === 'false' || " + $data + " === 0 || " + $data + " === null) " + $coerced + " = false; else if (" + $data + " === 'true' || " + $data + " === 1) " + $coerced + " = true; ";
              } else if ($type == "null") {
                out += " else if (" + $data + " === '' || " + $data + " === 0 || " + $data + " === false) " + $coerced + " = null; ";
              } else if (it.opts.coerceTypes == "array" && $type == "array") {
                out += " else if (" + $dataType + " == 'string' || " + $dataType + " == 'number' || " + $dataType + " == 'boolean' || " + $data + " == null) " + $coerced + " = [" + $data + "]; ";
              }
            }
          }
          out += " else {   ";
          var $$outStack = $$outStack || [];
          $$outStack.push(out);
          out = "";
          if (it.createErrors !== false) {
            out += " { keyword: '" + ($errorKeyword || "type") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { type: '";
            if ($typeIsArray) {
              out += "" + $typeSchema.join(",");
            } else {
              out += "" + $typeSchema;
            }
            out += "' } ";
            if (it.opts.messages !== false) {
              out += " , message: 'should be ";
              if ($typeIsArray) {
                out += "" + $typeSchema.join(",");
              } else {
                out += "" + $typeSchema;
              }
              out += "' ";
            }
            if (it.opts.verbose) {
              out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
            }
            out += " } ";
          } else {
            out += " {} ";
          }
          var __err = out;
          out = $$outStack.pop();
          if (!it.compositeRule && $breakOnError) {
            if (it.async) {
              out += " throw new ValidationError([" + __err + "]); ";
            } else {
              out += " validate.errors = [" + __err + "]; return false; ";
            }
          } else {
            out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
          }
          out += " } if (" + $coerced + " !== undefined) {  ";
          var $parentData = $dataLvl ? "data" + ($dataLvl - 1 || "") : "parentData", $parentDataProperty = $dataLvl ? it.dataPathArr[$dataLvl] : "parentDataProperty";
          out += " " + $data + " = " + $coerced + "; ";
          if (!$dataLvl) {
            out += "if (" + $parentData + " !== undefined)";
          }
          out += " " + $parentData + "[" + $parentDataProperty + "] = " + $coerced + "; } ";
        } else {
          var $$outStack = $$outStack || [];
          $$outStack.push(out);
          out = "";
          if (it.createErrors !== false) {
            out += " { keyword: '" + ($errorKeyword || "type") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { type: '";
            if ($typeIsArray) {
              out += "" + $typeSchema.join(",");
            } else {
              out += "" + $typeSchema;
            }
            out += "' } ";
            if (it.opts.messages !== false) {
              out += " , message: 'should be ";
              if ($typeIsArray) {
                out += "" + $typeSchema.join(",");
              } else {
                out += "" + $typeSchema;
              }
              out += "' ";
            }
            if (it.opts.verbose) {
              out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
            }
            out += " } ";
          } else {
            out += " {} ";
          }
          var __err = out;
          out = $$outStack.pop();
          if (!it.compositeRule && $breakOnError) {
            if (it.async) {
              out += " throw new ValidationError([" + __err + "]); ";
            } else {
              out += " validate.errors = [" + __err + "]; return false; ";
            }
          } else {
            out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
          }
        }
        out += " } ";
      }
    }
    if (it.schema.$ref && !$refKeywords) {
      out += " " + it.RULES.all.$ref.code(it, "$ref") + " ";
      if ($breakOnError) {
        out += " } if (errors === ";
        if ($top) {
          out += "0";
        } else {
          out += "errs_" + $lvl;
        }
        out += ") { ";
        $closingBraces2 += "}";
      }
    } else {
      var arr2 = it.RULES;
      if (arr2) {
        var $rulesGroup, i2 = -1, l2 = arr2.length - 1;
        while (i2 < l2) {
          $rulesGroup = arr2[i2 += 1];
          if ($shouldUseGroup($rulesGroup)) {
            if ($rulesGroup.type) {
              out += " if (" + it.util.checkDataType($rulesGroup.type, $data, it.opts.strictNumbers) + ") { ";
            }
            if (it.opts.useDefaults) {
              if ($rulesGroup.type == "object" && it.schema.properties) {
                var $schema = it.schema.properties, $schemaKeys = Object.keys($schema);
                var arr3 = $schemaKeys;
                if (arr3) {
                  var $propertyKey, i3 = -1, l3 = arr3.length - 1;
                  while (i3 < l3) {
                    $propertyKey = arr3[i3 += 1];
                    var $sch = $schema[$propertyKey];
                    if ($sch.default !== void 0) {
                      var $passData = $data + it.util.getProperty($propertyKey);
                      if (it.compositeRule) {
                        if (it.opts.strictDefaults) {
                          var $defaultMsg = "default is ignored for: " + $passData;
                          if (it.opts.strictDefaults === "log")
                            it.logger.warn($defaultMsg);
                          else
                            throw new Error($defaultMsg);
                        }
                      } else {
                        out += " if (" + $passData + " === undefined ";
                        if (it.opts.useDefaults == "empty") {
                          out += " || " + $passData + " === null || " + $passData + " === '' ";
                        }
                        out += " ) " + $passData + " = ";
                        if (it.opts.useDefaults == "shared") {
                          out += " " + it.useDefault($sch.default) + " ";
                        } else {
                          out += " " + JSON.stringify($sch.default) + " ";
                        }
                        out += "; ";
                      }
                    }
                  }
                }
              } else if ($rulesGroup.type == "array" && Array.isArray(it.schema.items)) {
                var arr4 = it.schema.items;
                if (arr4) {
                  var $sch, $i = -1, l4 = arr4.length - 1;
                  while ($i < l4) {
                    $sch = arr4[$i += 1];
                    if ($sch.default !== void 0) {
                      var $passData = $data + "[" + $i + "]";
                      if (it.compositeRule) {
                        if (it.opts.strictDefaults) {
                          var $defaultMsg = "default is ignored for: " + $passData;
                          if (it.opts.strictDefaults === "log")
                            it.logger.warn($defaultMsg);
                          else
                            throw new Error($defaultMsg);
                        }
                      } else {
                        out += " if (" + $passData + " === undefined ";
                        if (it.opts.useDefaults == "empty") {
                          out += " || " + $passData + " === null || " + $passData + " === '' ";
                        }
                        out += " ) " + $passData + " = ";
                        if (it.opts.useDefaults == "shared") {
                          out += " " + it.useDefault($sch.default) + " ";
                        } else {
                          out += " " + JSON.stringify($sch.default) + " ";
                        }
                        out += "; ";
                      }
                    }
                  }
                }
              }
            }
            var arr5 = $rulesGroup.rules;
            if (arr5) {
              var $rule, i5 = -1, l5 = arr5.length - 1;
              while (i5 < l5) {
                $rule = arr5[i5 += 1];
                if ($shouldUseRule($rule)) {
                  var $code = $rule.code(it, $rule.keyword, $rulesGroup.type);
                  if ($code) {
                    out += " " + $code + " ";
                    if ($breakOnError) {
                      $closingBraces1 += "}";
                    }
                  }
                }
              }
            }
            if ($breakOnError) {
              out += " " + $closingBraces1 + " ";
              $closingBraces1 = "";
            }
            if ($rulesGroup.type) {
              out += " } ";
              if ($typeSchema && $typeSchema === $rulesGroup.type && !$coerceToTypes) {
                out += " else { ";
                var $schemaPath = it.schemaPath + ".type", $errSchemaPath = it.errSchemaPath + "/type";
                var $$outStack = $$outStack || [];
                $$outStack.push(out);
                out = "";
                if (it.createErrors !== false) {
                  out += " { keyword: '" + ($errorKeyword || "type") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { type: '";
                  if ($typeIsArray) {
                    out += "" + $typeSchema.join(",");
                  } else {
                    out += "" + $typeSchema;
                  }
                  out += "' } ";
                  if (it.opts.messages !== false) {
                    out += " , message: 'should be ";
                    if ($typeIsArray) {
                      out += "" + $typeSchema.join(",");
                    } else {
                      out += "" + $typeSchema;
                    }
                    out += "' ";
                  }
                  if (it.opts.verbose) {
                    out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
                  }
                  out += " } ";
                } else {
                  out += " {} ";
                }
                var __err = out;
                out = $$outStack.pop();
                if (!it.compositeRule && $breakOnError) {
                  if (it.async) {
                    out += " throw new ValidationError([" + __err + "]); ";
                  } else {
                    out += " validate.errors = [" + __err + "]; return false; ";
                  }
                } else {
                  out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
                }
                out += " } ";
              }
            }
            if ($breakOnError) {
              out += " if (errors === ";
              if ($top) {
                out += "0";
              } else {
                out += "errs_" + $lvl;
              }
              out += ") { ";
              $closingBraces2 += "}";
            }
          }
        }
      }
    }
    if ($breakOnError) {
      out += " " + $closingBraces2 + " ";
    }
    if ($top) {
      if ($async) {
        out += " if (errors === 0) return data;           ";
        out += " else throw new ValidationError(vErrors); ";
      } else {
        out += " validate.errors = vErrors; ";
        out += " return errors === 0;       ";
      }
      out += " }; return validate;";
    } else {
      out += " var " + $valid + " = errors === errs_" + $lvl + ";";
    }
    function $shouldUseGroup($rulesGroup2) {
      var rules = $rulesGroup2.rules;
      for (var i = 0; i < rules.length; i++)
        if ($shouldUseRule(rules[i]))
          return true;
    }
    function $shouldUseRule($rule2) {
      return it.schema[$rule2.keyword] !== void 0 || $rule2.implements && $ruleImplementsSomeKeyword($rule2);
    }
    function $ruleImplementsSomeKeyword($rule2) {
      var impl = $rule2.implements;
      for (var i = 0; i < impl.length; i++)
        if (it.schema[impl[i]] !== void 0)
          return true;
    }
    return out;
  };
});

// node_modules/ajv/lib/compile/index.js
var require_compile = __commonJS((exports2, module2) => {
  "use strict";
  var resolve = require_resolve();
  var util = require_util();
  var errorClasses = require_error_classes();
  var stableStringify = require_fast_json_stable_stringify();
  var validateGenerator = require_validate();
  var ucs2length = util.ucs2length;
  var equal = require_fast_deep_equal();
  var ValidationError4 = errorClasses.Validation;
  module2.exports = compile;
  function compile(schema, root, localRefs, baseId) {
    var self2 = this, opts = this._opts, refVal = [void 0], refs = {}, patterns = [], patternsHash = {}, defaults = [], defaultsHash = {}, customRules = [];
    root = root || {schema, refVal, refs};
    var c = checkCompiling.call(this, schema, root, baseId);
    var compilation = this._compilations[c.index];
    if (c.compiling)
      return compilation.callValidate = callValidate;
    var formats = this._formats;
    var RULES = this.RULES;
    try {
      var v = localCompile(schema, root, localRefs, baseId);
      compilation.validate = v;
      var cv = compilation.callValidate;
      if (cv) {
        cv.schema = v.schema;
        cv.errors = null;
        cv.refs = v.refs;
        cv.refVal = v.refVal;
        cv.root = v.root;
        cv.$async = v.$async;
        if (opts.sourceCode)
          cv.source = v.source;
      }
      return v;
    } finally {
      endCompiling.call(this, schema, root, baseId);
    }
    function callValidate() {
      var validate = compilation.validate;
      var result = validate.apply(this, arguments);
      callValidate.errors = validate.errors;
      return result;
    }
    function localCompile(_schema, _root, localRefs2, baseId2) {
      var isRoot = !_root || _root && _root.schema == _schema;
      if (_root.schema != root.schema)
        return compile.call(self2, _schema, _root, localRefs2, baseId2);
      var $async = _schema.$async === true;
      var sourceCode = validateGenerator({
        isTop: true,
        schema: _schema,
        isRoot,
        baseId: baseId2,
        root: _root,
        schemaPath: "",
        errSchemaPath: "#",
        errorPath: '""',
        MissingRefError: errorClasses.MissingRef,
        RULES,
        validate: validateGenerator,
        util,
        resolve,
        resolveRef,
        usePattern,
        useDefault,
        useCustomRule,
        opts,
        formats,
        logger: self2.logger,
        self: self2
      });
      sourceCode = vars(refVal, refValCode) + vars(patterns, patternCode) + vars(defaults, defaultCode) + vars(customRules, customRuleCode) + sourceCode;
      if (opts.processCode)
        sourceCode = opts.processCode(sourceCode, _schema);
      var validate;
      try {
        var makeValidate = new Function("self", "RULES", "formats", "root", "refVal", "defaults", "customRules", "equal", "ucs2length", "ValidationError", sourceCode);
        validate = makeValidate(self2, RULES, formats, root, refVal, defaults, customRules, equal, ucs2length, ValidationError4);
        refVal[0] = validate;
      } catch (e) {
        self2.logger.error("Error compiling schema, function code:", sourceCode);
        throw e;
      }
      validate.schema = _schema;
      validate.errors = null;
      validate.refs = refs;
      validate.refVal = refVal;
      validate.root = isRoot ? validate : _root;
      if ($async)
        validate.$async = true;
      if (opts.sourceCode === true) {
        validate.source = {
          code: sourceCode,
          patterns,
          defaults
        };
      }
      return validate;
    }
    function resolveRef(baseId2, ref, isRoot) {
      ref = resolve.url(baseId2, ref);
      var refIndex = refs[ref];
      var _refVal, refCode;
      if (refIndex !== void 0) {
        _refVal = refVal[refIndex];
        refCode = "refVal[" + refIndex + "]";
        return resolvedRef(_refVal, refCode);
      }
      if (!isRoot && root.refs) {
        var rootRefId = root.refs[ref];
        if (rootRefId !== void 0) {
          _refVal = root.refVal[rootRefId];
          refCode = addLocalRef(ref, _refVal);
          return resolvedRef(_refVal, refCode);
        }
      }
      refCode = addLocalRef(ref);
      var v2 = resolve.call(self2, localCompile, root, ref);
      if (v2 === void 0) {
        var localSchema = localRefs && localRefs[ref];
        if (localSchema) {
          v2 = resolve.inlineRef(localSchema, opts.inlineRefs) ? localSchema : compile.call(self2, localSchema, root, localRefs, baseId2);
        }
      }
      if (v2 === void 0) {
        removeLocalRef(ref);
      } else {
        replaceLocalRef(ref, v2);
        return resolvedRef(v2, refCode);
      }
    }
    function addLocalRef(ref, v2) {
      var refId = refVal.length;
      refVal[refId] = v2;
      refs[ref] = refId;
      return "refVal" + refId;
    }
    function removeLocalRef(ref) {
      delete refs[ref];
    }
    function replaceLocalRef(ref, v2) {
      var refId = refs[ref];
      refVal[refId] = v2;
    }
    function resolvedRef(refVal2, code) {
      return typeof refVal2 == "object" || typeof refVal2 == "boolean" ? {code, schema: refVal2, inline: true} : {code, $async: refVal2 && !!refVal2.$async};
    }
    function usePattern(regexStr) {
      var index = patternsHash[regexStr];
      if (index === void 0) {
        index = patternsHash[regexStr] = patterns.length;
        patterns[index] = regexStr;
      }
      return "pattern" + index;
    }
    function useDefault(value) {
      switch (typeof value) {
        case "boolean":
        case "number":
          return "" + value;
        case "string":
          return util.toQuotedString(value);
        case "object":
          if (value === null)
            return "null";
          var valueStr = stableStringify(value);
          var index = defaultsHash[valueStr];
          if (index === void 0) {
            index = defaultsHash[valueStr] = defaults.length;
            defaults[index] = value;
          }
          return "default" + index;
      }
    }
    function useCustomRule(rule, schema2, parentSchema, it) {
      if (self2._opts.validateSchema !== false) {
        var deps = rule.definition.dependencies;
        if (deps && !deps.every(function(keyword) {
          return Object.prototype.hasOwnProperty.call(parentSchema, keyword);
        }))
          throw new Error("parent schema must have all required keywords: " + deps.join(","));
        var validateSchema = rule.definition.validateSchema;
        if (validateSchema) {
          var valid = validateSchema(schema2);
          if (!valid) {
            var message = "keyword schema is invalid: " + self2.errorsText(validateSchema.errors);
            if (self2._opts.validateSchema == "log")
              self2.logger.error(message);
            else
              throw new Error(message);
          }
        }
      }
      var compile2 = rule.definition.compile, inline = rule.definition.inline, macro = rule.definition.macro;
      var validate;
      if (compile2) {
        validate = compile2.call(self2, schema2, parentSchema, it);
      } else if (macro) {
        validate = macro.call(self2, schema2, parentSchema, it);
        if (opts.validateSchema !== false)
          self2.validateSchema(validate, true);
      } else if (inline) {
        validate = inline.call(self2, it, rule.keyword, schema2, parentSchema);
      } else {
        validate = rule.definition.validate;
        if (!validate)
          return;
      }
      if (validate === void 0)
        throw new Error('custom keyword "' + rule.keyword + '"failed to compile');
      var index = customRules.length;
      customRules[index] = validate;
      return {
        code: "customRule" + index,
        validate
      };
    }
  }
  function checkCompiling(schema, root, baseId) {
    var index = compIndex.call(this, schema, root, baseId);
    if (index >= 0)
      return {index, compiling: true};
    index = this._compilations.length;
    this._compilations[index] = {
      schema,
      root,
      baseId
    };
    return {index, compiling: false};
  }
  function endCompiling(schema, root, baseId) {
    var i = compIndex.call(this, schema, root, baseId);
    if (i >= 0)
      this._compilations.splice(i, 1);
  }
  function compIndex(schema, root, baseId) {
    for (var i = 0; i < this._compilations.length; i++) {
      var c = this._compilations[i];
      if (c.schema == schema && c.root == root && c.baseId == baseId)
        return i;
    }
    return -1;
  }
  function patternCode(i, patterns) {
    return "var pattern" + i + " = new RegExp(" + util.toQuotedString(patterns[i]) + ");";
  }
  function defaultCode(i) {
    return "var default" + i + " = defaults[" + i + "];";
  }
  function refValCode(i, refVal) {
    return refVal[i] === void 0 ? "" : "var refVal" + i + " = refVal[" + i + "];";
  }
  function customRuleCode(i) {
    return "var customRule" + i + " = customRules[" + i + "];";
  }
  function vars(arr, statement) {
    if (!arr.length)
      return "";
    var code = "";
    for (var i = 0; i < arr.length; i++)
      code += statement(i, arr);
    return code;
  }
});

// node_modules/ajv/lib/cache.js
var require_cache = __commonJS((exports2, module2) => {
  "use strict";
  var Cache = module2.exports = function Cache2() {
    this._cache = {};
  };
  Cache.prototype.put = function Cache_put(key, value) {
    this._cache[key] = value;
  };
  Cache.prototype.get = function Cache_get(key) {
    return this._cache[key];
  };
  Cache.prototype.del = function Cache_del(key) {
    delete this._cache[key];
  };
  Cache.prototype.clear = function Cache_clear() {
    this._cache = {};
  };
});

// node_modules/ajv/lib/compile/formats.js
var require_formats = __commonJS((exports2, module2) => {
  "use strict";
  var util = require_util();
  var DATE = /^(\d\d\d\d)-(\d\d)-(\d\d)$/;
  var DAYS = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  var TIME = /^(\d\d):(\d\d):(\d\d)(\.\d+)?(z|[+-]\d\d(?::?\d\d)?)?$/i;
  var HOSTNAME = /^(?=.{1,253}\.?$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[-0-9a-z]{0,61}[0-9a-z])?)*\.?$/i;
  var URI = /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)(?:\?(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
  var URIREF = /^(?:[a-z][a-z0-9+\-.]*:)?(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'"()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?(?:\?(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
  var URITEMPLATE = /^(?:(?:[^\x00-\x20"'<>%\\^`{|}]|%[0-9a-f]{2})|\{[+#./;?&=,!@|]?(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?(?:,(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?)*\})*$/i;
  var URL2 = /^(?:(?:http[s\u017F]?|ftp):\/\/)(?:(?:[\0-\x08\x0E-\x1F!-\x9F\xA1-\u167F\u1681-\u1FFF\u200B-\u2027\u202A-\u202E\u2030-\u205E\u2060-\u2FFF\u3001-\uD7FF\uE000-\uFEFE\uFF00-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])+(?::(?:[\0-\x08\x0E-\x1F!-\x9F\xA1-\u167F\u1681-\u1FFF\u200B-\u2027\u202A-\u202E\u2030-\u205E\u2060-\u2FFF\u3001-\uD7FF\uE000-\uFEFE\uFF00-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])*)?@)?(?:(?!10(?:\.[0-9]{1,3}){3})(?!127(?:\.[0-9]{1,3}){3})(?!169\.254(?:\.[0-9]{1,3}){2})(?!192\.168(?:\.[0-9]{1,3}){2})(?!172\.(?:1[6-9]|2[0-9]|3[01])(?:\.[0-9]{1,3}){2})(?:[1-9][0-9]?|1[0-9][0-9]|2[01][0-9]|22[0-3])(?:\.(?:1?[0-9]{1,2}|2[0-4][0-9]|25[0-5])){2}(?:\.(?:[1-9][0-9]?|1[0-9][0-9]|2[0-4][0-9]|25[0-4]))|(?:(?:(?:[0-9a-z\xA1-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])+-)*(?:[0-9a-z\xA1-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])+)(?:\.(?:(?:[0-9a-z\xA1-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])+-)*(?:[0-9a-z\xA1-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])+)*(?:\.(?:(?:[a-z\xA1-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]){2,})))(?::[0-9]{2,5})?(?:\/(?:[\0-\x08\x0E-\x1F!-\x9F\xA1-\u167F\u1681-\u1FFF\u200B-\u2027\u202A-\u202E\u2030-\u205E\u2060-\u2FFF\u3001-\uD7FF\uE000-\uFEFE\uFF00-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])*)?$/i;
  var UUID = /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
  var JSON_POINTER = /^(?:\/(?:[^~/]|~0|~1)*)*$/;
  var JSON_POINTER_URI_FRAGMENT = /^#(?:\/(?:[a-z0-9_\-.!$&'()*+,;:=@]|%[0-9a-f]{2}|~0|~1)*)*$/i;
  var RELATIVE_JSON_POINTER = /^(?:0|[1-9][0-9]*)(?:#|(?:\/(?:[^~/]|~0|~1)*)*)$/;
  module2.exports = formats;
  function formats(mode) {
    mode = mode == "full" ? "full" : "fast";
    return util.copy(formats[mode]);
  }
  formats.fast = {
    date: /^\d\d\d\d-[0-1]\d-[0-3]\d$/,
    time: /^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i,
    "date-time": /^\d\d\d\d-[0-1]\d-[0-3]\d[t\s](?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i,
    uri: /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/)?[^\s]*$/i,
    "uri-reference": /^(?:(?:[a-z][a-z0-9+\-.]*:)?\/?\/)?(?:[^\\\s#][^\s#]*)?(?:#[^\\\s]*)?$/i,
    "uri-template": URITEMPLATE,
    url: URL2,
    email: /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i,
    hostname: HOSTNAME,
    ipv4: /^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/,
    ipv6: /^\s*(?:(?:(?:[0-9a-f]{1,4}:){7}(?:[0-9a-f]{1,4}|:))|(?:(?:[0-9a-f]{1,4}:){6}(?::[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(?:(?:[0-9a-f]{1,4}:){5}(?:(?:(?::[0-9a-f]{1,4}){1,2})|:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(?:(?:[0-9a-f]{1,4}:){4}(?:(?:(?::[0-9a-f]{1,4}){1,3})|(?:(?::[0-9a-f]{1,4})?:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?:(?:[0-9a-f]{1,4}:){3}(?:(?:(?::[0-9a-f]{1,4}){1,4})|(?:(?::[0-9a-f]{1,4}){0,2}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?:(?:[0-9a-f]{1,4}:){2}(?:(?:(?::[0-9a-f]{1,4}){1,5})|(?:(?::[0-9a-f]{1,4}){0,3}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?:(?:[0-9a-f]{1,4}:){1}(?:(?:(?::[0-9a-f]{1,4}){1,6})|(?:(?::[0-9a-f]{1,4}){0,4}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?::(?:(?:(?::[0-9a-f]{1,4}){1,7})|(?:(?::[0-9a-f]{1,4}){0,5}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(?:%.+)?\s*$/i,
    regex,
    uuid: UUID,
    "json-pointer": JSON_POINTER,
    "json-pointer-uri-fragment": JSON_POINTER_URI_FRAGMENT,
    "relative-json-pointer": RELATIVE_JSON_POINTER
  };
  formats.full = {
    date,
    time,
    "date-time": date_time,
    uri,
    "uri-reference": URIREF,
    "uri-template": URITEMPLATE,
    url: URL2,
    email: /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i,
    hostname: HOSTNAME,
    ipv4: /^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/,
    ipv6: /^\s*(?:(?:(?:[0-9a-f]{1,4}:){7}(?:[0-9a-f]{1,4}|:))|(?:(?:[0-9a-f]{1,4}:){6}(?::[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(?:(?:[0-9a-f]{1,4}:){5}(?:(?:(?::[0-9a-f]{1,4}){1,2})|:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(?:(?:[0-9a-f]{1,4}:){4}(?:(?:(?::[0-9a-f]{1,4}){1,3})|(?:(?::[0-9a-f]{1,4})?:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?:(?:[0-9a-f]{1,4}:){3}(?:(?:(?::[0-9a-f]{1,4}){1,4})|(?:(?::[0-9a-f]{1,4}){0,2}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?:(?:[0-9a-f]{1,4}:){2}(?:(?:(?::[0-9a-f]{1,4}){1,5})|(?:(?::[0-9a-f]{1,4}){0,3}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?:(?:[0-9a-f]{1,4}:){1}(?:(?:(?::[0-9a-f]{1,4}){1,6})|(?:(?::[0-9a-f]{1,4}){0,4}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?::(?:(?:(?::[0-9a-f]{1,4}){1,7})|(?:(?::[0-9a-f]{1,4}){0,5}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(?:%.+)?\s*$/i,
    regex,
    uuid: UUID,
    "json-pointer": JSON_POINTER,
    "json-pointer-uri-fragment": JSON_POINTER_URI_FRAGMENT,
    "relative-json-pointer": RELATIVE_JSON_POINTER
  };
  function isLeapYear(year) {
    return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  }
  function date(str) {
    var matches = str.match(DATE);
    if (!matches)
      return false;
    var year = +matches[1];
    var month = +matches[2];
    var day = +matches[3];
    return month >= 1 && month <= 12 && day >= 1 && day <= (month == 2 && isLeapYear(year) ? 29 : DAYS[month]);
  }
  function time(str, full) {
    var matches = str.match(TIME);
    if (!matches)
      return false;
    var hour = matches[1];
    var minute = matches[2];
    var second = matches[3];
    var timeZone = matches[5];
    return (hour <= 23 && minute <= 59 && second <= 59 || hour == 23 && minute == 59 && second == 60) && (!full || timeZone);
  }
  var DATE_TIME_SEPARATOR = /t|\s/i;
  function date_time(str) {
    var dateTime = str.split(DATE_TIME_SEPARATOR);
    return dateTime.length == 2 && date(dateTime[0]) && time(dateTime[1], true);
  }
  var NOT_URI_FRAGMENT = /\/|:/;
  function uri(str) {
    return NOT_URI_FRAGMENT.test(str) && URI.test(str);
  }
  var Z_ANCHOR = /[^\\]\\Z/;
  function regex(str) {
    if (Z_ANCHOR.test(str))
      return false;
    try {
      new RegExp(str);
      return true;
    } catch (e) {
      return false;
    }
  }
});

// node_modules/ajv/lib/dotjs/ref.js
var require_ref = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_ref(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $async, $refCode;
    if ($schema == "#" || $schema == "#/") {
      if (it.isRoot) {
        $async = it.async;
        $refCode = "validate";
      } else {
        $async = it.root.schema.$async === true;
        $refCode = "root.refVal[0]";
      }
    } else {
      var $refVal = it.resolveRef(it.baseId, $schema, it.isRoot);
      if ($refVal === void 0) {
        var $message = it.MissingRefError.message(it.baseId, $schema);
        if (it.opts.missingRefs == "fail") {
          it.logger.error($message);
          var $$outStack = $$outStack || [];
          $$outStack.push(out);
          out = "";
          if (it.createErrors !== false) {
            out += " { keyword: '$ref' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { ref: '" + it.util.escapeQuotes($schema) + "' } ";
            if (it.opts.messages !== false) {
              out += " , message: 'can\\'t resolve reference " + it.util.escapeQuotes($schema) + "' ";
            }
            if (it.opts.verbose) {
              out += " , schema: " + it.util.toQuotedString($schema) + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
            }
            out += " } ";
          } else {
            out += " {} ";
          }
          var __err = out;
          out = $$outStack.pop();
          if (!it.compositeRule && $breakOnError) {
            if (it.async) {
              out += " throw new ValidationError([" + __err + "]); ";
            } else {
              out += " validate.errors = [" + __err + "]; return false; ";
            }
          } else {
            out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
          }
          if ($breakOnError) {
            out += " if (false) { ";
          }
        } else if (it.opts.missingRefs == "ignore") {
          it.logger.warn($message);
          if ($breakOnError) {
            out += " if (true) { ";
          }
        } else {
          throw new it.MissingRefError(it.baseId, $schema, $message);
        }
      } else if ($refVal.inline) {
        var $it = it.util.copy(it);
        $it.level++;
        var $nextValid = "valid" + $it.level;
        $it.schema = $refVal.schema;
        $it.schemaPath = "";
        $it.errSchemaPath = $schema;
        var $code = it.validate($it).replace(/validate\.schema/g, $refVal.code);
        out += " " + $code + " ";
        if ($breakOnError) {
          out += " if (" + $nextValid + ") { ";
        }
      } else {
        $async = $refVal.$async === true || it.async && $refVal.$async !== false;
        $refCode = $refVal.code;
      }
    }
    if ($refCode) {
      var $$outStack = $$outStack || [];
      $$outStack.push(out);
      out = "";
      if (it.opts.passContext) {
        out += " " + $refCode + ".call(this, ";
      } else {
        out += " " + $refCode + "( ";
      }
      out += " " + $data + ", (dataPath || '')";
      if (it.errorPath != '""') {
        out += " + " + it.errorPath;
      }
      var $parentData = $dataLvl ? "data" + ($dataLvl - 1 || "") : "parentData", $parentDataProperty = $dataLvl ? it.dataPathArr[$dataLvl] : "parentDataProperty";
      out += " , " + $parentData + " , " + $parentDataProperty + ", rootData)  ";
      var __callValidate = out;
      out = $$outStack.pop();
      if ($async) {
        if (!it.async)
          throw new Error("async schema referenced by sync schema");
        if ($breakOnError) {
          out += " var " + $valid + "; ";
        }
        out += " try { await " + __callValidate + "; ";
        if ($breakOnError) {
          out += " " + $valid + " = true; ";
        }
        out += " } catch (e) { if (!(e instanceof ValidationError)) throw e; if (vErrors === null) vErrors = e.errors; else vErrors = vErrors.concat(e.errors); errors = vErrors.length; ";
        if ($breakOnError) {
          out += " " + $valid + " = false; ";
        }
        out += " } ";
        if ($breakOnError) {
          out += " if (" + $valid + ") { ";
        }
      } else {
        out += " if (!" + __callValidate + ") { if (vErrors === null) vErrors = " + $refCode + ".errors; else vErrors = vErrors.concat(" + $refCode + ".errors); errors = vErrors.length; } ";
        if ($breakOnError) {
          out += " else { ";
        }
      }
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/allOf.js
var require_allOf = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_allOf(it, $keyword, $ruleType) {
    var out = " ";
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $it = it.util.copy(it);
    var $closingBraces = "";
    $it.level++;
    var $nextValid = "valid" + $it.level;
    var $currentBaseId = $it.baseId, $allSchemasEmpty = true;
    var arr1 = $schema;
    if (arr1) {
      var $sch, $i = -1, l1 = arr1.length - 1;
      while ($i < l1) {
        $sch = arr1[$i += 1];
        if (it.opts.strictKeywords ? typeof $sch == "object" && Object.keys($sch).length > 0 || $sch === false : it.util.schemaHasRules($sch, it.RULES.all)) {
          $allSchemasEmpty = false;
          $it.schema = $sch;
          $it.schemaPath = $schemaPath + "[" + $i + "]";
          $it.errSchemaPath = $errSchemaPath + "/" + $i;
          out += "  " + it.validate($it) + " ";
          $it.baseId = $currentBaseId;
          if ($breakOnError) {
            out += " if (" + $nextValid + ") { ";
            $closingBraces += "}";
          }
        }
      }
    }
    if ($breakOnError) {
      if ($allSchemasEmpty) {
        out += " if (true) { ";
      } else {
        out += " " + $closingBraces.slice(0, -1) + " ";
      }
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/anyOf.js
var require_anyOf = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_anyOf(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $errs = "errs__" + $lvl;
    var $it = it.util.copy(it);
    var $closingBraces = "";
    $it.level++;
    var $nextValid = "valid" + $it.level;
    var $noEmptySchema = $schema.every(function($sch2) {
      return it.opts.strictKeywords ? typeof $sch2 == "object" && Object.keys($sch2).length > 0 || $sch2 === false : it.util.schemaHasRules($sch2, it.RULES.all);
    });
    if ($noEmptySchema) {
      var $currentBaseId = $it.baseId;
      out += " var " + $errs + " = errors; var " + $valid + " = false;  ";
      var $wasComposite = it.compositeRule;
      it.compositeRule = $it.compositeRule = true;
      var arr1 = $schema;
      if (arr1) {
        var $sch, $i = -1, l1 = arr1.length - 1;
        while ($i < l1) {
          $sch = arr1[$i += 1];
          $it.schema = $sch;
          $it.schemaPath = $schemaPath + "[" + $i + "]";
          $it.errSchemaPath = $errSchemaPath + "/" + $i;
          out += "  " + it.validate($it) + " ";
          $it.baseId = $currentBaseId;
          out += " " + $valid + " = " + $valid + " || " + $nextValid + "; if (!" + $valid + ") { ";
          $closingBraces += "}";
        }
      }
      it.compositeRule = $it.compositeRule = $wasComposite;
      out += " " + $closingBraces + " if (!" + $valid + ") {   var err =   ";
      if (it.createErrors !== false) {
        out += " { keyword: 'anyOf' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: {} ";
        if (it.opts.messages !== false) {
          out += " , message: 'should match some schema in anyOf' ";
        }
        if (it.opts.verbose) {
          out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
        }
        out += " } ";
      } else {
        out += " {} ";
      }
      out += ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
      if (!it.compositeRule && $breakOnError) {
        if (it.async) {
          out += " throw new ValidationError(vErrors); ";
        } else {
          out += " validate.errors = vErrors; return false; ";
        }
      }
      out += " } else {  errors = " + $errs + "; if (vErrors !== null) { if (" + $errs + ") vErrors.length = " + $errs + "; else vErrors = null; } ";
      if (it.opts.allErrors) {
        out += " } ";
      }
    } else {
      if ($breakOnError) {
        out += " if (true) { ";
      }
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/comment.js
var require_comment = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_comment(it, $keyword, $ruleType) {
    var out = " ";
    var $schema = it.schema[$keyword];
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $comment = it.util.toQuotedString($schema);
    if (it.opts.$comment === true) {
      out += " console.log(" + $comment + ");";
    } else if (typeof it.opts.$comment == "function") {
      out += " self._opts.$comment(" + $comment + ", " + it.util.toQuotedString($errSchemaPath) + ", validate.root.schema);";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/const.js
var require_const = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_const(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    if (!$isData) {
      out += " var schema" + $lvl + " = validate.schema" + $schemaPath + ";";
    }
    out += "var " + $valid + " = equal(" + $data + ", schema" + $lvl + "); if (!" + $valid + ") {   ";
    var $$outStack = $$outStack || [];
    $$outStack.push(out);
    out = "";
    if (it.createErrors !== false) {
      out += " { keyword: 'const' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { allowedValue: schema" + $lvl + " } ";
      if (it.opts.messages !== false) {
        out += " , message: 'should be equal to constant' ";
      }
      if (it.opts.verbose) {
        out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    var __err = out;
    out = $$outStack.pop();
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError([" + __err + "]); ";
      } else {
        out += " validate.errors = [" + __err + "]; return false; ";
      }
    } else {
      out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    }
    out += " }";
    if ($breakOnError) {
      out += " else { ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/contains.js
var require_contains = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_contains(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $errs = "errs__" + $lvl;
    var $it = it.util.copy(it);
    var $closingBraces = "";
    $it.level++;
    var $nextValid = "valid" + $it.level;
    var $idx = "i" + $lvl, $dataNxt = $it.dataLevel = it.dataLevel + 1, $nextData = "data" + $dataNxt, $currentBaseId = it.baseId, $nonEmptySchema = it.opts.strictKeywords ? typeof $schema == "object" && Object.keys($schema).length > 0 || $schema === false : it.util.schemaHasRules($schema, it.RULES.all);
    out += "var " + $errs + " = errors;var " + $valid + ";";
    if ($nonEmptySchema) {
      var $wasComposite = it.compositeRule;
      it.compositeRule = $it.compositeRule = true;
      $it.schema = $schema;
      $it.schemaPath = $schemaPath;
      $it.errSchemaPath = $errSchemaPath;
      out += " var " + $nextValid + " = false; for (var " + $idx + " = 0; " + $idx + " < " + $data + ".length; " + $idx + "++) { ";
      $it.errorPath = it.util.getPathExpr(it.errorPath, $idx, it.opts.jsonPointers, true);
      var $passData = $data + "[" + $idx + "]";
      $it.dataPathArr[$dataNxt] = $idx;
      var $code = it.validate($it);
      $it.baseId = $currentBaseId;
      if (it.util.varOccurences($code, $nextData) < 2) {
        out += " " + it.util.varReplace($code, $nextData, $passData) + " ";
      } else {
        out += " var " + $nextData + " = " + $passData + "; " + $code + " ";
      }
      out += " if (" + $nextValid + ") break; }  ";
      it.compositeRule = $it.compositeRule = $wasComposite;
      out += " " + $closingBraces + " if (!" + $nextValid + ") {";
    } else {
      out += " if (" + $data + ".length == 0) {";
    }
    var $$outStack = $$outStack || [];
    $$outStack.push(out);
    out = "";
    if (it.createErrors !== false) {
      out += " { keyword: 'contains' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: {} ";
      if (it.opts.messages !== false) {
        out += " , message: 'should contain a valid item' ";
      }
      if (it.opts.verbose) {
        out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    var __err = out;
    out = $$outStack.pop();
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError([" + __err + "]); ";
      } else {
        out += " validate.errors = [" + __err + "]; return false; ";
      }
    } else {
      out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    }
    out += " } else { ";
    if ($nonEmptySchema) {
      out += "  errors = " + $errs + "; if (vErrors !== null) { if (" + $errs + ") vErrors.length = " + $errs + "; else vErrors = null; } ";
    }
    if (it.opts.allErrors) {
      out += " } ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/dependencies.js
var require_dependencies = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_dependencies(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $errs = "errs__" + $lvl;
    var $it = it.util.copy(it);
    var $closingBraces = "";
    $it.level++;
    var $nextValid = "valid" + $it.level;
    var $schemaDeps = {}, $propertyDeps = {}, $ownProperties = it.opts.ownProperties;
    for ($property in $schema) {
      if ($property == "__proto__")
        continue;
      var $sch = $schema[$property];
      var $deps = Array.isArray($sch) ? $propertyDeps : $schemaDeps;
      $deps[$property] = $sch;
    }
    out += "var " + $errs + " = errors;";
    var $currentErrorPath = it.errorPath;
    out += "var missing" + $lvl + ";";
    for (var $property in $propertyDeps) {
      $deps = $propertyDeps[$property];
      if ($deps.length) {
        out += " if ( " + $data + it.util.getProperty($property) + " !== undefined ";
        if ($ownProperties) {
          out += " && Object.prototype.hasOwnProperty.call(" + $data + ", '" + it.util.escapeQuotes($property) + "') ";
        }
        if ($breakOnError) {
          out += " && ( ";
          var arr1 = $deps;
          if (arr1) {
            var $propertyKey, $i = -1, l1 = arr1.length - 1;
            while ($i < l1) {
              $propertyKey = arr1[$i += 1];
              if ($i) {
                out += " || ";
              }
              var $prop = it.util.getProperty($propertyKey), $useData = $data + $prop;
              out += " ( ( " + $useData + " === undefined ";
              if ($ownProperties) {
                out += " || ! Object.prototype.hasOwnProperty.call(" + $data + ", '" + it.util.escapeQuotes($propertyKey) + "') ";
              }
              out += ") && (missing" + $lvl + " = " + it.util.toQuotedString(it.opts.jsonPointers ? $propertyKey : $prop) + ") ) ";
            }
          }
          out += ")) {  ";
          var $propertyPath = "missing" + $lvl, $missingProperty = "' + " + $propertyPath + " + '";
          if (it.opts._errorDataPathProperty) {
            it.errorPath = it.opts.jsonPointers ? it.util.getPathExpr($currentErrorPath, $propertyPath, true) : $currentErrorPath + " + " + $propertyPath;
          }
          var $$outStack = $$outStack || [];
          $$outStack.push(out);
          out = "";
          if (it.createErrors !== false) {
            out += " { keyword: 'dependencies' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { property: '" + it.util.escapeQuotes($property) + "', missingProperty: '" + $missingProperty + "', depsCount: " + $deps.length + ", deps: '" + it.util.escapeQuotes($deps.length == 1 ? $deps[0] : $deps.join(", ")) + "' } ";
            if (it.opts.messages !== false) {
              out += " , message: 'should have ";
              if ($deps.length == 1) {
                out += "property " + it.util.escapeQuotes($deps[0]);
              } else {
                out += "properties " + it.util.escapeQuotes($deps.join(", "));
              }
              out += " when property " + it.util.escapeQuotes($property) + " is present' ";
            }
            if (it.opts.verbose) {
              out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
            }
            out += " } ";
          } else {
            out += " {} ";
          }
          var __err = out;
          out = $$outStack.pop();
          if (!it.compositeRule && $breakOnError) {
            if (it.async) {
              out += " throw new ValidationError([" + __err + "]); ";
            } else {
              out += " validate.errors = [" + __err + "]; return false; ";
            }
          } else {
            out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
          }
        } else {
          out += " ) { ";
          var arr2 = $deps;
          if (arr2) {
            var $propertyKey, i2 = -1, l2 = arr2.length - 1;
            while (i2 < l2) {
              $propertyKey = arr2[i2 += 1];
              var $prop = it.util.getProperty($propertyKey), $missingProperty = it.util.escapeQuotes($propertyKey), $useData = $data + $prop;
              if (it.opts._errorDataPathProperty) {
                it.errorPath = it.util.getPath($currentErrorPath, $propertyKey, it.opts.jsonPointers);
              }
              out += " if ( " + $useData + " === undefined ";
              if ($ownProperties) {
                out += " || ! Object.prototype.hasOwnProperty.call(" + $data + ", '" + it.util.escapeQuotes($propertyKey) + "') ";
              }
              out += ") {  var err =   ";
              if (it.createErrors !== false) {
                out += " { keyword: 'dependencies' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { property: '" + it.util.escapeQuotes($property) + "', missingProperty: '" + $missingProperty + "', depsCount: " + $deps.length + ", deps: '" + it.util.escapeQuotes($deps.length == 1 ? $deps[0] : $deps.join(", ")) + "' } ";
                if (it.opts.messages !== false) {
                  out += " , message: 'should have ";
                  if ($deps.length == 1) {
                    out += "property " + it.util.escapeQuotes($deps[0]);
                  } else {
                    out += "properties " + it.util.escapeQuotes($deps.join(", "));
                  }
                  out += " when property " + it.util.escapeQuotes($property) + " is present' ";
                }
                if (it.opts.verbose) {
                  out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
                }
                out += " } ";
              } else {
                out += " {} ";
              }
              out += ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; } ";
            }
          }
        }
        out += " }   ";
        if ($breakOnError) {
          $closingBraces += "}";
          out += " else { ";
        }
      }
    }
    it.errorPath = $currentErrorPath;
    var $currentBaseId = $it.baseId;
    for (var $property in $schemaDeps) {
      var $sch = $schemaDeps[$property];
      if (it.opts.strictKeywords ? typeof $sch == "object" && Object.keys($sch).length > 0 || $sch === false : it.util.schemaHasRules($sch, it.RULES.all)) {
        out += " " + $nextValid + " = true; if ( " + $data + it.util.getProperty($property) + " !== undefined ";
        if ($ownProperties) {
          out += " && Object.prototype.hasOwnProperty.call(" + $data + ", '" + it.util.escapeQuotes($property) + "') ";
        }
        out += ") { ";
        $it.schema = $sch;
        $it.schemaPath = $schemaPath + it.util.getProperty($property);
        $it.errSchemaPath = $errSchemaPath + "/" + it.util.escapeFragment($property);
        out += "  " + it.validate($it) + " ";
        $it.baseId = $currentBaseId;
        out += " }  ";
        if ($breakOnError) {
          out += " if (" + $nextValid + ") { ";
          $closingBraces += "}";
        }
      }
    }
    if ($breakOnError) {
      out += "   " + $closingBraces + " if (" + $errs + " == errors) {";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/enum.js
var require_enum = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_enum(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    var $i = "i" + $lvl, $vSchema = "schema" + $lvl;
    if (!$isData) {
      out += " var " + $vSchema + " = validate.schema" + $schemaPath + ";";
    }
    out += "var " + $valid + ";";
    if ($isData) {
      out += " if (schema" + $lvl + " === undefined) " + $valid + " = true; else if (!Array.isArray(schema" + $lvl + ")) " + $valid + " = false; else {";
    }
    out += "" + $valid + " = false;for (var " + $i + "=0; " + $i + "<" + $vSchema + ".length; " + $i + "++) if (equal(" + $data + ", " + $vSchema + "[" + $i + "])) { " + $valid + " = true; break; }";
    if ($isData) {
      out += "  }  ";
    }
    out += " if (!" + $valid + ") {   ";
    var $$outStack = $$outStack || [];
    $$outStack.push(out);
    out = "";
    if (it.createErrors !== false) {
      out += " { keyword: 'enum' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { allowedValues: schema" + $lvl + " } ";
      if (it.opts.messages !== false) {
        out += " , message: 'should be equal to one of the allowed values' ";
      }
      if (it.opts.verbose) {
        out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    var __err = out;
    out = $$outStack.pop();
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError([" + __err + "]); ";
      } else {
        out += " validate.errors = [" + __err + "]; return false; ";
      }
    } else {
      out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    }
    out += " }";
    if ($breakOnError) {
      out += " else { ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/format.js
var require_format = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_format(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    if (it.opts.format === false) {
      if ($breakOnError) {
        out += " if (true) { ";
      }
      return out;
    }
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    var $unknownFormats = it.opts.unknownFormats, $allowUnknown = Array.isArray($unknownFormats);
    if ($isData) {
      var $format = "format" + $lvl, $isObject = "isObject" + $lvl, $formatType = "formatType" + $lvl;
      out += " var " + $format + " = formats[" + $schemaValue + "]; var " + $isObject + " = typeof " + $format + " == 'object' && !(" + $format + " instanceof RegExp) && " + $format + ".validate; var " + $formatType + " = " + $isObject + " && " + $format + ".type || 'string'; if (" + $isObject + ") { ";
      if (it.async) {
        out += " var async" + $lvl + " = " + $format + ".async; ";
      }
      out += " " + $format + " = " + $format + ".validate; } if (  ";
      if ($isData) {
        out += " (" + $schemaValue + " !== undefined && typeof " + $schemaValue + " != 'string') || ";
      }
      out += " (";
      if ($unknownFormats != "ignore") {
        out += " (" + $schemaValue + " && !" + $format + " ";
        if ($allowUnknown) {
          out += " && self._opts.unknownFormats.indexOf(" + $schemaValue + ") == -1 ";
        }
        out += ") || ";
      }
      out += " (" + $format + " && " + $formatType + " == '" + $ruleType + "' && !(typeof " + $format + " == 'function' ? ";
      if (it.async) {
        out += " (async" + $lvl + " ? await " + $format + "(" + $data + ") : " + $format + "(" + $data + ")) ";
      } else {
        out += " " + $format + "(" + $data + ") ";
      }
      out += " : " + $format + ".test(" + $data + "))))) {";
    } else {
      var $format = it.formats[$schema];
      if (!$format) {
        if ($unknownFormats == "ignore") {
          it.logger.warn('unknown format "' + $schema + '" ignored in schema at path "' + it.errSchemaPath + '"');
          if ($breakOnError) {
            out += " if (true) { ";
          }
          return out;
        } else if ($allowUnknown && $unknownFormats.indexOf($schema) >= 0) {
          if ($breakOnError) {
            out += " if (true) { ";
          }
          return out;
        } else {
          throw new Error('unknown format "' + $schema + '" is used in schema at path "' + it.errSchemaPath + '"');
        }
      }
      var $isObject = typeof $format == "object" && !($format instanceof RegExp) && $format.validate;
      var $formatType = $isObject && $format.type || "string";
      if ($isObject) {
        var $async = $format.async === true;
        $format = $format.validate;
      }
      if ($formatType != $ruleType) {
        if ($breakOnError) {
          out += " if (true) { ";
        }
        return out;
      }
      if ($async) {
        if (!it.async)
          throw new Error("async format in sync schema");
        var $formatRef = "formats" + it.util.getProperty($schema) + ".validate";
        out += " if (!(await " + $formatRef + "(" + $data + "))) { ";
      } else {
        out += " if (! ";
        var $formatRef = "formats" + it.util.getProperty($schema);
        if ($isObject)
          $formatRef += ".validate";
        if (typeof $format == "function") {
          out += " " + $formatRef + "(" + $data + ") ";
        } else {
          out += " " + $formatRef + ".test(" + $data + ") ";
        }
        out += ") { ";
      }
    }
    var $$outStack = $$outStack || [];
    $$outStack.push(out);
    out = "";
    if (it.createErrors !== false) {
      out += " { keyword: 'format' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { format:  ";
      if ($isData) {
        out += "" + $schemaValue;
      } else {
        out += "" + it.util.toQuotedString($schema);
      }
      out += "  } ";
      if (it.opts.messages !== false) {
        out += ` , message: 'should match format "`;
        if ($isData) {
          out += "' + " + $schemaValue + " + '";
        } else {
          out += "" + it.util.escapeQuotes($schema);
        }
        out += `"' `;
      }
      if (it.opts.verbose) {
        out += " , schema:  ";
        if ($isData) {
          out += "validate.schema" + $schemaPath;
        } else {
          out += "" + it.util.toQuotedString($schema);
        }
        out += "         , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    var __err = out;
    out = $$outStack.pop();
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError([" + __err + "]); ";
      } else {
        out += " validate.errors = [" + __err + "]; return false; ";
      }
    } else {
      out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    }
    out += " } ";
    if ($breakOnError) {
      out += " else { ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/if.js
var require_if = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_if(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $errs = "errs__" + $lvl;
    var $it = it.util.copy(it);
    $it.level++;
    var $nextValid = "valid" + $it.level;
    var $thenSch = it.schema["then"], $elseSch = it.schema["else"], $thenPresent = $thenSch !== void 0 && (it.opts.strictKeywords ? typeof $thenSch == "object" && Object.keys($thenSch).length > 0 || $thenSch === false : it.util.schemaHasRules($thenSch, it.RULES.all)), $elsePresent = $elseSch !== void 0 && (it.opts.strictKeywords ? typeof $elseSch == "object" && Object.keys($elseSch).length > 0 || $elseSch === false : it.util.schemaHasRules($elseSch, it.RULES.all)), $currentBaseId = $it.baseId;
    if ($thenPresent || $elsePresent) {
      var $ifClause;
      $it.createErrors = false;
      $it.schema = $schema;
      $it.schemaPath = $schemaPath;
      $it.errSchemaPath = $errSchemaPath;
      out += " var " + $errs + " = errors; var " + $valid + " = true;  ";
      var $wasComposite = it.compositeRule;
      it.compositeRule = $it.compositeRule = true;
      out += "  " + it.validate($it) + " ";
      $it.baseId = $currentBaseId;
      $it.createErrors = true;
      out += "  errors = " + $errs + "; if (vErrors !== null) { if (" + $errs + ") vErrors.length = " + $errs + "; else vErrors = null; }  ";
      it.compositeRule = $it.compositeRule = $wasComposite;
      if ($thenPresent) {
        out += " if (" + $nextValid + ") {  ";
        $it.schema = it.schema["then"];
        $it.schemaPath = it.schemaPath + ".then";
        $it.errSchemaPath = it.errSchemaPath + "/then";
        out += "  " + it.validate($it) + " ";
        $it.baseId = $currentBaseId;
        out += " " + $valid + " = " + $nextValid + "; ";
        if ($thenPresent && $elsePresent) {
          $ifClause = "ifClause" + $lvl;
          out += " var " + $ifClause + " = 'then'; ";
        } else {
          $ifClause = "'then'";
        }
        out += " } ";
        if ($elsePresent) {
          out += " else { ";
        }
      } else {
        out += " if (!" + $nextValid + ") { ";
      }
      if ($elsePresent) {
        $it.schema = it.schema["else"];
        $it.schemaPath = it.schemaPath + ".else";
        $it.errSchemaPath = it.errSchemaPath + "/else";
        out += "  " + it.validate($it) + " ";
        $it.baseId = $currentBaseId;
        out += " " + $valid + " = " + $nextValid + "; ";
        if ($thenPresent && $elsePresent) {
          $ifClause = "ifClause" + $lvl;
          out += " var " + $ifClause + " = 'else'; ";
        } else {
          $ifClause = "'else'";
        }
        out += " } ";
      }
      out += " if (!" + $valid + ") {   var err =   ";
      if (it.createErrors !== false) {
        out += " { keyword: 'if' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { failingKeyword: " + $ifClause + " } ";
        if (it.opts.messages !== false) {
          out += ` , message: 'should match "' + ` + $ifClause + ` + '" schema' `;
        }
        if (it.opts.verbose) {
          out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
        }
        out += " } ";
      } else {
        out += " {} ";
      }
      out += ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
      if (!it.compositeRule && $breakOnError) {
        if (it.async) {
          out += " throw new ValidationError(vErrors); ";
        } else {
          out += " validate.errors = vErrors; return false; ";
        }
      }
      out += " }   ";
      if ($breakOnError) {
        out += " else { ";
      }
    } else {
      if ($breakOnError) {
        out += " if (true) { ";
      }
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/items.js
var require_items = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_items(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $errs = "errs__" + $lvl;
    var $it = it.util.copy(it);
    var $closingBraces = "";
    $it.level++;
    var $nextValid = "valid" + $it.level;
    var $idx = "i" + $lvl, $dataNxt = $it.dataLevel = it.dataLevel + 1, $nextData = "data" + $dataNxt, $currentBaseId = it.baseId;
    out += "var " + $errs + " = errors;var " + $valid + ";";
    if (Array.isArray($schema)) {
      var $additionalItems = it.schema.additionalItems;
      if ($additionalItems === false) {
        out += " " + $valid + " = " + $data + ".length <= " + $schema.length + "; ";
        var $currErrSchemaPath = $errSchemaPath;
        $errSchemaPath = it.errSchemaPath + "/additionalItems";
        out += "  if (!" + $valid + ") {   ";
        var $$outStack = $$outStack || [];
        $$outStack.push(out);
        out = "";
        if (it.createErrors !== false) {
          out += " { keyword: 'additionalItems' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { limit: " + $schema.length + " } ";
          if (it.opts.messages !== false) {
            out += " , message: 'should NOT have more than " + $schema.length + " items' ";
          }
          if (it.opts.verbose) {
            out += " , schema: false , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
          }
          out += " } ";
        } else {
          out += " {} ";
        }
        var __err = out;
        out = $$outStack.pop();
        if (!it.compositeRule && $breakOnError) {
          if (it.async) {
            out += " throw new ValidationError([" + __err + "]); ";
          } else {
            out += " validate.errors = [" + __err + "]; return false; ";
          }
        } else {
          out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
        }
        out += " } ";
        $errSchemaPath = $currErrSchemaPath;
        if ($breakOnError) {
          $closingBraces += "}";
          out += " else { ";
        }
      }
      var arr1 = $schema;
      if (arr1) {
        var $sch, $i = -1, l1 = arr1.length - 1;
        while ($i < l1) {
          $sch = arr1[$i += 1];
          if (it.opts.strictKeywords ? typeof $sch == "object" && Object.keys($sch).length > 0 || $sch === false : it.util.schemaHasRules($sch, it.RULES.all)) {
            out += " " + $nextValid + " = true; if (" + $data + ".length > " + $i + ") { ";
            var $passData = $data + "[" + $i + "]";
            $it.schema = $sch;
            $it.schemaPath = $schemaPath + "[" + $i + "]";
            $it.errSchemaPath = $errSchemaPath + "/" + $i;
            $it.errorPath = it.util.getPathExpr(it.errorPath, $i, it.opts.jsonPointers, true);
            $it.dataPathArr[$dataNxt] = $i;
            var $code = it.validate($it);
            $it.baseId = $currentBaseId;
            if (it.util.varOccurences($code, $nextData) < 2) {
              out += " " + it.util.varReplace($code, $nextData, $passData) + " ";
            } else {
              out += " var " + $nextData + " = " + $passData + "; " + $code + " ";
            }
            out += " }  ";
            if ($breakOnError) {
              out += " if (" + $nextValid + ") { ";
              $closingBraces += "}";
            }
          }
        }
      }
      if (typeof $additionalItems == "object" && (it.opts.strictKeywords ? typeof $additionalItems == "object" && Object.keys($additionalItems).length > 0 || $additionalItems === false : it.util.schemaHasRules($additionalItems, it.RULES.all))) {
        $it.schema = $additionalItems;
        $it.schemaPath = it.schemaPath + ".additionalItems";
        $it.errSchemaPath = it.errSchemaPath + "/additionalItems";
        out += " " + $nextValid + " = true; if (" + $data + ".length > " + $schema.length + ") {  for (var " + $idx + " = " + $schema.length + "; " + $idx + " < " + $data + ".length; " + $idx + "++) { ";
        $it.errorPath = it.util.getPathExpr(it.errorPath, $idx, it.opts.jsonPointers, true);
        var $passData = $data + "[" + $idx + "]";
        $it.dataPathArr[$dataNxt] = $idx;
        var $code = it.validate($it);
        $it.baseId = $currentBaseId;
        if (it.util.varOccurences($code, $nextData) < 2) {
          out += " " + it.util.varReplace($code, $nextData, $passData) + " ";
        } else {
          out += " var " + $nextData + " = " + $passData + "; " + $code + " ";
        }
        if ($breakOnError) {
          out += " if (!" + $nextValid + ") break; ";
        }
        out += " } }  ";
        if ($breakOnError) {
          out += " if (" + $nextValid + ") { ";
          $closingBraces += "}";
        }
      }
    } else if (it.opts.strictKeywords ? typeof $schema == "object" && Object.keys($schema).length > 0 || $schema === false : it.util.schemaHasRules($schema, it.RULES.all)) {
      $it.schema = $schema;
      $it.schemaPath = $schemaPath;
      $it.errSchemaPath = $errSchemaPath;
      out += "  for (var " + $idx + " = " + 0 + "; " + $idx + " < " + $data + ".length; " + $idx + "++) { ";
      $it.errorPath = it.util.getPathExpr(it.errorPath, $idx, it.opts.jsonPointers, true);
      var $passData = $data + "[" + $idx + "]";
      $it.dataPathArr[$dataNxt] = $idx;
      var $code = it.validate($it);
      $it.baseId = $currentBaseId;
      if (it.util.varOccurences($code, $nextData) < 2) {
        out += " " + it.util.varReplace($code, $nextData, $passData) + " ";
      } else {
        out += " var " + $nextData + " = " + $passData + "; " + $code + " ";
      }
      if ($breakOnError) {
        out += " if (!" + $nextValid + ") break; ";
      }
      out += " }";
    }
    if ($breakOnError) {
      out += " " + $closingBraces + " if (" + $errs + " == errors) {";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/_limit.js
var require_limit = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate__limit(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $errorKeyword;
    var $data = "data" + ($dataLvl || "");
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    var $isMax = $keyword == "maximum", $exclusiveKeyword = $isMax ? "exclusiveMaximum" : "exclusiveMinimum", $schemaExcl = it.schema[$exclusiveKeyword], $isDataExcl = it.opts.$data && $schemaExcl && $schemaExcl.$data, $op = $isMax ? "<" : ">", $notOp = $isMax ? ">" : "<", $errorKeyword = void 0;
    if (!($isData || typeof $schema == "number" || $schema === void 0)) {
      throw new Error($keyword + " must be number");
    }
    if (!($isDataExcl || $schemaExcl === void 0 || typeof $schemaExcl == "number" || typeof $schemaExcl == "boolean")) {
      throw new Error($exclusiveKeyword + " must be number or boolean");
    }
    if ($isDataExcl) {
      var $schemaValueExcl = it.util.getData($schemaExcl.$data, $dataLvl, it.dataPathArr), $exclusive = "exclusive" + $lvl, $exclType = "exclType" + $lvl, $exclIsNumber = "exclIsNumber" + $lvl, $opExpr = "op" + $lvl, $opStr = "' + " + $opExpr + " + '";
      out += " var schemaExcl" + $lvl + " = " + $schemaValueExcl + "; ";
      $schemaValueExcl = "schemaExcl" + $lvl;
      out += " var " + $exclusive + "; var " + $exclType + " = typeof " + $schemaValueExcl + "; if (" + $exclType + " != 'boolean' && " + $exclType + " != 'undefined' && " + $exclType + " != 'number') { ";
      var $errorKeyword = $exclusiveKeyword;
      var $$outStack = $$outStack || [];
      $$outStack.push(out);
      out = "";
      if (it.createErrors !== false) {
        out += " { keyword: '" + ($errorKeyword || "_exclusiveLimit") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: {} ";
        if (it.opts.messages !== false) {
          out += " , message: '" + $exclusiveKeyword + " should be boolean' ";
        }
        if (it.opts.verbose) {
          out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
        }
        out += " } ";
      } else {
        out += " {} ";
      }
      var __err = out;
      out = $$outStack.pop();
      if (!it.compositeRule && $breakOnError) {
        if (it.async) {
          out += " throw new ValidationError([" + __err + "]); ";
        } else {
          out += " validate.errors = [" + __err + "]; return false; ";
        }
      } else {
        out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
      }
      out += " } else if ( ";
      if ($isData) {
        out += " (" + $schemaValue + " !== undefined && typeof " + $schemaValue + " != 'number') || ";
      }
      out += " " + $exclType + " == 'number' ? ( (" + $exclusive + " = " + $schemaValue + " === undefined || " + $schemaValueExcl + " " + $op + "= " + $schemaValue + ") ? " + $data + " " + $notOp + "= " + $schemaValueExcl + " : " + $data + " " + $notOp + " " + $schemaValue + " ) : ( (" + $exclusive + " = " + $schemaValueExcl + " === true) ? " + $data + " " + $notOp + "= " + $schemaValue + " : " + $data + " " + $notOp + " " + $schemaValue + " ) || " + $data + " !== " + $data + ") { var op" + $lvl + " = " + $exclusive + " ? '" + $op + "' : '" + $op + "='; ";
      if ($schema === void 0) {
        $errorKeyword = $exclusiveKeyword;
        $errSchemaPath = it.errSchemaPath + "/" + $exclusiveKeyword;
        $schemaValue = $schemaValueExcl;
        $isData = $isDataExcl;
      }
    } else {
      var $exclIsNumber = typeof $schemaExcl == "number", $opStr = $op;
      if ($exclIsNumber && $isData) {
        var $opExpr = "'" + $opStr + "'";
        out += " if ( ";
        if ($isData) {
          out += " (" + $schemaValue + " !== undefined && typeof " + $schemaValue + " != 'number') || ";
        }
        out += " ( " + $schemaValue + " === undefined || " + $schemaExcl + " " + $op + "= " + $schemaValue + " ? " + $data + " " + $notOp + "= " + $schemaExcl + " : " + $data + " " + $notOp + " " + $schemaValue + " ) || " + $data + " !== " + $data + ") { ";
      } else {
        if ($exclIsNumber && $schema === void 0) {
          $exclusive = true;
          $errorKeyword = $exclusiveKeyword;
          $errSchemaPath = it.errSchemaPath + "/" + $exclusiveKeyword;
          $schemaValue = $schemaExcl;
          $notOp += "=";
        } else {
          if ($exclIsNumber)
            $schemaValue = Math[$isMax ? "min" : "max"]($schemaExcl, $schema);
          if ($schemaExcl === ($exclIsNumber ? $schemaValue : true)) {
            $exclusive = true;
            $errorKeyword = $exclusiveKeyword;
            $errSchemaPath = it.errSchemaPath + "/" + $exclusiveKeyword;
            $notOp += "=";
          } else {
            $exclusive = false;
            $opStr += "=";
          }
        }
        var $opExpr = "'" + $opStr + "'";
        out += " if ( ";
        if ($isData) {
          out += " (" + $schemaValue + " !== undefined && typeof " + $schemaValue + " != 'number') || ";
        }
        out += " " + $data + " " + $notOp + " " + $schemaValue + " || " + $data + " !== " + $data + ") { ";
      }
    }
    $errorKeyword = $errorKeyword || $keyword;
    var $$outStack = $$outStack || [];
    $$outStack.push(out);
    out = "";
    if (it.createErrors !== false) {
      out += " { keyword: '" + ($errorKeyword || "_limit") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { comparison: " + $opExpr + ", limit: " + $schemaValue + ", exclusive: " + $exclusive + " } ";
      if (it.opts.messages !== false) {
        out += " , message: 'should be " + $opStr + " ";
        if ($isData) {
          out += "' + " + $schemaValue;
        } else {
          out += "" + $schemaValue + "'";
        }
      }
      if (it.opts.verbose) {
        out += " , schema:  ";
        if ($isData) {
          out += "validate.schema" + $schemaPath;
        } else {
          out += "" + $schema;
        }
        out += "         , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    var __err = out;
    out = $$outStack.pop();
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError([" + __err + "]); ";
      } else {
        out += " validate.errors = [" + __err + "]; return false; ";
      }
    } else {
      out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    }
    out += " } ";
    if ($breakOnError) {
      out += " else { ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/_limitItems.js
var require_limitItems = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate__limitItems(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $errorKeyword;
    var $data = "data" + ($dataLvl || "");
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    if (!($isData || typeof $schema == "number")) {
      throw new Error($keyword + " must be number");
    }
    var $op = $keyword == "maxItems" ? ">" : "<";
    out += "if ( ";
    if ($isData) {
      out += " (" + $schemaValue + " !== undefined && typeof " + $schemaValue + " != 'number') || ";
    }
    out += " " + $data + ".length " + $op + " " + $schemaValue + ") { ";
    var $errorKeyword = $keyword;
    var $$outStack = $$outStack || [];
    $$outStack.push(out);
    out = "";
    if (it.createErrors !== false) {
      out += " { keyword: '" + ($errorKeyword || "_limitItems") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { limit: " + $schemaValue + " } ";
      if (it.opts.messages !== false) {
        out += " , message: 'should NOT have ";
        if ($keyword == "maxItems") {
          out += "more";
        } else {
          out += "fewer";
        }
        out += " than ";
        if ($isData) {
          out += "' + " + $schemaValue + " + '";
        } else {
          out += "" + $schema;
        }
        out += " items' ";
      }
      if (it.opts.verbose) {
        out += " , schema:  ";
        if ($isData) {
          out += "validate.schema" + $schemaPath;
        } else {
          out += "" + $schema;
        }
        out += "         , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    var __err = out;
    out = $$outStack.pop();
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError([" + __err + "]); ";
      } else {
        out += " validate.errors = [" + __err + "]; return false; ";
      }
    } else {
      out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    }
    out += "} ";
    if ($breakOnError) {
      out += " else { ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/_limitLength.js
var require_limitLength = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate__limitLength(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $errorKeyword;
    var $data = "data" + ($dataLvl || "");
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    if (!($isData || typeof $schema == "number")) {
      throw new Error($keyword + " must be number");
    }
    var $op = $keyword == "maxLength" ? ">" : "<";
    out += "if ( ";
    if ($isData) {
      out += " (" + $schemaValue + " !== undefined && typeof " + $schemaValue + " != 'number') || ";
    }
    if (it.opts.unicode === false) {
      out += " " + $data + ".length ";
    } else {
      out += " ucs2length(" + $data + ") ";
    }
    out += " " + $op + " " + $schemaValue + ") { ";
    var $errorKeyword = $keyword;
    var $$outStack = $$outStack || [];
    $$outStack.push(out);
    out = "";
    if (it.createErrors !== false) {
      out += " { keyword: '" + ($errorKeyword || "_limitLength") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { limit: " + $schemaValue + " } ";
      if (it.opts.messages !== false) {
        out += " , message: 'should NOT be ";
        if ($keyword == "maxLength") {
          out += "longer";
        } else {
          out += "shorter";
        }
        out += " than ";
        if ($isData) {
          out += "' + " + $schemaValue + " + '";
        } else {
          out += "" + $schema;
        }
        out += " characters' ";
      }
      if (it.opts.verbose) {
        out += " , schema:  ";
        if ($isData) {
          out += "validate.schema" + $schemaPath;
        } else {
          out += "" + $schema;
        }
        out += "         , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    var __err = out;
    out = $$outStack.pop();
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError([" + __err + "]); ";
      } else {
        out += " validate.errors = [" + __err + "]; return false; ";
      }
    } else {
      out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    }
    out += "} ";
    if ($breakOnError) {
      out += " else { ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/_limitProperties.js
var require_limitProperties = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate__limitProperties(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $errorKeyword;
    var $data = "data" + ($dataLvl || "");
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    if (!($isData || typeof $schema == "number")) {
      throw new Error($keyword + " must be number");
    }
    var $op = $keyword == "maxProperties" ? ">" : "<";
    out += "if ( ";
    if ($isData) {
      out += " (" + $schemaValue + " !== undefined && typeof " + $schemaValue + " != 'number') || ";
    }
    out += " Object.keys(" + $data + ").length " + $op + " " + $schemaValue + ") { ";
    var $errorKeyword = $keyword;
    var $$outStack = $$outStack || [];
    $$outStack.push(out);
    out = "";
    if (it.createErrors !== false) {
      out += " { keyword: '" + ($errorKeyword || "_limitProperties") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { limit: " + $schemaValue + " } ";
      if (it.opts.messages !== false) {
        out += " , message: 'should NOT have ";
        if ($keyword == "maxProperties") {
          out += "more";
        } else {
          out += "fewer";
        }
        out += " than ";
        if ($isData) {
          out += "' + " + $schemaValue + " + '";
        } else {
          out += "" + $schema;
        }
        out += " properties' ";
      }
      if (it.opts.verbose) {
        out += " , schema:  ";
        if ($isData) {
          out += "validate.schema" + $schemaPath;
        } else {
          out += "" + $schema;
        }
        out += "         , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    var __err = out;
    out = $$outStack.pop();
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError([" + __err + "]); ";
      } else {
        out += " validate.errors = [" + __err + "]; return false; ";
      }
    } else {
      out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    }
    out += "} ";
    if ($breakOnError) {
      out += " else { ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/multipleOf.js
var require_multipleOf = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_multipleOf(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    if (!($isData || typeof $schema == "number")) {
      throw new Error($keyword + " must be number");
    }
    out += "var division" + $lvl + ";if (";
    if ($isData) {
      out += " " + $schemaValue + " !== undefined && ( typeof " + $schemaValue + " != 'number' || ";
    }
    out += " (division" + $lvl + " = " + $data + " / " + $schemaValue + ", ";
    if (it.opts.multipleOfPrecision) {
      out += " Math.abs(Math.round(division" + $lvl + ") - division" + $lvl + ") > 1e-" + it.opts.multipleOfPrecision + " ";
    } else {
      out += " division" + $lvl + " !== parseInt(division" + $lvl + ") ";
    }
    out += " ) ";
    if ($isData) {
      out += "  )  ";
    }
    out += " ) {   ";
    var $$outStack = $$outStack || [];
    $$outStack.push(out);
    out = "";
    if (it.createErrors !== false) {
      out += " { keyword: 'multipleOf' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { multipleOf: " + $schemaValue + " } ";
      if (it.opts.messages !== false) {
        out += " , message: 'should be multiple of ";
        if ($isData) {
          out += "' + " + $schemaValue;
        } else {
          out += "" + $schemaValue + "'";
        }
      }
      if (it.opts.verbose) {
        out += " , schema:  ";
        if ($isData) {
          out += "validate.schema" + $schemaPath;
        } else {
          out += "" + $schema;
        }
        out += "         , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    var __err = out;
    out = $$outStack.pop();
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError([" + __err + "]); ";
      } else {
        out += " validate.errors = [" + __err + "]; return false; ";
      }
    } else {
      out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    }
    out += "} ";
    if ($breakOnError) {
      out += " else { ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/not.js
var require_not = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_not(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $errs = "errs__" + $lvl;
    var $it = it.util.copy(it);
    $it.level++;
    var $nextValid = "valid" + $it.level;
    if (it.opts.strictKeywords ? typeof $schema == "object" && Object.keys($schema).length > 0 || $schema === false : it.util.schemaHasRules($schema, it.RULES.all)) {
      $it.schema = $schema;
      $it.schemaPath = $schemaPath;
      $it.errSchemaPath = $errSchemaPath;
      out += " var " + $errs + " = errors;  ";
      var $wasComposite = it.compositeRule;
      it.compositeRule = $it.compositeRule = true;
      $it.createErrors = false;
      var $allErrorsOption;
      if ($it.opts.allErrors) {
        $allErrorsOption = $it.opts.allErrors;
        $it.opts.allErrors = false;
      }
      out += " " + it.validate($it) + " ";
      $it.createErrors = true;
      if ($allErrorsOption)
        $it.opts.allErrors = $allErrorsOption;
      it.compositeRule = $it.compositeRule = $wasComposite;
      out += " if (" + $nextValid + ") {   ";
      var $$outStack = $$outStack || [];
      $$outStack.push(out);
      out = "";
      if (it.createErrors !== false) {
        out += " { keyword: 'not' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: {} ";
        if (it.opts.messages !== false) {
          out += " , message: 'should NOT be valid' ";
        }
        if (it.opts.verbose) {
          out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
        }
        out += " } ";
      } else {
        out += " {} ";
      }
      var __err = out;
      out = $$outStack.pop();
      if (!it.compositeRule && $breakOnError) {
        if (it.async) {
          out += " throw new ValidationError([" + __err + "]); ";
        } else {
          out += " validate.errors = [" + __err + "]; return false; ";
        }
      } else {
        out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
      }
      out += " } else {  errors = " + $errs + "; if (vErrors !== null) { if (" + $errs + ") vErrors.length = " + $errs + "; else vErrors = null; } ";
      if (it.opts.allErrors) {
        out += " } ";
      }
    } else {
      out += "  var err =   ";
      if (it.createErrors !== false) {
        out += " { keyword: 'not' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: {} ";
        if (it.opts.messages !== false) {
          out += " , message: 'should NOT be valid' ";
        }
        if (it.opts.verbose) {
          out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
        }
        out += " } ";
      } else {
        out += " {} ";
      }
      out += ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
      if ($breakOnError) {
        out += " if (false) { ";
      }
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/oneOf.js
var require_oneOf = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_oneOf(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $errs = "errs__" + $lvl;
    var $it = it.util.copy(it);
    var $closingBraces = "";
    $it.level++;
    var $nextValid = "valid" + $it.level;
    var $currentBaseId = $it.baseId, $prevValid = "prevValid" + $lvl, $passingSchemas = "passingSchemas" + $lvl;
    out += "var " + $errs + " = errors , " + $prevValid + " = false , " + $valid + " = false , " + $passingSchemas + " = null; ";
    var $wasComposite = it.compositeRule;
    it.compositeRule = $it.compositeRule = true;
    var arr1 = $schema;
    if (arr1) {
      var $sch, $i = -1, l1 = arr1.length - 1;
      while ($i < l1) {
        $sch = arr1[$i += 1];
        if (it.opts.strictKeywords ? typeof $sch == "object" && Object.keys($sch).length > 0 || $sch === false : it.util.schemaHasRules($sch, it.RULES.all)) {
          $it.schema = $sch;
          $it.schemaPath = $schemaPath + "[" + $i + "]";
          $it.errSchemaPath = $errSchemaPath + "/" + $i;
          out += "  " + it.validate($it) + " ";
          $it.baseId = $currentBaseId;
        } else {
          out += " var " + $nextValid + " = true; ";
        }
        if ($i) {
          out += " if (" + $nextValid + " && " + $prevValid + ") { " + $valid + " = false; " + $passingSchemas + " = [" + $passingSchemas + ", " + $i + "]; } else { ";
          $closingBraces += "}";
        }
        out += " if (" + $nextValid + ") { " + $valid + " = " + $prevValid + " = true; " + $passingSchemas + " = " + $i + "; }";
      }
    }
    it.compositeRule = $it.compositeRule = $wasComposite;
    out += "" + $closingBraces + "if (!" + $valid + ") {   var err =   ";
    if (it.createErrors !== false) {
      out += " { keyword: 'oneOf' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { passingSchemas: " + $passingSchemas + " } ";
      if (it.opts.messages !== false) {
        out += " , message: 'should match exactly one schema in oneOf' ";
      }
      if (it.opts.verbose) {
        out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    out += ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError(vErrors); ";
      } else {
        out += " validate.errors = vErrors; return false; ";
      }
    }
    out += "} else {  errors = " + $errs + "; if (vErrors !== null) { if (" + $errs + ") vErrors.length = " + $errs + "; else vErrors = null; }";
    if (it.opts.allErrors) {
      out += " } ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/pattern.js
var require_pattern = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_pattern(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    var $regexp = $isData ? "(new RegExp(" + $schemaValue + "))" : it.usePattern($schema);
    out += "if ( ";
    if ($isData) {
      out += " (" + $schemaValue + " !== undefined && typeof " + $schemaValue + " != 'string') || ";
    }
    out += " !" + $regexp + ".test(" + $data + ") ) {   ";
    var $$outStack = $$outStack || [];
    $$outStack.push(out);
    out = "";
    if (it.createErrors !== false) {
      out += " { keyword: 'pattern' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { pattern:  ";
      if ($isData) {
        out += "" + $schemaValue;
      } else {
        out += "" + it.util.toQuotedString($schema);
      }
      out += "  } ";
      if (it.opts.messages !== false) {
        out += ` , message: 'should match pattern "`;
        if ($isData) {
          out += "' + " + $schemaValue + " + '";
        } else {
          out += "" + it.util.escapeQuotes($schema);
        }
        out += `"' `;
      }
      if (it.opts.verbose) {
        out += " , schema:  ";
        if ($isData) {
          out += "validate.schema" + $schemaPath;
        } else {
          out += "" + it.util.toQuotedString($schema);
        }
        out += "         , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
      }
      out += " } ";
    } else {
      out += " {} ";
    }
    var __err = out;
    out = $$outStack.pop();
    if (!it.compositeRule && $breakOnError) {
      if (it.async) {
        out += " throw new ValidationError([" + __err + "]); ";
      } else {
        out += " validate.errors = [" + __err + "]; return false; ";
      }
    } else {
      out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
    }
    out += "} ";
    if ($breakOnError) {
      out += " else { ";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/properties.js
var require_properties = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_properties(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $errs = "errs__" + $lvl;
    var $it = it.util.copy(it);
    var $closingBraces = "";
    $it.level++;
    var $nextValid = "valid" + $it.level;
    var $key = "key" + $lvl, $idx = "idx" + $lvl, $dataNxt = $it.dataLevel = it.dataLevel + 1, $nextData = "data" + $dataNxt, $dataProperties = "dataProperties" + $lvl;
    var $schemaKeys = Object.keys($schema || {}).filter(notProto), $pProperties = it.schema.patternProperties || {}, $pPropertyKeys = Object.keys($pProperties).filter(notProto), $aProperties = it.schema.additionalProperties, $someProperties = $schemaKeys.length || $pPropertyKeys.length, $noAdditional = $aProperties === false, $additionalIsSchema = typeof $aProperties == "object" && Object.keys($aProperties).length, $removeAdditional = it.opts.removeAdditional, $checkAdditional = $noAdditional || $additionalIsSchema || $removeAdditional, $ownProperties = it.opts.ownProperties, $currentBaseId = it.baseId;
    var $required = it.schema.required;
    if ($required && !(it.opts.$data && $required.$data) && $required.length < it.opts.loopRequired) {
      var $requiredHash = it.util.toHash($required);
    }
    function notProto(p) {
      return p !== "__proto__";
    }
    out += "var " + $errs + " = errors;var " + $nextValid + " = true;";
    if ($ownProperties) {
      out += " var " + $dataProperties + " = undefined;";
    }
    if ($checkAdditional) {
      if ($ownProperties) {
        out += " " + $dataProperties + " = " + $dataProperties + " || Object.keys(" + $data + "); for (var " + $idx + "=0; " + $idx + "<" + $dataProperties + ".length; " + $idx + "++) { var " + $key + " = " + $dataProperties + "[" + $idx + "]; ";
      } else {
        out += " for (var " + $key + " in " + $data + ") { ";
      }
      if ($someProperties) {
        out += " var isAdditional" + $lvl + " = !(false ";
        if ($schemaKeys.length) {
          if ($schemaKeys.length > 8) {
            out += " || validate.schema" + $schemaPath + ".hasOwnProperty(" + $key + ") ";
          } else {
            var arr1 = $schemaKeys;
            if (arr1) {
              var $propertyKey, i1 = -1, l1 = arr1.length - 1;
              while (i1 < l1) {
                $propertyKey = arr1[i1 += 1];
                out += " || " + $key + " == " + it.util.toQuotedString($propertyKey) + " ";
              }
            }
          }
        }
        if ($pPropertyKeys.length) {
          var arr2 = $pPropertyKeys;
          if (arr2) {
            var $pProperty, $i = -1, l2 = arr2.length - 1;
            while ($i < l2) {
              $pProperty = arr2[$i += 1];
              out += " || " + it.usePattern($pProperty) + ".test(" + $key + ") ";
            }
          }
        }
        out += " ); if (isAdditional" + $lvl + ") { ";
      }
      if ($removeAdditional == "all") {
        out += " delete " + $data + "[" + $key + "]; ";
      } else {
        var $currentErrorPath = it.errorPath;
        var $additionalProperty = "' + " + $key + " + '";
        if (it.opts._errorDataPathProperty) {
          it.errorPath = it.util.getPathExpr(it.errorPath, $key, it.opts.jsonPointers);
        }
        if ($noAdditional) {
          if ($removeAdditional) {
            out += " delete " + $data + "[" + $key + "]; ";
          } else {
            out += " " + $nextValid + " = false; ";
            var $currErrSchemaPath = $errSchemaPath;
            $errSchemaPath = it.errSchemaPath + "/additionalProperties";
            var $$outStack = $$outStack || [];
            $$outStack.push(out);
            out = "";
            if (it.createErrors !== false) {
              out += " { keyword: 'additionalProperties' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { additionalProperty: '" + $additionalProperty + "' } ";
              if (it.opts.messages !== false) {
                out += " , message: '";
                if (it.opts._errorDataPathProperty) {
                  out += "is an invalid additional property";
                } else {
                  out += "should NOT have additional properties";
                }
                out += "' ";
              }
              if (it.opts.verbose) {
                out += " , schema: false , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
              }
              out += " } ";
            } else {
              out += " {} ";
            }
            var __err = out;
            out = $$outStack.pop();
            if (!it.compositeRule && $breakOnError) {
              if (it.async) {
                out += " throw new ValidationError([" + __err + "]); ";
              } else {
                out += " validate.errors = [" + __err + "]; return false; ";
              }
            } else {
              out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
            }
            $errSchemaPath = $currErrSchemaPath;
            if ($breakOnError) {
              out += " break; ";
            }
          }
        } else if ($additionalIsSchema) {
          if ($removeAdditional == "failing") {
            out += " var " + $errs + " = errors;  ";
            var $wasComposite = it.compositeRule;
            it.compositeRule = $it.compositeRule = true;
            $it.schema = $aProperties;
            $it.schemaPath = it.schemaPath + ".additionalProperties";
            $it.errSchemaPath = it.errSchemaPath + "/additionalProperties";
            $it.errorPath = it.opts._errorDataPathProperty ? it.errorPath : it.util.getPathExpr(it.errorPath, $key, it.opts.jsonPointers);
            var $passData = $data + "[" + $key + "]";
            $it.dataPathArr[$dataNxt] = $key;
            var $code = it.validate($it);
            $it.baseId = $currentBaseId;
            if (it.util.varOccurences($code, $nextData) < 2) {
              out += " " + it.util.varReplace($code, $nextData, $passData) + " ";
            } else {
              out += " var " + $nextData + " = " + $passData + "; " + $code + " ";
            }
            out += " if (!" + $nextValid + ") { errors = " + $errs + "; if (validate.errors !== null) { if (errors) validate.errors.length = errors; else validate.errors = null; } delete " + $data + "[" + $key + "]; }  ";
            it.compositeRule = $it.compositeRule = $wasComposite;
          } else {
            $it.schema = $aProperties;
            $it.schemaPath = it.schemaPath + ".additionalProperties";
            $it.errSchemaPath = it.errSchemaPath + "/additionalProperties";
            $it.errorPath = it.opts._errorDataPathProperty ? it.errorPath : it.util.getPathExpr(it.errorPath, $key, it.opts.jsonPointers);
            var $passData = $data + "[" + $key + "]";
            $it.dataPathArr[$dataNxt] = $key;
            var $code = it.validate($it);
            $it.baseId = $currentBaseId;
            if (it.util.varOccurences($code, $nextData) < 2) {
              out += " " + it.util.varReplace($code, $nextData, $passData) + " ";
            } else {
              out += " var " + $nextData + " = " + $passData + "; " + $code + " ";
            }
            if ($breakOnError) {
              out += " if (!" + $nextValid + ") break; ";
            }
          }
        }
        it.errorPath = $currentErrorPath;
      }
      if ($someProperties) {
        out += " } ";
      }
      out += " }  ";
      if ($breakOnError) {
        out += " if (" + $nextValid + ") { ";
        $closingBraces += "}";
      }
    }
    var $useDefaults = it.opts.useDefaults && !it.compositeRule;
    if ($schemaKeys.length) {
      var arr3 = $schemaKeys;
      if (arr3) {
        var $propertyKey, i3 = -1, l3 = arr3.length - 1;
        while (i3 < l3) {
          $propertyKey = arr3[i3 += 1];
          var $sch = $schema[$propertyKey];
          if (it.opts.strictKeywords ? typeof $sch == "object" && Object.keys($sch).length > 0 || $sch === false : it.util.schemaHasRules($sch, it.RULES.all)) {
            var $prop = it.util.getProperty($propertyKey), $passData = $data + $prop, $hasDefault = $useDefaults && $sch.default !== void 0;
            $it.schema = $sch;
            $it.schemaPath = $schemaPath + $prop;
            $it.errSchemaPath = $errSchemaPath + "/" + it.util.escapeFragment($propertyKey);
            $it.errorPath = it.util.getPath(it.errorPath, $propertyKey, it.opts.jsonPointers);
            $it.dataPathArr[$dataNxt] = it.util.toQuotedString($propertyKey);
            var $code = it.validate($it);
            $it.baseId = $currentBaseId;
            if (it.util.varOccurences($code, $nextData) < 2) {
              $code = it.util.varReplace($code, $nextData, $passData);
              var $useData = $passData;
            } else {
              var $useData = $nextData;
              out += " var " + $nextData + " = " + $passData + "; ";
            }
            if ($hasDefault) {
              out += " " + $code + " ";
            } else {
              if ($requiredHash && $requiredHash[$propertyKey]) {
                out += " if ( " + $useData + " === undefined ";
                if ($ownProperties) {
                  out += " || ! Object.prototype.hasOwnProperty.call(" + $data + ", '" + it.util.escapeQuotes($propertyKey) + "') ";
                }
                out += ") { " + $nextValid + " = false; ";
                var $currentErrorPath = it.errorPath, $currErrSchemaPath = $errSchemaPath, $missingProperty = it.util.escapeQuotes($propertyKey);
                if (it.opts._errorDataPathProperty) {
                  it.errorPath = it.util.getPath($currentErrorPath, $propertyKey, it.opts.jsonPointers);
                }
                $errSchemaPath = it.errSchemaPath + "/required";
                var $$outStack = $$outStack || [];
                $$outStack.push(out);
                out = "";
                if (it.createErrors !== false) {
                  out += " { keyword: 'required' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { missingProperty: '" + $missingProperty + "' } ";
                  if (it.opts.messages !== false) {
                    out += " , message: '";
                    if (it.opts._errorDataPathProperty) {
                      out += "is a required property";
                    } else {
                      out += "should have required property \\'" + $missingProperty + "\\'";
                    }
                    out += "' ";
                  }
                  if (it.opts.verbose) {
                    out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
                  }
                  out += " } ";
                } else {
                  out += " {} ";
                }
                var __err = out;
                out = $$outStack.pop();
                if (!it.compositeRule && $breakOnError) {
                  if (it.async) {
                    out += " throw new ValidationError([" + __err + "]); ";
                  } else {
                    out += " validate.errors = [" + __err + "]; return false; ";
                  }
                } else {
                  out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
                }
                $errSchemaPath = $currErrSchemaPath;
                it.errorPath = $currentErrorPath;
                out += " } else { ";
              } else {
                if ($breakOnError) {
                  out += " if ( " + $useData + " === undefined ";
                  if ($ownProperties) {
                    out += " || ! Object.prototype.hasOwnProperty.call(" + $data + ", '" + it.util.escapeQuotes($propertyKey) + "') ";
                  }
                  out += ") { " + $nextValid + " = true; } else { ";
                } else {
                  out += " if (" + $useData + " !== undefined ";
                  if ($ownProperties) {
                    out += " &&   Object.prototype.hasOwnProperty.call(" + $data + ", '" + it.util.escapeQuotes($propertyKey) + "') ";
                  }
                  out += " ) { ";
                }
              }
              out += " " + $code + " } ";
            }
          }
          if ($breakOnError) {
            out += " if (" + $nextValid + ") { ";
            $closingBraces += "}";
          }
        }
      }
    }
    if ($pPropertyKeys.length) {
      var arr4 = $pPropertyKeys;
      if (arr4) {
        var $pProperty, i4 = -1, l4 = arr4.length - 1;
        while (i4 < l4) {
          $pProperty = arr4[i4 += 1];
          var $sch = $pProperties[$pProperty];
          if (it.opts.strictKeywords ? typeof $sch == "object" && Object.keys($sch).length > 0 || $sch === false : it.util.schemaHasRules($sch, it.RULES.all)) {
            $it.schema = $sch;
            $it.schemaPath = it.schemaPath + ".patternProperties" + it.util.getProperty($pProperty);
            $it.errSchemaPath = it.errSchemaPath + "/patternProperties/" + it.util.escapeFragment($pProperty);
            if ($ownProperties) {
              out += " " + $dataProperties + " = " + $dataProperties + " || Object.keys(" + $data + "); for (var " + $idx + "=0; " + $idx + "<" + $dataProperties + ".length; " + $idx + "++) { var " + $key + " = " + $dataProperties + "[" + $idx + "]; ";
            } else {
              out += " for (var " + $key + " in " + $data + ") { ";
            }
            out += " if (" + it.usePattern($pProperty) + ".test(" + $key + ")) { ";
            $it.errorPath = it.util.getPathExpr(it.errorPath, $key, it.opts.jsonPointers);
            var $passData = $data + "[" + $key + "]";
            $it.dataPathArr[$dataNxt] = $key;
            var $code = it.validate($it);
            $it.baseId = $currentBaseId;
            if (it.util.varOccurences($code, $nextData) < 2) {
              out += " " + it.util.varReplace($code, $nextData, $passData) + " ";
            } else {
              out += " var " + $nextData + " = " + $passData + "; " + $code + " ";
            }
            if ($breakOnError) {
              out += " if (!" + $nextValid + ") break; ";
            }
            out += " } ";
            if ($breakOnError) {
              out += " else " + $nextValid + " = true; ";
            }
            out += " }  ";
            if ($breakOnError) {
              out += " if (" + $nextValid + ") { ";
              $closingBraces += "}";
            }
          }
        }
      }
    }
    if ($breakOnError) {
      out += " " + $closingBraces + " if (" + $errs + " == errors) {";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/propertyNames.js
var require_propertyNames = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_propertyNames(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $errs = "errs__" + $lvl;
    var $it = it.util.copy(it);
    var $closingBraces = "";
    $it.level++;
    var $nextValid = "valid" + $it.level;
    out += "var " + $errs + " = errors;";
    if (it.opts.strictKeywords ? typeof $schema == "object" && Object.keys($schema).length > 0 || $schema === false : it.util.schemaHasRules($schema, it.RULES.all)) {
      $it.schema = $schema;
      $it.schemaPath = $schemaPath;
      $it.errSchemaPath = $errSchemaPath;
      var $key = "key" + $lvl, $idx = "idx" + $lvl, $i = "i" + $lvl, $invalidName = "' + " + $key + " + '", $dataNxt = $it.dataLevel = it.dataLevel + 1, $nextData = "data" + $dataNxt, $dataProperties = "dataProperties" + $lvl, $ownProperties = it.opts.ownProperties, $currentBaseId = it.baseId;
      if ($ownProperties) {
        out += " var " + $dataProperties + " = undefined; ";
      }
      if ($ownProperties) {
        out += " " + $dataProperties + " = " + $dataProperties + " || Object.keys(" + $data + "); for (var " + $idx + "=0; " + $idx + "<" + $dataProperties + ".length; " + $idx + "++) { var " + $key + " = " + $dataProperties + "[" + $idx + "]; ";
      } else {
        out += " for (var " + $key + " in " + $data + ") { ";
      }
      out += " var startErrs" + $lvl + " = errors; ";
      var $passData = $key;
      var $wasComposite = it.compositeRule;
      it.compositeRule = $it.compositeRule = true;
      var $code = it.validate($it);
      $it.baseId = $currentBaseId;
      if (it.util.varOccurences($code, $nextData) < 2) {
        out += " " + it.util.varReplace($code, $nextData, $passData) + " ";
      } else {
        out += " var " + $nextData + " = " + $passData + "; " + $code + " ";
      }
      it.compositeRule = $it.compositeRule = $wasComposite;
      out += " if (!" + $nextValid + ") { for (var " + $i + "=startErrs" + $lvl + "; " + $i + "<errors; " + $i + "++) { vErrors[" + $i + "].propertyName = " + $key + "; }   var err =   ";
      if (it.createErrors !== false) {
        out += " { keyword: 'propertyNames' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { propertyName: '" + $invalidName + "' } ";
        if (it.opts.messages !== false) {
          out += " , message: 'property name \\'" + $invalidName + "\\' is invalid' ";
        }
        if (it.opts.verbose) {
          out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
        }
        out += " } ";
      } else {
        out += " {} ";
      }
      out += ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
      if (!it.compositeRule && $breakOnError) {
        if (it.async) {
          out += " throw new ValidationError(vErrors); ";
        } else {
          out += " validate.errors = vErrors; return false; ";
        }
      }
      if ($breakOnError) {
        out += " break; ";
      }
      out += " } }";
    }
    if ($breakOnError) {
      out += " " + $closingBraces + " if (" + $errs + " == errors) {";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/required.js
var require_required = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_required(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    var $vSchema = "schema" + $lvl;
    if (!$isData) {
      if ($schema.length < it.opts.loopRequired && it.schema.properties && Object.keys(it.schema.properties).length) {
        var $required = [];
        var arr1 = $schema;
        if (arr1) {
          var $property, i1 = -1, l1 = arr1.length - 1;
          while (i1 < l1) {
            $property = arr1[i1 += 1];
            var $propertySch = it.schema.properties[$property];
            if (!($propertySch && (it.opts.strictKeywords ? typeof $propertySch == "object" && Object.keys($propertySch).length > 0 || $propertySch === false : it.util.schemaHasRules($propertySch, it.RULES.all)))) {
              $required[$required.length] = $property;
            }
          }
        }
      } else {
        var $required = $schema;
      }
    }
    if ($isData || $required.length) {
      var $currentErrorPath = it.errorPath, $loopRequired = $isData || $required.length >= it.opts.loopRequired, $ownProperties = it.opts.ownProperties;
      if ($breakOnError) {
        out += " var missing" + $lvl + "; ";
        if ($loopRequired) {
          if (!$isData) {
            out += " var " + $vSchema + " = validate.schema" + $schemaPath + "; ";
          }
          var $i = "i" + $lvl, $propertyPath = "schema" + $lvl + "[" + $i + "]", $missingProperty = "' + " + $propertyPath + " + '";
          if (it.opts._errorDataPathProperty) {
            it.errorPath = it.util.getPathExpr($currentErrorPath, $propertyPath, it.opts.jsonPointers);
          }
          out += " var " + $valid + " = true; ";
          if ($isData) {
            out += " if (schema" + $lvl + " === undefined) " + $valid + " = true; else if (!Array.isArray(schema" + $lvl + ")) " + $valid + " = false; else {";
          }
          out += " for (var " + $i + " = 0; " + $i + " < " + $vSchema + ".length; " + $i + "++) { " + $valid + " = " + $data + "[" + $vSchema + "[" + $i + "]] !== undefined ";
          if ($ownProperties) {
            out += " &&   Object.prototype.hasOwnProperty.call(" + $data + ", " + $vSchema + "[" + $i + "]) ";
          }
          out += "; if (!" + $valid + ") break; } ";
          if ($isData) {
            out += "  }  ";
          }
          out += "  if (!" + $valid + ") {   ";
          var $$outStack = $$outStack || [];
          $$outStack.push(out);
          out = "";
          if (it.createErrors !== false) {
            out += " { keyword: 'required' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { missingProperty: '" + $missingProperty + "' } ";
            if (it.opts.messages !== false) {
              out += " , message: '";
              if (it.opts._errorDataPathProperty) {
                out += "is a required property";
              } else {
                out += "should have required property \\'" + $missingProperty + "\\'";
              }
              out += "' ";
            }
            if (it.opts.verbose) {
              out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
            }
            out += " } ";
          } else {
            out += " {} ";
          }
          var __err = out;
          out = $$outStack.pop();
          if (!it.compositeRule && $breakOnError) {
            if (it.async) {
              out += " throw new ValidationError([" + __err + "]); ";
            } else {
              out += " validate.errors = [" + __err + "]; return false; ";
            }
          } else {
            out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
          }
          out += " } else { ";
        } else {
          out += " if ( ";
          var arr2 = $required;
          if (arr2) {
            var $propertyKey, $i = -1, l2 = arr2.length - 1;
            while ($i < l2) {
              $propertyKey = arr2[$i += 1];
              if ($i) {
                out += " || ";
              }
              var $prop = it.util.getProperty($propertyKey), $useData = $data + $prop;
              out += " ( ( " + $useData + " === undefined ";
              if ($ownProperties) {
                out += " || ! Object.prototype.hasOwnProperty.call(" + $data + ", '" + it.util.escapeQuotes($propertyKey) + "') ";
              }
              out += ") && (missing" + $lvl + " = " + it.util.toQuotedString(it.opts.jsonPointers ? $propertyKey : $prop) + ") ) ";
            }
          }
          out += ") {  ";
          var $propertyPath = "missing" + $lvl, $missingProperty = "' + " + $propertyPath + " + '";
          if (it.opts._errorDataPathProperty) {
            it.errorPath = it.opts.jsonPointers ? it.util.getPathExpr($currentErrorPath, $propertyPath, true) : $currentErrorPath + " + " + $propertyPath;
          }
          var $$outStack = $$outStack || [];
          $$outStack.push(out);
          out = "";
          if (it.createErrors !== false) {
            out += " { keyword: 'required' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { missingProperty: '" + $missingProperty + "' } ";
            if (it.opts.messages !== false) {
              out += " , message: '";
              if (it.opts._errorDataPathProperty) {
                out += "is a required property";
              } else {
                out += "should have required property \\'" + $missingProperty + "\\'";
              }
              out += "' ";
            }
            if (it.opts.verbose) {
              out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
            }
            out += " } ";
          } else {
            out += " {} ";
          }
          var __err = out;
          out = $$outStack.pop();
          if (!it.compositeRule && $breakOnError) {
            if (it.async) {
              out += " throw new ValidationError([" + __err + "]); ";
            } else {
              out += " validate.errors = [" + __err + "]; return false; ";
            }
          } else {
            out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
          }
          out += " } else { ";
        }
      } else {
        if ($loopRequired) {
          if (!$isData) {
            out += " var " + $vSchema + " = validate.schema" + $schemaPath + "; ";
          }
          var $i = "i" + $lvl, $propertyPath = "schema" + $lvl + "[" + $i + "]", $missingProperty = "' + " + $propertyPath + " + '";
          if (it.opts._errorDataPathProperty) {
            it.errorPath = it.util.getPathExpr($currentErrorPath, $propertyPath, it.opts.jsonPointers);
          }
          if ($isData) {
            out += " if (" + $vSchema + " && !Array.isArray(" + $vSchema + ")) {  var err =   ";
            if (it.createErrors !== false) {
              out += " { keyword: 'required' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { missingProperty: '" + $missingProperty + "' } ";
              if (it.opts.messages !== false) {
                out += " , message: '";
                if (it.opts._errorDataPathProperty) {
                  out += "is a required property";
                } else {
                  out += "should have required property \\'" + $missingProperty + "\\'";
                }
                out += "' ";
              }
              if (it.opts.verbose) {
                out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
              }
              out += " } ";
            } else {
              out += " {} ";
            }
            out += ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; } else if (" + $vSchema + " !== undefined) { ";
          }
          out += " for (var " + $i + " = 0; " + $i + " < " + $vSchema + ".length; " + $i + "++) { if (" + $data + "[" + $vSchema + "[" + $i + "]] === undefined ";
          if ($ownProperties) {
            out += " || ! Object.prototype.hasOwnProperty.call(" + $data + ", " + $vSchema + "[" + $i + "]) ";
          }
          out += ") {  var err =   ";
          if (it.createErrors !== false) {
            out += " { keyword: 'required' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { missingProperty: '" + $missingProperty + "' } ";
            if (it.opts.messages !== false) {
              out += " , message: '";
              if (it.opts._errorDataPathProperty) {
                out += "is a required property";
              } else {
                out += "should have required property \\'" + $missingProperty + "\\'";
              }
              out += "' ";
            }
            if (it.opts.verbose) {
              out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
            }
            out += " } ";
          } else {
            out += " {} ";
          }
          out += ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; } } ";
          if ($isData) {
            out += "  }  ";
          }
        } else {
          var arr3 = $required;
          if (arr3) {
            var $propertyKey, i3 = -1, l3 = arr3.length - 1;
            while (i3 < l3) {
              $propertyKey = arr3[i3 += 1];
              var $prop = it.util.getProperty($propertyKey), $missingProperty = it.util.escapeQuotes($propertyKey), $useData = $data + $prop;
              if (it.opts._errorDataPathProperty) {
                it.errorPath = it.util.getPath($currentErrorPath, $propertyKey, it.opts.jsonPointers);
              }
              out += " if ( " + $useData + " === undefined ";
              if ($ownProperties) {
                out += " || ! Object.prototype.hasOwnProperty.call(" + $data + ", '" + it.util.escapeQuotes($propertyKey) + "') ";
              }
              out += ") {  var err =   ";
              if (it.createErrors !== false) {
                out += " { keyword: 'required' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { missingProperty: '" + $missingProperty + "' } ";
                if (it.opts.messages !== false) {
                  out += " , message: '";
                  if (it.opts._errorDataPathProperty) {
                    out += "is a required property";
                  } else {
                    out += "should have required property \\'" + $missingProperty + "\\'";
                  }
                  out += "' ";
                }
                if (it.opts.verbose) {
                  out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
                }
                out += " } ";
              } else {
                out += " {} ";
              }
              out += ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; } ";
            }
          }
        }
      }
      it.errorPath = $currentErrorPath;
    } else if ($breakOnError) {
      out += " if (true) {";
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/uniqueItems.js
var require_uniqueItems = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_uniqueItems(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    if (($schema || $isData) && it.opts.uniqueItems !== false) {
      if ($isData) {
        out += " var " + $valid + "; if (" + $schemaValue + " === false || " + $schemaValue + " === undefined) " + $valid + " = true; else if (typeof " + $schemaValue + " != 'boolean') " + $valid + " = false; else { ";
      }
      out += " var i = " + $data + ".length , " + $valid + " = true , j; if (i > 1) { ";
      var $itemType = it.schema.items && it.schema.items.type, $typeIsArray = Array.isArray($itemType);
      if (!$itemType || $itemType == "object" || $itemType == "array" || $typeIsArray && ($itemType.indexOf("object") >= 0 || $itemType.indexOf("array") >= 0)) {
        out += " outer: for (;i--;) { for (j = i; j--;) { if (equal(" + $data + "[i], " + $data + "[j])) { " + $valid + " = false; break outer; } } } ";
      } else {
        out += " var itemIndices = {}, item; for (;i--;) { var item = " + $data + "[i]; ";
        var $method = "checkDataType" + ($typeIsArray ? "s" : "");
        out += " if (" + it.util[$method]($itemType, "item", it.opts.strictNumbers, true) + ") continue; ";
        if ($typeIsArray) {
          out += ` if (typeof item == 'string') item = '"' + item; `;
        }
        out += " if (typeof itemIndices[item] == 'number') { " + $valid + " = false; j = itemIndices[item]; break; } itemIndices[item] = i; } ";
      }
      out += " } ";
      if ($isData) {
        out += "  }  ";
      }
      out += " if (!" + $valid + ") {   ";
      var $$outStack = $$outStack || [];
      $$outStack.push(out);
      out = "";
      if (it.createErrors !== false) {
        out += " { keyword: 'uniqueItems' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { i: i, j: j } ";
        if (it.opts.messages !== false) {
          out += " , message: 'should NOT have duplicate items (items ## ' + j + ' and ' + i + ' are identical)' ";
        }
        if (it.opts.verbose) {
          out += " , schema:  ";
          if ($isData) {
            out += "validate.schema" + $schemaPath;
          } else {
            out += "" + $schema;
          }
          out += "         , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
        }
        out += " } ";
      } else {
        out += " {} ";
      }
      var __err = out;
      out = $$outStack.pop();
      if (!it.compositeRule && $breakOnError) {
        if (it.async) {
          out += " throw new ValidationError([" + __err + "]); ";
        } else {
          out += " validate.errors = [" + __err + "]; return false; ";
        }
      } else {
        out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
      }
      out += " } ";
      if ($breakOnError) {
        out += " else { ";
      }
    } else {
      if ($breakOnError) {
        out += " if (true) { ";
      }
    }
    return out;
  };
});

// node_modules/ajv/lib/dotjs/index.js
var require_dotjs = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = {
    $ref: require_ref(),
    allOf: require_allOf(),
    anyOf: require_anyOf(),
    $comment: require_comment(),
    const: require_const(),
    contains: require_contains(),
    dependencies: require_dependencies(),
    enum: require_enum(),
    format: require_format(),
    if: require_if(),
    items: require_items(),
    maximum: require_limit(),
    minimum: require_limit(),
    maxItems: require_limitItems(),
    minItems: require_limitItems(),
    maxLength: require_limitLength(),
    minLength: require_limitLength(),
    maxProperties: require_limitProperties(),
    minProperties: require_limitProperties(),
    multipleOf: require_multipleOf(),
    not: require_not(),
    oneOf: require_oneOf(),
    pattern: require_pattern(),
    properties: require_properties(),
    propertyNames: require_propertyNames(),
    required: require_required(),
    uniqueItems: require_uniqueItems(),
    validate: require_validate()
  };
});

// node_modules/ajv/lib/compile/rules.js
var require_rules = __commonJS((exports2, module2) => {
  "use strict";
  var ruleModules = require_dotjs();
  var toHash = require_util().toHash;
  module2.exports = function rules() {
    var RULES = [
      {
        type: "number",
        rules: [
          {maximum: ["exclusiveMaximum"]},
          {minimum: ["exclusiveMinimum"]},
          "multipleOf",
          "format"
        ]
      },
      {
        type: "string",
        rules: ["maxLength", "minLength", "pattern", "format"]
      },
      {
        type: "array",
        rules: ["maxItems", "minItems", "items", "contains", "uniqueItems"]
      },
      {
        type: "object",
        rules: [
          "maxProperties",
          "minProperties",
          "required",
          "dependencies",
          "propertyNames",
          {properties: ["additionalProperties", "patternProperties"]}
        ]
      },
      {rules: ["$ref", "const", "enum", "not", "anyOf", "oneOf", "allOf", "if"]}
    ];
    var ALL = ["type", "$comment"];
    var KEYWORDS = [
      "$schema",
      "$id",
      "id",
      "$data",
      "$async",
      "title",
      "description",
      "default",
      "definitions",
      "examples",
      "readOnly",
      "writeOnly",
      "contentMediaType",
      "contentEncoding",
      "additionalItems",
      "then",
      "else"
    ];
    var TYPES = ["number", "integer", "string", "array", "object", "boolean", "null"];
    RULES.all = toHash(ALL);
    RULES.types = toHash(TYPES);
    RULES.forEach(function(group) {
      group.rules = group.rules.map(function(keyword) {
        var implKeywords;
        if (typeof keyword == "object") {
          var key = Object.keys(keyword)[0];
          implKeywords = keyword[key];
          keyword = key;
          implKeywords.forEach(function(k) {
            ALL.push(k);
            RULES.all[k] = true;
          });
        }
        ALL.push(keyword);
        var rule = RULES.all[keyword] = {
          keyword,
          code: ruleModules[keyword],
          implements: implKeywords
        };
        return rule;
      });
      RULES.all.$comment = {
        keyword: "$comment",
        code: ruleModules.$comment
      };
      if (group.type)
        RULES.types[group.type] = group;
    });
    RULES.keywords = toHash(ALL.concat(KEYWORDS));
    RULES.custom = {};
    return RULES;
  };
});

// node_modules/ajv/lib/data.js
var require_data = __commonJS((exports2, module2) => {
  "use strict";
  var KEYWORDS = [
    "multipleOf",
    "maximum",
    "exclusiveMaximum",
    "minimum",
    "exclusiveMinimum",
    "maxLength",
    "minLength",
    "pattern",
    "additionalItems",
    "maxItems",
    "minItems",
    "uniqueItems",
    "maxProperties",
    "minProperties",
    "required",
    "additionalProperties",
    "enum",
    "format",
    "const"
  ];
  module2.exports = function(metaSchema, keywordsJsonPointers) {
    for (var i = 0; i < keywordsJsonPointers.length; i++) {
      metaSchema = JSON.parse(JSON.stringify(metaSchema));
      var segments = keywordsJsonPointers[i].split("/");
      var keywords = metaSchema;
      var j;
      for (j = 1; j < segments.length; j++)
        keywords = keywords[segments[j]];
      for (j = 0; j < KEYWORDS.length; j++) {
        var key = KEYWORDS[j];
        var schema = keywords[key];
        if (schema) {
          keywords[key] = {
            anyOf: [
              schema,
              {$ref: "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#"}
            ]
          };
        }
      }
    }
    return metaSchema;
  };
});

// node_modules/ajv/lib/compile/async.js
var require_async = __commonJS((exports2, module2) => {
  "use strict";
  var MissingRefError = require_error_classes().MissingRef;
  module2.exports = compileAsync;
  function compileAsync(schema, meta, callback) {
    var self2 = this;
    if (typeof this._opts.loadSchema != "function")
      throw new Error("options.loadSchema should be a function");
    if (typeof meta == "function") {
      callback = meta;
      meta = void 0;
    }
    var p = loadMetaSchemaOf(schema).then(function() {
      var schemaObj = self2._addSchema(schema, void 0, meta);
      return schemaObj.validate || _compileAsync(schemaObj);
    });
    if (callback) {
      p.then(function(v) {
        callback(null, v);
      }, callback);
    }
    return p;
    function loadMetaSchemaOf(sch) {
      var $schema = sch.$schema;
      return $schema && !self2.getSchema($schema) ? compileAsync.call(self2, {$ref: $schema}, true) : Promise.resolve();
    }
    function _compileAsync(schemaObj) {
      try {
        return self2._compile(schemaObj);
      } catch (e) {
        if (e instanceof MissingRefError)
          return loadMissingSchema(e);
        throw e;
      }
      function loadMissingSchema(e) {
        var ref = e.missingSchema;
        if (added(ref))
          throw new Error("Schema " + ref + " is loaded but " + e.missingRef + " cannot be resolved");
        var schemaPromise = self2._loadingSchemas[ref];
        if (!schemaPromise) {
          schemaPromise = self2._loadingSchemas[ref] = self2._opts.loadSchema(ref);
          schemaPromise.then(removePromise, removePromise);
        }
        return schemaPromise.then(function(sch) {
          if (!added(ref)) {
            return loadMetaSchemaOf(sch).then(function() {
              if (!added(ref))
                self2.addSchema(sch, ref, void 0, meta);
            });
          }
        }).then(function() {
          return _compileAsync(schemaObj);
        });
        function removePromise() {
          delete self2._loadingSchemas[ref];
        }
        function added(ref2) {
          return self2._refs[ref2] || self2._schemas[ref2];
        }
      }
    }
  }
});

// node_modules/ajv/lib/dotjs/custom.js
var require_custom = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function generate_custom(it, $keyword, $ruleType) {
    var out = " ";
    var $lvl = it.level;
    var $dataLvl = it.dataLevel;
    var $schema = it.schema[$keyword];
    var $schemaPath = it.schemaPath + it.util.getProperty($keyword);
    var $errSchemaPath = it.errSchemaPath + "/" + $keyword;
    var $breakOnError = !it.opts.allErrors;
    var $errorKeyword;
    var $data = "data" + ($dataLvl || "");
    var $valid = "valid" + $lvl;
    var $errs = "errs__" + $lvl;
    var $isData = it.opts.$data && $schema && $schema.$data, $schemaValue;
    if ($isData) {
      out += " var schema" + $lvl + " = " + it.util.getData($schema.$data, $dataLvl, it.dataPathArr) + "; ";
      $schemaValue = "schema" + $lvl;
    } else {
      $schemaValue = $schema;
    }
    var $rule = this, $definition = "definition" + $lvl, $rDef = $rule.definition, $closingBraces = "";
    var $compile, $inline, $macro, $ruleValidate, $validateCode;
    if ($isData && $rDef.$data) {
      $validateCode = "keywordValidate" + $lvl;
      var $validateSchema = $rDef.validateSchema;
      out += " var " + $definition + " = RULES.custom['" + $keyword + "'].definition; var " + $validateCode + " = " + $definition + ".validate;";
    } else {
      $ruleValidate = it.useCustomRule($rule, $schema, it.schema, it);
      if (!$ruleValidate)
        return;
      $schemaValue = "validate.schema" + $schemaPath;
      $validateCode = $ruleValidate.code;
      $compile = $rDef.compile;
      $inline = $rDef.inline;
      $macro = $rDef.macro;
    }
    var $ruleErrs = $validateCode + ".errors", $i = "i" + $lvl, $ruleErr = "ruleErr" + $lvl, $asyncKeyword = $rDef.async;
    if ($asyncKeyword && !it.async)
      throw new Error("async keyword in sync schema");
    if (!($inline || $macro)) {
      out += "" + $ruleErrs + " = null;";
    }
    out += "var " + $errs + " = errors;var " + $valid + ";";
    if ($isData && $rDef.$data) {
      $closingBraces += "}";
      out += " if (" + $schemaValue + " === undefined) { " + $valid + " = true; } else { ";
      if ($validateSchema) {
        $closingBraces += "}";
        out += " " + $valid + " = " + $definition + ".validateSchema(" + $schemaValue + "); if (" + $valid + ") { ";
      }
    }
    if ($inline) {
      if ($rDef.statements) {
        out += " " + $ruleValidate.validate + " ";
      } else {
        out += " " + $valid + " = " + $ruleValidate.validate + "; ";
      }
    } else if ($macro) {
      var $it = it.util.copy(it);
      var $closingBraces = "";
      $it.level++;
      var $nextValid = "valid" + $it.level;
      $it.schema = $ruleValidate.validate;
      $it.schemaPath = "";
      var $wasComposite = it.compositeRule;
      it.compositeRule = $it.compositeRule = true;
      var $code = it.validate($it).replace(/validate\.schema/g, $validateCode);
      it.compositeRule = $it.compositeRule = $wasComposite;
      out += " " + $code;
    } else {
      var $$outStack = $$outStack || [];
      $$outStack.push(out);
      out = "";
      out += "  " + $validateCode + ".call( ";
      if (it.opts.passContext) {
        out += "this";
      } else {
        out += "self";
      }
      if ($compile || $rDef.schema === false) {
        out += " , " + $data + " ";
      } else {
        out += " , " + $schemaValue + " , " + $data + " , validate.schema" + it.schemaPath + " ";
      }
      out += " , (dataPath || '')";
      if (it.errorPath != '""') {
        out += " + " + it.errorPath;
      }
      var $parentData = $dataLvl ? "data" + ($dataLvl - 1 || "") : "parentData", $parentDataProperty = $dataLvl ? it.dataPathArr[$dataLvl] : "parentDataProperty";
      out += " , " + $parentData + " , " + $parentDataProperty + " , rootData )  ";
      var def_callRuleValidate = out;
      out = $$outStack.pop();
      if ($rDef.errors === false) {
        out += " " + $valid + " = ";
        if ($asyncKeyword) {
          out += "await ";
        }
        out += "" + def_callRuleValidate + "; ";
      } else {
        if ($asyncKeyword) {
          $ruleErrs = "customErrors" + $lvl;
          out += " var " + $ruleErrs + " = null; try { " + $valid + " = await " + def_callRuleValidate + "; } catch (e) { " + $valid + " = false; if (e instanceof ValidationError) " + $ruleErrs + " = e.errors; else throw e; } ";
        } else {
          out += " " + $ruleErrs + " = null; " + $valid + " = " + def_callRuleValidate + "; ";
        }
      }
    }
    if ($rDef.modifying) {
      out += " if (" + $parentData + ") " + $data + " = " + $parentData + "[" + $parentDataProperty + "];";
    }
    out += "" + $closingBraces;
    if ($rDef.valid) {
      if ($breakOnError) {
        out += " if (true) { ";
      }
    } else {
      out += " if ( ";
      if ($rDef.valid === void 0) {
        out += " !";
        if ($macro) {
          out += "" + $nextValid;
        } else {
          out += "" + $valid;
        }
      } else {
        out += " " + !$rDef.valid + " ";
      }
      out += ") { ";
      $errorKeyword = $rule.keyword;
      var $$outStack = $$outStack || [];
      $$outStack.push(out);
      out = "";
      var $$outStack = $$outStack || [];
      $$outStack.push(out);
      out = "";
      if (it.createErrors !== false) {
        out += " { keyword: '" + ($errorKeyword || "custom") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { keyword: '" + $rule.keyword + "' } ";
        if (it.opts.messages !== false) {
          out += ` , message: 'should pass "` + $rule.keyword + `" keyword validation' `;
        }
        if (it.opts.verbose) {
          out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
        }
        out += " } ";
      } else {
        out += " {} ";
      }
      var __err = out;
      out = $$outStack.pop();
      if (!it.compositeRule && $breakOnError) {
        if (it.async) {
          out += " throw new ValidationError([" + __err + "]); ";
        } else {
          out += " validate.errors = [" + __err + "]; return false; ";
        }
      } else {
        out += " var err = " + __err + ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
      }
      var def_customError = out;
      out = $$outStack.pop();
      if ($inline) {
        if ($rDef.errors) {
          if ($rDef.errors != "full") {
            out += "  for (var " + $i + "=" + $errs + "; " + $i + "<errors; " + $i + "++) { var " + $ruleErr + " = vErrors[" + $i + "]; if (" + $ruleErr + ".dataPath === undefined) " + $ruleErr + ".dataPath = (dataPath || '') + " + it.errorPath + "; if (" + $ruleErr + ".schemaPath === undefined) { " + $ruleErr + '.schemaPath = "' + $errSchemaPath + '"; } ';
            if (it.opts.verbose) {
              out += " " + $ruleErr + ".schema = " + $schemaValue + "; " + $ruleErr + ".data = " + $data + "; ";
            }
            out += " } ";
          }
        } else {
          if ($rDef.errors === false) {
            out += " " + def_customError + " ";
          } else {
            out += " if (" + $errs + " == errors) { " + def_customError + " } else {  for (var " + $i + "=" + $errs + "; " + $i + "<errors; " + $i + "++) { var " + $ruleErr + " = vErrors[" + $i + "]; if (" + $ruleErr + ".dataPath === undefined) " + $ruleErr + ".dataPath = (dataPath || '') + " + it.errorPath + "; if (" + $ruleErr + ".schemaPath === undefined) { " + $ruleErr + '.schemaPath = "' + $errSchemaPath + '"; } ';
            if (it.opts.verbose) {
              out += " " + $ruleErr + ".schema = " + $schemaValue + "; " + $ruleErr + ".data = " + $data + "; ";
            }
            out += " } } ";
          }
        }
      } else if ($macro) {
        out += "   var err =   ";
        if (it.createErrors !== false) {
          out += " { keyword: '" + ($errorKeyword || "custom") + "' , dataPath: (dataPath || '') + " + it.errorPath + " , schemaPath: " + it.util.toQuotedString($errSchemaPath) + " , params: { keyword: '" + $rule.keyword + "' } ";
          if (it.opts.messages !== false) {
            out += ` , message: 'should pass "` + $rule.keyword + `" keyword validation' `;
          }
          if (it.opts.verbose) {
            out += " , schema: validate.schema" + $schemaPath + " , parentSchema: validate.schema" + it.schemaPath + " , data: " + $data + " ";
          }
          out += " } ";
        } else {
          out += " {} ";
        }
        out += ";  if (vErrors === null) vErrors = [err]; else vErrors.push(err); errors++; ";
        if (!it.compositeRule && $breakOnError) {
          if (it.async) {
            out += " throw new ValidationError(vErrors); ";
          } else {
            out += " validate.errors = vErrors; return false; ";
          }
        }
      } else {
        if ($rDef.errors === false) {
          out += " " + def_customError + " ";
        } else {
          out += " if (Array.isArray(" + $ruleErrs + ")) { if (vErrors === null) vErrors = " + $ruleErrs + "; else vErrors = vErrors.concat(" + $ruleErrs + "); errors = vErrors.length;  for (var " + $i + "=" + $errs + "; " + $i + "<errors; " + $i + "++) { var " + $ruleErr + " = vErrors[" + $i + "]; if (" + $ruleErr + ".dataPath === undefined) " + $ruleErr + ".dataPath = (dataPath || '') + " + it.errorPath + ";  " + $ruleErr + '.schemaPath = "' + $errSchemaPath + '";  ';
          if (it.opts.verbose) {
            out += " " + $ruleErr + ".schema = " + $schemaValue + "; " + $ruleErr + ".data = " + $data + "; ";
          }
          out += " } } else { " + def_customError + " } ";
        }
      }
      out += " } ";
      if ($breakOnError) {
        out += " else { ";
      }
    }
    return out;
  };
});

// node_modules/ajv/lib/refs/json-schema-draft-07.json
var require_json_schema_draft_07 = __commonJS((exports2, module2) => {
  module2.exports = {
    $schema: "http://json-schema.org/draft-07/schema#",
    $id: "http://json-schema.org/draft-07/schema#",
    title: "Core schema meta-schema",
    definitions: {
      schemaArray: {
        type: "array",
        minItems: 1,
        items: {$ref: "#"}
      },
      nonNegativeInteger: {
        type: "integer",
        minimum: 0
      },
      nonNegativeIntegerDefault0: {
        allOf: [
          {$ref: "#/definitions/nonNegativeInteger"},
          {default: 0}
        ]
      },
      simpleTypes: {
        enum: [
          "array",
          "boolean",
          "integer",
          "null",
          "number",
          "object",
          "string"
        ]
      },
      stringArray: {
        type: "array",
        items: {type: "string"},
        uniqueItems: true,
        default: []
      }
    },
    type: ["object", "boolean"],
    properties: {
      $id: {
        type: "string",
        format: "uri-reference"
      },
      $schema: {
        type: "string",
        format: "uri"
      },
      $ref: {
        type: "string",
        format: "uri-reference"
      },
      $comment: {
        type: "string"
      },
      title: {
        type: "string"
      },
      description: {
        type: "string"
      },
      default: true,
      readOnly: {
        type: "boolean",
        default: false
      },
      examples: {
        type: "array",
        items: true
      },
      multipleOf: {
        type: "number",
        exclusiveMinimum: 0
      },
      maximum: {
        type: "number"
      },
      exclusiveMaximum: {
        type: "number"
      },
      minimum: {
        type: "number"
      },
      exclusiveMinimum: {
        type: "number"
      },
      maxLength: {$ref: "#/definitions/nonNegativeInteger"},
      minLength: {$ref: "#/definitions/nonNegativeIntegerDefault0"},
      pattern: {
        type: "string",
        format: "regex"
      },
      additionalItems: {$ref: "#"},
      items: {
        anyOf: [
          {$ref: "#"},
          {$ref: "#/definitions/schemaArray"}
        ],
        default: true
      },
      maxItems: {$ref: "#/definitions/nonNegativeInteger"},
      minItems: {$ref: "#/definitions/nonNegativeIntegerDefault0"},
      uniqueItems: {
        type: "boolean",
        default: false
      },
      contains: {$ref: "#"},
      maxProperties: {$ref: "#/definitions/nonNegativeInteger"},
      minProperties: {$ref: "#/definitions/nonNegativeIntegerDefault0"},
      required: {$ref: "#/definitions/stringArray"},
      additionalProperties: {$ref: "#"},
      definitions: {
        type: "object",
        additionalProperties: {$ref: "#"},
        default: {}
      },
      properties: {
        type: "object",
        additionalProperties: {$ref: "#"},
        default: {}
      },
      patternProperties: {
        type: "object",
        additionalProperties: {$ref: "#"},
        propertyNames: {format: "regex"},
        default: {}
      },
      dependencies: {
        type: "object",
        additionalProperties: {
          anyOf: [
            {$ref: "#"},
            {$ref: "#/definitions/stringArray"}
          ]
        }
      },
      propertyNames: {$ref: "#"},
      const: true,
      enum: {
        type: "array",
        items: true,
        minItems: 1,
        uniqueItems: true
      },
      type: {
        anyOf: [
          {$ref: "#/definitions/simpleTypes"},
          {
            type: "array",
            items: {$ref: "#/definitions/simpleTypes"},
            minItems: 1,
            uniqueItems: true
          }
        ]
      },
      format: {type: "string"},
      contentMediaType: {type: "string"},
      contentEncoding: {type: "string"},
      if: {$ref: "#"},
      then: {$ref: "#"},
      else: {$ref: "#"},
      allOf: {$ref: "#/definitions/schemaArray"},
      anyOf: {$ref: "#/definitions/schemaArray"},
      oneOf: {$ref: "#/definitions/schemaArray"},
      not: {$ref: "#"}
    },
    default: true
  };
});

// node_modules/ajv/lib/definition_schema.js
var require_definition_schema = __commonJS((exports2, module2) => {
  "use strict";
  var metaSchema = require_json_schema_draft_07();
  module2.exports = {
    $id: "https://github.com/ajv-validator/ajv/blob/master/lib/definition_schema.js",
    definitions: {
      simpleTypes: metaSchema.definitions.simpleTypes
    },
    type: "object",
    dependencies: {
      schema: ["validate"],
      $data: ["validate"],
      statements: ["inline"],
      valid: {not: {required: ["macro"]}}
    },
    properties: {
      type: metaSchema.properties.type,
      schema: {type: "boolean"},
      statements: {type: "boolean"},
      dependencies: {
        type: "array",
        items: {type: "string"}
      },
      metaSchema: {type: "object"},
      modifying: {type: "boolean"},
      valid: {type: "boolean"},
      $data: {type: "boolean"},
      async: {type: "boolean"},
      errors: {
        anyOf: [
          {type: "boolean"},
          {const: "full"}
        ]
      }
    }
  };
});

// node_modules/ajv/lib/keyword.js
var require_keyword = __commonJS((exports2, module2) => {
  "use strict";
  var IDENTIFIER = /^[a-z_$][a-z0-9_$-]*$/i;
  var customRuleCode = require_custom();
  var definitionSchema = require_definition_schema();
  module2.exports = {
    add: addKeyword,
    get: getKeyword,
    remove: removeKeyword,
    validate: validateKeyword
  };
  function addKeyword(keyword, definition) {
    var RULES = this.RULES;
    if (RULES.keywords[keyword])
      throw new Error("Keyword " + keyword + " is already defined");
    if (!IDENTIFIER.test(keyword))
      throw new Error("Keyword " + keyword + " is not a valid identifier");
    if (definition) {
      this.validateKeyword(definition, true);
      var dataType = definition.type;
      if (Array.isArray(dataType)) {
        for (var i = 0; i < dataType.length; i++)
          _addRule(keyword, dataType[i], definition);
      } else {
        _addRule(keyword, dataType, definition);
      }
      var metaSchema = definition.metaSchema;
      if (metaSchema) {
        if (definition.$data && this._opts.$data) {
          metaSchema = {
            anyOf: [
              metaSchema,
              {$ref: "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#"}
            ]
          };
        }
        definition.validateSchema = this.compile(metaSchema, true);
      }
    }
    RULES.keywords[keyword] = RULES.all[keyword] = true;
    function _addRule(keyword2, dataType2, definition2) {
      var ruleGroup;
      for (var i2 = 0; i2 < RULES.length; i2++) {
        var rg = RULES[i2];
        if (rg.type == dataType2) {
          ruleGroup = rg;
          break;
        }
      }
      if (!ruleGroup) {
        ruleGroup = {type: dataType2, rules: []};
        RULES.push(ruleGroup);
      }
      var rule = {
        keyword: keyword2,
        definition: definition2,
        custom: true,
        code: customRuleCode,
        implements: definition2.implements
      };
      ruleGroup.rules.push(rule);
      RULES.custom[keyword2] = rule;
    }
    return this;
  }
  function getKeyword(keyword) {
    var rule = this.RULES.custom[keyword];
    return rule ? rule.definition : this.RULES.keywords[keyword] || false;
  }
  function removeKeyword(keyword) {
    var RULES = this.RULES;
    delete RULES.keywords[keyword];
    delete RULES.all[keyword];
    delete RULES.custom[keyword];
    for (var i = 0; i < RULES.length; i++) {
      var rules = RULES[i].rules;
      for (var j = 0; j < rules.length; j++) {
        if (rules[j].keyword == keyword) {
          rules.splice(j, 1);
          break;
        }
      }
    }
    return this;
  }
  function validateKeyword(definition, throwError) {
    validateKeyword.errors = null;
    var v = this._validateKeyword = this._validateKeyword || this.compile(definitionSchema, true);
    if (v(definition))
      return true;
    validateKeyword.errors = v.errors;
    if (throwError)
      throw new Error("custom keyword definition is invalid: " + this.errorsText(v.errors));
    else
      return false;
  }
});

// node_modules/ajv/lib/refs/data.json
var require_data2 = __commonJS((exports2, module2) => {
  module2.exports = {
    $schema: "http://json-schema.org/draft-07/schema#",
    $id: "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#",
    description: "Meta-schema for $data reference (JSON Schema extension proposal)",
    type: "object",
    required: ["$data"],
    properties: {
      $data: {
        type: "string",
        anyOf: [
          {format: "relative-json-pointer"},
          {format: "json-pointer"}
        ]
      }
    },
    additionalProperties: false
  };
});

// node_modules/ajv/lib/ajv.js
var require_ajv = __commonJS((exports2, module2) => {
  "use strict";
  var compileSchema = require_compile();
  var resolve = require_resolve();
  var Cache = require_cache();
  var SchemaObject = require_schema_obj();
  var stableStringify = require_fast_json_stable_stringify();
  var formats = require_formats();
  var rules = require_rules();
  var $dataMetaSchema = require_data();
  var util = require_util();
  module2.exports = Ajv;
  Ajv.prototype.validate = validate;
  Ajv.prototype.compile = compile;
  Ajv.prototype.addSchema = addSchema;
  Ajv.prototype.addMetaSchema = addMetaSchema;
  Ajv.prototype.validateSchema = validateSchema;
  Ajv.prototype.getSchema = getSchema;
  Ajv.prototype.removeSchema = removeSchema;
  Ajv.prototype.addFormat = addFormat;
  Ajv.prototype.errorsText = errorsText;
  Ajv.prototype._addSchema = _addSchema;
  Ajv.prototype._compile = _compile;
  Ajv.prototype.compileAsync = require_async();
  var customKeyword = require_keyword();
  Ajv.prototype.addKeyword = customKeyword.add;
  Ajv.prototype.getKeyword = customKeyword.get;
  Ajv.prototype.removeKeyword = customKeyword.remove;
  Ajv.prototype.validateKeyword = customKeyword.validate;
  var errorClasses = require_error_classes();
  Ajv.ValidationError = errorClasses.Validation;
  Ajv.MissingRefError = errorClasses.MissingRef;
  Ajv.$dataMetaSchema = $dataMetaSchema;
  var META_SCHEMA_ID = "http://json-schema.org/draft-07/schema";
  var META_IGNORE_OPTIONS = ["removeAdditional", "useDefaults", "coerceTypes", "strictDefaults"];
  var META_SUPPORT_DATA = ["/properties"];
  function Ajv(opts) {
    if (!(this instanceof Ajv))
      return new Ajv(opts);
    opts = this._opts = util.copy(opts) || {};
    setLogger(this);
    this._schemas = {};
    this._refs = {};
    this._fragments = {};
    this._formats = formats(opts.format);
    this._cache = opts.cache || new Cache();
    this._loadingSchemas = {};
    this._compilations = [];
    this.RULES = rules();
    this._getId = chooseGetId(opts);
    opts.loopRequired = opts.loopRequired || Infinity;
    if (opts.errorDataPath == "property")
      opts._errorDataPathProperty = true;
    if (opts.serialize === void 0)
      opts.serialize = stableStringify;
    this._metaOpts = getMetaSchemaOptions(this);
    if (opts.formats)
      addInitialFormats(this);
    if (opts.keywords)
      addInitialKeywords(this);
    addDefaultMetaSchema(this);
    if (typeof opts.meta == "object")
      this.addMetaSchema(opts.meta);
    if (opts.nullable)
      this.addKeyword("nullable", {metaSchema: {type: "boolean"}});
    addInitialSchemas(this);
  }
  function validate(schemaKeyRef, data) {
    var v;
    if (typeof schemaKeyRef == "string") {
      v = this.getSchema(schemaKeyRef);
      if (!v)
        throw new Error('no schema with key or ref "' + schemaKeyRef + '"');
    } else {
      var schemaObj = this._addSchema(schemaKeyRef);
      v = schemaObj.validate || this._compile(schemaObj);
    }
    var valid = v(data);
    if (v.$async !== true)
      this.errors = v.errors;
    return valid;
  }
  function compile(schema, _meta) {
    var schemaObj = this._addSchema(schema, void 0, _meta);
    return schemaObj.validate || this._compile(schemaObj);
  }
  function addSchema(schema, key, _skipValidation, _meta) {
    if (Array.isArray(schema)) {
      for (var i = 0; i < schema.length; i++)
        this.addSchema(schema[i], void 0, _skipValidation, _meta);
      return this;
    }
    var id = this._getId(schema);
    if (id !== void 0 && typeof id != "string")
      throw new Error("schema id must be string");
    key = resolve.normalizeId(key || id);
    checkUnique(this, key);
    this._schemas[key] = this._addSchema(schema, _skipValidation, _meta, true);
    return this;
  }
  function addMetaSchema(schema, key, skipValidation) {
    this.addSchema(schema, key, skipValidation, true);
    return this;
  }
  function validateSchema(schema, throwOrLogError) {
    var $schema = schema.$schema;
    if ($schema !== void 0 && typeof $schema != "string")
      throw new Error("$schema must be a string");
    $schema = $schema || this._opts.defaultMeta || defaultMeta(this);
    if (!$schema) {
      this.logger.warn("meta-schema not available");
      this.errors = null;
      return true;
    }
    var valid = this.validate($schema, schema);
    if (!valid && throwOrLogError) {
      var message = "schema is invalid: " + this.errorsText();
      if (this._opts.validateSchema == "log")
        this.logger.error(message);
      else
        throw new Error(message);
    }
    return valid;
  }
  function defaultMeta(self2) {
    var meta = self2._opts.meta;
    self2._opts.defaultMeta = typeof meta == "object" ? self2._getId(meta) || meta : self2.getSchema(META_SCHEMA_ID) ? META_SCHEMA_ID : void 0;
    return self2._opts.defaultMeta;
  }
  function getSchema(keyRef) {
    var schemaObj = _getSchemaObj(this, keyRef);
    switch (typeof schemaObj) {
      case "object":
        return schemaObj.validate || this._compile(schemaObj);
      case "string":
        return this.getSchema(schemaObj);
      case "undefined":
        return _getSchemaFragment(this, keyRef);
    }
  }
  function _getSchemaFragment(self2, ref) {
    var res = resolve.schema.call(self2, {schema: {}}, ref);
    if (res) {
      var schema = res.schema, root = res.root, baseId = res.baseId;
      var v = compileSchema.call(self2, schema, root, void 0, baseId);
      self2._fragments[ref] = new SchemaObject({
        ref,
        fragment: true,
        schema,
        root,
        baseId,
        validate: v
      });
      return v;
    }
  }
  function _getSchemaObj(self2, keyRef) {
    keyRef = resolve.normalizeId(keyRef);
    return self2._schemas[keyRef] || self2._refs[keyRef] || self2._fragments[keyRef];
  }
  function removeSchema(schemaKeyRef) {
    if (schemaKeyRef instanceof RegExp) {
      _removeAllSchemas(this, this._schemas, schemaKeyRef);
      _removeAllSchemas(this, this._refs, schemaKeyRef);
      return this;
    }
    switch (typeof schemaKeyRef) {
      case "undefined":
        _removeAllSchemas(this, this._schemas);
        _removeAllSchemas(this, this._refs);
        this._cache.clear();
        return this;
      case "string":
        var schemaObj = _getSchemaObj(this, schemaKeyRef);
        if (schemaObj)
          this._cache.del(schemaObj.cacheKey);
        delete this._schemas[schemaKeyRef];
        delete this._refs[schemaKeyRef];
        return this;
      case "object":
        var serialize = this._opts.serialize;
        var cacheKey = serialize ? serialize(schemaKeyRef) : schemaKeyRef;
        this._cache.del(cacheKey);
        var id = this._getId(schemaKeyRef);
        if (id) {
          id = resolve.normalizeId(id);
          delete this._schemas[id];
          delete this._refs[id];
        }
    }
    return this;
  }
  function _removeAllSchemas(self2, schemas, regex) {
    for (var keyRef in schemas) {
      var schemaObj = schemas[keyRef];
      if (!schemaObj.meta && (!regex || regex.test(keyRef))) {
        self2._cache.del(schemaObj.cacheKey);
        delete schemas[keyRef];
      }
    }
  }
  function _addSchema(schema, skipValidation, meta, shouldAddSchema) {
    if (typeof schema != "object" && typeof schema != "boolean")
      throw new Error("schema should be object or boolean");
    var serialize = this._opts.serialize;
    var cacheKey = serialize ? serialize(schema) : schema;
    var cached = this._cache.get(cacheKey);
    if (cached)
      return cached;
    shouldAddSchema = shouldAddSchema || this._opts.addUsedSchema !== false;
    var id = resolve.normalizeId(this._getId(schema));
    if (id && shouldAddSchema)
      checkUnique(this, id);
    var willValidate = this._opts.validateSchema !== false && !skipValidation;
    var recursiveMeta;
    if (willValidate && !(recursiveMeta = id && id == resolve.normalizeId(schema.$schema)))
      this.validateSchema(schema, true);
    var localRefs = resolve.ids.call(this, schema);
    var schemaObj = new SchemaObject({
      id,
      schema,
      localRefs,
      cacheKey,
      meta
    });
    if (id[0] != "#" && shouldAddSchema)
      this._refs[id] = schemaObj;
    this._cache.put(cacheKey, schemaObj);
    if (willValidate && recursiveMeta)
      this.validateSchema(schema, true);
    return schemaObj;
  }
  function _compile(schemaObj, root) {
    if (schemaObj.compiling) {
      schemaObj.validate = callValidate;
      callValidate.schema = schemaObj.schema;
      callValidate.errors = null;
      callValidate.root = root ? root : callValidate;
      if (schemaObj.schema.$async === true)
        callValidate.$async = true;
      return callValidate;
    }
    schemaObj.compiling = true;
    var currentOpts;
    if (schemaObj.meta) {
      currentOpts = this._opts;
      this._opts = this._metaOpts;
    }
    var v;
    try {
      v = compileSchema.call(this, schemaObj.schema, root, schemaObj.localRefs);
    } catch (e) {
      delete schemaObj.validate;
      throw e;
    } finally {
      schemaObj.compiling = false;
      if (schemaObj.meta)
        this._opts = currentOpts;
    }
    schemaObj.validate = v;
    schemaObj.refs = v.refs;
    schemaObj.refVal = v.refVal;
    schemaObj.root = v.root;
    return v;
    function callValidate() {
      var _validate = schemaObj.validate;
      var result = _validate.apply(this, arguments);
      callValidate.errors = _validate.errors;
      return result;
    }
  }
  function chooseGetId(opts) {
    switch (opts.schemaId) {
      case "auto":
        return _get$IdOrId;
      case "id":
        return _getId;
      default:
        return _get$Id;
    }
  }
  function _getId(schema) {
    if (schema.$id)
      this.logger.warn("schema $id ignored", schema.$id);
    return schema.id;
  }
  function _get$Id(schema) {
    if (schema.id)
      this.logger.warn("schema id ignored", schema.id);
    return schema.$id;
  }
  function _get$IdOrId(schema) {
    if (schema.$id && schema.id && schema.$id != schema.id)
      throw new Error("schema $id is different from id");
    return schema.$id || schema.id;
  }
  function errorsText(errors, options) {
    errors = errors || this.errors;
    if (!errors)
      return "No errors";
    options = options || {};
    var separator = options.separator === void 0 ? ", " : options.separator;
    var dataVar = options.dataVar === void 0 ? "data" : options.dataVar;
    var text = "";
    for (var i = 0; i < errors.length; i++) {
      var e = errors[i];
      if (e)
        text += dataVar + e.dataPath + " " + e.message + separator;
    }
    return text.slice(0, -separator.length);
  }
  function addFormat(name, format) {
    if (typeof format == "string")
      format = new RegExp(format);
    this._formats[name] = format;
    return this;
  }
  function addDefaultMetaSchema(self2) {
    var $dataSchema;
    if (self2._opts.$data) {
      $dataSchema = require_data2();
      self2.addMetaSchema($dataSchema, $dataSchema.$id, true);
    }
    if (self2._opts.meta === false)
      return;
    var metaSchema = require_json_schema_draft_07();
    if (self2._opts.$data)
      metaSchema = $dataMetaSchema(metaSchema, META_SUPPORT_DATA);
    self2.addMetaSchema(metaSchema, META_SCHEMA_ID, true);
    self2._refs["http://json-schema.org/schema"] = META_SCHEMA_ID;
  }
  function addInitialSchemas(self2) {
    var optsSchemas = self2._opts.schemas;
    if (!optsSchemas)
      return;
    if (Array.isArray(optsSchemas))
      self2.addSchema(optsSchemas);
    else
      for (var key in optsSchemas)
        self2.addSchema(optsSchemas[key], key);
  }
  function addInitialFormats(self2) {
    for (var name in self2._opts.formats) {
      var format = self2._opts.formats[name];
      self2.addFormat(name, format);
    }
  }
  function addInitialKeywords(self2) {
    for (var name in self2._opts.keywords) {
      var keyword = self2._opts.keywords[name];
      self2.addKeyword(name, keyword);
    }
  }
  function checkUnique(self2, id) {
    if (self2._schemas[id] || self2._refs[id])
      throw new Error('schema with key or id "' + id + '" already exists');
  }
  function getMetaSchemaOptions(self2) {
    var metaOpts = util.copy(self2._opts);
    for (var i = 0; i < META_IGNORE_OPTIONS.length; i++)
      delete metaOpts[META_IGNORE_OPTIONS[i]];
    return metaOpts;
  }
  function setLogger(self2) {
    var logger = self2._opts.logger;
    if (logger === false) {
      self2.logger = {log: noop, warn: noop, error: noop};
    } else {
      if (logger === void 0)
        logger = console;
      if (!(typeof logger == "object" && logger.log && logger.warn && logger.error))
        throw new Error("logger must implement log, warn and error methods");
      self2.logger = logger;
    }
  }
  function noop() {
  }
});

// node_modules/@middy/validator/index.js
var require_validator = __commonJS((exports2, module2) => {
  var createError = require_http_errors();
  var Ajv = require_ajv();
  var {deepStrictEqual} = require("assert");
  var ajv;
  var previousConstructorOptions;
  var optionsDefault = {
    v5: true,
    coerceTypes: "array",
    allErrors: true,
    useDefaults: true,
    $data: true,
    defaultLanguage: "en",
    jsonPointers: true
  };
  var pluginsInstances = {};
  var pluginsDefault = {
    keywords: null,
    errors: null,
    i18n: null
  };
  var availableLanguages;
  var languageNormalizationMap = {
    pt: "pt-BR",
    "pt-br": "pt-BR",
    pt_BR: "pt-BR",
    pt_br: "pt-BR"
  };
  var normalizePreferredLanguage = (lang) => languageNormalizationMap[lang] || lang;
  var chooseLanguage = ({preferredLanguage}, defaultLanguage) => {
    if (preferredLanguage) {
      const lang = normalizePreferredLanguage(preferredLanguage);
      if (availableLanguages.includes(lang)) {
        return lang;
      }
    }
    return defaultLanguage;
  };
  module2.exports = ({inputSchema, outputSchema, ajvOptions, ajvPlugins = pluginsDefault}) => {
    const options = Object.assign({}, optionsDefault, ajvOptions);
    lazyLoadAjv(options, ajvPlugins);
    const validateInput = inputSchema ? ajv.compile(inputSchema) : null;
    const validateOutput = outputSchema ? ajv.compile(outputSchema) : null;
    return {
      before(handler, next) {
        if (!inputSchema) {
          return next();
        }
        const valid = validateInput(handler.event);
        if (!valid) {
          const error = new createError.BadRequest("Event object failed validation");
          handler.event.headers = Object.assign({}, handler.event.headers);
          if (pluginsInstances.i18n) {
            const language = chooseLanguage(handler.event, options.defaultLanguage);
            pluginsInstances.i18n[language](validateInput.errors);
          }
          error.details = validateInput.errors;
          throw error;
        }
        return next();
      },
      after(handler, next) {
        if (!outputSchema || !handler.response && handler.error) {
          return next();
        }
        const valid = validateOutput(handler.response);
        if (!valid) {
          const error = new createError.InternalServerError("Response object failed validation");
          error.details = validateOutput.errors;
          error.response = handler.response;
          throw error;
        }
        return next();
      }
    };
  };
  function lazyLoadAjv(options, plugins) {
    if (shouldInitAjv(options)) {
      initAjv(options, plugins);
    }
    return ajv;
  }
  function shouldInitAjv(options) {
    return !ajv || areConstructorOptionsNew(options);
  }
  function areConstructorOptionsNew(options) {
    try {
      deepStrictEqual(options, previousConstructorOptions);
    } catch (e) {
      return true;
    }
    return false;
  }
  function initAjv(options, pluginsOptions) {
    ajv = new Ajv(options);
    Object.keys(pluginsOptions).forEach((p) => {
      try {
        pluginsInstances[p] = require(`ajv-${p}`);
      } catch (e) {
        getPlugins(p);
      }
      if (typeof pluginsInstances[p] === "function") {
        pluginsInstances[p](ajv, pluginsOptions[p]);
      }
    });
    availableLanguages = Object.keys(pluginsInstances.i18n || {});
    previousConstructorOptions = options;
  }
  function getPlugins(p) {
    try {
      const pckJson = require(`../../ajv-${p}/package.json`);
      pluginsInstances[p] = require(`../../ajv-${p}/${pckJson.main}`);
    } catch (e) {
      console.error(`Error getting plugins ${e.message}`);
    }
  }
});

// node_modules/@cazoo-uk/middy/dist/constants/errors.js
var require_errors = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.UNKNOWN_ERROR = "Unknown error occurred";
});

// node_modules/@cazoo-uk/middy/dist/constants/index.js
var require_constants = __commonJS((exports2) => {
  "use strict";
  function __export2(m) {
    for (var p in m)
      if (!exports2.hasOwnProperty(p))
        exports2[p] = m[p];
  }
  Object.defineProperty(exports2, "__esModule", {value: true});
  __export2(require_errors());
});

// node_modules/pino-std-serializers/lib/err.js
var require_err = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = errSerializer;
  var seen = Symbol("circular-ref-tag");
  var rawSymbol = Symbol("pino-raw-err-ref");
  var pinoErrProto = Object.create({}, {
    type: {
      enumerable: true,
      writable: true,
      value: void 0
    },
    message: {
      enumerable: true,
      writable: true,
      value: void 0
    },
    stack: {
      enumerable: true,
      writable: true,
      value: void 0
    },
    raw: {
      enumerable: false,
      get: function() {
        return this[rawSymbol];
      },
      set: function(val) {
        this[rawSymbol] = val;
      }
    }
  });
  Object.defineProperty(pinoErrProto, rawSymbol, {
    writable: true,
    value: {}
  });
  function errSerializer(err) {
    if (!(err instanceof Error)) {
      return err;
    }
    err[seen] = void 0;
    const _err = Object.create(pinoErrProto);
    _err.type = err.constructor.name;
    _err.message = err.message;
    _err.stack = err.stack;
    for (const key in err) {
      if (_err[key] === void 0) {
        const val = err[key];
        if (val instanceof Error) {
          if (!val.hasOwnProperty(seen)) {
            _err[key] = errSerializer(val);
          }
        } else {
          _err[key] = val;
        }
      }
    }
    delete err[seen];
    _err.raw = err;
    return _err;
  }
});

// node_modules/pino-std-serializers/lib/req.js
var require_req = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = {
    mapHttpRequest,
    reqSerializer
  };
  var rawSymbol = Symbol("pino-raw-req-ref");
  var pinoReqProto = Object.create({}, {
    id: {
      enumerable: true,
      writable: true,
      value: ""
    },
    method: {
      enumerable: true,
      writable: true,
      value: ""
    },
    url: {
      enumerable: true,
      writable: true,
      value: ""
    },
    headers: {
      enumerable: true,
      writable: true,
      value: {}
    },
    remoteAddress: {
      enumerable: true,
      writable: true,
      value: ""
    },
    remotePort: {
      enumerable: true,
      writable: true,
      value: ""
    },
    raw: {
      enumerable: false,
      get: function() {
        return this[rawSymbol];
      },
      set: function(val) {
        this[rawSymbol] = val;
      }
    }
  });
  Object.defineProperty(pinoReqProto, rawSymbol, {
    writable: true,
    value: {}
  });
  function reqSerializer(req) {
    var connection = req.info || req.connection;
    const _req = Object.create(pinoReqProto);
    _req.id = typeof req.id === "function" ? req.id() : req.id || (req.info ? req.info.id : void 0);
    _req.method = req.method;
    if (req.originalUrl) {
      _req.url = req.originalUrl;
    } else {
      _req.url = req.path || (req.url ? req.url.path || req.url : void 0);
    }
    _req.headers = req.headers;
    _req.remoteAddress = connection && connection.remoteAddress;
    _req.remotePort = connection && connection.remotePort;
    _req.raw = req.raw || req;
    return _req;
  }
  function mapHttpRequest(req) {
    return {
      req: reqSerializer(req)
    };
  }
});

// node_modules/pino-std-serializers/lib/res.js
var require_res = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = {
    mapHttpResponse,
    resSerializer
  };
  var rawSymbol = Symbol("pino-raw-res-ref");
  var pinoResProto = Object.create({}, {
    statusCode: {
      enumerable: true,
      writable: true,
      value: 0
    },
    headers: {
      enumerable: true,
      writable: true,
      value: ""
    },
    raw: {
      enumerable: false,
      get: function() {
        return this[rawSymbol];
      },
      set: function(val) {
        this[rawSymbol] = val;
      }
    }
  });
  Object.defineProperty(pinoResProto, rawSymbol, {
    writable: true,
    value: {}
  });
  function resSerializer(res) {
    const _res = Object.create(pinoResProto);
    _res.statusCode = res.statusCode;
    _res.headers = res.getHeaders ? res.getHeaders() : res._headers;
    _res.raw = res;
    return _res;
  }
  function mapHttpResponse(res) {
    return {
      res: resSerializer(res)
    };
  }
});

// node_modules/pino-std-serializers/index.js
var require_pino_std_serializers = __commonJS((exports2, module2) => {
  "use strict";
  var errSerializer = require_err();
  var reqSerializers = require_req();
  var resSerializers = require_res();
  module2.exports = {
    err: errSerializer,
    mapHttpRequest: reqSerializers.mapHttpRequest,
    mapHttpResponse: resSerializers.mapHttpResponse,
    req: reqSerializers.reqSerializer,
    res: resSerializers.resSerializer,
    wrapErrorSerializer: function wrapErrorSerializer(customSerializer) {
      if (customSerializer === errSerializer)
        return customSerializer;
      return function wrapErrSerializer(err) {
        return customSerializer(errSerializer(err));
      };
    },
    wrapRequestSerializer: function wrapRequestSerializer(customSerializer) {
      if (customSerializer === reqSerializers.reqSerializer)
        return customSerializer;
      return function wrappedReqSerializer(req) {
        return customSerializer(reqSerializers.reqSerializer(req));
      };
    },
    wrapResponseSerializer: function wrapResponseSerializer(customSerializer) {
      if (customSerializer === resSerializers.resSerializer)
        return customSerializer;
      return function wrappedResSerializer(res) {
        return customSerializer(resSerializers.resSerializer(res));
      };
    }
  };
});

// node_modules/fast-redact/lib/validator.js
var require_validator2 = __commonJS((exports2, module2) => {
  "use strict";
  var {createContext, runInContext} = require("vm");
  module2.exports = validator3;
  function validator3(opts = {}) {
    const {
      ERR_PATHS_MUST_BE_STRINGS = () => "fast-redact - Paths must be (non-empty) strings",
      ERR_INVALID_PATH = (s) => `fast-redact \u2013 Invalid path (${s})`
    } = opts;
    return function validate({paths}) {
      paths.forEach((s) => {
        if (typeof s !== "string") {
          throw Error(ERR_PATHS_MUST_BE_STRINGS());
        }
        try {
          if (/〇/.test(s))
            throw Error();
          const proxy = new Proxy({}, {get: () => proxy, set: () => {
            throw Error();
          }});
          const expr = (s[0] === "[" ? "" : ".") + s.replace(/^\*/, "\u3007").replace(/\.\*/g, ".\u3007").replace(/\[\*\]/g, "[\u3007]");
          if (/\n|\r|;/.test(expr))
            throw Error();
          if (/\/\*/.test(expr))
            throw Error();
          runInContext(`
          (function () {
            'use strict'
            o${expr}
            if ([o${expr}].length !== 1) throw Error()
          })()
        `, createContext({o: proxy, \u3007: null}), {
            codeGeneration: {strings: false, wasm: false}
          });
        } catch (e) {
          throw Error(ERR_INVALID_PATH(s));
        }
      });
    };
  }
});

// node_modules/fast-redact/lib/rx.js
var require_rx = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = /[^.[\]]+|\[((?:.)*?)\]/g;
});

// node_modules/fast-redact/lib/parse.js
var require_parse = __commonJS((exports2, module2) => {
  "use strict";
  var rx = require_rx();
  module2.exports = parse;
  function parse({paths}) {
    const wildcards = [];
    var wcLen = 0;
    const secret = paths.reduce(function(o, strPath, ix) {
      var path = strPath.match(rx).map((p) => p.replace(/'|"|`/g, ""));
      const leadingBracket = strPath[0] === "[";
      path = path.map((p) => {
        if (p[0] === "[")
          return p.substr(1, p.length - 2);
        else
          return p;
      });
      const star = path.indexOf("*");
      if (star > -1) {
        const before = path.slice(0, star);
        const beforeStr = before.join(".");
        const after = path.slice(star + 1, path.length);
        if (after.indexOf("*") > -1)
          throw Error("fast-redact \u2013 Only one wildcard per path is supported");
        const nested = after.length > 0;
        wcLen++;
        wildcards.push({
          before,
          beforeStr,
          after,
          nested
        });
      } else {
        o[strPath] = {
          path,
          val: void 0,
          precensored: false,
          circle: "",
          escPath: JSON.stringify(strPath),
          leadingBracket
        };
      }
      return o;
    }, {});
    return {wildcards, wcLen, secret};
  }
});

// node_modules/fast-redact/lib/redactor.js
var require_redactor = __commonJS((exports2, module2) => {
  "use strict";
  var rx = require_rx();
  module2.exports = redactor;
  function redactor({secret, serialize, wcLen, strict, isCensorFct, censorFctTakesPath}, state) {
    const redact = Function("o", `
    if (typeof o !== 'object' || o == null) {
      ${strictImpl(strict, serialize)}
    }
    const { censor, secret } = this
    ${redactTmpl(secret, isCensorFct, censorFctTakesPath)}
    this.compileRestore()
    ${dynamicRedactTmpl(wcLen > 0, isCensorFct, censorFctTakesPath)}
    ${resultTmpl(serialize)}
  `).bind(state);
    if (serialize === false) {
      redact.restore = (o) => state.restore(o);
    }
    return redact;
  }
  function redactTmpl(secret, isCensorFct, censorFctTakesPath) {
    return Object.keys(secret).map((path) => {
      const {escPath, leadingBracket, path: arrPath} = secret[path];
      const skip = leadingBracket ? 1 : 0;
      const delim = leadingBracket ? "" : ".";
      const hops = [];
      var match;
      while ((match = rx.exec(path)) !== null) {
        const [, ix] = match;
        const {index, input} = match;
        if (index > skip)
          hops.push(input.substring(0, index - (ix ? 0 : 1)));
      }
      var existence = hops.map((p) => `o${delim}${p}`).join(" && ");
      if (existence.length === 0)
        existence += `o${delim}${path} != null`;
      else
        existence += ` && o${delim}${path} != null`;
      const circularDetection = `
      switch (true) {
        ${hops.reverse().map((p) => `
          case o${delim}${p} === censor:
            secret[${escPath}].circle = ${JSON.stringify(p)}
            break
        `).join("\n")}
      }
    `;
      const censorArgs = censorFctTakesPath ? `val, ${JSON.stringify(arrPath)}` : `val`;
      return `
      if (${existence}) {
        const val = o${delim}${path}
        if (val === censor) {
          secret[${escPath}].precensored = true
        } else {
          secret[${escPath}].val = val
          o${delim}${path} = ${isCensorFct ? `censor(${censorArgs})` : "censor"}
          ${circularDetection}
        }
      }
    `;
    }).join("\n");
  }
  function dynamicRedactTmpl(hasWildcards, isCensorFct, censorFctTakesPath) {
    return hasWildcards === true ? `
    {
      const { wildcards, wcLen, groupRedact, nestedRedact } = this
      for (var i = 0; i < wcLen; i++) {
        const { before, beforeStr, after, nested } = wildcards[i]
        if (nested === true) {
          secret[beforeStr] = secret[beforeStr] || []
          nestedRedact(secret[beforeStr], o, before, after, censor, ${isCensorFct}, ${censorFctTakesPath})
        } else secret[beforeStr] = groupRedact(o, before, censor, ${isCensorFct}, ${censorFctTakesPath})
      }
    }
  ` : "";
  }
  function resultTmpl(serialize) {
    return serialize === false ? `return o` : `
    var s = this.serialize(o)
    this.restore(o)
    return s
  `;
  }
  function strictImpl(strict, serialize) {
    return strict === true ? `throw Error('fast-redact: primitives cannot be redacted')` : serialize === false ? `return o` : `return this.serialize(o)`;
  }
});

// node_modules/fast-redact/lib/modifiers.js
var require_modifiers = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = {
    groupRedact,
    groupRestore,
    nestedRedact,
    nestedRestore
  };
  function groupRestore({keys, values, target}) {
    if (target == null)
      return;
    const length = keys.length;
    for (var i = 0; i < length; i++) {
      const k = keys[i];
      target[k] = values[i];
    }
  }
  function groupRedact(o, path, censor, isCensorFct, censorFctTakesPath) {
    const target = get(o, path);
    if (target == null)
      return {keys: null, values: null, target: null, flat: true};
    const keys = Object.keys(target);
    const keysLength = keys.length;
    const pathLength = path.length;
    const pathWithKey = censorFctTakesPath ? [...path] : void 0;
    const values = new Array(keysLength);
    for (var i = 0; i < keysLength; i++) {
      const key = keys[i];
      values[i] = target[key];
      if (censorFctTakesPath) {
        pathWithKey[pathLength] = key;
        target[key] = censor(target[key], pathWithKey);
      } else if (isCensorFct) {
        target[key] = censor(target[key]);
      } else {
        target[key] = censor;
      }
    }
    return {keys, values, target, flat: true};
  }
  function nestedRestore(arr) {
    const length = arr.length;
    for (var i = 0; i < length; i++) {
      const {key, target, value} = arr[i];
      target[key] = value;
    }
  }
  function nestedRedact(store, o, path, ns, censor, isCensorFct, censorFctTakesPath) {
    const target = get(o, path);
    if (target == null)
      return;
    const keys = Object.keys(target);
    const keysLength = keys.length;
    for (var i = 0; i < keysLength; i++) {
      const key = keys[i];
      const {value, parent, exists} = specialSet(target, key, path, ns, censor, isCensorFct, censorFctTakesPath);
      if (exists === true && parent !== null) {
        store.push({key: ns[ns.length - 1], target: parent, value});
      }
    }
    return store;
  }
  function has(obj, prop) {
    return Object.prototype.hasOwnProperty.call(obj, prop);
  }
  function specialSet(o, k, path, afterPath, censor, isCensorFct, censorFctTakesPath) {
    const afterPathLen = afterPath.length;
    const lastPathIndex = afterPathLen - 1;
    const originalKey = k;
    var i = -1;
    var n;
    var nv;
    var ov;
    var oov = null;
    var exists = true;
    ov = n = o[k];
    if (typeof n !== "object")
      return {value: null, parent: null, exists};
    while (n != null && ++i < afterPathLen) {
      k = afterPath[i];
      oov = ov;
      if (!(k in n)) {
        exists = false;
        break;
      }
      ov = n[k];
      nv = i !== lastPathIndex ? ov : isCensorFct ? censorFctTakesPath ? censor(ov, [...path, originalKey, ...afterPath]) : censor(ov) : censor;
      n[k] = has(n, k) && nv === ov || nv === void 0 && censor !== void 0 ? n[k] : nv;
      n = n[k];
      if (typeof n !== "object")
        break;
    }
    return {value: ov, parent: oov, exists};
  }
  function get(o, p) {
    var i = -1;
    var l = p.length;
    var n = o;
    while (n != null && ++i < l) {
      n = n[p[i]];
    }
    return n;
  }
});

// node_modules/fast-redact/lib/restorer.js
var require_restorer = __commonJS((exports2, module2) => {
  "use strict";
  var {groupRestore, nestedRestore} = require_modifiers();
  module2.exports = restorer;
  function restorer({secret, wcLen}) {
    return function compileRestore() {
      if (this.restore)
        return;
      const paths = Object.keys(secret).filter((path) => secret[path].precensored === false);
      const resetters = resetTmpl(secret, paths);
      const hasWildcards = wcLen > 0;
      const state = hasWildcards ? {secret, groupRestore, nestedRestore} : {secret};
      this.restore = Function("o", restoreTmpl(resetters, paths, hasWildcards)).bind(state);
    };
  }
  function resetTmpl(secret, paths) {
    return paths.map((path) => {
      const {circle, escPath, leadingBracket} = secret[path];
      const delim = leadingBracket ? "" : ".";
      const reset = circle ? `o.${circle} = secret[${escPath}].val` : `o${delim}${path} = secret[${escPath}].val`;
      const clear = `secret[${escPath}].val = undefined`;
      return `
      if (secret[${escPath}].val !== undefined) {
        try { ${reset} } catch (e) {}
        ${clear}
      }
    `;
    }).join("");
  }
  function restoreTmpl(resetters, paths, hasWildcards) {
    const dynamicReset = hasWildcards === true ? `
    const keys = Object.keys(secret)
    const len = keys.length
    for (var i = ${paths.length}; i < len; i++) {
      const k = keys[i]
      const o = secret[k]
      if (o.flat === true) this.groupRestore(o)
      else this.nestedRestore(o)
      secret[k] = null
    }
  ` : "";
    return `
    const secret = this.secret
    ${resetters}
    ${dynamicReset}
    return o
  `;
  }
});

// node_modules/fast-redact/lib/state.js
var require_state = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = state;
  function state(o) {
    const {
      secret,
      censor,
      compileRestore,
      serialize,
      groupRedact,
      nestedRedact,
      wildcards,
      wcLen
    } = o;
    const builder = [{secret, censor, compileRestore}];
    if (serialize !== false)
      builder.push({serialize});
    if (wcLen > 0)
      builder.push({groupRedact, nestedRedact, wildcards, wcLen});
    return Object.assign(...builder);
  }
});

// node_modules/fast-redact/index.js
var require_fast_redact = __commonJS((exports2, module2) => {
  "use strict";
  var validator3 = require_validator2();
  var parse = require_parse();
  var redactor = require_redactor();
  var restorer = require_restorer();
  var {groupRedact, nestedRedact} = require_modifiers();
  var state = require_state();
  var rx = require_rx();
  var validate = validator3();
  var noop = (o) => o;
  noop.restore = noop;
  var DEFAULT_CENSOR = "[REDACTED]";
  fastRedact.rx = rx;
  fastRedact.validator = validator3;
  module2.exports = fastRedact;
  function fastRedact(opts = {}) {
    const paths = Array.from(new Set(opts.paths || []));
    const serialize = "serialize" in opts ? opts.serialize === false ? opts.serialize : typeof opts.serialize === "function" ? opts.serialize : JSON.stringify : JSON.stringify;
    const remove = opts.remove;
    if (remove === true && serialize !== JSON.stringify) {
      throw Error("fast-redact \u2013 remove option may only be set when serializer is JSON.stringify");
    }
    const censor = remove === true ? void 0 : "censor" in opts ? opts.censor : DEFAULT_CENSOR;
    const isCensorFct = typeof censor === "function";
    const censorFctTakesPath = isCensorFct && censor.length > 1;
    if (paths.length === 0)
      return serialize || noop;
    validate({paths, serialize, censor});
    const {wildcards, wcLen, secret} = parse({paths, censor});
    const compileRestore = restorer({secret, wcLen});
    const strict = "strict" in opts ? opts.strict : true;
    return redactor({secret, wcLen, serialize, strict, isCensorFct, censorFctTakesPath}, state({
      secret,
      censor,
      compileRestore,
      serialize,
      groupRedact,
      nestedRedact,
      wildcards,
      wcLen
    }));
  }
});

// node_modules/pino/lib/symbols.js
var require_symbols = __commonJS((exports2, module2) => {
  "use strict";
  var setLevelSym = Symbol("pino.setLevel");
  var getLevelSym = Symbol("pino.getLevel");
  var levelValSym = Symbol("pino.levelVal");
  var useLevelLabelsSym = Symbol("pino.useLevelLabels");
  var levelKeySym = Symbol("pino.levelKey");
  var useOnlyCustomLevelsSym = Symbol("pino.useOnlyCustomLevels");
  var mixinSym = Symbol("pino.mixin");
  var lsCacheSym = Symbol("pino.lsCache");
  var chindingsSym = Symbol("pino.chindings");
  var parsedChindingsSym = Symbol("pino.parsedChindings");
  var asJsonSym = Symbol("pino.asJson");
  var writeSym = Symbol("pino.write");
  var redactFmtSym = Symbol("pino.redactFmt");
  var timeSym = Symbol("pino.time");
  var timeSliceIndexSym = Symbol("pino.timeSliceIndex");
  var streamSym = Symbol("pino.stream");
  var stringifySym = Symbol("pino.stringify");
  var stringifiersSym = Symbol("pino.stringifiers");
  var endSym = Symbol("pino.end");
  var formatOptsSym = Symbol("pino.formatOpts");
  var messageKeySym = Symbol("pino.messageKey");
  var nestedKeySym = Symbol("pino.nestedKey");
  var wildcardFirstSym = Symbol("pino.wildcardFirst");
  var serializersSym = Symbol.for("pino.serializers");
  var wildcardGsym = Symbol.for("pino.*");
  var needsMetadataGsym = Symbol.for("pino.metadata");
  module2.exports = {
    setLevelSym,
    getLevelSym,
    levelValSym,
    useLevelLabelsSym,
    mixinSym,
    lsCacheSym,
    chindingsSym,
    parsedChindingsSym,
    asJsonSym,
    writeSym,
    serializersSym,
    redactFmtSym,
    timeSym,
    timeSliceIndexSym,
    streamSym,
    stringifySym,
    stringifiersSym,
    endSym,
    formatOptsSym,
    messageKeySym,
    nestedKeySym,
    wildcardFirstSym,
    levelKeySym,
    wildcardGsym,
    needsMetadataGsym,
    useOnlyCustomLevelsSym
  };
});

// node_modules/pino/lib/redaction.js
var require_redaction = __commonJS((exports2, module2) => {
  "use strict";
  var fastRedact = require_fast_redact();
  var {redactFmtSym, wildcardFirstSym} = require_symbols();
  var {rx, validator: validator3} = fastRedact;
  var validate = validator3({
    ERR_PATHS_MUST_BE_STRINGS: () => "pino \u2013 redacted paths must be strings",
    ERR_INVALID_PATH: (s) => `pino \u2013 redact paths array contains an invalid path (${s})`
  });
  var CENSOR = "[Redacted]";
  var strict = false;
  function redaction(opts, serialize) {
    const {paths, censor} = handle(opts);
    const shape = paths.reduce((o, str) => {
      rx.lastIndex = 0;
      const first = rx.exec(str);
      const next = rx.exec(str);
      let ns = first[1] !== void 0 ? first[1].replace(/^(?:"|'|`)(.*)(?:"|'|`)$/, "$1") : first[0];
      if (ns === "*") {
        ns = wildcardFirstSym;
      }
      if (next === null) {
        o[ns] = null;
        return o;
      }
      if (o[ns] === null) {
        return o;
      }
      const {index} = next;
      const nextPath = `${str.substr(index, str.length - 1)}`;
      o[ns] = o[ns] || [];
      if (ns !== wildcardFirstSym && o[ns].length === 0) {
        o[ns].push(...o[wildcardFirstSym] || []);
      }
      if (ns === wildcardFirstSym) {
        Object.keys(o).forEach(function(k) {
          if (o[k]) {
            o[k].push(nextPath);
          }
        });
      }
      o[ns].push(nextPath);
      return o;
    }, {});
    const result = {
      [redactFmtSym]: fastRedact({paths, censor, serialize, strict})
    };
    const topCensor = (...args) => typeof censor === "function" ? serialize(censor(...args)) : serialize(censor);
    return [...Object.keys(shape), ...Object.getOwnPropertySymbols(shape)].reduce((o, k) => {
      if (shape[k] === null)
        o[k] = topCensor;
      else
        o[k] = fastRedact({paths: shape[k], censor, serialize, strict});
      return o;
    }, result);
  }
  function handle(opts) {
    if (Array.isArray(opts)) {
      opts = {paths: opts, censor: CENSOR};
      validate(opts);
      return opts;
    }
    var {paths, censor = CENSOR, remove} = opts;
    if (Array.isArray(paths) === false) {
      throw Error("pino \u2013 redact must contain an array of strings");
    }
    if (remove === true)
      censor = void 0;
    validate({paths, censor});
    return {paths, censor};
  }
  module2.exports = redaction;
});

// node_modules/pino/lib/time.js
var require_time = __commonJS((exports2, module2) => {
  "use strict";
  var nullTime = () => "";
  var epochTime = () => `,"time":${Date.now()}`;
  var unixTime = () => `,"time":${Math.round(Date.now() / 1e3)}`;
  var isoTime = () => `,"time":"${new Date(Date.now()).toISOString()}"`;
  module2.exports = {nullTime, epochTime, unixTime, isoTime};
});

// node_modules/flatstr/index.js
var require_flatstr = __commonJS((exports2, module2) => {
  "use strict";
  function flatstr(s) {
    s | 0;
    return s;
  }
  module2.exports = flatstr;
});

// node_modules/atomic-sleep/index.js
var require_atomic_sleep = __commonJS((exports2, module2) => {
  "use strict";
  if (typeof SharedArrayBuffer !== "undefined" && typeof Atomics !== "undefined") {
    let sleep = function(ms) {
      const valid = ms > 0 && ms < Infinity;
      if (valid === false) {
        if (typeof ms !== "number" && typeof ms !== "bigint") {
          throw TypeError("sleep: ms must be a number");
        }
        throw RangeError("sleep: ms must be a number that is greater than 0 but less than Infinity");
      }
      Atomics.wait(nil, 0, 0, Number(ms));
    };
    const nil = new Int32Array(new SharedArrayBuffer(4));
    module2.exports = sleep;
  } else {
    let sleep = function(ms) {
      const valid = ms > 0 && ms < Infinity;
      if (valid === false) {
        if (typeof ms !== "number" && typeof ms !== "bigint") {
          throw TypeError("sleep: ms must be a number");
        }
        throw RangeError("sleep: ms must be a number that is greater than 0 but less than Infinity");
      }
      const target = Date.now() + Number(ms);
      while (target > Date.now()) {
      }
    };
    module2.exports = sleep;
  }
});

// node_modules/sonic-boom/index.js
var require_sonic_boom = __commonJS((exports2, module2) => {
  "use strict";
  var fs = require("fs");
  var EventEmitter = require("events");
  var flatstr = require_flatstr();
  var inherits = require("util").inherits;
  var BUSY_WRITE_TIMEOUT = 100;
  var sleep = require_atomic_sleep();
  var MAX_WRITE = 16 * 1024 * 1024;
  function openFile(file, sonic) {
    sonic._opening = true;
    sonic._writing = true;
    sonic.file = file;
    fs.open(file, "a", (err, fd) => {
      if (err) {
        sonic.emit("error", err);
        return;
      }
      sonic.fd = fd;
      sonic._reopening = false;
      sonic._opening = false;
      sonic._writing = false;
      sonic.emit("ready");
      if (sonic._reopening) {
        return;
      }
      var len = sonic._buf.length;
      if (len > 0 && len > sonic.minLength && !sonic.destroyed) {
        actualWrite(sonic);
      }
    });
  }
  function SonicBoom(fd, minLength, sync) {
    if (!(this instanceof SonicBoom)) {
      return new SonicBoom(fd, minLength, sync);
    }
    this._buf = "";
    this.fd = -1;
    this._writing = false;
    this._writingBuf = "";
    this._ending = false;
    this._reopening = false;
    this._asyncDrainScheduled = false;
    this.file = null;
    this.destroyed = false;
    this.sync = sync || false;
    this.minLength = minLength || 0;
    if (typeof fd === "number") {
      this.fd = fd;
      process.nextTick(() => this.emit("ready"));
    } else if (typeof fd === "string") {
      openFile(fd, this);
    } else {
      throw new Error("SonicBoom supports only file descriptors and files");
    }
    this.release = (err, n) => {
      if (err) {
        if (err.code === "EAGAIN") {
          if (this.sync) {
            try {
              sleep(BUSY_WRITE_TIMEOUT);
              this.release(void 0, 0);
            } catch (err2) {
              this.release(err2);
            }
          } else {
            setTimeout(() => {
              fs.write(this.fd, this._writingBuf, "utf8", this.release);
            }, BUSY_WRITE_TIMEOUT);
          }
        } else {
          this.emit("error", err);
        }
        return;
      }
      if (this._writingBuf.length !== n) {
        this._writingBuf = this._writingBuf.slice(n);
        if (this.sync) {
          try {
            do {
              n = fs.writeSync(this.fd, this._writingBuf, "utf8");
              this._writingBuf = this._writingBuf.slice(n);
            } while (this._writingBuf.length !== 0);
          } catch (err2) {
            this.release(err2);
            return;
          }
        } else {
          fs.write(this.fd, this._writingBuf, "utf8", this.release);
          return;
        }
      }
      this._writingBuf = "";
      if (this.destroyed) {
        return;
      }
      var len = this._buf.length;
      if (this._reopening) {
        this._writing = false;
        this._reopening = false;
        this.reopen();
      } else if (len > 0 && len > this.minLength) {
        actualWrite(this);
      } else if (this._ending) {
        if (len > 0) {
          actualWrite(this);
        } else {
          this._writing = false;
          actualClose(this);
        }
      } else {
        this._writing = false;
        if (this.sync) {
          if (!this._asyncDrainScheduled) {
            this._asyncDrainScheduled = true;
            process.nextTick(emitDrain, this);
          }
        } else {
          this.emit("drain");
        }
      }
    };
  }
  function emitDrain(sonic) {
    sonic._asyncDrainScheduled = false;
    sonic.emit("drain");
  }
  inherits(SonicBoom, EventEmitter);
  SonicBoom.prototype.write = function(data) {
    if (this.destroyed) {
      throw new Error("SonicBoom destroyed");
    }
    this._buf += data;
    var len = this._buf.length;
    if (!this._writing && len > this.minLength) {
      actualWrite(this);
    }
    return len < 16384;
  };
  SonicBoom.prototype.flush = function() {
    if (this.destroyed) {
      throw new Error("SonicBoom destroyed");
    }
    if (this._writing || this.minLength <= 0) {
      return;
    }
    actualWrite(this);
  };
  SonicBoom.prototype.reopen = function(file) {
    if (this.destroyed) {
      throw new Error("SonicBoom destroyed");
    }
    if (this._opening) {
      this.once("ready", () => {
        this.reopen(file);
      });
      return;
    }
    if (this._ending) {
      return;
    }
    if (!this.file) {
      throw new Error("Unable to reopen a file descriptor, you must pass a file to SonicBoom");
    }
    this._reopening = true;
    if (this._writing) {
      return;
    }
    fs.close(this.fd, (err) => {
      if (err) {
        return this.emit("error", err);
      }
    });
    openFile(file || this.file, this);
  };
  SonicBoom.prototype.end = function() {
    if (this.destroyed) {
      throw new Error("SonicBoom destroyed");
    }
    if (this._opening) {
      this.once("ready", () => {
        this.end();
      });
      return;
    }
    if (this._ending) {
      return;
    }
    this._ending = true;
    if (!this._writing && this._buf.length > 0 && this.fd >= 0) {
      actualWrite(this);
      return;
    }
    if (this._writing) {
      return;
    }
    actualClose(this);
  };
  SonicBoom.prototype.flushSync = function() {
    if (this.destroyed) {
      throw new Error("SonicBoom destroyed");
    }
    if (this.fd < 0) {
      throw new Error("sonic boom is not ready yet");
    }
    if (this._buf.length > 0) {
      fs.writeSync(this.fd, this._buf, "utf8");
      this._buf = "";
    }
  };
  SonicBoom.prototype.destroy = function() {
    if (this.destroyed) {
      return;
    }
    actualClose(this);
  };
  function actualWrite(sonic) {
    sonic._writing = true;
    var buf = sonic._buf;
    var release = sonic.release;
    if (buf.length > MAX_WRITE) {
      buf = buf.slice(0, MAX_WRITE);
      sonic._buf = sonic._buf.slice(MAX_WRITE);
    } else {
      sonic._buf = "";
    }
    flatstr(buf);
    sonic._writingBuf = buf;
    if (sonic.sync) {
      try {
        var written = fs.writeSync(sonic.fd, buf, "utf8");
        release(null, written);
      } catch (err) {
        release(err);
      }
    } else {
      fs.write(sonic.fd, buf, "utf8", release);
    }
  }
  function actualClose(sonic) {
    if (sonic.fd === -1) {
      sonic.once("ready", actualClose.bind(null, sonic));
      return;
    }
    fs.close(sonic.fd, (err) => {
      if (err) {
        sonic.emit("error", err);
        return;
      }
      if (sonic._ending && !sonic._writing) {
        sonic.emit("finish");
      }
      sonic.emit("close");
    });
    sonic.destroyed = true;
    sonic._buf = "";
  }
  module2.exports = SonicBoom;
});

// node_modules/quick-format-unescaped/index.js
var require_quick_format_unescaped = __commonJS((exports2, module2) => {
  "use strict";
  function tryStringify(o) {
    try {
      return JSON.stringify(o);
    } catch (e) {
      return '"[Circular]"';
    }
  }
  module2.exports = format;
  function format(f, args, opts) {
    var ss = opts && opts.stringify || tryStringify;
    var offset = 1;
    if (f === null) {
      f = args[0];
      offset = 0;
    }
    if (typeof f === "object" && f !== null) {
      var len = args.length + offset;
      if (len === 1)
        return f;
      var objects = new Array(len);
      objects[0] = ss(f);
      for (var index = 1; index < len; index++) {
        objects[index] = ss(args[index]);
      }
      return objects.join(" ");
    }
    var argLen = args.length;
    if (argLen === 0)
      return f;
    var x = "";
    var str = "";
    var a = 1 - offset;
    var lastPos = 0;
    var flen = f && f.length || 0;
    for (var i = 0; i < flen; ) {
      if (f.charCodeAt(i) === 37 && i + 1 < flen) {
        switch (f.charCodeAt(i + 1)) {
          case 100:
            if (a >= argLen)
              break;
            if (lastPos < i)
              str += f.slice(lastPos, i);
            if (args[a] == null)
              break;
            str += Number(args[a]);
            lastPos = i = i + 2;
            break;
          case 79:
          case 111:
          case 106:
            if (a >= argLen)
              break;
            if (lastPos < i)
              str += f.slice(lastPos, i);
            if (args[a] === void 0)
              break;
            var type = typeof args[a];
            if (type === "string") {
              str += "'" + args[a] + "'";
              lastPos = i + 2;
              i++;
              break;
            }
            if (type === "function") {
              str += args[a].name || "<anonymous>";
              lastPos = i + 2;
              i++;
              break;
            }
            str += ss(args[a]);
            lastPos = i + 2;
            i++;
            break;
          case 115:
            if (a >= argLen)
              break;
            if (lastPos < i)
              str += f.slice(lastPos, i);
            str += String(args[a]);
            lastPos = i + 2;
            i++;
            break;
          case 37:
            if (lastPos < i)
              str += f.slice(lastPos, i);
            str += "%";
            lastPos = i + 2;
            i++;
            break;
        }
        ++a;
      }
      ++i;
    }
    if (lastPos === 0)
      str = f;
    else if (lastPos < flen) {
      str += f.slice(lastPos);
    }
    while (a < argLen) {
      x = args[a++];
      if (x === null || typeof x !== "object") {
        str += " " + String(x);
      } else {
        str += " " + ss(x);
      }
    }
    return str;
  }
});

// node_modules/fast-safe-stringify/index.js
var require_fast_safe_stringify = __commonJS((exports2, module2) => {
  module2.exports = stringify;
  stringify.default = stringify;
  stringify.stable = deterministicStringify;
  stringify.stableStringify = deterministicStringify;
  var arr = [];
  var replacerStack = [];
  function stringify(obj, replacer, spacer) {
    decirc(obj, "", [], void 0);
    var res;
    if (replacerStack.length === 0) {
      res = JSON.stringify(obj, replacer, spacer);
    } else {
      res = JSON.stringify(obj, replaceGetterValues(replacer), spacer);
    }
    while (arr.length !== 0) {
      var part = arr.pop();
      if (part.length === 4) {
        Object.defineProperty(part[0], part[1], part[3]);
      } else {
        part[0][part[1]] = part[2];
      }
    }
    return res;
  }
  function decirc(val, k, stack, parent) {
    var i;
    if (typeof val === "object" && val !== null) {
      for (i = 0; i < stack.length; i++) {
        if (stack[i] === val) {
          var propertyDescriptor = Object.getOwnPropertyDescriptor(parent, k);
          if (propertyDescriptor.get !== void 0) {
            if (propertyDescriptor.configurable) {
              Object.defineProperty(parent, k, {value: "[Circular]"});
              arr.push([parent, k, val, propertyDescriptor]);
            } else {
              replacerStack.push([val, k]);
            }
          } else {
            parent[k] = "[Circular]";
            arr.push([parent, k, val]);
          }
          return;
        }
      }
      stack.push(val);
      if (Array.isArray(val)) {
        for (i = 0; i < val.length; i++) {
          decirc(val[i], i, stack, val);
        }
      } else {
        var keys = Object.keys(val);
        for (i = 0; i < keys.length; i++) {
          var key = keys[i];
          decirc(val[key], key, stack, val);
        }
      }
      stack.pop();
    }
  }
  function compareFunction(a, b) {
    if (a < b) {
      return -1;
    }
    if (a > b) {
      return 1;
    }
    return 0;
  }
  function deterministicStringify(obj, replacer, spacer) {
    var tmp = deterministicDecirc(obj, "", [], void 0) || obj;
    var res;
    if (replacerStack.length === 0) {
      res = JSON.stringify(tmp, replacer, spacer);
    } else {
      res = JSON.stringify(tmp, replaceGetterValues(replacer), spacer);
    }
    while (arr.length !== 0) {
      var part = arr.pop();
      if (part.length === 4) {
        Object.defineProperty(part[0], part[1], part[3]);
      } else {
        part[0][part[1]] = part[2];
      }
    }
    return res;
  }
  function deterministicDecirc(val, k, stack, parent) {
    var i;
    if (typeof val === "object" && val !== null) {
      for (i = 0; i < stack.length; i++) {
        if (stack[i] === val) {
          var propertyDescriptor = Object.getOwnPropertyDescriptor(parent, k);
          if (propertyDescriptor.get !== void 0) {
            if (propertyDescriptor.configurable) {
              Object.defineProperty(parent, k, {value: "[Circular]"});
              arr.push([parent, k, val, propertyDescriptor]);
            } else {
              replacerStack.push([val, k]);
            }
          } else {
            parent[k] = "[Circular]";
            arr.push([parent, k, val]);
          }
          return;
        }
      }
      if (typeof val.toJSON === "function") {
        return;
      }
      stack.push(val);
      if (Array.isArray(val)) {
        for (i = 0; i < val.length; i++) {
          deterministicDecirc(val[i], i, stack, val);
        }
      } else {
        var tmp = {};
        var keys = Object.keys(val).sort(compareFunction);
        for (i = 0; i < keys.length; i++) {
          var key = keys[i];
          deterministicDecirc(val[key], key, stack, val);
          tmp[key] = val[key];
        }
        if (parent !== void 0) {
          arr.push([parent, k, val]);
          parent[k] = tmp;
        } else {
          return tmp;
        }
      }
      stack.pop();
    }
  }
  function replaceGetterValues(replacer) {
    replacer = replacer !== void 0 ? replacer : function(k, v) {
      return v;
    };
    return function(key, val) {
      if (replacerStack.length > 0) {
        for (var i = 0; i < replacerStack.length; i++) {
          var part = replacerStack[i];
          if (part[1] === key && part[0] === val) {
            val = "[Circular]";
            replacerStack.splice(i, 1);
            break;
          }
        }
      }
      return replacer.call(this, key, val);
    };
  }
});

// node_modules/escape-string-regexp/index.js
var require_escape_string_regexp = __commonJS((exports2, module2) => {
  "use strict";
  var matchOperatorsRe = /[|\\{}()[\]^$+*?.]/g;
  module2.exports = function(str) {
    if (typeof str !== "string") {
      throw new TypeError("Expected a string");
    }
    return str.replace(matchOperatorsRe, "\\$&");
  };
});

// node_modules/color-name/index.js
var require_color_name = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = {
    aliceblue: [240, 248, 255],
    antiquewhite: [250, 235, 215],
    aqua: [0, 255, 255],
    aquamarine: [127, 255, 212],
    azure: [240, 255, 255],
    beige: [245, 245, 220],
    bisque: [255, 228, 196],
    black: [0, 0, 0],
    blanchedalmond: [255, 235, 205],
    blue: [0, 0, 255],
    blueviolet: [138, 43, 226],
    brown: [165, 42, 42],
    burlywood: [222, 184, 135],
    cadetblue: [95, 158, 160],
    chartreuse: [127, 255, 0],
    chocolate: [210, 105, 30],
    coral: [255, 127, 80],
    cornflowerblue: [100, 149, 237],
    cornsilk: [255, 248, 220],
    crimson: [220, 20, 60],
    cyan: [0, 255, 255],
    darkblue: [0, 0, 139],
    darkcyan: [0, 139, 139],
    darkgoldenrod: [184, 134, 11],
    darkgray: [169, 169, 169],
    darkgreen: [0, 100, 0],
    darkgrey: [169, 169, 169],
    darkkhaki: [189, 183, 107],
    darkmagenta: [139, 0, 139],
    darkolivegreen: [85, 107, 47],
    darkorange: [255, 140, 0],
    darkorchid: [153, 50, 204],
    darkred: [139, 0, 0],
    darksalmon: [233, 150, 122],
    darkseagreen: [143, 188, 143],
    darkslateblue: [72, 61, 139],
    darkslategray: [47, 79, 79],
    darkslategrey: [47, 79, 79],
    darkturquoise: [0, 206, 209],
    darkviolet: [148, 0, 211],
    deeppink: [255, 20, 147],
    deepskyblue: [0, 191, 255],
    dimgray: [105, 105, 105],
    dimgrey: [105, 105, 105],
    dodgerblue: [30, 144, 255],
    firebrick: [178, 34, 34],
    floralwhite: [255, 250, 240],
    forestgreen: [34, 139, 34],
    fuchsia: [255, 0, 255],
    gainsboro: [220, 220, 220],
    ghostwhite: [248, 248, 255],
    gold: [255, 215, 0],
    goldenrod: [218, 165, 32],
    gray: [128, 128, 128],
    green: [0, 128, 0],
    greenyellow: [173, 255, 47],
    grey: [128, 128, 128],
    honeydew: [240, 255, 240],
    hotpink: [255, 105, 180],
    indianred: [205, 92, 92],
    indigo: [75, 0, 130],
    ivory: [255, 255, 240],
    khaki: [240, 230, 140],
    lavender: [230, 230, 250],
    lavenderblush: [255, 240, 245],
    lawngreen: [124, 252, 0],
    lemonchiffon: [255, 250, 205],
    lightblue: [173, 216, 230],
    lightcoral: [240, 128, 128],
    lightcyan: [224, 255, 255],
    lightgoldenrodyellow: [250, 250, 210],
    lightgray: [211, 211, 211],
    lightgreen: [144, 238, 144],
    lightgrey: [211, 211, 211],
    lightpink: [255, 182, 193],
    lightsalmon: [255, 160, 122],
    lightseagreen: [32, 178, 170],
    lightskyblue: [135, 206, 250],
    lightslategray: [119, 136, 153],
    lightslategrey: [119, 136, 153],
    lightsteelblue: [176, 196, 222],
    lightyellow: [255, 255, 224],
    lime: [0, 255, 0],
    limegreen: [50, 205, 50],
    linen: [250, 240, 230],
    magenta: [255, 0, 255],
    maroon: [128, 0, 0],
    mediumaquamarine: [102, 205, 170],
    mediumblue: [0, 0, 205],
    mediumorchid: [186, 85, 211],
    mediumpurple: [147, 112, 219],
    mediumseagreen: [60, 179, 113],
    mediumslateblue: [123, 104, 238],
    mediumspringgreen: [0, 250, 154],
    mediumturquoise: [72, 209, 204],
    mediumvioletred: [199, 21, 133],
    midnightblue: [25, 25, 112],
    mintcream: [245, 255, 250],
    mistyrose: [255, 228, 225],
    moccasin: [255, 228, 181],
    navajowhite: [255, 222, 173],
    navy: [0, 0, 128],
    oldlace: [253, 245, 230],
    olive: [128, 128, 0],
    olivedrab: [107, 142, 35],
    orange: [255, 165, 0],
    orangered: [255, 69, 0],
    orchid: [218, 112, 214],
    palegoldenrod: [238, 232, 170],
    palegreen: [152, 251, 152],
    paleturquoise: [175, 238, 238],
    palevioletred: [219, 112, 147],
    papayawhip: [255, 239, 213],
    peachpuff: [255, 218, 185],
    peru: [205, 133, 63],
    pink: [255, 192, 203],
    plum: [221, 160, 221],
    powderblue: [176, 224, 230],
    purple: [128, 0, 128],
    rebeccapurple: [102, 51, 153],
    red: [255, 0, 0],
    rosybrown: [188, 143, 143],
    royalblue: [65, 105, 225],
    saddlebrown: [139, 69, 19],
    salmon: [250, 128, 114],
    sandybrown: [244, 164, 96],
    seagreen: [46, 139, 87],
    seashell: [255, 245, 238],
    sienna: [160, 82, 45],
    silver: [192, 192, 192],
    skyblue: [135, 206, 235],
    slateblue: [106, 90, 205],
    slategray: [112, 128, 144],
    slategrey: [112, 128, 144],
    snow: [255, 250, 250],
    springgreen: [0, 255, 127],
    steelblue: [70, 130, 180],
    tan: [210, 180, 140],
    teal: [0, 128, 128],
    thistle: [216, 191, 216],
    tomato: [255, 99, 71],
    turquoise: [64, 224, 208],
    violet: [238, 130, 238],
    wheat: [245, 222, 179],
    white: [255, 255, 255],
    whitesmoke: [245, 245, 245],
    yellow: [255, 255, 0],
    yellowgreen: [154, 205, 50]
  };
});

// node_modules/color-convert/conversions.js
var require_conversions = __commonJS((exports2, module2) => {
  var cssKeywords = require_color_name();
  var reverseKeywords = {};
  for (var key in cssKeywords) {
    if (cssKeywords.hasOwnProperty(key)) {
      reverseKeywords[cssKeywords[key]] = key;
    }
  }
  var convert = module2.exports = {
    rgb: {channels: 3, labels: "rgb"},
    hsl: {channels: 3, labels: "hsl"},
    hsv: {channels: 3, labels: "hsv"},
    hwb: {channels: 3, labels: "hwb"},
    cmyk: {channels: 4, labels: "cmyk"},
    xyz: {channels: 3, labels: "xyz"},
    lab: {channels: 3, labels: "lab"},
    lch: {channels: 3, labels: "lch"},
    hex: {channels: 1, labels: ["hex"]},
    keyword: {channels: 1, labels: ["keyword"]},
    ansi16: {channels: 1, labels: ["ansi16"]},
    ansi256: {channels: 1, labels: ["ansi256"]},
    hcg: {channels: 3, labels: ["h", "c", "g"]},
    apple: {channels: 3, labels: ["r16", "g16", "b16"]},
    gray: {channels: 1, labels: ["gray"]}
  };
  for (var model in convert) {
    if (convert.hasOwnProperty(model)) {
      if (!("channels" in convert[model])) {
        throw new Error("missing channels property: " + model);
      }
      if (!("labels" in convert[model])) {
        throw new Error("missing channel labels property: " + model);
      }
      if (convert[model].labels.length !== convert[model].channels) {
        throw new Error("channel and label counts mismatch: " + model);
      }
      channels = convert[model].channels;
      labels = convert[model].labels;
      delete convert[model].channels;
      delete convert[model].labels;
      Object.defineProperty(convert[model], "channels", {value: channels});
      Object.defineProperty(convert[model], "labels", {value: labels});
    }
  }
  var channels;
  var labels;
  convert.rgb.hsl = function(rgb) {
    var r = rgb[0] / 255;
    var g = rgb[1] / 255;
    var b = rgb[2] / 255;
    var min = Math.min(r, g, b);
    var max = Math.max(r, g, b);
    var delta = max - min;
    var h;
    var s;
    var l;
    if (max === min) {
      h = 0;
    } else if (r === max) {
      h = (g - b) / delta;
    } else if (g === max) {
      h = 2 + (b - r) / delta;
    } else if (b === max) {
      h = 4 + (r - g) / delta;
    }
    h = Math.min(h * 60, 360);
    if (h < 0) {
      h += 360;
    }
    l = (min + max) / 2;
    if (max === min) {
      s = 0;
    } else if (l <= 0.5) {
      s = delta / (max + min);
    } else {
      s = delta / (2 - max - min);
    }
    return [h, s * 100, l * 100];
  };
  convert.rgb.hsv = function(rgb) {
    var rdif;
    var gdif;
    var bdif;
    var h;
    var s;
    var r = rgb[0] / 255;
    var g = rgb[1] / 255;
    var b = rgb[2] / 255;
    var v = Math.max(r, g, b);
    var diff = v - Math.min(r, g, b);
    var diffc = function(c) {
      return (v - c) / 6 / diff + 1 / 2;
    };
    if (diff === 0) {
      h = s = 0;
    } else {
      s = diff / v;
      rdif = diffc(r);
      gdif = diffc(g);
      bdif = diffc(b);
      if (r === v) {
        h = bdif - gdif;
      } else if (g === v) {
        h = 1 / 3 + rdif - bdif;
      } else if (b === v) {
        h = 2 / 3 + gdif - rdif;
      }
      if (h < 0) {
        h += 1;
      } else if (h > 1) {
        h -= 1;
      }
    }
    return [
      h * 360,
      s * 100,
      v * 100
    ];
  };
  convert.rgb.hwb = function(rgb) {
    var r = rgb[0];
    var g = rgb[1];
    var b = rgb[2];
    var h = convert.rgb.hsl(rgb)[0];
    var w = 1 / 255 * Math.min(r, Math.min(g, b));
    b = 1 - 1 / 255 * Math.max(r, Math.max(g, b));
    return [h, w * 100, b * 100];
  };
  convert.rgb.cmyk = function(rgb) {
    var r = rgb[0] / 255;
    var g = rgb[1] / 255;
    var b = rgb[2] / 255;
    var c;
    var m;
    var y;
    var k;
    k = Math.min(1 - r, 1 - g, 1 - b);
    c = (1 - r - k) / (1 - k) || 0;
    m = (1 - g - k) / (1 - k) || 0;
    y = (1 - b - k) / (1 - k) || 0;
    return [c * 100, m * 100, y * 100, k * 100];
  };
  function comparativeDistance(x, y) {
    return Math.pow(x[0] - y[0], 2) + Math.pow(x[1] - y[1], 2) + Math.pow(x[2] - y[2], 2);
  }
  convert.rgb.keyword = function(rgb) {
    var reversed = reverseKeywords[rgb];
    if (reversed) {
      return reversed;
    }
    var currentClosestDistance = Infinity;
    var currentClosestKeyword;
    for (var keyword in cssKeywords) {
      if (cssKeywords.hasOwnProperty(keyword)) {
        var value = cssKeywords[keyword];
        var distance = comparativeDistance(rgb, value);
        if (distance < currentClosestDistance) {
          currentClosestDistance = distance;
          currentClosestKeyword = keyword;
        }
      }
    }
    return currentClosestKeyword;
  };
  convert.keyword.rgb = function(keyword) {
    return cssKeywords[keyword];
  };
  convert.rgb.xyz = function(rgb) {
    var r = rgb[0] / 255;
    var g = rgb[1] / 255;
    var b = rgb[2] / 255;
    r = r > 0.04045 ? Math.pow((r + 0.055) / 1.055, 2.4) : r / 12.92;
    g = g > 0.04045 ? Math.pow((g + 0.055) / 1.055, 2.4) : g / 12.92;
    b = b > 0.04045 ? Math.pow((b + 0.055) / 1.055, 2.4) : b / 12.92;
    var x = r * 0.4124 + g * 0.3576 + b * 0.1805;
    var y = r * 0.2126 + g * 0.7152 + b * 0.0722;
    var z = r * 0.0193 + g * 0.1192 + b * 0.9505;
    return [x * 100, y * 100, z * 100];
  };
  convert.rgb.lab = function(rgb) {
    var xyz = convert.rgb.xyz(rgb);
    var x = xyz[0];
    var y = xyz[1];
    var z = xyz[2];
    var l;
    var a;
    var b;
    x /= 95.047;
    y /= 100;
    z /= 108.883;
    x = x > 8856e-6 ? Math.pow(x, 1 / 3) : 7.787 * x + 16 / 116;
    y = y > 8856e-6 ? Math.pow(y, 1 / 3) : 7.787 * y + 16 / 116;
    z = z > 8856e-6 ? Math.pow(z, 1 / 3) : 7.787 * z + 16 / 116;
    l = 116 * y - 16;
    a = 500 * (x - y);
    b = 200 * (y - z);
    return [l, a, b];
  };
  convert.hsl.rgb = function(hsl) {
    var h = hsl[0] / 360;
    var s = hsl[1] / 100;
    var l = hsl[2] / 100;
    var t1;
    var t2;
    var t3;
    var rgb;
    var val;
    if (s === 0) {
      val = l * 255;
      return [val, val, val];
    }
    if (l < 0.5) {
      t2 = l * (1 + s);
    } else {
      t2 = l + s - l * s;
    }
    t1 = 2 * l - t2;
    rgb = [0, 0, 0];
    for (var i = 0; i < 3; i++) {
      t3 = h + 1 / 3 * -(i - 1);
      if (t3 < 0) {
        t3++;
      }
      if (t3 > 1) {
        t3--;
      }
      if (6 * t3 < 1) {
        val = t1 + (t2 - t1) * 6 * t3;
      } else if (2 * t3 < 1) {
        val = t2;
      } else if (3 * t3 < 2) {
        val = t1 + (t2 - t1) * (2 / 3 - t3) * 6;
      } else {
        val = t1;
      }
      rgb[i] = val * 255;
    }
    return rgb;
  };
  convert.hsl.hsv = function(hsl) {
    var h = hsl[0];
    var s = hsl[1] / 100;
    var l = hsl[2] / 100;
    var smin = s;
    var lmin = Math.max(l, 0.01);
    var sv;
    var v;
    l *= 2;
    s *= l <= 1 ? l : 2 - l;
    smin *= lmin <= 1 ? lmin : 2 - lmin;
    v = (l + s) / 2;
    sv = l === 0 ? 2 * smin / (lmin + smin) : 2 * s / (l + s);
    return [h, sv * 100, v * 100];
  };
  convert.hsv.rgb = function(hsv) {
    var h = hsv[0] / 60;
    var s = hsv[1] / 100;
    var v = hsv[2] / 100;
    var hi = Math.floor(h) % 6;
    var f = h - Math.floor(h);
    var p = 255 * v * (1 - s);
    var q = 255 * v * (1 - s * f);
    var t = 255 * v * (1 - s * (1 - f));
    v *= 255;
    switch (hi) {
      case 0:
        return [v, t, p];
      case 1:
        return [q, v, p];
      case 2:
        return [p, v, t];
      case 3:
        return [p, q, v];
      case 4:
        return [t, p, v];
      case 5:
        return [v, p, q];
    }
  };
  convert.hsv.hsl = function(hsv) {
    var h = hsv[0];
    var s = hsv[1] / 100;
    var v = hsv[2] / 100;
    var vmin = Math.max(v, 0.01);
    var lmin;
    var sl;
    var l;
    l = (2 - s) * v;
    lmin = (2 - s) * vmin;
    sl = s * vmin;
    sl /= lmin <= 1 ? lmin : 2 - lmin;
    sl = sl || 0;
    l /= 2;
    return [h, sl * 100, l * 100];
  };
  convert.hwb.rgb = function(hwb) {
    var h = hwb[0] / 360;
    var wh = hwb[1] / 100;
    var bl = hwb[2] / 100;
    var ratio = wh + bl;
    var i;
    var v;
    var f;
    var n;
    if (ratio > 1) {
      wh /= ratio;
      bl /= ratio;
    }
    i = Math.floor(6 * h);
    v = 1 - bl;
    f = 6 * h - i;
    if ((i & 1) !== 0) {
      f = 1 - f;
    }
    n = wh + f * (v - wh);
    var r;
    var g;
    var b;
    switch (i) {
      default:
      case 6:
      case 0:
        r = v;
        g = n;
        b = wh;
        break;
      case 1:
        r = n;
        g = v;
        b = wh;
        break;
      case 2:
        r = wh;
        g = v;
        b = n;
        break;
      case 3:
        r = wh;
        g = n;
        b = v;
        break;
      case 4:
        r = n;
        g = wh;
        b = v;
        break;
      case 5:
        r = v;
        g = wh;
        b = n;
        break;
    }
    return [r * 255, g * 255, b * 255];
  };
  convert.cmyk.rgb = function(cmyk) {
    var c = cmyk[0] / 100;
    var m = cmyk[1] / 100;
    var y = cmyk[2] / 100;
    var k = cmyk[3] / 100;
    var r;
    var g;
    var b;
    r = 1 - Math.min(1, c * (1 - k) + k);
    g = 1 - Math.min(1, m * (1 - k) + k);
    b = 1 - Math.min(1, y * (1 - k) + k);
    return [r * 255, g * 255, b * 255];
  };
  convert.xyz.rgb = function(xyz) {
    var x = xyz[0] / 100;
    var y = xyz[1] / 100;
    var z = xyz[2] / 100;
    var r;
    var g;
    var b;
    r = x * 3.2406 + y * -1.5372 + z * -0.4986;
    g = x * -0.9689 + y * 1.8758 + z * 0.0415;
    b = x * 0.0557 + y * -0.204 + z * 1.057;
    r = r > 31308e-7 ? 1.055 * Math.pow(r, 1 / 2.4) - 0.055 : r * 12.92;
    g = g > 31308e-7 ? 1.055 * Math.pow(g, 1 / 2.4) - 0.055 : g * 12.92;
    b = b > 31308e-7 ? 1.055 * Math.pow(b, 1 / 2.4) - 0.055 : b * 12.92;
    r = Math.min(Math.max(0, r), 1);
    g = Math.min(Math.max(0, g), 1);
    b = Math.min(Math.max(0, b), 1);
    return [r * 255, g * 255, b * 255];
  };
  convert.xyz.lab = function(xyz) {
    var x = xyz[0];
    var y = xyz[1];
    var z = xyz[2];
    var l;
    var a;
    var b;
    x /= 95.047;
    y /= 100;
    z /= 108.883;
    x = x > 8856e-6 ? Math.pow(x, 1 / 3) : 7.787 * x + 16 / 116;
    y = y > 8856e-6 ? Math.pow(y, 1 / 3) : 7.787 * y + 16 / 116;
    z = z > 8856e-6 ? Math.pow(z, 1 / 3) : 7.787 * z + 16 / 116;
    l = 116 * y - 16;
    a = 500 * (x - y);
    b = 200 * (y - z);
    return [l, a, b];
  };
  convert.lab.xyz = function(lab) {
    var l = lab[0];
    var a = lab[1];
    var b = lab[2];
    var x;
    var y;
    var z;
    y = (l + 16) / 116;
    x = a / 500 + y;
    z = y - b / 200;
    var y2 = Math.pow(y, 3);
    var x2 = Math.pow(x, 3);
    var z2 = Math.pow(z, 3);
    y = y2 > 8856e-6 ? y2 : (y - 16 / 116) / 7.787;
    x = x2 > 8856e-6 ? x2 : (x - 16 / 116) / 7.787;
    z = z2 > 8856e-6 ? z2 : (z - 16 / 116) / 7.787;
    x *= 95.047;
    y *= 100;
    z *= 108.883;
    return [x, y, z];
  };
  convert.lab.lch = function(lab) {
    var l = lab[0];
    var a = lab[1];
    var b = lab[2];
    var hr;
    var h;
    var c;
    hr = Math.atan2(b, a);
    h = hr * 360 / 2 / Math.PI;
    if (h < 0) {
      h += 360;
    }
    c = Math.sqrt(a * a + b * b);
    return [l, c, h];
  };
  convert.lch.lab = function(lch) {
    var l = lch[0];
    var c = lch[1];
    var h = lch[2];
    var a;
    var b;
    var hr;
    hr = h / 360 * 2 * Math.PI;
    a = c * Math.cos(hr);
    b = c * Math.sin(hr);
    return [l, a, b];
  };
  convert.rgb.ansi16 = function(args) {
    var r = args[0];
    var g = args[1];
    var b = args[2];
    var value = 1 in arguments ? arguments[1] : convert.rgb.hsv(args)[2];
    value = Math.round(value / 50);
    if (value === 0) {
      return 30;
    }
    var ansi = 30 + (Math.round(b / 255) << 2 | Math.round(g / 255) << 1 | Math.round(r / 255));
    if (value === 2) {
      ansi += 60;
    }
    return ansi;
  };
  convert.hsv.ansi16 = function(args) {
    return convert.rgb.ansi16(convert.hsv.rgb(args), args[2]);
  };
  convert.rgb.ansi256 = function(args) {
    var r = args[0];
    var g = args[1];
    var b = args[2];
    if (r === g && g === b) {
      if (r < 8) {
        return 16;
      }
      if (r > 248) {
        return 231;
      }
      return Math.round((r - 8) / 247 * 24) + 232;
    }
    var ansi = 16 + 36 * Math.round(r / 255 * 5) + 6 * Math.round(g / 255 * 5) + Math.round(b / 255 * 5);
    return ansi;
  };
  convert.ansi16.rgb = function(args) {
    var color = args % 10;
    if (color === 0 || color === 7) {
      if (args > 50) {
        color += 3.5;
      }
      color = color / 10.5 * 255;
      return [color, color, color];
    }
    var mult = (~~(args > 50) + 1) * 0.5;
    var r = (color & 1) * mult * 255;
    var g = (color >> 1 & 1) * mult * 255;
    var b = (color >> 2 & 1) * mult * 255;
    return [r, g, b];
  };
  convert.ansi256.rgb = function(args) {
    if (args >= 232) {
      var c = (args - 232) * 10 + 8;
      return [c, c, c];
    }
    args -= 16;
    var rem;
    var r = Math.floor(args / 36) / 5 * 255;
    var g = Math.floor((rem = args % 36) / 6) / 5 * 255;
    var b = rem % 6 / 5 * 255;
    return [r, g, b];
  };
  convert.rgb.hex = function(args) {
    var integer = ((Math.round(args[0]) & 255) << 16) + ((Math.round(args[1]) & 255) << 8) + (Math.round(args[2]) & 255);
    var string = integer.toString(16).toUpperCase();
    return "000000".substring(string.length) + string;
  };
  convert.hex.rgb = function(args) {
    var match = args.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
    if (!match) {
      return [0, 0, 0];
    }
    var colorString = match[0];
    if (match[0].length === 3) {
      colorString = colorString.split("").map(function(char) {
        return char + char;
      }).join("");
    }
    var integer = parseInt(colorString, 16);
    var r = integer >> 16 & 255;
    var g = integer >> 8 & 255;
    var b = integer & 255;
    return [r, g, b];
  };
  convert.rgb.hcg = function(rgb) {
    var r = rgb[0] / 255;
    var g = rgb[1] / 255;
    var b = rgb[2] / 255;
    var max = Math.max(Math.max(r, g), b);
    var min = Math.min(Math.min(r, g), b);
    var chroma = max - min;
    var grayscale;
    var hue;
    if (chroma < 1) {
      grayscale = min / (1 - chroma);
    } else {
      grayscale = 0;
    }
    if (chroma <= 0) {
      hue = 0;
    } else if (max === r) {
      hue = (g - b) / chroma % 6;
    } else if (max === g) {
      hue = 2 + (b - r) / chroma;
    } else {
      hue = 4 + (r - g) / chroma + 4;
    }
    hue /= 6;
    hue %= 1;
    return [hue * 360, chroma * 100, grayscale * 100];
  };
  convert.hsl.hcg = function(hsl) {
    var s = hsl[1] / 100;
    var l = hsl[2] / 100;
    var c = 1;
    var f = 0;
    if (l < 0.5) {
      c = 2 * s * l;
    } else {
      c = 2 * s * (1 - l);
    }
    if (c < 1) {
      f = (l - 0.5 * c) / (1 - c);
    }
    return [hsl[0], c * 100, f * 100];
  };
  convert.hsv.hcg = function(hsv) {
    var s = hsv[1] / 100;
    var v = hsv[2] / 100;
    var c = s * v;
    var f = 0;
    if (c < 1) {
      f = (v - c) / (1 - c);
    }
    return [hsv[0], c * 100, f * 100];
  };
  convert.hcg.rgb = function(hcg) {
    var h = hcg[0] / 360;
    var c = hcg[1] / 100;
    var g = hcg[2] / 100;
    if (c === 0) {
      return [g * 255, g * 255, g * 255];
    }
    var pure = [0, 0, 0];
    var hi = h % 1 * 6;
    var v = hi % 1;
    var w = 1 - v;
    var mg = 0;
    switch (Math.floor(hi)) {
      case 0:
        pure[0] = 1;
        pure[1] = v;
        pure[2] = 0;
        break;
      case 1:
        pure[0] = w;
        pure[1] = 1;
        pure[2] = 0;
        break;
      case 2:
        pure[0] = 0;
        pure[1] = 1;
        pure[2] = v;
        break;
      case 3:
        pure[0] = 0;
        pure[1] = w;
        pure[2] = 1;
        break;
      case 4:
        pure[0] = v;
        pure[1] = 0;
        pure[2] = 1;
        break;
      default:
        pure[0] = 1;
        pure[1] = 0;
        pure[2] = w;
    }
    mg = (1 - c) * g;
    return [
      (c * pure[0] + mg) * 255,
      (c * pure[1] + mg) * 255,
      (c * pure[2] + mg) * 255
    ];
  };
  convert.hcg.hsv = function(hcg) {
    var c = hcg[1] / 100;
    var g = hcg[2] / 100;
    var v = c + g * (1 - c);
    var f = 0;
    if (v > 0) {
      f = c / v;
    }
    return [hcg[0], f * 100, v * 100];
  };
  convert.hcg.hsl = function(hcg) {
    var c = hcg[1] / 100;
    var g = hcg[2] / 100;
    var l = g * (1 - c) + 0.5 * c;
    var s = 0;
    if (l > 0 && l < 0.5) {
      s = c / (2 * l);
    } else if (l >= 0.5 && l < 1) {
      s = c / (2 * (1 - l));
    }
    return [hcg[0], s * 100, l * 100];
  };
  convert.hcg.hwb = function(hcg) {
    var c = hcg[1] / 100;
    var g = hcg[2] / 100;
    var v = c + g * (1 - c);
    return [hcg[0], (v - c) * 100, (1 - v) * 100];
  };
  convert.hwb.hcg = function(hwb) {
    var w = hwb[1] / 100;
    var b = hwb[2] / 100;
    var v = 1 - b;
    var c = v - w;
    var g = 0;
    if (c < 1) {
      g = (v - c) / (1 - c);
    }
    return [hwb[0], c * 100, g * 100];
  };
  convert.apple.rgb = function(apple) {
    return [apple[0] / 65535 * 255, apple[1] / 65535 * 255, apple[2] / 65535 * 255];
  };
  convert.rgb.apple = function(rgb) {
    return [rgb[0] / 255 * 65535, rgb[1] / 255 * 65535, rgb[2] / 255 * 65535];
  };
  convert.gray.rgb = function(args) {
    return [args[0] / 100 * 255, args[0] / 100 * 255, args[0] / 100 * 255];
  };
  convert.gray.hsl = convert.gray.hsv = function(args) {
    return [0, 0, args[0]];
  };
  convert.gray.hwb = function(gray) {
    return [0, 100, gray[0]];
  };
  convert.gray.cmyk = function(gray) {
    return [0, 0, 0, gray[0]];
  };
  convert.gray.lab = function(gray) {
    return [gray[0], 0, 0];
  };
  convert.gray.hex = function(gray) {
    var val = Math.round(gray[0] / 100 * 255) & 255;
    var integer = (val << 16) + (val << 8) + val;
    var string = integer.toString(16).toUpperCase();
    return "000000".substring(string.length) + string;
  };
  convert.rgb.gray = function(rgb) {
    var val = (rgb[0] + rgb[1] + rgb[2]) / 3;
    return [val / 255 * 100];
  };
});

// node_modules/color-convert/route.js
var require_route = __commonJS((exports2, module2) => {
  var conversions = require_conversions();
  function buildGraph() {
    var graph = {};
    var models = Object.keys(conversions);
    for (var len = models.length, i = 0; i < len; i++) {
      graph[models[i]] = {
        distance: -1,
        parent: null
      };
    }
    return graph;
  }
  function deriveBFS(fromModel) {
    var graph = buildGraph();
    var queue = [fromModel];
    graph[fromModel].distance = 0;
    while (queue.length) {
      var current = queue.pop();
      var adjacents = Object.keys(conversions[current]);
      for (var len = adjacents.length, i = 0; i < len; i++) {
        var adjacent = adjacents[i];
        var node = graph[adjacent];
        if (node.distance === -1) {
          node.distance = graph[current].distance + 1;
          node.parent = current;
          queue.unshift(adjacent);
        }
      }
    }
    return graph;
  }
  function link(from, to) {
    return function(args) {
      return to(from(args));
    };
  }
  function wrapConversion(toModel, graph) {
    var path = [graph[toModel].parent, toModel];
    var fn = conversions[graph[toModel].parent][toModel];
    var cur = graph[toModel].parent;
    while (graph[cur].parent) {
      path.unshift(graph[cur].parent);
      fn = link(conversions[graph[cur].parent][cur], fn);
      cur = graph[cur].parent;
    }
    fn.conversion = path;
    return fn;
  }
  module2.exports = function(fromModel) {
    var graph = deriveBFS(fromModel);
    var conversion = {};
    var models = Object.keys(graph);
    for (var len = models.length, i = 0; i < len; i++) {
      var toModel = models[i];
      var node = graph[toModel];
      if (node.parent === null) {
        continue;
      }
      conversion[toModel] = wrapConversion(toModel, graph);
    }
    return conversion;
  };
});

// node_modules/color-convert/index.js
var require_color_convert = __commonJS((exports2, module2) => {
  var conversions = require_conversions();
  var route = require_route();
  var convert = {};
  var models = Object.keys(conversions);
  function wrapRaw(fn) {
    var wrappedFn = function(args) {
      if (args === void 0 || args === null) {
        return args;
      }
      if (arguments.length > 1) {
        args = Array.prototype.slice.call(arguments);
      }
      return fn(args);
    };
    if ("conversion" in fn) {
      wrappedFn.conversion = fn.conversion;
    }
    return wrappedFn;
  }
  function wrapRounded(fn) {
    var wrappedFn = function(args) {
      if (args === void 0 || args === null) {
        return args;
      }
      if (arguments.length > 1) {
        args = Array.prototype.slice.call(arguments);
      }
      var result = fn(args);
      if (typeof result === "object") {
        for (var len = result.length, i = 0; i < len; i++) {
          result[i] = Math.round(result[i]);
        }
      }
      return result;
    };
    if ("conversion" in fn) {
      wrappedFn.conversion = fn.conversion;
    }
    return wrappedFn;
  }
  models.forEach(function(fromModel) {
    convert[fromModel] = {};
    Object.defineProperty(convert[fromModel], "channels", {value: conversions[fromModel].channels});
    Object.defineProperty(convert[fromModel], "labels", {value: conversions[fromModel].labels});
    var routes = route(fromModel);
    var routeModels = Object.keys(routes);
    routeModels.forEach(function(toModel) {
      var fn = routes[toModel];
      convert[fromModel][toModel] = wrapRounded(fn);
      convert[fromModel][toModel].raw = wrapRaw(fn);
    });
  });
  module2.exports = convert;
});

// node_modules/ansi-styles/index.js
var require_ansi_styles = __commonJS((exports2, module2) => {
  "use strict";
  var colorConvert = require_color_convert();
  var wrapAnsi16 = (fn, offset) => function() {
    const code = fn.apply(colorConvert, arguments);
    return `[${code + offset}m`;
  };
  var wrapAnsi256 = (fn, offset) => function() {
    const code = fn.apply(colorConvert, arguments);
    return `[${38 + offset};5;${code}m`;
  };
  var wrapAnsi16m = (fn, offset) => function() {
    const rgb = fn.apply(colorConvert, arguments);
    return `[${38 + offset};2;${rgb[0]};${rgb[1]};${rgb[2]}m`;
  };
  function assembleStyles() {
    const codes = new Map();
    const styles = {
      modifier: {
        reset: [0, 0],
        bold: [1, 22],
        dim: [2, 22],
        italic: [3, 23],
        underline: [4, 24],
        inverse: [7, 27],
        hidden: [8, 28],
        strikethrough: [9, 29]
      },
      color: {
        black: [30, 39],
        red: [31, 39],
        green: [32, 39],
        yellow: [33, 39],
        blue: [34, 39],
        magenta: [35, 39],
        cyan: [36, 39],
        white: [37, 39],
        gray: [90, 39],
        redBright: [91, 39],
        greenBright: [92, 39],
        yellowBright: [93, 39],
        blueBright: [94, 39],
        magentaBright: [95, 39],
        cyanBright: [96, 39],
        whiteBright: [97, 39]
      },
      bgColor: {
        bgBlack: [40, 49],
        bgRed: [41, 49],
        bgGreen: [42, 49],
        bgYellow: [43, 49],
        bgBlue: [44, 49],
        bgMagenta: [45, 49],
        bgCyan: [46, 49],
        bgWhite: [47, 49],
        bgBlackBright: [100, 49],
        bgRedBright: [101, 49],
        bgGreenBright: [102, 49],
        bgYellowBright: [103, 49],
        bgBlueBright: [104, 49],
        bgMagentaBright: [105, 49],
        bgCyanBright: [106, 49],
        bgWhiteBright: [107, 49]
      }
    };
    styles.color.grey = styles.color.gray;
    for (const groupName of Object.keys(styles)) {
      const group = styles[groupName];
      for (const styleName of Object.keys(group)) {
        const style = group[styleName];
        styles[styleName] = {
          open: `[${style[0]}m`,
          close: `[${style[1]}m`
        };
        group[styleName] = styles[styleName];
        codes.set(style[0], style[1]);
      }
      Object.defineProperty(styles, groupName, {
        value: group,
        enumerable: false
      });
      Object.defineProperty(styles, "codes", {
        value: codes,
        enumerable: false
      });
    }
    const ansi2ansi = (n) => n;
    const rgb2rgb = (r, g, b) => [r, g, b];
    styles.color.close = "[39m";
    styles.bgColor.close = "[49m";
    styles.color.ansi = {
      ansi: wrapAnsi16(ansi2ansi, 0)
    };
    styles.color.ansi256 = {
      ansi256: wrapAnsi256(ansi2ansi, 0)
    };
    styles.color.ansi16m = {
      rgb: wrapAnsi16m(rgb2rgb, 0)
    };
    styles.bgColor.ansi = {
      ansi: wrapAnsi16(ansi2ansi, 10)
    };
    styles.bgColor.ansi256 = {
      ansi256: wrapAnsi256(ansi2ansi, 10)
    };
    styles.bgColor.ansi16m = {
      rgb: wrapAnsi16m(rgb2rgb, 10)
    };
    for (let key of Object.keys(colorConvert)) {
      if (typeof colorConvert[key] !== "object") {
        continue;
      }
      const suite = colorConvert[key];
      if (key === "ansi16") {
        key = "ansi";
      }
      if ("ansi16" in suite) {
        styles.color.ansi[key] = wrapAnsi16(suite.ansi16, 0);
        styles.bgColor.ansi[key] = wrapAnsi16(suite.ansi16, 10);
      }
      if ("ansi256" in suite) {
        styles.color.ansi256[key] = wrapAnsi256(suite.ansi256, 0);
        styles.bgColor.ansi256[key] = wrapAnsi256(suite.ansi256, 10);
      }
      if ("rgb" in suite) {
        styles.color.ansi16m[key] = wrapAnsi16m(suite.rgb, 0);
        styles.bgColor.ansi16m[key] = wrapAnsi16m(suite.rgb, 10);
      }
    }
    return styles;
  }
  Object.defineProperty(module2, "exports", {
    enumerable: true,
    get: assembleStyles
  });
});

// node_modules/has-flag/index.js
var require_has_flag = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = (flag, argv) => {
    argv = argv || process.argv;
    const prefix = flag.startsWith("-") ? "" : flag.length === 1 ? "-" : "--";
    const pos = argv.indexOf(prefix + flag);
    const terminatorPos = argv.indexOf("--");
    return pos !== -1 && (terminatorPos === -1 ? true : pos < terminatorPos);
  };
});

// node_modules/supports-color/index.js
var require_supports_color = __commonJS((exports2, module2) => {
  "use strict";
  var os = require("os");
  var hasFlag = require_has_flag();
  var env = process.env;
  var forceColor;
  if (hasFlag("no-color") || hasFlag("no-colors") || hasFlag("color=false")) {
    forceColor = false;
  } else if (hasFlag("color") || hasFlag("colors") || hasFlag("color=true") || hasFlag("color=always")) {
    forceColor = true;
  }
  if ("FORCE_COLOR" in env) {
    forceColor = env.FORCE_COLOR.length === 0 || parseInt(env.FORCE_COLOR, 10) !== 0;
  }
  function translateLevel(level) {
    if (level === 0) {
      return false;
    }
    return {
      level,
      hasBasic: true,
      has256: level >= 2,
      has16m: level >= 3
    };
  }
  function supportsColor(stream) {
    if (forceColor === false) {
      return 0;
    }
    if (hasFlag("color=16m") || hasFlag("color=full") || hasFlag("color=truecolor")) {
      return 3;
    }
    if (hasFlag("color=256")) {
      return 2;
    }
    if (stream && !stream.isTTY && forceColor !== true) {
      return 0;
    }
    const min = forceColor ? 1 : 0;
    if (process.platform === "win32") {
      const osRelease = os.release().split(".");
      if (Number(process.versions.node.split(".")[0]) >= 8 && Number(osRelease[0]) >= 10 && Number(osRelease[2]) >= 10586) {
        return Number(osRelease[2]) >= 14931 ? 3 : 2;
      }
      return 1;
    }
    if ("CI" in env) {
      if (["TRAVIS", "CIRCLECI", "APPVEYOR", "GITLAB_CI"].some((sign2) => sign2 in env) || env.CI_NAME === "codeship") {
        return 1;
      }
      return min;
    }
    if ("TEAMCITY_VERSION" in env) {
      return /^(9\.(0*[1-9]\d*)\.|\d{2,}\.)/.test(env.TEAMCITY_VERSION) ? 1 : 0;
    }
    if (env.COLORTERM === "truecolor") {
      return 3;
    }
    if ("TERM_PROGRAM" in env) {
      const version = parseInt((env.TERM_PROGRAM_VERSION || "").split(".")[0], 10);
      switch (env.TERM_PROGRAM) {
        case "iTerm.app":
          return version >= 3 ? 3 : 2;
        case "Apple_Terminal":
          return 2;
      }
    }
    if (/-256(color)?$/i.test(env.TERM)) {
      return 2;
    }
    if (/^screen|^xterm|^vt100|^vt220|^rxvt|color|ansi|cygwin|linux/i.test(env.TERM)) {
      return 1;
    }
    if ("COLORTERM" in env) {
      return 1;
    }
    if (env.TERM === "dumb") {
      return min;
    }
    return min;
  }
  function getSupportLevel(stream) {
    const level = supportsColor(stream);
    return translateLevel(level);
  }
  module2.exports = {
    supportsColor: getSupportLevel,
    stdout: getSupportLevel(process.stdout),
    stderr: getSupportLevel(process.stderr)
  };
});

// node_modules/chalk/templates.js
var require_templates = __commonJS((exports2, module2) => {
  "use strict";
  var TEMPLATE_REGEX = /(?:\\(u[a-f\d]{4}|x[a-f\d]{2}|.))|(?:\{(~)?(\w+(?:\([^)]*\))?(?:\.\w+(?:\([^)]*\))?)*)(?:[ \t]|(?=\r?\n)))|(\})|((?:.|[\r\n\f])+?)/gi;
  var STYLE_REGEX = /(?:^|\.)(\w+)(?:\(([^)]*)\))?/g;
  var STRING_REGEX = /^(['"])((?:\\.|(?!\1)[^\\])*)\1$/;
  var ESCAPE_REGEX = /\\(u[a-f\d]{4}|x[a-f\d]{2}|.)|([^\\])/gi;
  var ESCAPES = new Map([
    ["n", "\n"],
    ["r", "\r"],
    ["t", "	"],
    ["b", "\b"],
    ["f", "\f"],
    ["v", "\v"],
    ["0", "\0"],
    ["\\", "\\"],
    ["e", ""],
    ["a", "\x07"]
  ]);
  function unescape(c) {
    if (c[0] === "u" && c.length === 5 || c[0] === "x" && c.length === 3) {
      return String.fromCharCode(parseInt(c.slice(1), 16));
    }
    return ESCAPES.get(c) || c;
  }
  function parseArguments(name, args) {
    const results = [];
    const chunks = args.trim().split(/\s*,\s*/g);
    let matches;
    for (const chunk of chunks) {
      if (!isNaN(chunk)) {
        results.push(Number(chunk));
      } else if (matches = chunk.match(STRING_REGEX)) {
        results.push(matches[2].replace(ESCAPE_REGEX, (m, escape, chr) => escape ? unescape(escape) : chr));
      } else {
        throw new Error(`Invalid Chalk template style argument: ${chunk} (in style '${name}')`);
      }
    }
    return results;
  }
  function parseStyle(style) {
    STYLE_REGEX.lastIndex = 0;
    const results = [];
    let matches;
    while ((matches = STYLE_REGEX.exec(style)) !== null) {
      const name = matches[1];
      if (matches[2]) {
        const args = parseArguments(name, matches[2]);
        results.push([name].concat(args));
      } else {
        results.push([name]);
      }
    }
    return results;
  }
  function buildStyle(chalk, styles) {
    const enabled = {};
    for (const layer of styles) {
      for (const style of layer.styles) {
        enabled[style[0]] = layer.inverse ? null : style.slice(1);
      }
    }
    let current = chalk;
    for (const styleName of Object.keys(enabled)) {
      if (Array.isArray(enabled[styleName])) {
        if (!(styleName in current)) {
          throw new Error(`Unknown Chalk style: ${styleName}`);
        }
        if (enabled[styleName].length > 0) {
          current = current[styleName].apply(current, enabled[styleName]);
        } else {
          current = current[styleName];
        }
      }
    }
    return current;
  }
  module2.exports = (chalk, tmp) => {
    const styles = [];
    const chunks = [];
    let chunk = [];
    tmp.replace(TEMPLATE_REGEX, (m, escapeChar, inverse, style, close, chr) => {
      if (escapeChar) {
        chunk.push(unescape(escapeChar));
      } else if (style) {
        const str = chunk.join("");
        chunk = [];
        chunks.push(styles.length === 0 ? str : buildStyle(chalk, styles)(str));
        styles.push({inverse, styles: parseStyle(style)});
      } else if (close) {
        if (styles.length === 0) {
          throw new Error("Found extraneous } in Chalk template literal");
        }
        chunks.push(buildStyle(chalk, styles)(chunk.join("")));
        chunk = [];
        styles.pop();
      } else {
        chunk.push(chr);
      }
    });
    chunks.push(chunk.join(""));
    if (styles.length > 0) {
      const errMsg = `Chalk template literal is missing ${styles.length} closing bracket${styles.length === 1 ? "" : "s"} (\`}\`)`;
      throw new Error(errMsg);
    }
    return chunks.join("");
  };
});

// node_modules/chalk/index.js
var require_chalk = __commonJS((exports2, module2) => {
  "use strict";
  var escapeStringRegexp = require_escape_string_regexp();
  var ansiStyles = require_ansi_styles();
  var stdoutColor = require_supports_color().stdout;
  var template = require_templates();
  var isSimpleWindowsTerm = process.platform === "win32" && !(process.env.TERM || "").toLowerCase().startsWith("xterm");
  var levelMapping = ["ansi", "ansi", "ansi256", "ansi16m"];
  var skipModels = new Set(["gray"]);
  var styles = Object.create(null);
  function applyOptions(obj, options) {
    options = options || {};
    const scLevel = stdoutColor ? stdoutColor.level : 0;
    obj.level = options.level === void 0 ? scLevel : options.level;
    obj.enabled = "enabled" in options ? options.enabled : obj.level > 0;
  }
  function Chalk(options) {
    if (!this || !(this instanceof Chalk) || this.template) {
      const chalk = {};
      applyOptions(chalk, options);
      chalk.template = function() {
        const args = [].slice.call(arguments);
        return chalkTag.apply(null, [chalk.template].concat(args));
      };
      Object.setPrototypeOf(chalk, Chalk.prototype);
      Object.setPrototypeOf(chalk.template, chalk);
      chalk.template.constructor = Chalk;
      return chalk.template;
    }
    applyOptions(this, options);
  }
  if (isSimpleWindowsTerm) {
    ansiStyles.blue.open = "[94m";
  }
  for (const key of Object.keys(ansiStyles)) {
    ansiStyles[key].closeRe = new RegExp(escapeStringRegexp(ansiStyles[key].close), "g");
    styles[key] = {
      get() {
        const codes = ansiStyles[key];
        return build.call(this, this._styles ? this._styles.concat(codes) : [codes], this._empty, key);
      }
    };
  }
  styles.visible = {
    get() {
      return build.call(this, this._styles || [], true, "visible");
    }
  };
  ansiStyles.color.closeRe = new RegExp(escapeStringRegexp(ansiStyles.color.close), "g");
  for (const model of Object.keys(ansiStyles.color.ansi)) {
    if (skipModels.has(model)) {
      continue;
    }
    styles[model] = {
      get() {
        const level = this.level;
        return function() {
          const open = ansiStyles.color[levelMapping[level]][model].apply(null, arguments);
          const codes = {
            open,
            close: ansiStyles.color.close,
            closeRe: ansiStyles.color.closeRe
          };
          return build.call(this, this._styles ? this._styles.concat(codes) : [codes], this._empty, model);
        };
      }
    };
  }
  ansiStyles.bgColor.closeRe = new RegExp(escapeStringRegexp(ansiStyles.bgColor.close), "g");
  for (const model of Object.keys(ansiStyles.bgColor.ansi)) {
    if (skipModels.has(model)) {
      continue;
    }
    const bgModel = "bg" + model[0].toUpperCase() + model.slice(1);
    styles[bgModel] = {
      get() {
        const level = this.level;
        return function() {
          const open = ansiStyles.bgColor[levelMapping[level]][model].apply(null, arguments);
          const codes = {
            open,
            close: ansiStyles.bgColor.close,
            closeRe: ansiStyles.bgColor.closeRe
          };
          return build.call(this, this._styles ? this._styles.concat(codes) : [codes], this._empty, model);
        };
      }
    };
  }
  var proto = Object.defineProperties(() => {
  }, styles);
  function build(_styles, _empty, key) {
    const builder = function() {
      return applyStyle.apply(builder, arguments);
    };
    builder._styles = _styles;
    builder._empty = _empty;
    const self2 = this;
    Object.defineProperty(builder, "level", {
      enumerable: true,
      get() {
        return self2.level;
      },
      set(level) {
        self2.level = level;
      }
    });
    Object.defineProperty(builder, "enabled", {
      enumerable: true,
      get() {
        return self2.enabled;
      },
      set(enabled) {
        self2.enabled = enabled;
      }
    });
    builder.hasGrey = this.hasGrey || key === "gray" || key === "grey";
    builder.__proto__ = proto;
    return builder;
  }
  function applyStyle() {
    const args = arguments;
    const argsLen = args.length;
    let str = String(arguments[0]);
    if (argsLen === 0) {
      return "";
    }
    if (argsLen > 1) {
      for (let a = 1; a < argsLen; a++) {
        str += " " + args[a];
      }
    }
    if (!this.enabled || this.level <= 0 || !str) {
      return this._empty ? "" : str;
    }
    const originalDim = ansiStyles.dim.open;
    if (isSimpleWindowsTerm && this.hasGrey) {
      ansiStyles.dim.open = "";
    }
    for (const code of this._styles.slice().reverse()) {
      str = code.open + str.replace(code.closeRe, code.open) + code.close;
      str = str.replace(/\r?\n/g, `${code.close}$&${code.open}`);
    }
    ansiStyles.dim.open = originalDim;
    return str;
  }
  function chalkTag(chalk, strings) {
    if (!Array.isArray(strings)) {
      return [].slice.call(arguments, 1).join(" ");
    }
    const args = [].slice.call(arguments, 2);
    const parts = [strings.raw[0]];
    for (let i = 1; i < strings.length; i++) {
      parts.push(String(args[i - 1]).replace(/[{}\\]/g, "\\$&"));
      parts.push(String(strings.raw[i]));
    }
    return template(chalk, parts.join(""));
  }
  Object.defineProperties(Chalk.prototype, styles);
  module2.exports = Chalk();
  module2.exports.supportsColor = stdoutColor;
  module2.exports.default = module2.exports;
});

// node_modules/jmespath/jmespath.js
var require_jmespath = __commonJS((exports2) => {
  (function(exports3) {
    "use strict";
    function isArray(obj) {
      if (obj !== null) {
        return Object.prototype.toString.call(obj) === "[object Array]";
      } else {
        return false;
      }
    }
    function isObject2(obj) {
      if (obj !== null) {
        return Object.prototype.toString.call(obj) === "[object Object]";
      } else {
        return false;
      }
    }
    function strictDeepEqual(first, second) {
      if (first === second) {
        return true;
      }
      var firstType = Object.prototype.toString.call(first);
      if (firstType !== Object.prototype.toString.call(second)) {
        return false;
      }
      if (isArray(first) === true) {
        if (first.length !== second.length) {
          return false;
        }
        for (var i = 0; i < first.length; i++) {
          if (strictDeepEqual(first[i], second[i]) === false) {
            return false;
          }
        }
        return true;
      }
      if (isObject2(first) === true) {
        var keysSeen = {};
        for (var key in first) {
          if (hasOwnProperty.call(first, key)) {
            if (strictDeepEqual(first[key], second[key]) === false) {
              return false;
            }
            keysSeen[key] = true;
          }
        }
        for (var key2 in second) {
          if (hasOwnProperty.call(second, key2)) {
            if (keysSeen[key2] !== true) {
              return false;
            }
          }
        }
        return true;
      }
      return false;
    }
    function isFalse(obj) {
      if (obj === "" || obj === false || obj === null) {
        return true;
      } else if (isArray(obj) && obj.length === 0) {
        return true;
      } else if (isObject2(obj)) {
        for (var key in obj) {
          if (obj.hasOwnProperty(key)) {
            return false;
          }
        }
        return true;
      } else {
        return false;
      }
    }
    function objValues(obj) {
      var keys = Object.keys(obj);
      var values = [];
      for (var i = 0; i < keys.length; i++) {
        values.push(obj[keys[i]]);
      }
      return values;
    }
    function merge(a, b) {
      var merged = {};
      for (var key in a) {
        merged[key] = a[key];
      }
      for (var key2 in b) {
        merged[key2] = b[key2];
      }
      return merged;
    }
    var trimLeft;
    if (typeof String.prototype.trimLeft === "function") {
      trimLeft = function(str) {
        return str.trimLeft();
      };
    } else {
      trimLeft = function(str) {
        return str.match(/^\s*(.*)/)[1];
      };
    }
    var TYPE_NUMBER = 0;
    var TYPE_ANY = 1;
    var TYPE_STRING = 2;
    var TYPE_ARRAY = 3;
    var TYPE_OBJECT = 4;
    var TYPE_BOOLEAN = 5;
    var TYPE_EXPREF = 6;
    var TYPE_NULL = 7;
    var TYPE_ARRAY_NUMBER = 8;
    var TYPE_ARRAY_STRING = 9;
    var TOK_EOF = "EOF";
    var TOK_UNQUOTEDIDENTIFIER = "UnquotedIdentifier";
    var TOK_QUOTEDIDENTIFIER = "QuotedIdentifier";
    var TOK_RBRACKET = "Rbracket";
    var TOK_RPAREN = "Rparen";
    var TOK_COMMA = "Comma";
    var TOK_COLON = "Colon";
    var TOK_RBRACE = "Rbrace";
    var TOK_NUMBER = "Number";
    var TOK_CURRENT = "Current";
    var TOK_EXPREF = "Expref";
    var TOK_PIPE = "Pipe";
    var TOK_OR = "Or";
    var TOK_AND = "And";
    var TOK_EQ = "EQ";
    var TOK_GT = "GT";
    var TOK_LT = "LT";
    var TOK_GTE = "GTE";
    var TOK_LTE = "LTE";
    var TOK_NE = "NE";
    var TOK_FLATTEN = "Flatten";
    var TOK_STAR = "Star";
    var TOK_FILTER = "Filter";
    var TOK_DOT = "Dot";
    var TOK_NOT = "Not";
    var TOK_LBRACE = "Lbrace";
    var TOK_LBRACKET = "Lbracket";
    var TOK_LPAREN = "Lparen";
    var TOK_LITERAL = "Literal";
    var basicTokens = {
      ".": TOK_DOT,
      "*": TOK_STAR,
      ",": TOK_COMMA,
      ":": TOK_COLON,
      "{": TOK_LBRACE,
      "}": TOK_RBRACE,
      "]": TOK_RBRACKET,
      "(": TOK_LPAREN,
      ")": TOK_RPAREN,
      "@": TOK_CURRENT
    };
    var operatorStartToken = {
      "<": true,
      ">": true,
      "=": true,
      "!": true
    };
    var skipChars = {
      " ": true,
      "	": true,
      "\n": true
    };
    function isAlpha(ch) {
      return ch >= "a" && ch <= "z" || ch >= "A" && ch <= "Z" || ch === "_";
    }
    function isNum(ch) {
      return ch >= "0" && ch <= "9" || ch === "-";
    }
    function isAlphaNum(ch) {
      return ch >= "a" && ch <= "z" || ch >= "A" && ch <= "Z" || ch >= "0" && ch <= "9" || ch === "_";
    }
    function Lexer() {
    }
    Lexer.prototype = {
      tokenize: function(stream) {
        var tokens = [];
        this._current = 0;
        var start;
        var identifier;
        var token;
        while (this._current < stream.length) {
          if (isAlpha(stream[this._current])) {
            start = this._current;
            identifier = this._consumeUnquotedIdentifier(stream);
            tokens.push({
              type: TOK_UNQUOTEDIDENTIFIER,
              value: identifier,
              start
            });
          } else if (basicTokens[stream[this._current]] !== void 0) {
            tokens.push({
              type: basicTokens[stream[this._current]],
              value: stream[this._current],
              start: this._current
            });
            this._current++;
          } else if (isNum(stream[this._current])) {
            token = this._consumeNumber(stream);
            tokens.push(token);
          } else if (stream[this._current] === "[") {
            token = this._consumeLBracket(stream);
            tokens.push(token);
          } else if (stream[this._current] === '"') {
            start = this._current;
            identifier = this._consumeQuotedIdentifier(stream);
            tokens.push({
              type: TOK_QUOTEDIDENTIFIER,
              value: identifier,
              start
            });
          } else if (stream[this._current] === "'") {
            start = this._current;
            identifier = this._consumeRawStringLiteral(stream);
            tokens.push({
              type: TOK_LITERAL,
              value: identifier,
              start
            });
          } else if (stream[this._current] === "`") {
            start = this._current;
            var literal = this._consumeLiteral(stream);
            tokens.push({
              type: TOK_LITERAL,
              value: literal,
              start
            });
          } else if (operatorStartToken[stream[this._current]] !== void 0) {
            tokens.push(this._consumeOperator(stream));
          } else if (skipChars[stream[this._current]] !== void 0) {
            this._current++;
          } else if (stream[this._current] === "&") {
            start = this._current;
            this._current++;
            if (stream[this._current] === "&") {
              this._current++;
              tokens.push({type: TOK_AND, value: "&&", start});
            } else {
              tokens.push({type: TOK_EXPREF, value: "&", start});
            }
          } else if (stream[this._current] === "|") {
            start = this._current;
            this._current++;
            if (stream[this._current] === "|") {
              this._current++;
              tokens.push({type: TOK_OR, value: "||", start});
            } else {
              tokens.push({type: TOK_PIPE, value: "|", start});
            }
          } else {
            var error = new Error("Unknown character:" + stream[this._current]);
            error.name = "LexerError";
            throw error;
          }
        }
        return tokens;
      },
      _consumeUnquotedIdentifier: function(stream) {
        var start = this._current;
        this._current++;
        while (this._current < stream.length && isAlphaNum(stream[this._current])) {
          this._current++;
        }
        return stream.slice(start, this._current);
      },
      _consumeQuotedIdentifier: function(stream) {
        var start = this._current;
        this._current++;
        var maxLength = stream.length;
        while (stream[this._current] !== '"' && this._current < maxLength) {
          var current = this._current;
          if (stream[current] === "\\" && (stream[current + 1] === "\\" || stream[current + 1] === '"')) {
            current += 2;
          } else {
            current++;
          }
          this._current = current;
        }
        this._current++;
        return JSON.parse(stream.slice(start, this._current));
      },
      _consumeRawStringLiteral: function(stream) {
        var start = this._current;
        this._current++;
        var maxLength = stream.length;
        while (stream[this._current] !== "'" && this._current < maxLength) {
          var current = this._current;
          if (stream[current] === "\\" && (stream[current + 1] === "\\" || stream[current + 1] === "'")) {
            current += 2;
          } else {
            current++;
          }
          this._current = current;
        }
        this._current++;
        var literal = stream.slice(start + 1, this._current - 1);
        return literal.replace("\\'", "'");
      },
      _consumeNumber: function(stream) {
        var start = this._current;
        this._current++;
        var maxLength = stream.length;
        while (isNum(stream[this._current]) && this._current < maxLength) {
          this._current++;
        }
        var value = parseInt(stream.slice(start, this._current));
        return {type: TOK_NUMBER, value, start};
      },
      _consumeLBracket: function(stream) {
        var start = this._current;
        this._current++;
        if (stream[this._current] === "?") {
          this._current++;
          return {type: TOK_FILTER, value: "[?", start};
        } else if (stream[this._current] === "]") {
          this._current++;
          return {type: TOK_FLATTEN, value: "[]", start};
        } else {
          return {type: TOK_LBRACKET, value: "[", start};
        }
      },
      _consumeOperator: function(stream) {
        var start = this._current;
        var startingChar = stream[start];
        this._current++;
        if (startingChar === "!") {
          if (stream[this._current] === "=") {
            this._current++;
            return {type: TOK_NE, value: "!=", start};
          } else {
            return {type: TOK_NOT, value: "!", start};
          }
        } else if (startingChar === "<") {
          if (stream[this._current] === "=") {
            this._current++;
            return {type: TOK_LTE, value: "<=", start};
          } else {
            return {type: TOK_LT, value: "<", start};
          }
        } else if (startingChar === ">") {
          if (stream[this._current] === "=") {
            this._current++;
            return {type: TOK_GTE, value: ">=", start};
          } else {
            return {type: TOK_GT, value: ">", start};
          }
        } else if (startingChar === "=") {
          if (stream[this._current] === "=") {
            this._current++;
            return {type: TOK_EQ, value: "==", start};
          }
        }
      },
      _consumeLiteral: function(stream) {
        this._current++;
        var start = this._current;
        var maxLength = stream.length;
        var literal;
        while (stream[this._current] !== "`" && this._current < maxLength) {
          var current = this._current;
          if (stream[current] === "\\" && (stream[current + 1] === "\\" || stream[current + 1] === "`")) {
            current += 2;
          } else {
            current++;
          }
          this._current = current;
        }
        var literalString = trimLeft(stream.slice(start, this._current));
        literalString = literalString.replace("\\`", "`");
        if (this._looksLikeJSON(literalString)) {
          literal = JSON.parse(literalString);
        } else {
          literal = JSON.parse('"' + literalString + '"');
        }
        this._current++;
        return literal;
      },
      _looksLikeJSON: function(literalString) {
        var startingChars = '[{"';
        var jsonLiterals = ["true", "false", "null"];
        var numberLooking = "-0123456789";
        if (literalString === "") {
          return false;
        } else if (startingChars.indexOf(literalString[0]) >= 0) {
          return true;
        } else if (jsonLiterals.indexOf(literalString) >= 0) {
          return true;
        } else if (numberLooking.indexOf(literalString[0]) >= 0) {
          try {
            JSON.parse(literalString);
            return true;
          } catch (ex) {
            return false;
          }
        } else {
          return false;
        }
      }
    };
    var bindingPower = {};
    bindingPower[TOK_EOF] = 0;
    bindingPower[TOK_UNQUOTEDIDENTIFIER] = 0;
    bindingPower[TOK_QUOTEDIDENTIFIER] = 0;
    bindingPower[TOK_RBRACKET] = 0;
    bindingPower[TOK_RPAREN] = 0;
    bindingPower[TOK_COMMA] = 0;
    bindingPower[TOK_RBRACE] = 0;
    bindingPower[TOK_NUMBER] = 0;
    bindingPower[TOK_CURRENT] = 0;
    bindingPower[TOK_EXPREF] = 0;
    bindingPower[TOK_PIPE] = 1;
    bindingPower[TOK_OR] = 2;
    bindingPower[TOK_AND] = 3;
    bindingPower[TOK_EQ] = 5;
    bindingPower[TOK_GT] = 5;
    bindingPower[TOK_LT] = 5;
    bindingPower[TOK_GTE] = 5;
    bindingPower[TOK_LTE] = 5;
    bindingPower[TOK_NE] = 5;
    bindingPower[TOK_FLATTEN] = 9;
    bindingPower[TOK_STAR] = 20;
    bindingPower[TOK_FILTER] = 21;
    bindingPower[TOK_DOT] = 40;
    bindingPower[TOK_NOT] = 45;
    bindingPower[TOK_LBRACE] = 50;
    bindingPower[TOK_LBRACKET] = 55;
    bindingPower[TOK_LPAREN] = 60;
    function Parser() {
    }
    Parser.prototype = {
      parse: function(expression) {
        this._loadTokens(expression);
        this.index = 0;
        var ast = this.expression(0);
        if (this._lookahead(0) !== TOK_EOF) {
          var t = this._lookaheadToken(0);
          var error = new Error("Unexpected token type: " + t.type + ", value: " + t.value);
          error.name = "ParserError";
          throw error;
        }
        return ast;
      },
      _loadTokens: function(expression) {
        var lexer = new Lexer();
        var tokens = lexer.tokenize(expression);
        tokens.push({type: TOK_EOF, value: "", start: expression.length});
        this.tokens = tokens;
      },
      expression: function(rbp) {
        var leftToken = this._lookaheadToken(0);
        this._advance();
        var left = this.nud(leftToken);
        var currentToken = this._lookahead(0);
        while (rbp < bindingPower[currentToken]) {
          this._advance();
          left = this.led(currentToken, left);
          currentToken = this._lookahead(0);
        }
        return left;
      },
      _lookahead: function(number) {
        return this.tokens[this.index + number].type;
      },
      _lookaheadToken: function(number) {
        return this.tokens[this.index + number];
      },
      _advance: function() {
        this.index++;
      },
      nud: function(token) {
        var left;
        var right;
        var expression;
        switch (token.type) {
          case TOK_LITERAL:
            return {type: "Literal", value: token.value};
          case TOK_UNQUOTEDIDENTIFIER:
            return {type: "Field", name: token.value};
          case TOK_QUOTEDIDENTIFIER:
            var node = {type: "Field", name: token.value};
            if (this._lookahead(0) === TOK_LPAREN) {
              throw new Error("Quoted identifier not allowed for function names.");
            } else {
              return node;
            }
            break;
          case TOK_NOT:
            right = this.expression(bindingPower.Not);
            return {type: "NotExpression", children: [right]};
          case TOK_STAR:
            left = {type: "Identity"};
            right = null;
            if (this._lookahead(0) === TOK_RBRACKET) {
              right = {type: "Identity"};
            } else {
              right = this._parseProjectionRHS(bindingPower.Star);
            }
            return {type: "ValueProjection", children: [left, right]};
          case TOK_FILTER:
            return this.led(token.type, {type: "Identity"});
          case TOK_LBRACE:
            return this._parseMultiselectHash();
          case TOK_FLATTEN:
            left = {type: TOK_FLATTEN, children: [{type: "Identity"}]};
            right = this._parseProjectionRHS(bindingPower.Flatten);
            return {type: "Projection", children: [left, right]};
          case TOK_LBRACKET:
            if (this._lookahead(0) === TOK_NUMBER || this._lookahead(0) === TOK_COLON) {
              right = this._parseIndexExpression();
              return this._projectIfSlice({type: "Identity"}, right);
            } else if (this._lookahead(0) === TOK_STAR && this._lookahead(1) === TOK_RBRACKET) {
              this._advance();
              this._advance();
              right = this._parseProjectionRHS(bindingPower.Star);
              return {
                type: "Projection",
                children: [{type: "Identity"}, right]
              };
            } else {
              return this._parseMultiselectList();
            }
            break;
          case TOK_CURRENT:
            return {type: TOK_CURRENT};
          case TOK_EXPREF:
            expression = this.expression(bindingPower.Expref);
            return {type: "ExpressionReference", children: [expression]};
          case TOK_LPAREN:
            var args = [];
            while (this._lookahead(0) !== TOK_RPAREN) {
              if (this._lookahead(0) === TOK_CURRENT) {
                expression = {type: TOK_CURRENT};
                this._advance();
              } else {
                expression = this.expression(0);
              }
              args.push(expression);
            }
            this._match(TOK_RPAREN);
            return args[0];
          default:
            this._errorToken(token);
        }
      },
      led: function(tokenName, left) {
        var right;
        switch (tokenName) {
          case TOK_DOT:
            var rbp = bindingPower.Dot;
            if (this._lookahead(0) !== TOK_STAR) {
              right = this._parseDotRHS(rbp);
              return {type: "Subexpression", children: [left, right]};
            } else {
              this._advance();
              right = this._parseProjectionRHS(rbp);
              return {type: "ValueProjection", children: [left, right]};
            }
            break;
          case TOK_PIPE:
            right = this.expression(bindingPower.Pipe);
            return {type: TOK_PIPE, children: [left, right]};
          case TOK_OR:
            right = this.expression(bindingPower.Or);
            return {type: "OrExpression", children: [left, right]};
          case TOK_AND:
            right = this.expression(bindingPower.And);
            return {type: "AndExpression", children: [left, right]};
          case TOK_LPAREN:
            var name = left.name;
            var args = [];
            var expression, node;
            while (this._lookahead(0) !== TOK_RPAREN) {
              if (this._lookahead(0) === TOK_CURRENT) {
                expression = {type: TOK_CURRENT};
                this._advance();
              } else {
                expression = this.expression(0);
              }
              if (this._lookahead(0) === TOK_COMMA) {
                this._match(TOK_COMMA);
              }
              args.push(expression);
            }
            this._match(TOK_RPAREN);
            node = {type: "Function", name, children: args};
            return node;
          case TOK_FILTER:
            var condition = this.expression(0);
            this._match(TOK_RBRACKET);
            if (this._lookahead(0) === TOK_FLATTEN) {
              right = {type: "Identity"};
            } else {
              right = this._parseProjectionRHS(bindingPower.Filter);
            }
            return {type: "FilterProjection", children: [left, right, condition]};
          case TOK_FLATTEN:
            var leftNode = {type: TOK_FLATTEN, children: [left]};
            var rightNode = this._parseProjectionRHS(bindingPower.Flatten);
            return {type: "Projection", children: [leftNode, rightNode]};
          case TOK_EQ:
          case TOK_NE:
          case TOK_GT:
          case TOK_GTE:
          case TOK_LT:
          case TOK_LTE:
            return this._parseComparator(left, tokenName);
          case TOK_LBRACKET:
            var token = this._lookaheadToken(0);
            if (token.type === TOK_NUMBER || token.type === TOK_COLON) {
              right = this._parseIndexExpression();
              return this._projectIfSlice(left, right);
            } else {
              this._match(TOK_STAR);
              this._match(TOK_RBRACKET);
              right = this._parseProjectionRHS(bindingPower.Star);
              return {type: "Projection", children: [left, right]};
            }
            break;
          default:
            this._errorToken(this._lookaheadToken(0));
        }
      },
      _match: function(tokenType) {
        if (this._lookahead(0) === tokenType) {
          this._advance();
        } else {
          var t = this._lookaheadToken(0);
          var error = new Error("Expected " + tokenType + ", got: " + t.type);
          error.name = "ParserError";
          throw error;
        }
      },
      _errorToken: function(token) {
        var error = new Error("Invalid token (" + token.type + '): "' + token.value + '"');
        error.name = "ParserError";
        throw error;
      },
      _parseIndexExpression: function() {
        if (this._lookahead(0) === TOK_COLON || this._lookahead(1) === TOK_COLON) {
          return this._parseSliceExpression();
        } else {
          var node = {
            type: "Index",
            value: this._lookaheadToken(0).value
          };
          this._advance();
          this._match(TOK_RBRACKET);
          return node;
        }
      },
      _projectIfSlice: function(left, right) {
        var indexExpr = {type: "IndexExpression", children: [left, right]};
        if (right.type === "Slice") {
          return {
            type: "Projection",
            children: [indexExpr, this._parseProjectionRHS(bindingPower.Star)]
          };
        } else {
          return indexExpr;
        }
      },
      _parseSliceExpression: function() {
        var parts = [null, null, null];
        var index = 0;
        var currentToken = this._lookahead(0);
        while (currentToken !== TOK_RBRACKET && index < 3) {
          if (currentToken === TOK_COLON) {
            index++;
            this._advance();
          } else if (currentToken === TOK_NUMBER) {
            parts[index] = this._lookaheadToken(0).value;
            this._advance();
          } else {
            var t = this._lookahead(0);
            var error = new Error("Syntax error, unexpected token: " + t.value + "(" + t.type + ")");
            error.name = "Parsererror";
            throw error;
          }
          currentToken = this._lookahead(0);
        }
        this._match(TOK_RBRACKET);
        return {
          type: "Slice",
          children: parts
        };
      },
      _parseComparator: function(left, comparator) {
        var right = this.expression(bindingPower[comparator]);
        return {type: "Comparator", name: comparator, children: [left, right]};
      },
      _parseDotRHS: function(rbp) {
        var lookahead = this._lookahead(0);
        var exprTokens = [TOK_UNQUOTEDIDENTIFIER, TOK_QUOTEDIDENTIFIER, TOK_STAR];
        if (exprTokens.indexOf(lookahead) >= 0) {
          return this.expression(rbp);
        } else if (lookahead === TOK_LBRACKET) {
          this._match(TOK_LBRACKET);
          return this._parseMultiselectList();
        } else if (lookahead === TOK_LBRACE) {
          this._match(TOK_LBRACE);
          return this._parseMultiselectHash();
        }
      },
      _parseProjectionRHS: function(rbp) {
        var right;
        if (bindingPower[this._lookahead(0)] < 10) {
          right = {type: "Identity"};
        } else if (this._lookahead(0) === TOK_LBRACKET) {
          right = this.expression(rbp);
        } else if (this._lookahead(0) === TOK_FILTER) {
          right = this.expression(rbp);
        } else if (this._lookahead(0) === TOK_DOT) {
          this._match(TOK_DOT);
          right = this._parseDotRHS(rbp);
        } else {
          var t = this._lookaheadToken(0);
          var error = new Error("Sytanx error, unexpected token: " + t.value + "(" + t.type + ")");
          error.name = "ParserError";
          throw error;
        }
        return right;
      },
      _parseMultiselectList: function() {
        var expressions = [];
        while (this._lookahead(0) !== TOK_RBRACKET) {
          var expression = this.expression(0);
          expressions.push(expression);
          if (this._lookahead(0) === TOK_COMMA) {
            this._match(TOK_COMMA);
            if (this._lookahead(0) === TOK_RBRACKET) {
              throw new Error("Unexpected token Rbracket");
            }
          }
        }
        this._match(TOK_RBRACKET);
        return {type: "MultiSelectList", children: expressions};
      },
      _parseMultiselectHash: function() {
        var pairs = [];
        var identifierTypes = [TOK_UNQUOTEDIDENTIFIER, TOK_QUOTEDIDENTIFIER];
        var keyToken, keyName, value, node;
        for (; ; ) {
          keyToken = this._lookaheadToken(0);
          if (identifierTypes.indexOf(keyToken.type) < 0) {
            throw new Error("Expecting an identifier token, got: " + keyToken.type);
          }
          keyName = keyToken.value;
          this._advance();
          this._match(TOK_COLON);
          value = this.expression(0);
          node = {type: "KeyValuePair", name: keyName, value};
          pairs.push(node);
          if (this._lookahead(0) === TOK_COMMA) {
            this._match(TOK_COMMA);
          } else if (this._lookahead(0) === TOK_RBRACE) {
            this._match(TOK_RBRACE);
            break;
          }
        }
        return {type: "MultiSelectHash", children: pairs};
      }
    };
    function TreeInterpreter(runtime) {
      this.runtime = runtime;
    }
    TreeInterpreter.prototype = {
      search: function(node, value) {
        return this.visit(node, value);
      },
      visit: function(node, value) {
        var matched, current, result, first, second, field, left, right, collected, i;
        switch (node.type) {
          case "Field":
            if (value === null) {
              return null;
            } else if (isObject2(value)) {
              field = value[node.name];
              if (field === void 0) {
                return null;
              } else {
                return field;
              }
            } else {
              return null;
            }
            break;
          case "Subexpression":
            result = this.visit(node.children[0], value);
            for (i = 1; i < node.children.length; i++) {
              result = this.visit(node.children[1], result);
              if (result === null) {
                return null;
              }
            }
            return result;
          case "IndexExpression":
            left = this.visit(node.children[0], value);
            right = this.visit(node.children[1], left);
            return right;
          case "Index":
            if (!isArray(value)) {
              return null;
            }
            var index = node.value;
            if (index < 0) {
              index = value.length + index;
            }
            result = value[index];
            if (result === void 0) {
              result = null;
            }
            return result;
          case "Slice":
            if (!isArray(value)) {
              return null;
            }
            var sliceParams = node.children.slice(0);
            var computed = this.computeSliceParams(value.length, sliceParams);
            var start = computed[0];
            var stop = computed[1];
            var step = computed[2];
            result = [];
            if (step > 0) {
              for (i = start; i < stop; i += step) {
                result.push(value[i]);
              }
            } else {
              for (i = start; i > stop; i += step) {
                result.push(value[i]);
              }
            }
            return result;
          case "Projection":
            var base = this.visit(node.children[0], value);
            if (!isArray(base)) {
              return null;
            }
            collected = [];
            for (i = 0; i < base.length; i++) {
              current = this.visit(node.children[1], base[i]);
              if (current !== null) {
                collected.push(current);
              }
            }
            return collected;
          case "ValueProjection":
            base = this.visit(node.children[0], value);
            if (!isObject2(base)) {
              return null;
            }
            collected = [];
            var values = objValues(base);
            for (i = 0; i < values.length; i++) {
              current = this.visit(node.children[1], values[i]);
              if (current !== null) {
                collected.push(current);
              }
            }
            return collected;
          case "FilterProjection":
            base = this.visit(node.children[0], value);
            if (!isArray(base)) {
              return null;
            }
            var filtered = [];
            var finalResults = [];
            for (i = 0; i < base.length; i++) {
              matched = this.visit(node.children[2], base[i]);
              if (!isFalse(matched)) {
                filtered.push(base[i]);
              }
            }
            for (var j = 0; j < filtered.length; j++) {
              current = this.visit(node.children[1], filtered[j]);
              if (current !== null) {
                finalResults.push(current);
              }
            }
            return finalResults;
          case "Comparator":
            first = this.visit(node.children[0], value);
            second = this.visit(node.children[1], value);
            switch (node.name) {
              case TOK_EQ:
                result = strictDeepEqual(first, second);
                break;
              case TOK_NE:
                result = !strictDeepEqual(first, second);
                break;
              case TOK_GT:
                result = first > second;
                break;
              case TOK_GTE:
                result = first >= second;
                break;
              case TOK_LT:
                result = first < second;
                break;
              case TOK_LTE:
                result = first <= second;
                break;
              default:
                throw new Error("Unknown comparator: " + node.name);
            }
            return result;
          case TOK_FLATTEN:
            var original = this.visit(node.children[0], value);
            if (!isArray(original)) {
              return null;
            }
            var merged = [];
            for (i = 0; i < original.length; i++) {
              current = original[i];
              if (isArray(current)) {
                merged.push.apply(merged, current);
              } else {
                merged.push(current);
              }
            }
            return merged;
          case "Identity":
            return value;
          case "MultiSelectList":
            if (value === null) {
              return null;
            }
            collected = [];
            for (i = 0; i < node.children.length; i++) {
              collected.push(this.visit(node.children[i], value));
            }
            return collected;
          case "MultiSelectHash":
            if (value === null) {
              return null;
            }
            collected = {};
            var child;
            for (i = 0; i < node.children.length; i++) {
              child = node.children[i];
              collected[child.name] = this.visit(child.value, value);
            }
            return collected;
          case "OrExpression":
            matched = this.visit(node.children[0], value);
            if (isFalse(matched)) {
              matched = this.visit(node.children[1], value);
            }
            return matched;
          case "AndExpression":
            first = this.visit(node.children[0], value);
            if (isFalse(first) === true) {
              return first;
            }
            return this.visit(node.children[1], value);
          case "NotExpression":
            first = this.visit(node.children[0], value);
            return isFalse(first);
          case "Literal":
            return node.value;
          case TOK_PIPE:
            left = this.visit(node.children[0], value);
            return this.visit(node.children[1], left);
          case TOK_CURRENT:
            return value;
          case "Function":
            var resolvedArgs = [];
            for (i = 0; i < node.children.length; i++) {
              resolvedArgs.push(this.visit(node.children[i], value));
            }
            return this.runtime.callFunction(node.name, resolvedArgs);
          case "ExpressionReference":
            var refNode = node.children[0];
            refNode.jmespathType = TOK_EXPREF;
            return refNode;
          default:
            throw new Error("Unknown node type: " + node.type);
        }
      },
      computeSliceParams: function(arrayLength, sliceParams) {
        var start = sliceParams[0];
        var stop = sliceParams[1];
        var step = sliceParams[2];
        var computed = [null, null, null];
        if (step === null) {
          step = 1;
        } else if (step === 0) {
          var error = new Error("Invalid slice, step cannot be 0");
          error.name = "RuntimeError";
          throw error;
        }
        var stepValueNegative = step < 0 ? true : false;
        if (start === null) {
          start = stepValueNegative ? arrayLength - 1 : 0;
        } else {
          start = this.capSliceRange(arrayLength, start, step);
        }
        if (stop === null) {
          stop = stepValueNegative ? -1 : arrayLength;
        } else {
          stop = this.capSliceRange(arrayLength, stop, step);
        }
        computed[0] = start;
        computed[1] = stop;
        computed[2] = step;
        return computed;
      },
      capSliceRange: function(arrayLength, actualValue, step) {
        if (actualValue < 0) {
          actualValue += arrayLength;
          if (actualValue < 0) {
            actualValue = step < 0 ? -1 : 0;
          }
        } else if (actualValue >= arrayLength) {
          actualValue = step < 0 ? arrayLength - 1 : arrayLength;
        }
        return actualValue;
      }
    };
    function Runtime(interpreter) {
      this._interpreter = interpreter;
      this.functionTable = {
        abs: {_func: this._functionAbs, _signature: [{types: [TYPE_NUMBER]}]},
        avg: {_func: this._functionAvg, _signature: [{types: [TYPE_ARRAY_NUMBER]}]},
        ceil: {_func: this._functionCeil, _signature: [{types: [TYPE_NUMBER]}]},
        contains: {
          _func: this._functionContains,
          _signature: [
            {types: [TYPE_STRING, TYPE_ARRAY]},
            {types: [TYPE_ANY]}
          ]
        },
        ends_with: {
          _func: this._functionEndsWith,
          _signature: [{types: [TYPE_STRING]}, {types: [TYPE_STRING]}]
        },
        floor: {_func: this._functionFloor, _signature: [{types: [TYPE_NUMBER]}]},
        length: {
          _func: this._functionLength,
          _signature: [{types: [TYPE_STRING, TYPE_ARRAY, TYPE_OBJECT]}]
        },
        map: {
          _func: this._functionMap,
          _signature: [{types: [TYPE_EXPREF]}, {types: [TYPE_ARRAY]}]
        },
        max: {
          _func: this._functionMax,
          _signature: [{types: [TYPE_ARRAY_NUMBER, TYPE_ARRAY_STRING]}]
        },
        merge: {
          _func: this._functionMerge,
          _signature: [{types: [TYPE_OBJECT], variadic: true}]
        },
        max_by: {
          _func: this._functionMaxBy,
          _signature: [{types: [TYPE_ARRAY]}, {types: [TYPE_EXPREF]}]
        },
        sum: {_func: this._functionSum, _signature: [{types: [TYPE_ARRAY_NUMBER]}]},
        starts_with: {
          _func: this._functionStartsWith,
          _signature: [{types: [TYPE_STRING]}, {types: [TYPE_STRING]}]
        },
        min: {
          _func: this._functionMin,
          _signature: [{types: [TYPE_ARRAY_NUMBER, TYPE_ARRAY_STRING]}]
        },
        min_by: {
          _func: this._functionMinBy,
          _signature: [{types: [TYPE_ARRAY]}, {types: [TYPE_EXPREF]}]
        },
        type: {_func: this._functionType, _signature: [{types: [TYPE_ANY]}]},
        keys: {_func: this._functionKeys, _signature: [{types: [TYPE_OBJECT]}]},
        values: {_func: this._functionValues, _signature: [{types: [TYPE_OBJECT]}]},
        sort: {_func: this._functionSort, _signature: [{types: [TYPE_ARRAY_STRING, TYPE_ARRAY_NUMBER]}]},
        sort_by: {
          _func: this._functionSortBy,
          _signature: [{types: [TYPE_ARRAY]}, {types: [TYPE_EXPREF]}]
        },
        join: {
          _func: this._functionJoin,
          _signature: [
            {types: [TYPE_STRING]},
            {types: [TYPE_ARRAY_STRING]}
          ]
        },
        reverse: {
          _func: this._functionReverse,
          _signature: [{types: [TYPE_STRING, TYPE_ARRAY]}]
        },
        to_array: {_func: this._functionToArray, _signature: [{types: [TYPE_ANY]}]},
        to_string: {_func: this._functionToString, _signature: [{types: [TYPE_ANY]}]},
        to_number: {_func: this._functionToNumber, _signature: [{types: [TYPE_ANY]}]},
        not_null: {
          _func: this._functionNotNull,
          _signature: [{types: [TYPE_ANY], variadic: true}]
        }
      };
    }
    Runtime.prototype = {
      callFunction: function(name, resolvedArgs) {
        var functionEntry = this.functionTable[name];
        if (functionEntry === void 0) {
          throw new Error("Unknown function: " + name + "()");
        }
        this._validateArgs(name, resolvedArgs, functionEntry._signature);
        return functionEntry._func.call(this, resolvedArgs);
      },
      _validateArgs: function(name, args, signature) {
        var pluralized;
        if (signature[signature.length - 1].variadic) {
          if (args.length < signature.length) {
            pluralized = signature.length === 1 ? " argument" : " arguments";
            throw new Error("ArgumentError: " + name + "() takes at least" + signature.length + pluralized + " but received " + args.length);
          }
        } else if (args.length !== signature.length) {
          pluralized = signature.length === 1 ? " argument" : " arguments";
          throw new Error("ArgumentError: " + name + "() takes " + signature.length + pluralized + " but received " + args.length);
        }
        var currentSpec;
        var actualType;
        var typeMatched;
        for (var i = 0; i < signature.length; i++) {
          typeMatched = false;
          currentSpec = signature[i].types;
          actualType = this._getTypeName(args[i]);
          for (var j = 0; j < currentSpec.length; j++) {
            if (this._typeMatches(actualType, currentSpec[j], args[i])) {
              typeMatched = true;
              break;
            }
          }
          if (!typeMatched) {
            throw new Error("TypeError: " + name + "() expected argument " + (i + 1) + " to be type " + currentSpec + " but received type " + actualType + " instead.");
          }
        }
      },
      _typeMatches: function(actual, expected, argValue) {
        if (expected === TYPE_ANY) {
          return true;
        }
        if (expected === TYPE_ARRAY_STRING || expected === TYPE_ARRAY_NUMBER || expected === TYPE_ARRAY) {
          if (expected === TYPE_ARRAY) {
            return actual === TYPE_ARRAY;
          } else if (actual === TYPE_ARRAY) {
            var subtype;
            if (expected === TYPE_ARRAY_NUMBER) {
              subtype = TYPE_NUMBER;
            } else if (expected === TYPE_ARRAY_STRING) {
              subtype = TYPE_STRING;
            }
            for (var i = 0; i < argValue.length; i++) {
              if (!this._typeMatches(this._getTypeName(argValue[i]), subtype, argValue[i])) {
                return false;
              }
            }
            return true;
          }
        } else {
          return actual === expected;
        }
      },
      _getTypeName: function(obj) {
        switch (Object.prototype.toString.call(obj)) {
          case "[object String]":
            return TYPE_STRING;
          case "[object Number]":
            return TYPE_NUMBER;
          case "[object Array]":
            return TYPE_ARRAY;
          case "[object Boolean]":
            return TYPE_BOOLEAN;
          case "[object Null]":
            return TYPE_NULL;
          case "[object Object]":
            if (obj.jmespathType === TOK_EXPREF) {
              return TYPE_EXPREF;
            } else {
              return TYPE_OBJECT;
            }
        }
      },
      _functionStartsWith: function(resolvedArgs) {
        return resolvedArgs[0].lastIndexOf(resolvedArgs[1]) === 0;
      },
      _functionEndsWith: function(resolvedArgs) {
        var searchStr = resolvedArgs[0];
        var suffix = resolvedArgs[1];
        return searchStr.indexOf(suffix, searchStr.length - suffix.length) !== -1;
      },
      _functionReverse: function(resolvedArgs) {
        var typeName = this._getTypeName(resolvedArgs[0]);
        if (typeName === TYPE_STRING) {
          var originalStr = resolvedArgs[0];
          var reversedStr = "";
          for (var i = originalStr.length - 1; i >= 0; i--) {
            reversedStr += originalStr[i];
          }
          return reversedStr;
        } else {
          var reversedArray = resolvedArgs[0].slice(0);
          reversedArray.reverse();
          return reversedArray;
        }
      },
      _functionAbs: function(resolvedArgs) {
        return Math.abs(resolvedArgs[0]);
      },
      _functionCeil: function(resolvedArgs) {
        return Math.ceil(resolvedArgs[0]);
      },
      _functionAvg: function(resolvedArgs) {
        var sum = 0;
        var inputArray = resolvedArgs[0];
        for (var i = 0; i < inputArray.length; i++) {
          sum += inputArray[i];
        }
        return sum / inputArray.length;
      },
      _functionContains: function(resolvedArgs) {
        return resolvedArgs[0].indexOf(resolvedArgs[1]) >= 0;
      },
      _functionFloor: function(resolvedArgs) {
        return Math.floor(resolvedArgs[0]);
      },
      _functionLength: function(resolvedArgs) {
        if (!isObject2(resolvedArgs[0])) {
          return resolvedArgs[0].length;
        } else {
          return Object.keys(resolvedArgs[0]).length;
        }
      },
      _functionMap: function(resolvedArgs) {
        var mapped = [];
        var interpreter = this._interpreter;
        var exprefNode = resolvedArgs[0];
        var elements = resolvedArgs[1];
        for (var i = 0; i < elements.length; i++) {
          mapped.push(interpreter.visit(exprefNode, elements[i]));
        }
        return mapped;
      },
      _functionMerge: function(resolvedArgs) {
        var merged = {};
        for (var i = 0; i < resolvedArgs.length; i++) {
          var current = resolvedArgs[i];
          for (var key in current) {
            merged[key] = current[key];
          }
        }
        return merged;
      },
      _functionMax: function(resolvedArgs) {
        if (resolvedArgs[0].length > 0) {
          var typeName = this._getTypeName(resolvedArgs[0][0]);
          if (typeName === TYPE_NUMBER) {
            return Math.max.apply(Math, resolvedArgs[0]);
          } else {
            var elements = resolvedArgs[0];
            var maxElement = elements[0];
            for (var i = 1; i < elements.length; i++) {
              if (maxElement.localeCompare(elements[i]) < 0) {
                maxElement = elements[i];
              }
            }
            return maxElement;
          }
        } else {
          return null;
        }
      },
      _functionMin: function(resolvedArgs) {
        if (resolvedArgs[0].length > 0) {
          var typeName = this._getTypeName(resolvedArgs[0][0]);
          if (typeName === TYPE_NUMBER) {
            return Math.min.apply(Math, resolvedArgs[0]);
          } else {
            var elements = resolvedArgs[0];
            var minElement = elements[0];
            for (var i = 1; i < elements.length; i++) {
              if (elements[i].localeCompare(minElement) < 0) {
                minElement = elements[i];
              }
            }
            return minElement;
          }
        } else {
          return null;
        }
      },
      _functionSum: function(resolvedArgs) {
        var sum = 0;
        var listToSum = resolvedArgs[0];
        for (var i = 0; i < listToSum.length; i++) {
          sum += listToSum[i];
        }
        return sum;
      },
      _functionType: function(resolvedArgs) {
        switch (this._getTypeName(resolvedArgs[0])) {
          case TYPE_NUMBER:
            return "number";
          case TYPE_STRING:
            return "string";
          case TYPE_ARRAY:
            return "array";
          case TYPE_OBJECT:
            return "object";
          case TYPE_BOOLEAN:
            return "boolean";
          case TYPE_EXPREF:
            return "expref";
          case TYPE_NULL:
            return "null";
        }
      },
      _functionKeys: function(resolvedArgs) {
        return Object.keys(resolvedArgs[0]);
      },
      _functionValues: function(resolvedArgs) {
        var obj = resolvedArgs[0];
        var keys = Object.keys(obj);
        var values = [];
        for (var i = 0; i < keys.length; i++) {
          values.push(obj[keys[i]]);
        }
        return values;
      },
      _functionJoin: function(resolvedArgs) {
        var joinChar = resolvedArgs[0];
        var listJoin = resolvedArgs[1];
        return listJoin.join(joinChar);
      },
      _functionToArray: function(resolvedArgs) {
        if (this._getTypeName(resolvedArgs[0]) === TYPE_ARRAY) {
          return resolvedArgs[0];
        } else {
          return [resolvedArgs[0]];
        }
      },
      _functionToString: function(resolvedArgs) {
        if (this._getTypeName(resolvedArgs[0]) === TYPE_STRING) {
          return resolvedArgs[0];
        } else {
          return JSON.stringify(resolvedArgs[0]);
        }
      },
      _functionToNumber: function(resolvedArgs) {
        var typeName = this._getTypeName(resolvedArgs[0]);
        var convertedValue;
        if (typeName === TYPE_NUMBER) {
          return resolvedArgs[0];
        } else if (typeName === TYPE_STRING) {
          convertedValue = +resolvedArgs[0];
          if (!isNaN(convertedValue)) {
            return convertedValue;
          }
        }
        return null;
      },
      _functionNotNull: function(resolvedArgs) {
        for (var i = 0; i < resolvedArgs.length; i++) {
          if (this._getTypeName(resolvedArgs[i]) !== TYPE_NULL) {
            return resolvedArgs[i];
          }
        }
        return null;
      },
      _functionSort: function(resolvedArgs) {
        var sortedArray = resolvedArgs[0].slice(0);
        sortedArray.sort();
        return sortedArray;
      },
      _functionSortBy: function(resolvedArgs) {
        var sortedArray = resolvedArgs[0].slice(0);
        if (sortedArray.length === 0) {
          return sortedArray;
        }
        var interpreter = this._interpreter;
        var exprefNode = resolvedArgs[1];
        var requiredType = this._getTypeName(interpreter.visit(exprefNode, sortedArray[0]));
        if ([TYPE_NUMBER, TYPE_STRING].indexOf(requiredType) < 0) {
          throw new Error("TypeError");
        }
        var that = this;
        var decorated = [];
        for (var i = 0; i < sortedArray.length; i++) {
          decorated.push([i, sortedArray[i]]);
        }
        decorated.sort(function(a, b) {
          var exprA = interpreter.visit(exprefNode, a[1]);
          var exprB = interpreter.visit(exprefNode, b[1]);
          if (that._getTypeName(exprA) !== requiredType) {
            throw new Error("TypeError: expected " + requiredType + ", received " + that._getTypeName(exprA));
          } else if (that._getTypeName(exprB) !== requiredType) {
            throw new Error("TypeError: expected " + requiredType + ", received " + that._getTypeName(exprB));
          }
          if (exprA > exprB) {
            return 1;
          } else if (exprA < exprB) {
            return -1;
          } else {
            return a[0] - b[0];
          }
        });
        for (var j = 0; j < decorated.length; j++) {
          sortedArray[j] = decorated[j][1];
        }
        return sortedArray;
      },
      _functionMaxBy: function(resolvedArgs) {
        var exprefNode = resolvedArgs[1];
        var resolvedArray = resolvedArgs[0];
        var keyFunction = this.createKeyFunction(exprefNode, [TYPE_NUMBER, TYPE_STRING]);
        var maxNumber = -Infinity;
        var maxRecord;
        var current;
        for (var i = 0; i < resolvedArray.length; i++) {
          current = keyFunction(resolvedArray[i]);
          if (current > maxNumber) {
            maxNumber = current;
            maxRecord = resolvedArray[i];
          }
        }
        return maxRecord;
      },
      _functionMinBy: function(resolvedArgs) {
        var exprefNode = resolvedArgs[1];
        var resolvedArray = resolvedArgs[0];
        var keyFunction = this.createKeyFunction(exprefNode, [TYPE_NUMBER, TYPE_STRING]);
        var minNumber = Infinity;
        var minRecord;
        var current;
        for (var i = 0; i < resolvedArray.length; i++) {
          current = keyFunction(resolvedArray[i]);
          if (current < minNumber) {
            minNumber = current;
            minRecord = resolvedArray[i];
          }
        }
        return minRecord;
      },
      createKeyFunction: function(exprefNode, allowedTypes) {
        var that = this;
        var interpreter = this._interpreter;
        var keyFunc = function(x) {
          var current = interpreter.visit(exprefNode, x);
          if (allowedTypes.indexOf(that._getTypeName(current)) < 0) {
            var msg = "TypeError: expected one of " + allowedTypes + ", received " + that._getTypeName(current);
            throw new Error(msg);
          }
          return current;
        };
        return keyFunc;
      }
    };
    function compile(stream) {
      var parser = new Parser();
      var ast = parser.parse(stream);
      return ast;
    }
    function tokenize(stream) {
      var lexer = new Lexer();
      return lexer.tokenize(stream);
    }
    function search(data, expression) {
      var parser = new Parser();
      var runtime = new Runtime();
      var interpreter = new TreeInterpreter(runtime);
      runtime._interpreter = interpreter;
      var node = parser.parse(expression);
      return interpreter.search(node, data);
    }
    exports3.tokenize = tokenize;
    exports3.compile = compile;
    exports3.search = search;
    exports3.strictDeepEqual = strictDeepEqual;
  })(typeof exports2 === "undefined" ? exports2.jmespath = {} : exports2);
});

// node_modules/pino-pretty/lib/constants.js
var require_constants2 = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = {
    DATE_FORMAT: "yyyy-mm-dd HH:MM:ss.l o",
    ERROR_LIKE_KEYS: ["err", "error"],
    MESSAGE_KEY: "msg",
    LEVEL_KEY: "level",
    TIMESTAMP_KEY: "time",
    LEVELS: {
      default: "USERLVL",
      60: "FATAL",
      50: "ERROR",
      40: "WARN ",
      30: "INFO ",
      20: "DEBUG",
      10: "TRACE"
    },
    LEVEL_NAMES: {
      fatal: 60,
      error: 50,
      warn: 40,
      info: 30,
      debug: 20,
      trace: 10
    },
    LOGGER_KEYS: [
      "pid",
      "hostname",
      "name",
      "level",
      "time",
      "timestamp",
      "v",
      "caller"
    ]
  };
});

// node_modules/pino-pretty/lib/colors.js
var require_colors = __commonJS((exports2, module2) => {
  "use strict";
  var {LEVELS, LEVEL_NAMES} = require_constants2();
  var nocolor = (input) => input;
  var plain = {
    default: nocolor,
    60: nocolor,
    50: nocolor,
    40: nocolor,
    30: nocolor,
    20: nocolor,
    10: nocolor,
    message: nocolor
  };
  var chalk = require_chalk();
  var ctx = new chalk.constructor({enabled: true, level: 3});
  var colored = {
    default: ctx.white,
    60: ctx.bgRed,
    50: ctx.red,
    40: ctx.yellow,
    30: ctx.green,
    20: ctx.blue,
    10: ctx.grey,
    message: ctx.cyan
  };
  function colorizeLevel(level, colorizer) {
    if (Number.isInteger(+level)) {
      return Object.prototype.hasOwnProperty.call(LEVELS, level) ? colorizer[level](LEVELS[level]) : colorizer.default(LEVELS.default);
    }
    const levelNum = LEVEL_NAMES[level.toLowerCase()] || "default";
    return colorizer[levelNum](LEVELS[levelNum]);
  }
  function plainColorizer(level) {
    return colorizeLevel(level, plain);
  }
  plainColorizer.message = plain.message;
  function coloredColorizer(level) {
    return colorizeLevel(level, colored);
  }
  coloredColorizer.message = colored.message;
  module2.exports = function getColorizer(useColors = false) {
    return useColors ? coloredColorizer : plainColorizer;
  };
});

// node_modules/dateformat/lib/dateformat.js
var require_dateformat = __commonJS((exports2, module2) => {
  (function(global2) {
    "use strict";
    var dateFormat = function() {
      var token = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZWN]|"[^"]*"|'[^']*'/g;
      var timezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g;
      var timezoneClip = /[^-+\dA-Z]/g;
      return function(date, mask, utc, gmt) {
        if (arguments.length === 1 && kindOf(date) === "string" && !/\d/.test(date)) {
          mask = date;
          date = void 0;
        }
        date = date || new Date();
        if (!(date instanceof Date)) {
          date = new Date(date);
        }
        if (isNaN(date)) {
          throw TypeError("Invalid date");
        }
        mask = String(dateFormat.masks[mask] || mask || dateFormat.masks["default"]);
        var maskSlice = mask.slice(0, 4);
        if (maskSlice === "UTC:" || maskSlice === "GMT:") {
          mask = mask.slice(4);
          utc = true;
          if (maskSlice === "GMT:") {
            gmt = true;
          }
        }
        var _ = utc ? "getUTC" : "get";
        var d = date[_ + "Date"]();
        var D = date[_ + "Day"]();
        var m = date[_ + "Month"]();
        var y = date[_ + "FullYear"]();
        var H = date[_ + "Hours"]();
        var M = date[_ + "Minutes"]();
        var s = date[_ + "Seconds"]();
        var L = date[_ + "Milliseconds"]();
        var o = utc ? 0 : date.getTimezoneOffset();
        var W = getWeek(date);
        var N = getDayOfWeek(date);
        var flags = {
          d,
          dd: pad(d),
          ddd: dateFormat.i18n.dayNames[D],
          dddd: dateFormat.i18n.dayNames[D + 7],
          m: m + 1,
          mm: pad(m + 1),
          mmm: dateFormat.i18n.monthNames[m],
          mmmm: dateFormat.i18n.monthNames[m + 12],
          yy: String(y).slice(2),
          yyyy: y,
          h: H % 12 || 12,
          hh: pad(H % 12 || 12),
          H,
          HH: pad(H),
          M,
          MM: pad(M),
          s,
          ss: pad(s),
          l: pad(L, 3),
          L: pad(Math.round(L / 10)),
          t: H < 12 ? dateFormat.i18n.timeNames[0] : dateFormat.i18n.timeNames[1],
          tt: H < 12 ? dateFormat.i18n.timeNames[2] : dateFormat.i18n.timeNames[3],
          T: H < 12 ? dateFormat.i18n.timeNames[4] : dateFormat.i18n.timeNames[5],
          TT: H < 12 ? dateFormat.i18n.timeNames[6] : dateFormat.i18n.timeNames[7],
          Z: gmt ? "GMT" : utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),
          o: (o > 0 ? "-" : "+") + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),
          S: ["th", "st", "nd", "rd"][d % 10 > 3 ? 0 : (d % 100 - d % 10 != 10) * d % 10],
          W,
          N
        };
        return mask.replace(token, function(match) {
          if (match in flags) {
            return flags[match];
          }
          return match.slice(1, match.length - 1);
        });
      };
    }();
    dateFormat.masks = {
      default: "ddd mmm dd yyyy HH:MM:ss",
      shortDate: "m/d/yy",
      mediumDate: "mmm d, yyyy",
      longDate: "mmmm d, yyyy",
      fullDate: "dddd, mmmm d, yyyy",
      shortTime: "h:MM TT",
      mediumTime: "h:MM:ss TT",
      longTime: "h:MM:ss TT Z",
      isoDate: "yyyy-mm-dd",
      isoTime: "HH:MM:ss",
      isoDateTime: "yyyy-mm-dd'T'HH:MM:sso",
      isoUtcDateTime: "UTC:yyyy-mm-dd'T'HH:MM:ss'Z'",
      expiresHeaderFormat: "ddd, dd mmm yyyy HH:MM:ss Z"
    };
    dateFormat.i18n = {
      dayNames: [
        "Sun",
        "Mon",
        "Tue",
        "Wed",
        "Thu",
        "Fri",
        "Sat",
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
      ],
      monthNames: [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
      ],
      timeNames: [
        "a",
        "p",
        "am",
        "pm",
        "A",
        "P",
        "AM",
        "PM"
      ]
    };
    function pad(val, len) {
      val = String(val);
      len = len || 2;
      while (val.length < len) {
        val = "0" + val;
      }
      return val;
    }
    function getWeek(date) {
      var targetThursday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
      targetThursday.setDate(targetThursday.getDate() - (targetThursday.getDay() + 6) % 7 + 3);
      var firstThursday = new Date(targetThursday.getFullYear(), 0, 4);
      firstThursday.setDate(firstThursday.getDate() - (firstThursday.getDay() + 6) % 7 + 3);
      var ds = targetThursday.getTimezoneOffset() - firstThursday.getTimezoneOffset();
      targetThursday.setHours(targetThursday.getHours() - ds);
      var weekDiff = (targetThursday - firstThursday) / (864e5 * 7);
      return 1 + Math.floor(weekDiff);
    }
    function getDayOfWeek(date) {
      var dow = date.getDay();
      if (dow === 0) {
        dow = 7;
      }
      return dow;
    }
    function kindOf(val) {
      if (val === null) {
        return "null";
      }
      if (val === void 0) {
        return "undefined";
      }
      if (typeof val !== "object") {
        return typeof val;
      }
      if (Array.isArray(val)) {
        return "array";
      }
      return {}.toString.call(val).slice(8, -1).toLowerCase();
    }
    ;
    if (typeof define === "function" && define.amd) {
      define(function() {
        return dateFormat;
      });
    } else if (typeof exports2 === "object") {
      module2.exports = dateFormat;
    } else {
      global2.dateFormat = dateFormat;
    }
  })(exports2);
});

// node_modules/pino-pretty/lib/utils.js
var require_utils = __commonJS((exports2, module2) => {
  "use strict";
  var dateformat = require_dateformat();
  var stringifySafe = require_fast_safe_stringify();
  var defaultColorizer = require_colors()();
  var {
    DATE_FORMAT,
    ERROR_LIKE_KEYS,
    MESSAGE_KEY,
    LEVEL_KEY,
    TIMESTAMP_KEY,
    LOGGER_KEYS
  } = require_constants2();
  module2.exports = {
    isObject: isObject2,
    prettifyErrorLog,
    prettifyLevel,
    prettifyMessage,
    prettifyMetadata,
    prettifyObject,
    prettifyTime
  };
  module2.exports.internals = {
    formatTime,
    joinLinesWithIndentation
  };
  function formatTime(epoch, translateTime = false) {
    if (translateTime === false) {
      return epoch;
    }
    const instant = new Date(epoch);
    if (translateTime === true) {
      return dateformat(instant, "UTC:" + DATE_FORMAT);
    }
    const upperFormat = translateTime.toUpperCase();
    if (upperFormat === "SYS:STANDARD") {
      return dateformat(instant, DATE_FORMAT);
    }
    const prefix = upperFormat.substr(0, 4);
    if (prefix === "SYS:" || prefix === "UTC:") {
      if (prefix === "UTC:") {
        return dateformat(instant, translateTime);
      }
      return dateformat(instant, translateTime.slice(4));
    }
    return dateformat(instant, `UTC:${translateTime}`);
  }
  function isObject2(input) {
    return Object.prototype.toString.apply(input) === "[object Object]";
  }
  function joinLinesWithIndentation({input, ident = "    ", eol = "\n"}) {
    const lines = input.split(/\r?\n/);
    for (var i = 1; i < lines.length; i += 1) {
      lines[i] = ident + lines[i];
    }
    return lines.join(eol);
  }
  function prettifyErrorLog({
    log: log2,
    messageKey = MESSAGE_KEY,
    ident = "    ",
    eol = "\n",
    errorLikeKeys = ERROR_LIKE_KEYS,
    errorProperties = []
  }) {
    const stack = log2.stack;
    const joinedLines = joinLinesWithIndentation({input: stack, ident, eol});
    let result = `${ident}${joinedLines}${eol}`;
    if (errorProperties.length > 0) {
      const excludeProperties = LOGGER_KEYS.concat(messageKey, "type", "stack");
      let propertiesToPrint;
      if (errorProperties[0] === "*") {
        propertiesToPrint = Object.keys(log2).filter((k) => excludeProperties.includes(k) === false);
      } else {
        propertiesToPrint = errorProperties.filter((k) => excludeProperties.includes(k) === false);
      }
      for (var i = 0; i < propertiesToPrint.length; i += 1) {
        const key = propertiesToPrint[i];
        if (key in log2 === false)
          continue;
        if (isObject2(log2[key])) {
          const prettifiedObject = prettifyObject({input: log2[key], errorLikeKeys, excludeLoggerKeys: false, eol, ident});
          result = `${result}${key}: {${eol}${prettifiedObject}}${eol}`;
          continue;
        }
        result = `${result}${key}: ${log2[key]}${eol}`;
      }
    }
    return result;
  }
  function prettifyLevel({log: log2, colorizer = defaultColorizer, levelKey = LEVEL_KEY}) {
    if (levelKey in log2 === false)
      return void 0;
    return colorizer(log2[levelKey]);
  }
  function prettifyMessage({log: log2, messageFormat, messageKey = MESSAGE_KEY, colorizer = defaultColorizer}) {
    if (messageFormat) {
      const message = String(messageFormat).replace(/{([^{}]+)}/g, function(match, p1) {
        if (p1 && log2[p1]) {
          return log2[p1];
        }
        return "";
      });
      return colorizer.message(message);
    }
    if (messageKey in log2 === false)
      return void 0;
    if (typeof log2[messageKey] !== "string")
      return void 0;
    return colorizer.message(log2[messageKey]);
  }
  function prettifyMetadata({log: log2}) {
    let line = "";
    if (log2.name || log2.pid || log2.hostname) {
      line += "(";
      if (log2.name) {
        line += log2.name;
      }
      if (log2.name && log2.pid) {
        line += "/" + log2.pid;
      } else if (log2.pid) {
        line += log2.pid;
      }
      if (log2.hostname) {
        line += `${line === "(" ? "on" : " on"} ${log2.hostname}`;
      }
      line += ")";
    }
    if (log2.caller) {
      line += `${line === "" ? "" : " "}<${log2.caller}>`;
    }
    if (line === "") {
      return void 0;
    } else {
      return line;
    }
  }
  function prettifyObject({
    input,
    ident = "    ",
    eol = "\n",
    skipKeys = [],
    customPrettifiers = {},
    errorLikeKeys = ERROR_LIKE_KEYS,
    excludeLoggerKeys = true
  }) {
    const objectKeys = Object.keys(input);
    const keysToIgnore = [].concat(skipKeys);
    if (excludeLoggerKeys === true)
      Array.prototype.push.apply(keysToIgnore, LOGGER_KEYS);
    let result = "";
    const keysToIterate = objectKeys.filter((k) => keysToIgnore.includes(k) === false);
    for (var i = 0; i < objectKeys.length; i += 1) {
      const keyName = keysToIterate[i];
      const keyValue = input[keyName];
      if (keyValue === void 0)
        continue;
      let lines;
      if (typeof customPrettifiers[keyName] === "function") {
        lines = customPrettifiers[keyName](keyValue, keyName, input);
      } else {
        lines = stringifySafe(keyValue, null, 2);
      }
      if (lines === void 0)
        continue;
      const joinedLines = joinLinesWithIndentation({input: lines, ident, eol});
      if (errorLikeKeys.includes(keyName) === true) {
        const splitLines = `${ident}${keyName}: ${joinedLines}${eol}`.split(eol);
        for (var j = 0; j < splitLines.length; j += 1) {
          if (j !== 0)
            result += eol;
          const line = splitLines[j];
          if (/^\s*"stack"/.test(line)) {
            const matches = /^(\s*"stack":)\s*(".*"),?$/.exec(line);
            if (matches && matches.length === 3) {
              const indentSize = /^\s*/.exec(line)[0].length + 4;
              const indentation = " ".repeat(indentSize);
              const stackMessage = matches[2];
              result += matches[1] + eol + indentation + JSON.parse(stackMessage).replace(/\n/g, eol + indentation);
            }
          } else {
            result += line;
          }
        }
      } else {
        result += `${ident}${keyName}: ${joinedLines}${eol}`;
      }
    }
    return result;
  }
  function prettifyTime({log: log2, timestampKey = TIMESTAMP_KEY, translateFormat = void 0}) {
    let time = null;
    if (timestampKey in log2) {
      time = log2[timestampKey];
    } else if ("timestamp" in log2) {
      time = log2.timestamp;
    }
    if (time === null)
      return void 0;
    if (translateFormat) {
      return "[" + formatTime(time, translateFormat) + "]";
    }
    return `[${time}]`;
  }
});

// node_modules/@hapi/bourne/lib/index.js
var require_lib = __commonJS((exports2) => {
  "use strict";
  var internals = {
    suspectRx: /"(?:_|\\u005[Ff])(?:_|\\u005[Ff])(?:p|\\u0070)(?:r|\\u0072)(?:o|\\u006[Ff])(?:t|\\u0074)(?:o|\\u006[Ff])(?:_|\\u005[Ff])(?:_|\\u005[Ff])"\s*\:/
  };
  exports2.parse = function(text, reviver, options) {
    if (!options) {
      if (reviver && typeof reviver === "object") {
        options = reviver;
        reviver = void 0;
      } else {
        options = {};
      }
    }
    const obj = JSON.parse(text, reviver);
    if (options.protoAction === "ignore") {
      return obj;
    }
    if (!obj || typeof obj !== "object") {
      return obj;
    }
    if (!text.match(internals.suspectRx)) {
      return obj;
    }
    exports2.scan(obj, options);
    return obj;
  };
  exports2.scan = function(obj, options) {
    options = options || {};
    let next = [obj];
    while (next.length) {
      const nodes = next;
      next = [];
      for (const node of nodes) {
        if (Object.prototype.hasOwnProperty.call(node, "__proto__")) {
          if (options.protoAction !== "remove") {
            throw new SyntaxError("Object contains forbidden prototype property");
          }
          delete node.__proto__;
        }
        for (const key in node) {
          const value = node[key];
          if (value && typeof value === "object") {
            next.push(node[key]);
          }
        }
      }
    }
  };
  exports2.safeParse = function(text, reviver) {
    try {
      return exports2.parse(text, reviver);
    } catch (ignoreError) {
      return null;
    }
  };
});

// node_modules/pino-pretty/index.js
var require_pino_pretty = __commonJS((exports2, module2) => {
  "use strict";
  var chalk = require_chalk();
  var jmespath = require_jmespath();
  var colors = require_colors();
  var {ERROR_LIKE_KEYS, MESSAGE_KEY, TIMESTAMP_KEY} = require_constants2();
  var {
    isObject: isObject2,
    prettifyErrorLog,
    prettifyLevel,
    prettifyMessage,
    prettifyMetadata,
    prettifyObject,
    prettifyTime
  } = require_utils();
  var bourne = require_lib();
  var jsonParser = (input) => {
    try {
      return {value: bourne.parse(input, {protoAction: "remove"})};
    } catch (err) {
      return {err};
    }
  };
  var defaultOptions = {
    colorize: chalk.supportsColor,
    crlf: false,
    errorLikeObjectKeys: ERROR_LIKE_KEYS,
    errorProps: "",
    levelFirst: false,
    messageKey: MESSAGE_KEY,
    messageFormat: false,
    timestampKey: TIMESTAMP_KEY,
    translateTime: false,
    useMetadata: false,
    outputStream: process.stdout,
    customPrettifiers: {}
  };
  module2.exports = function prettyFactory(options) {
    const opts = Object.assign({}, defaultOptions, options);
    const EOL = opts.crlf ? "\r\n" : "\n";
    const IDENT = "    ";
    const messageKey = opts.messageKey;
    const levelKey = opts.levelKey;
    const messageFormat = opts.messageFormat;
    const timestampKey = opts.timestampKey;
    const errorLikeObjectKeys = opts.errorLikeObjectKeys;
    const errorProps = opts.errorProps.split(",");
    const customPrettifiers = opts.customPrettifiers;
    const ignoreKeys = opts.ignore ? new Set(opts.ignore.split(",")) : void 0;
    const colorizer = colors(opts.colorize);
    const search = opts.search;
    return pretty;
    function pretty(inputData) {
      let log2;
      if (!isObject2(inputData)) {
        const parsed = jsonParser(inputData);
        if (parsed.err || !isObject2(parsed.value)) {
          return inputData + EOL;
        }
        log2 = parsed.value;
      } else {
        log2 = inputData;
      }
      if ([null, true, false].includes(log2) || Number.isFinite(log2)) {
        return `${log2}
`;
      }
      if (search && !jmespath.search(log2, search)) {
        return;
      }
      const prettifiedMessage = prettifyMessage({log: log2, messageKey, colorizer, messageFormat});
      if (ignoreKeys) {
        log2 = Object.keys(log2).filter((key) => !ignoreKeys.has(key)).reduce((res, key) => {
          res[key] = log2[key];
          return res;
        }, {});
      }
      const prettifiedLevel = prettifyLevel({log: log2, colorizer, levelKey});
      const prettifiedMetadata = prettifyMetadata({log: log2});
      const prettifiedTime = prettifyTime({log: log2, translateFormat: opts.translateTime, timestampKey});
      let line = "";
      if (opts.levelFirst && prettifiedLevel) {
        line = `${prettifiedLevel}`;
      }
      if (prettifiedTime && line === "") {
        line = `${prettifiedTime}`;
      } else if (prettifiedTime) {
        line = `${line} ${prettifiedTime}`;
      }
      if (!opts.levelFirst && prettifiedLevel) {
        if (line.length > 0) {
          line = `${line} ${prettifiedLevel}`;
        } else {
          line = prettifiedLevel;
        }
      }
      if (prettifiedMetadata) {
        line = `${line} ${prettifiedMetadata}:`;
      }
      if (line.endsWith(":") === false && line !== "") {
        line += ":";
      }
      if (prettifiedMessage) {
        line = `${line} ${prettifiedMessage}`;
      }
      if (line.length > 0) {
        line += EOL;
      }
      if (log2.type === "Error" && log2.stack) {
        const prettifiedErrorLog = prettifyErrorLog({
          log: log2,
          errorLikeKeys: errorLikeObjectKeys,
          errorProperties: errorProps,
          ident: IDENT,
          eol: EOL
        });
        line += prettifiedErrorLog;
      } else {
        const skipKeys = [messageKey, levelKey].filter((key) => typeof log2[key] === "string");
        const prettifiedObject = prettifyObject({
          input: log2,
          skipKeys,
          customPrettifiers,
          errorLikeKeys: errorLikeObjectKeys,
          eol: EOL,
          ident: IDENT
        });
        line += prettifiedObject;
      }
      return line;
    }
  };
});

// node_modules/pino/lib/tools.js
var require_tools = __commonJS((exports2, module2) => {
  "use strict";
  var format = require_quick_format_unescaped();
  var {mapHttpRequest, mapHttpResponse} = require_pino_std_serializers();
  var SonicBoom = require_sonic_boom();
  var stringifySafe = require_fast_safe_stringify();
  var {
    lsCacheSym,
    chindingsSym,
    parsedChindingsSym,
    writeSym,
    serializersSym,
    formatOptsSym,
    endSym,
    stringifiersSym,
    stringifySym,
    wildcardFirstSym,
    needsMetadataGsym,
    wildcardGsym,
    redactFmtSym,
    streamSym,
    nestedKeySym
  } = require_symbols();
  function noop() {
  }
  function genLog(z) {
    return function LOG(o, ...n) {
      if (typeof o === "object" && o !== null) {
        if (o.method && o.headers && o.socket) {
          o = mapHttpRequest(o);
        } else if (typeof o.setHeader === "function") {
          o = mapHttpResponse(o);
        }
        if (this[nestedKeySym])
          o = {[this[nestedKeySym]]: o};
        this[writeSym](o, format(null, n, this[formatOptsSym]), z);
      } else
        this[writeSym](null, format(o, n, this[formatOptsSym]), z);
    };
  }
  function asString(str) {
    var result = "";
    var last = 0;
    var found = false;
    var point = 255;
    const l = str.length;
    if (l > 100) {
      return JSON.stringify(str);
    }
    for (var i = 0; i < l && point >= 32; i++) {
      point = str.charCodeAt(i);
      if (point === 34 || point === 92) {
        result += str.slice(last, i) + "\\";
        last = i;
        found = true;
      }
    }
    if (!found) {
      result = str;
    } else {
      result += str.slice(last);
    }
    return point < 32 ? JSON.stringify(str) : '"' + result + '"';
  }
  function asJson(obj, num, time) {
    const stringify2 = this[stringifySym];
    const stringifiers = this[stringifiersSym];
    const end = this[endSym];
    const chindings = this[chindingsSym];
    const serializers = this[serializersSym];
    var data = this[lsCacheSym][num] + time;
    data = data + chindings;
    var value;
    var notHasOwnProperty = obj.hasOwnProperty === void 0;
    if (serializers[wildcardGsym]) {
      obj = serializers[wildcardGsym](obj);
    }
    const wildcardStringifier = stringifiers[wildcardFirstSym];
    for (var key in obj) {
      value = obj[key];
      if ((notHasOwnProperty || obj.hasOwnProperty(key)) && value !== void 0) {
        value = serializers[key] ? serializers[key](value) : value;
        const stringifier = stringifiers[key] || wildcardStringifier;
        switch (typeof value) {
          case "undefined":
          case "function":
            continue;
          case "number":
            if (Number.isFinite(value) === false) {
              value = null;
            }
          case "boolean":
            if (stringifier)
              value = stringifier(value);
            break;
          case "string":
            value = (stringifier || asString)(value);
            break;
          default:
            value = (stringifier || stringify2)(value);
        }
        if (value === void 0)
          continue;
        data += ',"' + key + '":' + value;
      }
    }
    return data + end;
  }
  function asChindings(instance, bindings) {
    if (!bindings) {
      throw Error("missing bindings for child Pino");
    }
    var key;
    var value;
    var data = instance[chindingsSym];
    const stringify2 = instance[stringifySym];
    const stringifiers = instance[stringifiersSym];
    const serializers = instance[serializersSym];
    if (serializers[wildcardGsym]) {
      bindings = serializers[wildcardGsym](bindings);
    }
    for (key in bindings) {
      value = bindings[key];
      const valid = key !== "level" && key !== "serializers" && key !== "customLevels" && bindings.hasOwnProperty(key) && value !== void 0;
      if (valid === true) {
        value = serializers[key] ? serializers[key](value) : value;
        value = (stringifiers[key] || stringify2)(value);
        if (value === void 0)
          continue;
        data += ',"' + key + '":' + value;
      }
    }
    return data;
  }
  function getPrettyStream(opts, prettifier, dest, instance) {
    if (prettifier && typeof prettifier === "function") {
      prettifier = prettifier.bind(instance);
      return prettifierMetaWrapper(prettifier(opts), dest);
    }
    try {
      var prettyFactory = require_pino_pretty();
      prettyFactory.asMetaWrapper = prettifierMetaWrapper;
      return prettifierMetaWrapper(prettyFactory(opts), dest);
    } catch (e) {
      throw Error("Missing `pino-pretty` module: `pino-pretty` must be installed separately");
    }
  }
  function prettifierMetaWrapper(pretty, dest) {
    var warned = false;
    return {
      [needsMetadataGsym]: true,
      lastLevel: 0,
      lastMsg: null,
      lastObj: null,
      lastLogger: null,
      flushSync() {
        if (warned) {
          return;
        }
        warned = true;
        setMetadataProps(dest, this);
        dest.write(pretty(Object.assign({
          level: 40,
          msg: "pino.final with prettyPrint does not support flushing",
          time: Date.now()
        }, this.chindings())));
      },
      chindings() {
        const lastLogger = this.lastLogger;
        var chindings = null;
        if (!lastLogger) {
          return null;
        }
        if (lastLogger.hasOwnProperty(parsedChindingsSym)) {
          chindings = lastLogger[parsedChindingsSym];
        } else {
          chindings = JSON.parse('{"v":1' + lastLogger[chindingsSym] + "}");
          lastLogger[parsedChindingsSym] = chindings;
        }
        return chindings;
      },
      write(chunk) {
        const lastLogger = this.lastLogger;
        const chindings = this.chindings();
        var time = this.lastTime;
        if (time.match(/^\d+/)) {
          time = parseInt(time);
        }
        var lastObj = this.lastObj;
        var errorProps = null;
        const obj = Object.assign({
          level: this.lastLevel,
          time
        }, chindings, lastObj, errorProps);
        const serializers = lastLogger[serializersSym];
        const keys = Object.keys(serializers);
        var key;
        for (var i = 0; i < keys.length; i++) {
          key = keys[i];
          if (obj[key] !== void 0) {
            obj[key] = serializers[key](obj[key]);
          }
        }
        const stringifiers = lastLogger[stringifiersSym];
        const redact = stringifiers[redactFmtSym];
        const formatted = pretty(typeof redact === "function" ? redact(obj) : obj);
        if (formatted === void 0)
          return;
        setMetadataProps(dest, this);
        dest.write(formatted);
      }
    };
  }
  function hasBeenTampered(stream) {
    return stream.write !== stream.constructor.prototype.write;
  }
  function buildSafeSonicBoom(dest, buffer = 0, sync = true) {
    const stream = new SonicBoom(dest, buffer, sync);
    stream.on("error", filterBrokenPipe);
    return stream;
    function filterBrokenPipe(err) {
      if (err.code === "EPIPE") {
        stream.write = noop;
        stream.end = noop;
        stream.flushSync = noop;
        stream.destroy = noop;
        return;
      }
      stream.removeListener("error", filterBrokenPipe);
      stream.emit("error", err);
    }
  }
  function createArgsNormalizer(defaultOptions) {
    return function normalizeArgs(instance, opts = {}, stream) {
      if (typeof opts === "string") {
        stream = buildSafeSonicBoom(opts);
        opts = {};
      } else if (typeof stream === "string") {
        stream = buildSafeSonicBoom(stream);
      } else if (opts instanceof SonicBoom || opts.writable || opts._writableState) {
        stream = opts;
        opts = null;
      }
      opts = Object.assign({}, defaultOptions, opts);
      if ("extreme" in opts) {
        throw Error("The extreme option has been removed, use pino.extreme instead");
      }
      if ("onTerminated" in opts) {
        throw Error("The onTerminated option has been removed, use pino.final instead");
      }
      if ("changeLevelName" in opts) {
        process.emitWarning("The changeLevelName option is deprecated and will be removed in v7. Use levelKey instead.", {code: "changeLevelName_deprecation"});
        opts.levelKey = opts.changeLevelName;
        delete opts.changeLevelName;
      }
      const {enabled, prettyPrint, prettifier, messageKey} = opts;
      if (enabled === false)
        opts.level = "silent";
      stream = stream || process.stdout;
      if (stream === process.stdout && stream.fd >= 0 && !hasBeenTampered(stream)) {
        stream = buildSafeSonicBoom(stream.fd);
      }
      if (prettyPrint) {
        const prettyOpts = Object.assign({messageKey}, prettyPrint);
        stream = getPrettyStream(prettyOpts, prettifier, stream, instance);
      }
      return {opts, stream};
    };
  }
  function final(logger, handler) {
    if (typeof logger === "undefined" || typeof logger.child !== "function") {
      throw Error("expected a pino logger instance");
    }
    const hasHandler = typeof handler !== "undefined";
    if (hasHandler && typeof handler !== "function") {
      throw Error("if supplied, the handler parameter should be a function");
    }
    const stream = logger[streamSym];
    if (typeof stream.flushSync !== "function") {
      throw Error("final requires a stream that has a flushSync method, such as pino.destination and pino.extreme");
    }
    const finalLogger = new Proxy(logger, {
      get: (logger2, key) => {
        if (key in logger2.levels.values) {
          return (...args) => {
            logger2[key](...args);
            stream.flushSync();
          };
        }
        return logger2[key];
      }
    });
    if (!hasHandler) {
      return finalLogger;
    }
    return (err = null, ...args) => {
      try {
        stream.flushSync();
      } catch (e) {
      }
      return handler(err, finalLogger, ...args);
    };
  }
  function stringify(obj) {
    try {
      return JSON.stringify(obj);
    } catch (_) {
      return stringifySafe(obj);
    }
  }
  function setMetadataProps(dest, that) {
    if (dest[needsMetadataGsym] === true) {
      dest.lastLevel = that.lastLevel;
      dest.lastMsg = that.lastMsg;
      dest.lastObj = that.lastObj;
      dest.lastTime = that.lastTime;
      dest.lastLogger = that.lastLogger;
    }
  }
  module2.exports = {
    noop,
    buildSafeSonicBoom,
    getPrettyStream,
    asChindings,
    asJson,
    genLog,
    createArgsNormalizer,
    final,
    stringify
  };
});

// node_modules/pino/lib/levels.js
var require_levels = __commonJS((exports2, module2) => {
  "use strict";
  var flatstr = require_flatstr();
  var {
    lsCacheSym,
    levelValSym,
    useLevelLabelsSym,
    levelKeySym,
    useOnlyCustomLevelsSym,
    streamSym
  } = require_symbols();
  var {noop, genLog} = require_tools();
  var levels = {
    trace: 10,
    debug: 20,
    info: 30,
    warn: 40,
    error: 50,
    fatal: 60
  };
  var logFatal = genLog(levels.fatal);
  var levelMethods = {
    fatal(...args) {
      const stream = this[streamSym];
      logFatal.call(this, ...args);
      if (typeof stream.flushSync === "function") {
        try {
          stream.flushSync();
        } catch (e) {
        }
      }
    },
    error: genLog(levels.error),
    warn: genLog(levels.warn),
    info: genLog(levels.info),
    debug: genLog(levels.debug),
    trace: genLog(levels.trace)
  };
  var nums = Object.keys(levels).reduce((o, k) => {
    o[levels[k]] = k;
    return o;
  }, {});
  var initialLsCache = Object.keys(nums).reduce((o, k) => {
    o[k] = flatstr('{"level":' + Number(k));
    return o;
  }, {});
  function genLsCache(instance) {
    const levelName = instance[levelKeySym];
    instance[lsCacheSym] = Object.keys(instance.levels.labels).reduce((o, k) => {
      o[k] = instance[useLevelLabelsSym] ? `{"${levelName}":"${instance.levels.labels[k]}"` : flatstr(`{"${levelName}":` + Number(k));
      return o;
    }, Object.assign({}, instance[lsCacheSym]));
    return instance;
  }
  function isStandardLevel(level, useOnlyCustomLevels) {
    if (useOnlyCustomLevels) {
      return false;
    }
    switch (level) {
      case "fatal":
      case "error":
      case "warn":
      case "info":
      case "debug":
      case "trace":
        return true;
      default:
        return false;
    }
  }
  function setLevel(level) {
    const {labels, values} = this.levels;
    if (typeof level === "number") {
      if (labels[level] === void 0)
        throw Error("unknown level value" + level);
      level = labels[level];
    }
    if (values[level] === void 0)
      throw Error("unknown level " + level);
    const preLevelVal = this[levelValSym];
    const levelVal = this[levelValSym] = values[level];
    const useOnlyCustomLevelsVal = this[useOnlyCustomLevelsSym];
    for (var key in values) {
      if (levelVal > values[key]) {
        this[key] = noop;
        continue;
      }
      this[key] = isStandardLevel(key, useOnlyCustomLevelsVal) ? levelMethods[key] : genLog(values[key]);
    }
    this.emit("level-change", level, levelVal, labels[preLevelVal], preLevelVal);
  }
  function getLevel(level) {
    const {levels: levels2, levelVal} = this;
    return levels2.labels[levelVal];
  }
  function isLevelEnabled(logLevel) {
    const {values} = this.levels;
    const logLevelVal = values[logLevel];
    return logLevelVal !== void 0 && logLevelVal >= this[levelValSym];
  }
  function mappings(customLevels = null, useOnlyCustomLevels = false) {
    const customNums = customLevels ? Object.keys(customLevels).reduce((o, k) => {
      o[customLevels[k]] = k;
      return o;
    }, {}) : null;
    const labels = Object.assign(Object.create(Object.prototype, {Infinity: {value: "silent"}}), useOnlyCustomLevels ? null : nums, customNums);
    const values = Object.assign(Object.create(Object.prototype, {silent: {value: Infinity}}), useOnlyCustomLevels ? null : levels, customLevels);
    return {labels, values};
  }
  function assertDefaultLevelFound(defaultLevel, customLevels, useOnlyCustomLevels) {
    if (typeof defaultLevel === "number") {
      const values = [].concat(Object.keys(customLevels || {}).map((key) => customLevels[key]), useOnlyCustomLevels ? [] : Object.keys(nums).map((level) => +level), Infinity);
      if (!values.includes(defaultLevel)) {
        throw Error(`default level:${defaultLevel} must be included in custom levels`);
      }
      return;
    }
    const labels = Object.assign(Object.create(Object.prototype, {silent: {value: Infinity}}), useOnlyCustomLevels ? null : levels, customLevels);
    if (!(defaultLevel in labels)) {
      throw Error(`default level:${defaultLevel} must be included in custom levels`);
    }
  }
  function assertNoLevelCollisions(levels2, customLevels) {
    const {labels, values} = levels2;
    for (const k in customLevels) {
      if (k in values) {
        throw Error("levels cannot be overridden");
      }
      if (customLevels[k] in labels) {
        throw Error("pre-existing level values cannot be used for new levels");
      }
    }
  }
  module2.exports = {
    initialLsCache,
    genLsCache,
    levelMethods,
    getLevel,
    setLevel,
    isLevelEnabled,
    mappings,
    assertNoLevelCollisions,
    assertDefaultLevelFound
  };
});

// node_modules/pino/package.json
var require_package = __commonJS((exports2, module2) => {
  module2.exports = {
    _args: [
      [
        "pino@5.17.0",
        "/Users/priya.bhojani/projects/customer-vehicle-api"
      ]
    ],
    _from: "pino@5.17.0",
    _id: "pino@5.17.0",
    _inBundle: false,
    _integrity: "sha512-LqrqmRcJz8etUjyV0ddqB6OTUutCgQULPFg2b4dtijRHUsucaAdBgSUW58vY6RFSX+NT8963F+q0tM6lNwGShA==",
    _location: "/pino",
    _phantomChildren: {},
    _requested: {
      type: "version",
      registry: true,
      raw: "pino@5.17.0",
      name: "pino",
      escapedName: "pino",
      rawSpec: "5.17.0",
      saveSpec: null,
      fetchSpec: "5.17.0"
    },
    _requiredBy: [
      "/cazoo-logger"
    ],
    _resolved: "https://registry.npmjs.org/pino/-/pino-5.17.0.tgz",
    _spec: "5.17.0",
    _where: "/Users/priya.bhojani/projects/customer-vehicle-api",
    author: {
      name: "Matteo Collina",
      email: "hello@matteocollina.com"
    },
    bin: {
      pino: "bin.js"
    },
    browser: "./browser.js",
    bugs: {
      url: "https://github.com/pinojs/pino/issues"
    },
    contributors: [
      {
        name: "David Mark Clements",
        email: "huperekchuno@googlemail.com"
      },
      {
        name: "James Sumners",
        email: "james.sumners@gmail.com"
      },
      {
        name: "Thomas Watson Steen",
        email: "w@tson.dk",
        url: "https://twitter.com/wa7son"
      }
    ],
    dependencies: {
      "fast-redact": "^2.0.0",
      "fast-safe-stringify": "^2.0.7",
      flatstr: "^1.0.12",
      "pino-std-serializers": "^2.4.2",
      "quick-format-unescaped": "^3.0.3",
      "sonic-boom": "^0.7.5"
    },
    description: "super fast, all natural json logger",
    devDependencies: {
      airtap: "2.0.2",
      benchmark: "^2.1.4",
      bole: "^3.0.2",
      bunyan: "^1.8.12",
      "cross-env": "^5.2.1",
      "docsify-cli": "^4.2.1",
      execa: "^1.0.0",
      fastbench: "^1.0.1",
      "flush-write-stream": "^2.0.0",
      "import-fresh": "^3.0.0",
      log: "^5.0.0",
      loglevel: "^1.6.4",
      "pino-pretty": "^2.6.1",
      "pre-commit": "^1.2.2",
      proxyquire: "^2.1.3",
      pump: "^3.0.0",
      qodaa: "^1.0.1",
      semver: "^6.3.0",
      snazzy: "^8.0.0",
      split2: "^3.1.1",
      standard: "^14.2.0",
      steed: "^1.1.3",
      tap: "^12.7.0",
      tape: "^4.11.0",
      through2: "^3.0.1",
      winston: "^3.2.1"
    },
    files: [
      "pino.js",
      "bin.js",
      "browser.js",
      "pretty.js",
      "usage.txt",
      "test",
      "docs",
      "example.js",
      "lib"
    ],
    homepage: "http://getpino.io",
    keywords: [
      "fast",
      "logger",
      "stream",
      "json"
    ],
    license: "MIT",
    main: "pino.js",
    name: "pino",
    precommit: "test",
    repository: {
      type: "git",
      url: "git+https://github.com/pinojs/pino.git"
    },
    scripts: {
      bench: "node benchmarks/utils/runbench all",
      "bench-basic": "node benchmarks/utils/runbench basic",
      "bench-child": "node benchmarks/utils/runbench child",
      "bench-child-child": "node benchmarks/utils/runbench child-child",
      "bench-child-creation": "node benchmarks/utils/runbench child-creation",
      "bench-deep-object": "node benchmarks/utils/runbench deep-object",
      "bench-longs-tring": "node benchmarks/utils/runbench long-string",
      "bench-multi-arg": "node benchmarks/utils/runbench multi-arg",
      "bench-object": "node benchmarks/utils/runbench object",
      "browser-test": "airtap --local 8080 test/browser*test.js",
      ci: 'standard | snazzy && cross-env TAP_TIMEOUT=480000 NODE_OPTIONS="--no-warnings -r qodaa" tap --no-esm -j 4 --100 test/*test.js',
      "cov-ci": 'cross-env TAP_TIMEOUT=480000 NODE_OPTIONS="--no-warnings -r qodaa" tap --no-esm -j 4 --100 --coverage-report=lcov test/*test.js',
      "cov-ui": 'cross-env NODE_OPTIONS="--no-warnings -r qodaa" tap --no-esm -j 4 --coverage-report=html test/*test.js',
      docs: "docsify serve",
      test: 'standard | snazzy && cross-env NODE_OPTIONS="--no-warnings -r qodaa" tap --no-esm -j 4 --no-cov test/*test.js',
      "update-bench-doc": "node benchmarks/utils/generate-benchmark-doc > docs/benchmarks.md"
    },
    version: "5.17.0"
  };
});

// node_modules/pino/lib/meta.js
var require_meta = __commonJS((exports2, module2) => {
  "use strict";
  var {version} = require_package();
  var LOG_VERSION = 1;
  module2.exports = {version, LOG_VERSION};
});

// node_modules/pino/lib/proto.js
var require_proto = __commonJS((exports2, module2) => {
  "use strict";
  var {EventEmitter} = require("events");
  var SonicBoom = require_sonic_boom();
  var flatstr = require_flatstr();
  var {
    lsCacheSym,
    levelValSym,
    setLevelSym,
    getLevelSym,
    chindingsSym,
    mixinSym,
    asJsonSym,
    messageKeySym,
    writeSym,
    timeSym,
    timeSliceIndexSym,
    streamSym,
    serializersSym,
    useOnlyCustomLevelsSym,
    needsMetadataGsym
  } = require_symbols();
  var {
    getLevel,
    setLevel,
    isLevelEnabled,
    mappings,
    initialLsCache,
    genLsCache,
    assertNoLevelCollisions
  } = require_levels();
  var {
    asChindings,
    asJson
  } = require_tools();
  var {
    version,
    LOG_VERSION
  } = require_meta();
  var constructor = class Pino {
  };
  var prototype = {
    constructor,
    child,
    bindings,
    setBindings,
    flush,
    isLevelEnabled,
    version,
    get level() {
      return this[getLevelSym]();
    },
    set level(lvl) {
      return this[setLevelSym](lvl);
    },
    get levelVal() {
      return this[levelValSym];
    },
    set levelVal(n) {
      throw Error("levelVal is read-only");
    },
    [lsCacheSym]: initialLsCache,
    [writeSym]: write,
    [asJsonSym]: asJson,
    [getLevelSym]: getLevel,
    [setLevelSym]: setLevel,
    LOG_VERSION
  };
  Object.setPrototypeOf(prototype, EventEmitter.prototype);
  module2.exports = prototype;
  function child(bindings2) {
    const {level} = this;
    const serializers = this[serializersSym];
    const chindings = asChindings(this, bindings2);
    const instance = Object.create(this);
    if (bindings2.hasOwnProperty("serializers") === true) {
      instance[serializersSym] = Object.create(null);
      for (var k in serializers) {
        instance[serializersSym][k] = serializers[k];
      }
      const parentSymbols = Object.getOwnPropertySymbols(serializers);
      for (var i = 0; i < parentSymbols.length; i++) {
        const ks = parentSymbols[i];
        instance[serializersSym][ks] = serializers[ks];
      }
      for (var bk in bindings2.serializers) {
        instance[serializersSym][bk] = bindings2.serializers[bk];
      }
      const bindingsSymbols = Object.getOwnPropertySymbols(bindings2.serializers);
      for (var bi = 0; bi < bindingsSymbols.length; bi++) {
        const bks = bindingsSymbols[bi];
        instance[serializersSym][bks] = bindings2.serializers[bks];
      }
    } else
      instance[serializersSym] = serializers;
    if (bindings2.hasOwnProperty("customLevels") === true) {
      assertNoLevelCollisions(this.levels, bindings2.customLevels);
      instance.levels = mappings(bindings2.customLevels, instance[useOnlyCustomLevelsSym]);
      genLsCache(instance);
    }
    instance[chindingsSym] = chindings;
    const childLevel = bindings2.level || level;
    instance[setLevelSym](childLevel);
    return instance;
  }
  function bindings() {
    const chindings = this[chindingsSym];
    var chindingsJson = `{${chindings.substr(1)}}`;
    var bindingsFromJson = JSON.parse(chindingsJson);
    delete bindingsFromJson.pid;
    delete bindingsFromJson.hostname;
    return bindingsFromJson;
  }
  function setBindings(newBindings) {
    const chindings = asChindings(this, newBindings);
    this[chindingsSym] = chindings;
  }
  function write(_obj, msg, num) {
    const t = this[timeSym]();
    const messageKey = this[messageKeySym];
    const mixin = this[mixinSym];
    const objError = _obj instanceof Error;
    var obj;
    if (_obj === void 0 || _obj === null) {
      obj = mixin ? mixin() : {};
      obj[messageKey] = msg;
    } else {
      obj = Object.assign(mixin ? mixin() : {}, _obj);
      if (msg) {
        obj[messageKey] = msg;
      } else if (objError) {
        obj[messageKey] = _obj.message;
      }
      if (objError) {
        obj.stack = _obj.stack;
        if (!obj.type) {
          obj.type = "Error";
        }
      }
    }
    const s = this[asJsonSym](obj, num, t);
    const stream = this[streamSym];
    if (stream[needsMetadataGsym] === true) {
      stream.lastLevel = num;
      stream.lastMsg = msg;
      stream.lastObj = obj;
      stream.lastTime = t.slice(this[timeSliceIndexSym]);
      stream.lastLogger = this;
    }
    if (stream instanceof SonicBoom)
      stream.write(s);
    else
      stream.write(flatstr(s));
  }
  function flush() {
    const stream = this[streamSym];
    if ("flush" in stream)
      stream.flush();
  }
});

// node_modules/pino/pino.js
var require_pino = __commonJS((exports2, module2) => {
  "use strict";
  var os = require("os");
  var stdSerializers = require_pino_std_serializers();
  var redaction = require_redaction();
  var time = require_time();
  var proto = require_proto();
  var symbols = require_symbols();
  var {assertDefaultLevelFound, mappings, genLsCache} = require_levels();
  var {
    createArgsNormalizer,
    asChindings,
    final,
    stringify,
    buildSafeSonicBoom
  } = require_tools();
  var {version, LOG_VERSION} = require_meta();
  var {
    chindingsSym,
    redactFmtSym,
    serializersSym,
    timeSym,
    timeSliceIndexSym,
    streamSym,
    stringifySym,
    stringifiersSym,
    setLevelSym,
    endSym,
    formatOptsSym,
    messageKeySym,
    nestedKeySym,
    useLevelLabelsSym,
    levelKeySym,
    mixinSym,
    useOnlyCustomLevelsSym
  } = symbols;
  var {epochTime, nullTime} = time;
  var {pid} = process;
  var hostname = os.hostname();
  var defaultErrorSerializer = stdSerializers.err;
  var defaultOptions = {
    level: "info",
    useLevelLabels: false,
    messageKey: "msg",
    nestedKey: null,
    enabled: true,
    prettyPrint: false,
    base: {pid, hostname},
    serializers: Object.assign(Object.create(null), {
      err: defaultErrorSerializer
    }),
    timestamp: epochTime,
    name: void 0,
    redact: null,
    customLevels: null,
    levelKey: "level",
    useOnlyCustomLevels: false
  };
  var normalize = createArgsNormalizer(defaultOptions);
  var serializers = Object.assign(Object.create(null), stdSerializers);
  function pino(...args) {
    const instance = {};
    const {opts, stream} = normalize(instance, ...args);
    const {
      redact,
      crlf,
      serializers: serializers2,
      timestamp,
      messageKey,
      nestedKey,
      base,
      name,
      level,
      customLevels,
      useLevelLabels,
      levelKey,
      mixin,
      useOnlyCustomLevels
    } = opts;
    const stringifiers = redact ? redaction(redact, stringify) : {};
    const formatOpts = redact ? {stringify: stringifiers[redactFmtSym]} : {stringify};
    const end = ',"v":' + LOG_VERSION + "}" + (crlf ? "\r\n" : "\n");
    const coreChindings = asChindings.bind(null, {
      [chindingsSym]: "",
      [serializersSym]: serializers2,
      [stringifiersSym]: stringifiers,
      [stringifySym]: stringify
    });
    const chindings = base === null ? "" : name === void 0 ? coreChindings(base) : coreChindings(Object.assign({}, base, {name}));
    const time2 = timestamp instanceof Function ? timestamp : timestamp ? epochTime : nullTime;
    const timeSliceIndex = time2().indexOf(":") + 1;
    if (useOnlyCustomLevels && !customLevels)
      throw Error("customLevels is required if useOnlyCustomLevels is set true");
    if (mixin && typeof mixin !== "function")
      throw Error(`Unknown mixin type "${typeof mixin}" - expected "function"`);
    assertDefaultLevelFound(level, customLevels, useOnlyCustomLevels);
    const levels = mappings(customLevels, useOnlyCustomLevels);
    Object.assign(instance, {
      levels,
      [useLevelLabelsSym]: useLevelLabels,
      [levelKeySym]: levelKey,
      [useOnlyCustomLevelsSym]: useOnlyCustomLevels,
      [streamSym]: stream,
      [timeSym]: time2,
      [timeSliceIndexSym]: timeSliceIndex,
      [stringifySym]: stringify,
      [stringifiersSym]: stringifiers,
      [endSym]: end,
      [formatOptsSym]: formatOpts,
      [messageKeySym]: messageKey,
      [nestedKeySym]: nestedKey,
      [serializersSym]: serializers2,
      [mixinSym]: mixin,
      [chindingsSym]: chindings
    });
    Object.setPrototypeOf(instance, proto);
    if (customLevels || useLevelLabels || levelKey !== defaultOptions.levelKey)
      genLsCache(instance);
    instance[setLevelSym](level);
    return instance;
  }
  pino.extreme = (dest = process.stdout.fd) => buildSafeSonicBoom(dest, 4096, false);
  pino.destination = (dest = process.stdout.fd) => buildSafeSonicBoom(dest, 0, true);
  pino.final = final;
  pino.levels = mappings();
  pino.stdSerializers = serializers;
  pino.stdTimeFunctions = Object.assign({}, time);
  pino.symbols = symbols;
  pino.version = version;
  pino.LOG_VERSION = LOG_VERSION;
  module2.exports = pino;
});

// node_modules/cazoo-logger/dist/pino/parentPinoLogger.js
var require_parentPinoLogger = __commonJS((exports2) => {
  "use strict";
  var __importDefault = exports2 && exports2.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {default: mod};
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  var pino_1 = __importDefault(require_pino());
  function parentPinoLogger(data, options) {
    const level = options && options.level || process.env.CAZOO_LOGGER_LEVEL || "info";
    if (options && options.stream) {
      return pino_1.default({
        timestamp: false,
        base: data,
        useLevelLabels: true,
        level
      }, options.stream);
    }
    return pino_1.default({
      timestamp: false,
      base: data,
      useLevelLabels: true,
      level,
      redact: options && options.redact
    });
  }
  exports2.parentPinoLogger = parentPinoLogger;
});

// node_modules/cazoo-logger/dist/shared/errors.js
var require_errors2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  function makeErrorRecord(error, msg) {
    let errorObj;
    if (error instanceof Error) {
      errorObj = error;
    } else if (error instanceof Object) {
      errorObj = {
        message: JSON.stringify(error),
        stack: void 0,
        name: typeof error
      };
    } else {
      errorObj = {
        message: error.toString(),
        stack: void 0,
        name: typeof error
      };
    }
    return {
      msg: msg || errorObj.message,
      error: {
        message: errorObj.message,
        stack: errorObj.stack,
        name: errorObj.name
      }
    };
  }
  function recordError(e, msg) {
    this.error(makeErrorRecord(e, msg));
  }
  exports2.recordError = recordError;
  function recordErrorAsWarning(e, msg) {
    this.warn(makeErrorRecord(e, msg));
  }
  exports2.recordErrorAsWarning = recordErrorAsWarning;
});

// node_modules/cazoo-logger/dist/pino/combineWithBoundContext.js
var require_combineWithBoundContext = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  function combineWithBoundContext(logger, data) {
    const bindings = logger.bindings();
    const context = bindings.context;
    const mergedContext = Object.assign(Object.assign({}, context), data);
    return mergedContext;
  }
  exports2.combineWithBoundContext = combineWithBoundContext;
});

// node_modules/cazoo-logger/dist/shared/makeHttpResponseContext.js
var require_makeHttpResponseContext = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  function makeHttpResponseContext(req, status, body, elapsedMs) {
    return {
      data: {
        http: {
          req: {
            id: req && req.id
          },
          resp: {
            status,
            body,
            elapsedMs
          }
        }
      }
    };
  }
  exports2.makeHttpResponseContext = makeHttpResponseContext;
});

// node_modules/cazoo-logger/dist/pino/getRequestFromBindings.js
var require_getRequestFromBindings = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  function getRequestFromBindings(logger) {
    const bindings = logger.bindings();
    return bindings && bindings.data && bindings.data.http && bindings.data.http.req;
  }
  exports2.getRequestFromBindings = getRequestFromBindings;
});

// node_modules/cazoo-logger/node_modules/uuid/lib/rng.js
var require_rng = __commonJS((exports2, module2) => {
  var crypto = require("crypto");
  module2.exports = function nodeRNG() {
    return crypto.randomBytes(16);
  };
});

// node_modules/cazoo-logger/node_modules/uuid/lib/bytesToUuid.js
var require_bytesToUuid = __commonJS((exports2, module2) => {
  var byteToHex = [];
  for (var i = 0; i < 256; ++i) {
    byteToHex[i] = (i + 256).toString(16).substr(1);
  }
  function bytesToUuid(buf, offset) {
    var i2 = offset || 0;
    var bth = byteToHex;
    return [
      bth[buf[i2++]],
      bth[buf[i2++]],
      bth[buf[i2++]],
      bth[buf[i2++]],
      "-",
      bth[buf[i2++]],
      bth[buf[i2++]],
      "-",
      bth[buf[i2++]],
      bth[buf[i2++]],
      "-",
      bth[buf[i2++]],
      bth[buf[i2++]],
      "-",
      bth[buf[i2++]],
      bth[buf[i2++]],
      bth[buf[i2++]],
      bth[buf[i2++]],
      bth[buf[i2++]],
      bth[buf[i2++]]
    ].join("");
  }
  module2.exports = bytesToUuid;
});

// node_modules/cazoo-logger/node_modules/uuid/v4.js
var require_v4 = __commonJS((exports2, module2) => {
  var rng = require_rng();
  var bytesToUuid = require_bytesToUuid();
  function v4(options, buf, offset) {
    var i = buf && offset || 0;
    if (typeof options == "string") {
      buf = options === "binary" ? new Array(16) : null;
      options = null;
    }
    options = options || {};
    var rnds = options.random || (options.rng || rng)();
    rnds[6] = rnds[6] & 15 | 64;
    rnds[8] = rnds[8] & 63 | 128;
    if (buf) {
      for (var ii = 0; ii < 16; ++ii) {
        buf[i + ii] = rnds[ii];
      }
    }
    return buf || bytesToUuid(rnds);
  }
  module2.exports = v4;
});

// node_modules/cazoo-logger/dist/shared/makeHttpRequestContext.js
var require_makeHttpRequestContext = __commonJS((exports2) => {
  "use strict";
  var __importDefault = exports2 && exports2.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {default: mod};
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  var v4_1 = __importDefault(require_v4());
  function makeHttpRequestContext(url, method, body) {
    const requestId = v4_1.default();
    const context = {
      data: {
        http: {
          req: {
            id: requestId,
            url,
            method,
            body
          }
        }
      }
    };
    return context;
  }
  exports2.makeHttpRequestContext = makeHttpRequestContext;
});

// node_modules/cazoo-logger/dist/shared/context.js
var require_context = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  function parseAccountId(arn) {
    if (!arn) {
      return "missing";
    }
    const parts = arn.split(":");
    if (parts.length >= 5) {
      return parts[4];
    }
    return `unknown (${arn})`;
  }
  function has(obj, ...props) {
    for (const p of props) {
      if (!obj.hasOwnProperty(p)) {
        return false;
      }
    }
    return true;
  }
  exports2.has = has;
  function makeContext(ctx, options, extra) {
    return Object.assign({
      request_id: ctx.awsRequestId,
      account_id: parseAccountId(ctx.invokedFunctionArn),
      function: {
        name: ctx.functionName,
        version: ctx.functionVersion,
        service: options && options.service || process.env.CAZOO_LOGGER_SERVICE || ctx.logStreamName
      }
    }, extra);
  }
  exports2.makeContext = makeContext;
});

// node_modules/cazoo-logger/dist/events/domainEvent.js
var require_domainEvent = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var context_1 = require_context();
  function isDomainEvent(event) {
    return context_1.has(event, "detail", "detail-type", "source", "id");
  }
  exports2.isDomainEvent = isDomainEvent;
  function makeDomainEventContext(context, options, event) {
    return context_1.makeContext(context, options, {
      event: {
        source: event.source,
        type: event["detail-type"],
        id: event.id
      }
    });
  }
  exports2.makeDomainEventContext = makeDomainEventContext;
});

// node_modules/cazoo-logger/dist/events/apiGateway.js
var require_apiGateway = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var context_1 = require_context();
  var context_2 = require_context();
  function isApiGatewayEvent(event) {
    return context_2.has(event, "requestContext");
  }
  exports2.isApiGatewayEvent = isApiGatewayEvent;
  function makeApiGatewayContext(context, options, event) {
    return context_1.makeContext(context, options, {
      http: {
        path: event.path,
        connectionId: event.requestContext.connectionId,
        method: event.httpMethod,
        stage: event.requestContext.stage,
        routeKey: event.requestContext.routeKey,
        query: event.multiValueQueryStringParameters
      }
    });
  }
  exports2.makeApiGatewayContext = makeApiGatewayContext;
});

// node_modules/cazoo-logger/dist/events/sqsRecord.js
var require_sqsRecord = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var context_1 = require_context();
  var context_2 = require_context();
  function isSQSRecord(record) {
    return context_1.has(record, "eventSourceARN", "messageId");
  }
  exports2.isSQSRecord = isSQSRecord;
  function makeSQSRecordContext(context, options, record) {
    return context_2.makeContext(context, options, {
      sqs: {
        source: record.eventSourceARN,
        id: record.messageId
      }
    });
  }
  exports2.makeSQSRecordContext = makeSQSRecordContext;
});

// node_modules/cazoo-logger/dist/events/cloudFront.js
var require_cloudFront = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var context_1 = require_context();
  function convert(config) {
    if (config.eventType === "viewer-request" || config.eventType === "viewer-response") {
      return config;
    }
    return void 0;
  }
  function getRequestId(event) {
    const config = event.config;
    const converted = convert(config);
    if (converted) {
      return converted.requestId;
    }
    return void 0;
  }
  function isCloudFrontRequest(request) {
    return !(!Array.isArray(request.Records) || request.Records[0].cf === void 0);
  }
  exports2.isCloudFrontRequest = isCloudFrontRequest;
  function makeCloudFrontContext(request, context, options) {
    const cf = request.Records[0].cf;
    const requestId = getRequestId(cf);
    const ctx = context_1.makeContext(context, options, {
      cf: {
        path: cf.request.uri,
        method: cf.request.method,
        dist: cf.config.distributionId,
        type: cf.config.eventType,
        id: requestId
      }
    });
    return ctx;
  }
  exports2.makeCloudFrontContext = makeCloudFrontContext;
});

// node_modules/cazoo-logger/dist/events/sns.js
var require_sns = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var context_1 = require_context();
  function s3For(event) {
    const msg = JSON.parse(event.Records[0].Sns.Message);
    const s3 = msg.Records[0].s3;
    return s3;
  }
  function isSNS(event) {
    if (!event.Records)
      return false;
    return event.Records[0].EventSource === "aws:sns";
  }
  exports2.isSNS = isSNS;
  function makeSNSContext(context, options, event) {
    const ctx = context_1.makeContext(context, options, {
      event: {
        id: event.Records[0].Sns.MessageId,
        source: event.Records[0].Sns.TopicArn
      }
    });
    if (event.Records[0].Sns.Subject === "Amazon S3 Notification") {
      ctx.s3 = {
        bucket: s3For(event).bucket.name,
        key: s3For(event).object.key
      };
    }
    return ctx;
  }
  exports2.makeSNSContext = makeSNSContext;
});

// node_modules/cazoo-logger/dist/events/dynamoDbStream.js
var require_dynamoDbStream = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var context_1 = require_context();
  function isDynamoDbStream(event) {
    if (!event.Records)
      return false;
    return event.Records[0].eventSource === "aws:dynamodb";
  }
  exports2.isDynamoDbStream = isDynamoDbStream;
  function makeDynamoDbContext(event, context, options) {
    const record = event.Records[0];
    const ctx = context_1.makeContext(context, options, {
      event: {
        id: record.eventID,
        source: record.eventSourceARN,
        type: record.eventName
      }
    });
    return ctx;
  }
  exports2.makeDynamoDbContext = makeDynamoDbContext;
});

// node_modules/cazoo-logger/dist/index.js
var require_dist = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var parentPinoLogger_1 = require_parentPinoLogger();
  var errors_1 = require_errors2();
  var combineWithBoundContext_1 = require_combineWithBoundContext();
  var makeHttpResponseContext_1 = require_makeHttpResponseContext();
  var getRequestFromBindings_1 = require_getRequestFromBindings();
  var makeHttpRequestContext_1 = require_makeHttpRequestContext();
  var domainEvent_1 = require_domainEvent();
  var apiGateway_1 = require_apiGateway();
  var sqsRecord_1 = require_sqsRecord();
  var cloudFront_1 = require_cloudFront();
  var sns_1 = require_sns();
  var dynamoDbStream_1 = require_dynamoDbStream();
  function makeLogger(data, parent, options) {
    let instance;
    if (parent === void 0) {
      instance = parentPinoLogger_1.parentPinoLogger(data, options);
    } else {
      instance = parent.child(data);
    }
    Object.assign(instance, {
      withData,
      withContext,
      withHttpRequest,
      withHttpResponse,
      recordErrorAsWarning: errors_1.recordErrorAsWarning,
      recordError: errors_1.recordError
    });
    return instance;
  }
  function withData(data) {
    return makeLogger({data}, this);
  }
  function withContext(data) {
    const mergedContext = combineWithBoundContext_1.combineWithBoundContext(this, data);
    return makeLogger({context: mergedContext}, this);
  }
  function withHttpResponse({status, body, elapsedMs}) {
    const responseContext = makeHttpResponseContext_1.makeHttpResponseContext(getRequestFromBindings_1.getRequestFromBindings(this), status, body, elapsedMs);
    return makeLogger(responseContext, this);
  }
  function withHttpRequest({url, method, body}) {
    const requestContext = makeHttpRequestContext_1.makeHttpRequestContext(url, method, body);
    return makeLogger(requestContext, this);
  }
  function forDomainEvent(event, context, options) {
    if (domainEvent_1.isDomainEvent(event)) {
      return makeLogger({
        context: domainEvent_1.makeDomainEventContext(context, options, event)
      }, void 0, options);
    }
  }
  exports2.forDomainEvent = forDomainEvent;
  function forAPIGatewayEvent(event, context, options) {
    if (apiGateway_1.isApiGatewayEvent(event)) {
      return makeLogger({
        context: apiGateway_1.makeApiGatewayContext(context, options, event)
      }, void 0, options);
    }
  }
  exports2.forAPIGatewayEvent = forAPIGatewayEvent;
  function forSQSRecord(record, context, options) {
    if (sqsRecord_1.isSQSRecord(record)) {
      return makeLogger({
        context: sqsRecord_1.makeSQSRecordContext(context, options, record)
      }, void 0, options);
    }
  }
  exports2.forSQSRecord = forSQSRecord;
  function forCloudFrontRequest(request, context, options) {
    if (cloudFront_1.isCloudFrontRequest(request)) {
      return makeLogger({
        context: cloudFront_1.makeCloudFrontContext(request, context, options)
      }, void 0, options);
    }
  }
  exports2.forCloudFrontRequest = forCloudFrontRequest;
  function forSNS(event, context, options) {
    if (sns_1.isSNS(event)) {
      return makeLogger({
        context: sns_1.makeSNSContext(context, options, event)
      }, void 0, options);
    }
  }
  exports2.forSNS = forSNS;
  function forDynamoDBStream(event, context, options) {
    if (dynamoDbStream_1.isDynamoDbStream(event)) {
      return makeLogger({
        context: dynamoDbStream_1.makeDynamoDbContext(event, context, options)
      }, void 0, options);
    }
  }
  exports2.forDynamoDBStream = forDynamoDBStream;
  function empty(options) {
    return makeLogger({}, void 0, options);
  }
  exports2.empty = empty;
  function fromContext(event, context, options) {
    try {
      return forDomainEvent(event, context, options) || forAPIGatewayEvent(event, context, options) || forSNS(event, context, options) || forSQSRecord(event, context, options) || forCloudFrontRequest(event, context, options) || forDynamoDBStream(event, context, options) || empty(options);
    } catch (error) {
      const logger = empty();
      logger.recordError(error);
      return logger;
    }
  }
  exports2.fromContext = fromContext;
});

// node_modules/@cazoo-uk/middy/dist/middlewares/cazooPrincipalAuthoriser.js
var require_cazooPrincipalAuthoriser = __commonJS((exports2) => {
  "use strict";
  var __importDefault = exports2 && exports2.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {default: mod};
  };
  var __importStar = exports2 && exports2.__importStar || function(mod) {
    if (mod && mod.__esModule)
      return mod;
    var result = {};
    if (mod != null) {
      for (var k in mod)
        if (Object.hasOwnProperty.call(mod, k))
          result[k] = mod[k];
    }
    result["default"] = mod;
    return result;
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  var http_errors_1 = __importDefault(require_http_errors());
  var Logger = __importStar(require_dist());
  var SERVERLESS_OFFLINE_PRINCIPAL_ID = "offlineContext_authorizer_principalId";
  var getEventLoggerWithFallback = (event, context) => event.cazooContext.logger || Logger.fromContext(event, context);
  var getUserContextLogger = ({userId, principalId}, parentLogger) => parentLogger.withContext({user: {userId, principalId}});
  var throwIfPrincipalDisallowed = (allowedPrincipals, authorizer, logger) => {
    var _a;
    const isRunningOffline = ((_a = authorizer) === null || _a === void 0 ? void 0 : _a.principalId) === SERVERLESS_OFFLINE_PRINCIPAL_ID;
    if (isRunningOffline) {
      return;
    }
    if (!authorizer) {
      logger.fatal("Misconfigured Endpoint. Endpoint is not protected by a Lambda Authorizer");
      throw new http_errors_1.default.InternalServerError();
    }
    const contextLogger = getUserContextLogger(authorizer, logger);
    if (!authorizer.authorized) {
      contextLogger.error("Unauthorized request received");
      throw new http_errors_1.default.Unauthorized();
    }
    const isAuthorizedPrincipal = !!allowedPrincipals.find((p) => p === authorizer.principalId);
    if (!isAuthorizedPrincipal) {
      contextLogger.error("Request received with unauthorized principal");
      throw new http_errors_1.default.Forbidden();
    }
    contextLogger.info("Authorised request received");
  };
  exports2.cazooPrincipalAuthoriser = ({allowedPrincipals = ["employee"], emitLogOnSuccess = true}) => ({
    before: ({event, context}, next) => {
      const {requestContext} = event;
      let logger = getEventLoggerWithFallback(event, context);
      const {authorizer} = requestContext;
      throwIfPrincipalDisallowed(allowedPrincipals, requestContext.authorizer, logger);
      const shouldEmitSuccessLog = emitLogOnSuccess === true;
      if (shouldEmitSuccessLog) {
        getUserContextLogger(authorizer, logger).info("Authorised request received");
      }
      next();
    }
  });
  exports2.employeeOnlyAuthoriser = ({emitLogOnSuccess} = {emitLogOnSuccess: true}) => exports2.cazooPrincipalAuthoriser({allowedPrincipals: ["employee"], emitLogOnSuccess});
  exports2.customerOnlyAuthoriser = ({emitLogOnSuccess} = {emitLogOnSuccess: true}) => exports2.cazooPrincipalAuthoriser({allowedPrincipals: ["customer"], emitLogOnSuccess});
});

// node_modules/@cazoo-uk/middy/dist/types/errors.js
var require_errors3 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var FieldError3 = class extends Error {
    constructor(field, message) {
      super("Field Error");
      this.field = field;
      this.description = message;
    }
  };
  exports2.FieldError = FieldError3;
  var InvalidStateError = class extends Error {
    constructor(description) {
      super("Invalid State Error");
      this.description = description;
    }
  };
  exports2.InvalidStateError = InvalidStateError;
  var ValidationError4 = class extends Error {
    constructor(fieldErrors) {
      super("Validation Error");
      this.errors = [];
      this.errors.push(...fieldErrors);
    }
  };
  exports2.ValidationError = ValidationError4;
  var NotFoundError2 = class extends Error {
    constructor(field, description = "Item not found") {
      super("Not found");
      this.field = field;
      this.description = description;
    }
  };
  exports2.NotFoundError = NotFoundError2;
  var GoneError = class extends Error {
    constructor(description) {
      super("Gone");
      this.description = description;
    }
  };
  exports2.GoneError = GoneError;
  var ConflictError2 = class extends Error {
    constructor(description) {
      super("Conflict");
      this.description = description;
    }
  };
  exports2.ConflictError = ConflictError2;
  var BadGatewayError6 = class extends Error {
    constructor(description) {
      super("Bad Gateway");
      this.description = description;
    }
  };
  exports2.BadGatewayError = BadGatewayError6;
  var ConfigurationError3 = class extends Error {
    constructor(description) {
      super("Configuration Error");
      this.description = description;
    }
  };
  exports2.ConfigurationError = ConfigurationError3;
});

// node_modules/@cazoo-uk/middy/dist/types/index.js
var require_types = __commonJS((exports2) => {
  "use strict";
  function __export2(m) {
    for (var p in m)
      if (!exports2.hasOwnProperty(p))
        exports2[p] = m[p];
  }
  Object.defineProperty(exports2, "__esModule", {value: true});
  __export2(require_errors3());
});

// node_modules/@cazoo-uk/middy/dist/util/mapErrorToApiResponse.js
var require_mapErrorToApiResponse = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var http_errors_1 = require_http_errors();
  var types_1 = require_types();
  var constants_1 = require_constants();
  function mapErrorToApiResponse(error) {
    let body = Object.assign(Object.assign({}, error), {stack: void 0});
    let status;
    if (error instanceof types_1.ValidationError) {
      status = 400;
    } else if (error instanceof types_1.FieldError) {
      status = 400;
      body = new types_1.ValidationError([error]);
    } else if (error instanceof types_1.NotFoundError) {
      status = 404;
    } else if (error instanceof types_1.ConflictError) {
      status = 409;
    } else if (error instanceof types_1.GoneError) {
      status = 410;
    } else if (error instanceof types_1.ConfigurationError) {
      status = 500;
    } else if (error instanceof types_1.BadGatewayError) {
      status = 502;
    } else {
      if (error instanceof http_errors_1.HttpError) {
        status = error.statusCode;
      } else {
        status = 500;
        body = {message: constants_1.UNKNOWN_ERROR};
      }
    }
    return {
      statusCode: status,
      body: JSON.stringify(body)
    };
  }
  exports2.mapErrorToApiResponse = mapErrorToApiResponse;
  exports2.default = mapErrorToApiResponse;
});

// node_modules/@cazoo-uk/middy/dist/util/getFieldMasker.js
var require_getFieldMasker = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var secretMask2 = "xxx";
  var depthMask2 = "[Object object]";
  var isObject2 = (obj) => typeof obj === "object";
  function getFieldMasker(sensitiveFields = [], depthLimit = 8) {
    const depthLimitReached = (depth) => depth > depthLimit;
    if (!sensitiveFields || sensitiveFields.length === 0)
      return (src) => src;
    return function filterSecrets(src, dst = {}, depth = 0) {
      if (!isObject2(src))
        return src;
      if (depthLimitReached(depth))
        return depthMask2;
      if (Array.isArray(src))
        return src.map((arrayItem) => filterSecrets(arrayItem, {}, depth + 1));
      for (const prop in src) {
        if (!src.hasOwnProperty(prop))
          continue;
        const srcVal = src[prop];
        if (sensitiveFields.includes(prop)) {
          dst[prop] = secretMask2;
          continue;
        }
        if (Array.isArray(srcVal)) {
          dst[prop] = depthLimitReached(depth + 1) ? depthMask2 : srcVal.map((arrayItem) => filterSecrets(arrayItem, {}, depth + 1));
          continue;
        }
        if (isObject2(srcVal)) {
          if (depthLimitReached(depth + 1)) {
            dst[prop] = depthMask2;
            continue;
          }
          dst[prop] = {};
          filterSecrets(srcVal, dst[prop], depth + 1);
          continue;
        }
        dst[prop] = srcVal;
      }
      return dst;
    };
  }
  exports2.getFieldMasker = getFieldMasker;
  exports2.default = getFieldMasker;
});

// node_modules/@cazoo-uk/middy/dist/util/getEventContextLogger.js
var require_getEventContextLogger = __commonJS((exports2) => {
  "use strict";
  var __importStar = exports2 && exports2.__importStar || function(mod) {
    if (mod && mod.__esModule)
      return mod;
    var result = {};
    if (mod != null) {
      for (var k in mod)
        if (Object.hasOwnProperty.call(mod, k))
          result[k] = mod[k];
    }
    result["default"] = mod;
    return result;
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  var Logger = __importStar(require_dist());
  var getFieldMasker_1 = require_getFieldMasker();
  var logMethods = [
    "info",
    "error",
    "debug",
    "fatal",
    "warn",
    "trace",
    "recordError"
  ];
  var withMethods = [
    "withData",
    "withContext",
    "withHttpRequest",
    "withHttpResponse"
  ];
  var _maskSensitiveFnArgs = (fieldMasker2, args) => args.map((arg) => typeof arg === "object" ? fieldMasker2(arg) : arg);
  var _getMaskedLogger = (target, fieldMasker2) => new Proxy(target, {
    get: (_, propKey) => {
      if (typeof target[propKey] !== "function")
        return target[propKey];
      const origFn = target[propKey];
      if (logMethods.includes(propKey)) {
        return (...args) => origFn.apply(target, _maskSensitiveFnArgs(fieldMasker2, args));
      }
      if (withMethods.includes(propKey)) {
        return (...args) => {
          const childLogger = origFn.apply(target, _maskSensitiveFnArgs(fieldMasker2, args));
          return _getMaskedLogger(childLogger, fieldMasker2);
        };
      }
      return origFn;
    }
  });
  exports2.getEventContextLogger = (event, context, sensitiveFields = [], loggerOptions = {}) => {
    const fieldMasker2 = getFieldMasker_1.getFieldMasker(sensitiveFields);
    const logger = Logger.fromContext(fieldMasker2(event), context, loggerOptions);
    return _getMaskedLogger(logger, fieldMasker2);
  };
});

// node_modules/@cazoo-uk/middy/dist/middlewares/errorHandler.js
var require_errorHandler = __commonJS((exports2) => {
  "use strict";
  var __importDefault = exports2 && exports2.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {default: mod};
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  var types_1 = require_types();
  var mapErrorToApiResponse_1 = __importDefault(require_mapErrorToApiResponse());
  var getEventContextLogger_1 = require_getEventContextLogger();
  exports2.errorHandler = () => {
    const detailToFieldError = ({dataPath = "", message = ""}) => {
      const s = dataPath.split(".");
      return new types_1.FieldError(s[s.length - 1], message);
    };
    return {
      onError: (handler) => {
        const {event, context} = handler;
        const logger = event && event.cazooContext && event.cazooContext.logger || getEventContextLogger_1.getEventContextLogger(event, context);
        let error = handler.error;
        if (error.name === "BadRequestError") {
          const details = error.details;
          if (Array.isArray(details)) {
            error = new types_1.ValidationError(details.map(detailToFieldError));
          }
        }
        logger.recordError(error);
        handler.response = mapErrorToApiResponse_1.default(error);
        return Promise.resolve();
      }
    };
  };
});

// node_modules/@cazoo-uk/middy/dist/middlewares/fieldMasker.js
var require_fieldMasker = __commonJS((exports2) => {
  "use strict";
  var __importDefault = exports2 && exports2.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {default: mod};
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  var getFieldMasker_1 = __importDefault(require_getFieldMasker());
  exports2.fieldMasker = ({sensitiveFields = []}) => ({
    before: (handler, next) => {
      const {event} = handler;
      if (!event.cazooContext)
        event.cazooContext = {};
      event.cazooContext.fieldMasker = getFieldMasker_1.default(sensitiveFields);
      next();
    }
  });
});

// node_modules/@cazoo-uk/middy/dist/middlewares/jsonResponder.js
var require_jsonResponder = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.jsonResponder = ({statusCode = 200, resultBody = true, defaultHeaders = {}}) => ({
    after: (handler, next) => {
      const {response} = handler;
      const headers = Object.assign({"Content-Type": "application/json"}, defaultHeaders);
      if (response) {
        handler.response = {
          statusCode,
          headers: Object.assign(Object.assign({}, headers), response.headers),
          body: resultBody ? JSON.stringify(Object.assign(Object.assign({}, response), {headers: void 0})) : ""
        };
      } else {
        handler.response = {statusCode, headers, body: ""};
      }
      next();
    }
  });
});

// node_modules/@cazoo-uk/middy/dist/util/index.js
var require_util2 = __commonJS((exports2) => {
  "use strict";
  function __export2(m) {
    for (var p in m)
      if (!exports2.hasOwnProperty(p))
        exports2[p] = m[p];
  }
  Object.defineProperty(exports2, "__esModule", {value: true});
  __export2(require_getEventContextLogger());
  __export2(require_getFieldMasker());
  __export2(require_mapErrorToApiResponse());
});

// node_modules/@cazoo-uk/middy/dist/middlewares/maskedLogger.js
var require_maskedLogger = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var util_1 = require_util2();
  exports2.maskedLogger = ({sensitiveFields = [], loggerOptions = {}}) => ({
    before: (handler, next) => {
      const {event, context} = handler;
      if (!event.cazooContext)
        event.cazooContext = {};
      event.cazooContext.logger = util_1.getEventContextLogger(event, context, sensitiveFields, loggerOptions);
      next();
    }
  });
});

// node_modules/@cazoo-uk/middy/dist/middlewares/index.js
var require_middlewares = __commonJS((exports2) => {
  "use strict";
  function __export2(m) {
    for (var p in m)
      if (!exports2.hasOwnProperty(p))
        exports2[p] = m[p];
  }
  Object.defineProperty(exports2, "__esModule", {value: true});
  __export2(require_cazooPrincipalAuthoriser());
  __export2(require_errorHandler());
  __export2(require_fieldMasker());
  __export2(require_jsonResponder());
  __export2(require_maskedLogger());
});

// node_modules/@cazoo-uk/middy/dist/index.js
var require_dist2 = __commonJS((exports2) => {
  "use strict";
  function __export2(m) {
    for (var p in m)
      if (!exports2.hasOwnProperty(p))
        exports2[p] = m[p];
  }
  Object.defineProperty(exports2, "__esModule", {value: true});
  __export2(require_constants());
  __export2(require_middlewares());
  __export2(require_types());
  __export2(require_util2());
});

// node_modules/@opentelemetry/core/build/src/common/attributes.js
var require_attributes = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.isAttributeValue = exports2.sanitizeAttributes = void 0;
  function sanitizeAttributes(attributes) {
    const out = {};
    if (attributes == null || typeof attributes !== "object") {
      return out;
    }
    for (const [k, v] of Object.entries(attributes)) {
      if (isAttributeValue(v)) {
        if (Array.isArray(v)) {
          out[k] = v.slice();
        } else {
          out[k] = v;
        }
      }
    }
    return out;
  }
  exports2.sanitizeAttributes = sanitizeAttributes;
  function isAttributeValue(val) {
    if (val == null) {
      return true;
    }
    if (Array.isArray(val)) {
      return isHomogeneousAttributeValueArray(val);
    }
    return isValidPrimitiveAttributeValue(val);
  }
  exports2.isAttributeValue = isAttributeValue;
  function isHomogeneousAttributeValueArray(arr) {
    let type;
    for (const element of arr) {
      if (element == null)
        continue;
      if (!type) {
        if (isValidPrimitiveAttributeValue(element)) {
          type = typeof element;
          continue;
        }
        return false;
      }
      if (typeof element === type) {
        continue;
      }
      return false;
    }
    return true;
  }
  function isValidPrimitiveAttributeValue(val) {
    switch (typeof val) {
      case "number":
        return true;
      case "boolean":
        return true;
      case "string":
        return true;
    }
    return false;
  }
});

// node_modules/@opentelemetry/api/build/src/baggage/internal/baggage.js
var require_baggage = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.BaggageImpl = void 0;
  var BaggageImpl = function() {
    function BaggageImpl2(entries) {
      this._entries = entries ? new Map(entries) : new Map();
    }
    BaggageImpl2.prototype.getEntry = function(key) {
      var entry = this._entries.get(key);
      if (!entry) {
        return void 0;
      }
      return Object.assign({}, entry);
    };
    BaggageImpl2.prototype.getAllEntries = function() {
      return Array.from(this._entries.entries()).map(function(_a) {
        var k = _a[0], v = _a[1];
        return [k, v];
      });
    };
    BaggageImpl2.prototype.setEntry = function(key, entry) {
      var newBaggage = new BaggageImpl2(this._entries);
      newBaggage._entries.set(key, entry);
      return newBaggage;
    };
    BaggageImpl2.prototype.removeEntry = function(key) {
      var newBaggage = new BaggageImpl2(this._entries);
      newBaggage._entries.delete(key);
      return newBaggage;
    };
    BaggageImpl2.prototype.removeEntries = function() {
      var keys = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        keys[_i] = arguments[_i];
      }
      var newBaggage = new BaggageImpl2(this._entries);
      for (var _a = 0, keys_1 = keys; _a < keys_1.length; _a++) {
        var key = keys_1[_a];
        newBaggage._entries.delete(key);
      }
      return newBaggage;
    };
    BaggageImpl2.prototype.clear = function() {
      return new BaggageImpl2();
    };
    return BaggageImpl2;
  }();
  exports2.BaggageImpl = BaggageImpl;
});

// node_modules/@opentelemetry/api/build/src/baggage/internal/symbol.js
var require_symbol = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.baggageEntryMetadataSymbol = void 0;
  exports2.baggageEntryMetadataSymbol = Symbol("BaggageEntryMetadata");
});

// node_modules/@opentelemetry/api/build/src/baggage/Baggage.js
var require_Baggage = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/baggage/Entry.js
var require_Entry = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/baggage/index.js
var require_baggage2 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.baggageEntryMetadataFromString = exports2.createBaggage = void 0;
  var baggage_1 = require_baggage();
  var symbol_1 = require_symbol();
  __exportStar(require_Baggage(), exports2);
  __exportStar(require_Entry(), exports2);
  function createBaggage(entries) {
    if (entries === void 0) {
      entries = {};
    }
    return new baggage_1.BaggageImpl(new Map(Object.entries(entries)));
  }
  exports2.createBaggage = createBaggage;
  function baggageEntryMetadataFromString(str) {
    if (typeof str !== "string") {
      str = "";
    }
    return {
      __TYPE__: symbol_1.baggageEntryMetadataSymbol,
      toString: function() {
        return str;
      }
    };
  }
  exports2.baggageEntryMetadataFromString = baggageEntryMetadataFromString;
});

// node_modules/@opentelemetry/api/build/src/common/Exception.js
var require_Exception = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/common/Time.js
var require_Time = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/diag/consoleLogger.js
var require_consoleLogger = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.DiagConsoleLogger = void 0;
  var consoleMap = [
    {n: "error", c: "error"},
    {n: "warn", c: "warn"},
    {n: "info", c: "info"},
    {n: "debug", c: "debug"},
    {n: "verbose", c: "trace"}
  ];
  var DiagConsoleLogger = function() {
    function DiagConsoleLogger2() {
      function _consoleFunc(funcName) {
        return function() {
          var orgArguments = arguments;
          if (console) {
            var theFunc = console[funcName];
            if (typeof theFunc !== "function") {
              theFunc = console.log;
            }
            if (typeof theFunc === "function") {
              return theFunc.apply(console, orgArguments);
            }
          }
        };
      }
      for (var i = 0; i < consoleMap.length; i++) {
        this[consoleMap[i].n] = _consoleFunc(consoleMap[i].c);
      }
    }
    return DiagConsoleLogger2;
  }();
  exports2.DiagConsoleLogger = DiagConsoleLogger;
});

// node_modules/@opentelemetry/api/build/src/diag/types.js
var require_types2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.DiagLogLevel = void 0;
  var DiagLogLevel;
  (function(DiagLogLevel2) {
    DiagLogLevel2[DiagLogLevel2["NONE"] = 0] = "NONE";
    DiagLogLevel2[DiagLogLevel2["ERROR"] = 30] = "ERROR";
    DiagLogLevel2[DiagLogLevel2["WARN"] = 50] = "WARN";
    DiagLogLevel2[DiagLogLevel2["INFO"] = 60] = "INFO";
    DiagLogLevel2[DiagLogLevel2["DEBUG"] = 70] = "DEBUG";
    DiagLogLevel2[DiagLogLevel2["VERBOSE"] = 80] = "VERBOSE";
    DiagLogLevel2[DiagLogLevel2["ALL"] = 9999] = "ALL";
  })(DiagLogLevel = exports2.DiagLogLevel || (exports2.DiagLogLevel = {}));
});

// node_modules/@opentelemetry/api/build/src/diag/index.js
var require_diag = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_consoleLogger(), exports2);
  __exportStar(require_types2(), exports2);
});

// node_modules/@opentelemetry/api/build/src/propagation/NoopTextMapPropagator.js
var require_NoopTextMapPropagator = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.NOOP_TEXT_MAP_PROPAGATOR = exports2.NoopTextMapPropagator = void 0;
  var NoopTextMapPropagator = function() {
    function NoopTextMapPropagator2() {
    }
    NoopTextMapPropagator2.prototype.inject = function(_context, _carrier) {
    };
    NoopTextMapPropagator2.prototype.extract = function(context, _carrier) {
      return context;
    };
    NoopTextMapPropagator2.prototype.fields = function() {
      return [];
    };
    return NoopTextMapPropagator2;
  }();
  exports2.NoopTextMapPropagator = NoopTextMapPropagator;
  exports2.NOOP_TEXT_MAP_PROPAGATOR = new NoopTextMapPropagator();
});

// node_modules/@opentelemetry/api/build/src/propagation/TextMapPropagator.js
var require_TextMapPropagator = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.defaultTextMapSetter = exports2.defaultTextMapGetter = void 0;
  exports2.defaultTextMapGetter = {
    get: function(carrier, key) {
      if (carrier == null) {
        return void 0;
      }
      return carrier[key];
    },
    keys: function(carrier) {
      if (carrier == null) {
        return [];
      }
      return Object.keys(carrier);
    }
  };
  exports2.defaultTextMapSetter = {
    set: function(carrier, key, value) {
      if (carrier == null) {
        return;
      }
      carrier[key] = value;
    }
  };
});

// node_modules/@opentelemetry/api/build/src/trace/attributes.js
var require_attributes2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/Event.js
var require_Event = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/link_context.js
var require_link_context = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/link.js
var require_link = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/trace_flags.js
var require_trace_flags = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.TraceFlags = void 0;
  var TraceFlags;
  (function(TraceFlags2) {
    TraceFlags2[TraceFlags2["NONE"] = 0] = "NONE";
    TraceFlags2[TraceFlags2["SAMPLED"] = 1] = "SAMPLED";
  })(TraceFlags = exports2.TraceFlags || (exports2.TraceFlags = {}));
});

// node_modules/@opentelemetry/api/build/src/trace/spancontext-utils.js
var require_spancontext_utils = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.isSpanContextValid = exports2.isValidSpanId = exports2.isValidTraceId = exports2.INVALID_SPAN_CONTEXT = exports2.INVALID_TRACEID = exports2.INVALID_SPANID = void 0;
  var trace_flags_1 = require_trace_flags();
  var VALID_TRACEID_REGEX = /^([0-9a-f]{32})$/i;
  var VALID_SPANID_REGEX = /^[0-9a-f]{16}$/i;
  exports2.INVALID_SPANID = "0000000000000000";
  exports2.INVALID_TRACEID = "00000000000000000000000000000000";
  exports2.INVALID_SPAN_CONTEXT = {
    traceId: exports2.INVALID_TRACEID,
    spanId: exports2.INVALID_SPANID,
    traceFlags: trace_flags_1.TraceFlags.NONE
  };
  function isValidTraceId(traceId) {
    return VALID_TRACEID_REGEX.test(traceId) && traceId !== exports2.INVALID_TRACEID;
  }
  exports2.isValidTraceId = isValidTraceId;
  function isValidSpanId(spanId) {
    return VALID_SPANID_REGEX.test(spanId) && spanId !== exports2.INVALID_SPANID;
  }
  exports2.isValidSpanId = isValidSpanId;
  function isSpanContextValid(spanContext) {
    return isValidTraceId(spanContext.traceId) && isValidSpanId(spanContext.spanId);
  }
  exports2.isSpanContextValid = isSpanContextValid;
});

// node_modules/@opentelemetry/api/build/src/trace/NoopSpan.js
var require_NoopSpan = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.NoopSpan = void 0;
  var spancontext_utils_1 = require_spancontext_utils();
  var NoopSpan = function() {
    function NoopSpan2(_spanContext) {
      if (_spanContext === void 0) {
        _spanContext = spancontext_utils_1.INVALID_SPAN_CONTEXT;
      }
      this._spanContext = _spanContext;
    }
    NoopSpan2.prototype.context = function() {
      return this._spanContext;
    };
    NoopSpan2.prototype.setAttribute = function(_key, _value) {
      return this;
    };
    NoopSpan2.prototype.setAttributes = function(_attributes) {
      return this;
    };
    NoopSpan2.prototype.addEvent = function(_name, _attributes) {
      return this;
    };
    NoopSpan2.prototype.setStatus = function(_status) {
      return this;
    };
    NoopSpan2.prototype.updateName = function(_name) {
      return this;
    };
    NoopSpan2.prototype.end = function(_endTime) {
    };
    NoopSpan2.prototype.isRecording = function() {
      return false;
    };
    NoopSpan2.prototype.recordException = function(_exception, _time) {
    };
    return NoopSpan2;
  }();
  exports2.NoopSpan = NoopSpan;
});

// node_modules/@opentelemetry/api/build/src/context/context.js
var require_context2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.ROOT_CONTEXT = exports2.createContextKey = exports2.setBaggage = exports2.getBaggage = exports2.isInstrumentationSuppressed = exports2.unsuppressInstrumentation = exports2.suppressInstrumentation = exports2.getSpanContext = exports2.setSpanContext = exports2.setSpan = exports2.getSpan = void 0;
  var NoopSpan_1 = require_NoopSpan();
  var SPAN_KEY = createContextKey("OpenTelemetry Context Key SPAN");
  var SUPPRESS_INSTRUMENTATION_KEY = createContextKey("OpenTelemetry Context Key SUPPRESS_INSTRUMENTATION");
  var BAGGAGE_KEY = createContextKey("OpenTelemetry Baggage Key");
  function getSpan(context) {
    return context.getValue(SPAN_KEY) || void 0;
  }
  exports2.getSpan = getSpan;
  function setSpan(context, span) {
    return context.setValue(SPAN_KEY, span);
  }
  exports2.setSpan = setSpan;
  function setSpanContext(context, spanContext) {
    return setSpan(context, new NoopSpan_1.NoopSpan(spanContext));
  }
  exports2.setSpanContext = setSpanContext;
  function getSpanContext(context) {
    var _a;
    return (_a = getSpan(context)) === null || _a === void 0 ? void 0 : _a.context();
  }
  exports2.getSpanContext = getSpanContext;
  function suppressInstrumentation(context) {
    return context.setValue(SUPPRESS_INSTRUMENTATION_KEY, true);
  }
  exports2.suppressInstrumentation = suppressInstrumentation;
  function unsuppressInstrumentation(context) {
    return context.setValue(SUPPRESS_INSTRUMENTATION_KEY, false);
  }
  exports2.unsuppressInstrumentation = unsuppressInstrumentation;
  function isInstrumentationSuppressed(context) {
    return Boolean(context.getValue(SUPPRESS_INSTRUMENTATION_KEY));
  }
  exports2.isInstrumentationSuppressed = isInstrumentationSuppressed;
  function getBaggage(context) {
    return context.getValue(BAGGAGE_KEY) || void 0;
  }
  exports2.getBaggage = getBaggage;
  function setBaggage(context, baggage) {
    return context.setValue(BAGGAGE_KEY, baggage);
  }
  exports2.setBaggage = setBaggage;
  function createContextKey(description) {
    return Symbol.for(description);
  }
  exports2.createContextKey = createContextKey;
  var BaseContext = function() {
    function BaseContext2(parentContext) {
      var self2 = this;
      self2._currentContext = parentContext ? new Map(parentContext) : new Map();
      self2.getValue = function(key) {
        return self2._currentContext.get(key);
      };
      self2.setValue = function(key, value) {
        var context = new BaseContext2(self2._currentContext);
        context._currentContext.set(key, value);
        return context;
      };
      self2.deleteValue = function(key) {
        var context = new BaseContext2(self2._currentContext);
        context._currentContext.delete(key);
        return context;
      };
    }
    return BaseContext2;
  }();
  exports2.ROOT_CONTEXT = new BaseContext();
});

// node_modules/@opentelemetry/api/build/src/trace/NoopTracer.js
var require_NoopTracer = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.NOOP_TRACER = exports2.NoopTracer = void 0;
  var context_1 = require_context2();
  var NoopSpan_1 = require_NoopSpan();
  var spancontext_utils_1 = require_spancontext_utils();
  var NoopTracer = function() {
    function NoopTracer2() {
    }
    NoopTracer2.prototype.startSpan = function(name, options, context) {
      var root = Boolean(options === null || options === void 0 ? void 0 : options.root);
      if (root) {
        return new NoopSpan_1.NoopSpan();
      }
      var parentFromContext = context && context_1.getSpanContext(context);
      if (isSpanContext(parentFromContext) && spancontext_utils_1.isSpanContextValid(parentFromContext)) {
        return new NoopSpan_1.NoopSpan(parentFromContext);
      } else {
        return new NoopSpan_1.NoopSpan();
      }
    };
    return NoopTracer2;
  }();
  exports2.NoopTracer = NoopTracer;
  function isSpanContext(spanContext) {
    return typeof spanContext === "object" && typeof spanContext["spanId"] === "string" && typeof spanContext["traceId"] === "string" && typeof spanContext["traceFlags"] === "number";
  }
  exports2.NOOP_TRACER = new NoopTracer();
});

// node_modules/@opentelemetry/api/build/src/trace/NoopTracerProvider.js
var require_NoopTracerProvider = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.NOOP_TRACER_PROVIDER = exports2.NoopTracerProvider = void 0;
  var NoopTracer_1 = require_NoopTracer();
  var NoopTracerProvider = function() {
    function NoopTracerProvider2() {
    }
    NoopTracerProvider2.prototype.getTracer = function(_name, _version) {
      return NoopTracer_1.NOOP_TRACER;
    };
    return NoopTracerProvider2;
  }();
  exports2.NoopTracerProvider = NoopTracerProvider;
  exports2.NOOP_TRACER_PROVIDER = new NoopTracerProvider();
});

// node_modules/@opentelemetry/api/build/src/trace/ProxyTracer.js
var require_ProxyTracer = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.ProxyTracer = void 0;
  var NoopTracer_1 = require_NoopTracer();
  var ProxyTracer = function() {
    function ProxyTracer2(_provider, name, version) {
      this._provider = _provider;
      this.name = name;
      this.version = version;
    }
    ProxyTracer2.prototype.startSpan = function(name, options, context) {
      return this._getTracer().startSpan(name, options, context);
    };
    ProxyTracer2.prototype._getTracer = function() {
      if (this._delegate) {
        return this._delegate;
      }
      var tracer = this._provider.getDelegateTracer(this.name, this.version);
      if (!tracer) {
        return NoopTracer_1.NOOP_TRACER;
      }
      this._delegate = tracer;
      return this._delegate;
    };
    return ProxyTracer2;
  }();
  exports2.ProxyTracer = ProxyTracer;
});

// node_modules/@opentelemetry/api/build/src/trace/ProxyTracerProvider.js
var require_ProxyTracerProvider = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.ProxyTracerProvider = void 0;
  var ProxyTracer_1 = require_ProxyTracer();
  var NoopTracerProvider_1 = require_NoopTracerProvider();
  var ProxyTracerProvider = function() {
    function ProxyTracerProvider2() {
    }
    ProxyTracerProvider2.prototype.getTracer = function(name, version) {
      var _a;
      return (_a = this.getDelegateTracer(name, version)) !== null && _a !== void 0 ? _a : new ProxyTracer_1.ProxyTracer(this, name, version);
    };
    ProxyTracerProvider2.prototype.getDelegate = function() {
      var _a;
      return (_a = this._delegate) !== null && _a !== void 0 ? _a : NoopTracerProvider_1.NOOP_TRACER_PROVIDER;
    };
    ProxyTracerProvider2.prototype.setDelegate = function(delegate) {
      this._delegate = delegate;
    };
    ProxyTracerProvider2.prototype.getDelegateTracer = function(name, version) {
      var _a;
      return (_a = this._delegate) === null || _a === void 0 ? void 0 : _a.getTracer(name, version);
    };
    return ProxyTracerProvider2;
  }();
  exports2.ProxyTracerProvider = ProxyTracerProvider;
});

// node_modules/@opentelemetry/api/build/src/trace/Sampler.js
var require_Sampler = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/SamplingResult.js
var require_SamplingResult = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.SamplingDecision = void 0;
  var SamplingDecision;
  (function(SamplingDecision2) {
    SamplingDecision2[SamplingDecision2["NOT_RECORD"] = 0] = "NOT_RECORD";
    SamplingDecision2[SamplingDecision2["RECORD"] = 1] = "RECORD";
    SamplingDecision2[SamplingDecision2["RECORD_AND_SAMPLED"] = 2] = "RECORD_AND_SAMPLED";
  })(SamplingDecision = exports2.SamplingDecision || (exports2.SamplingDecision = {}));
});

// node_modules/@opentelemetry/api/build/src/trace/span_context.js
var require_span_context = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/span_kind.js
var require_span_kind = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.SpanKind = void 0;
  var SpanKind;
  (function(SpanKind2) {
    SpanKind2[SpanKind2["INTERNAL"] = 0] = "INTERNAL";
    SpanKind2[SpanKind2["SERVER"] = 1] = "SERVER";
    SpanKind2[SpanKind2["CLIENT"] = 2] = "CLIENT";
    SpanKind2[SpanKind2["PRODUCER"] = 3] = "PRODUCER";
    SpanKind2[SpanKind2["CONSUMER"] = 4] = "CONSUMER";
  })(SpanKind = exports2.SpanKind || (exports2.SpanKind = {}));
});

// node_modules/@opentelemetry/api/build/src/trace/span.js
var require_span = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/SpanOptions.js
var require_SpanOptions = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/status.js
var require_status = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.SpanStatusCode = void 0;
  var SpanStatusCode;
  (function(SpanStatusCode2) {
    SpanStatusCode2[SpanStatusCode2["UNSET"] = 0] = "UNSET";
    SpanStatusCode2[SpanStatusCode2["OK"] = 1] = "OK";
    SpanStatusCode2[SpanStatusCode2["ERROR"] = 2] = "ERROR";
  })(SpanStatusCode = exports2.SpanStatusCode || (exports2.SpanStatusCode = {}));
});

// node_modules/@opentelemetry/api/build/src/trace/TimedEvent.js
var require_TimedEvent = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/trace_state.js
var require_trace_state = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/tracer_provider.js
var require_tracer_provider = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/trace/tracer.js
var require_tracer = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/context/NoopContextManager.js
var require_NoopContextManager = __commonJS((exports2) => {
  "use strict";
  var __spreadArrays = exports2 && exports2.__spreadArrays || function() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++)
      s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
      for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
        r[k] = a[j];
    return r;
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.NoopContextManager = void 0;
  var context_1 = require_context2();
  var NoopContextManager = function() {
    function NoopContextManager2() {
    }
    NoopContextManager2.prototype.active = function() {
      return context_1.ROOT_CONTEXT;
    };
    NoopContextManager2.prototype.with = function(_context, fn, thisArg) {
      var args = [];
      for (var _i = 3; _i < arguments.length; _i++) {
        args[_i - 3] = arguments[_i];
      }
      return fn.call.apply(fn, __spreadArrays([thisArg], args));
    };
    NoopContextManager2.prototype.bind = function(target, _context) {
      return target;
    };
    NoopContextManager2.prototype.enable = function() {
      return this;
    };
    NoopContextManager2.prototype.disable = function() {
      return this;
    };
    return NoopContextManager2;
  }();
  exports2.NoopContextManager = NoopContextManager;
});

// node_modules/@opentelemetry/api/build/src/context/types.js
var require_types3 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/api/build/src/platform/node/globalThis.js
var require_globalThis = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2._globalThis = void 0;
  exports2._globalThis = typeof globalThis === "object" ? globalThis : global;
});

// node_modules/@opentelemetry/api/build/src/platform/node/index.js
var require_node = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_globalThis(), exports2);
});

// node_modules/@opentelemetry/api/build/src/platform/index.js
var require_platform = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_node(), exports2);
});

// node_modules/@opentelemetry/api/build/src/version.js
var require_version = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.VERSION = void 0;
  exports2.VERSION = "0.18.1";
});

// node_modules/@opentelemetry/api/build/src/internal/semver.js
var require_semver = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.isCompatible = exports2._makeCompatibilityCheck = void 0;
  var version_1 = require_version();
  var re = /^(\d+)\.(\d+)\.(\d+)(?:-(.*))?$/;
  function _makeCompatibilityCheck(ownVersion) {
    var acceptedVersions = new Set([ownVersion]);
    var rejectedVersions = new Set();
    var myVersionMatch = ownVersion.match(re);
    if (!myVersionMatch) {
      return function() {
        return false;
      };
    }
    var ownVersionParsed = {
      major: +myVersionMatch[1],
      minor: +myVersionMatch[2],
      patch: +myVersionMatch[3]
    };
    function _reject(v) {
      rejectedVersions.add(v);
      return false;
    }
    function _accept(v) {
      acceptedVersions.add(v);
      return true;
    }
    return function isCompatible(globalVersion) {
      if (acceptedVersions.has(globalVersion)) {
        return true;
      }
      if (rejectedVersions.has(globalVersion)) {
        return false;
      }
      var globalVersionMatch = globalVersion.match(re);
      if (!globalVersionMatch) {
        return _reject(globalVersion);
      }
      var globalVersionParsed = {
        major: +globalVersionMatch[1],
        minor: +globalVersionMatch[2],
        patch: +globalVersionMatch[3]
      };
      if (ownVersionParsed.major !== globalVersionParsed.major) {
        return _reject(globalVersion);
      }
      if (ownVersionParsed.major === 0) {
        if (ownVersionParsed.minor === globalVersionParsed.minor && ownVersionParsed.patch <= globalVersionParsed.patch) {
          return _accept(globalVersion);
        }
        return _reject(globalVersion);
      }
      if (ownVersionParsed.minor <= globalVersionParsed.minor) {
        return _accept(globalVersion);
      }
      return _reject(globalVersion);
    };
  }
  exports2._makeCompatibilityCheck = _makeCompatibilityCheck;
  exports2.isCompatible = _makeCompatibilityCheck(version_1.VERSION);
});

// node_modules/@opentelemetry/api/build/src/internal/global-utils.js
var require_global_utils = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.unregisterGlobal = exports2.getGlobal = exports2.registerGlobal = void 0;
  var __1 = require_src();
  var platform_1 = require_platform();
  var version_1 = require_version();
  var semver_1 = require_semver();
  var major = version_1.VERSION.split(".")[0];
  var GLOBAL_OPENTELEMETRY_API_KEY = Symbol.for("io.opentelemetry.js.api." + major);
  var _global = platform_1._globalThis;
  function registerGlobal(type, instance, allowOverride) {
    var _a;
    if (allowOverride === void 0) {
      allowOverride = false;
    }
    _global[GLOBAL_OPENTELEMETRY_API_KEY] = (_a = _global[GLOBAL_OPENTELEMETRY_API_KEY]) !== null && _a !== void 0 ? _a : {
      version: version_1.VERSION
    };
    var api = _global[GLOBAL_OPENTELEMETRY_API_KEY];
    if (!allowOverride && api[type]) {
      var err = new Error("@opentelemetry/api: Attempted duplicate registration of API: " + type);
      __1.diag.error(err.stack || err.message);
      return;
    }
    if (api.version !== version_1.VERSION) {
      var err = new Error("@opentelemetry/api: All API registration versions must match");
      __1.diag.error(err.stack || err.message);
      return;
    }
    api[type] = instance;
  }
  exports2.registerGlobal = registerGlobal;
  function getGlobal(type) {
    var _a, _b;
    var globalVersion = (_a = _global[GLOBAL_OPENTELEMETRY_API_KEY]) === null || _a === void 0 ? void 0 : _a.version;
    if (!globalVersion || !semver_1.isCompatible(globalVersion)) {
      return;
    }
    return (_b = _global[GLOBAL_OPENTELEMETRY_API_KEY]) === null || _b === void 0 ? void 0 : _b[type];
  }
  exports2.getGlobal = getGlobal;
  function unregisterGlobal(type) {
    var api = _global[GLOBAL_OPENTELEMETRY_API_KEY];
    if (api) {
      delete api[type];
    }
  }
  exports2.unregisterGlobal = unregisterGlobal;
});

// node_modules/@opentelemetry/api/build/src/api/context.js
var require_context3 = __commonJS((exports2) => {
  "use strict";
  var __spreadArrays = exports2 && exports2.__spreadArrays || function() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++)
      s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
      for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
        r[k] = a[j];
    return r;
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.ContextAPI = void 0;
  var NoopContextManager_1 = require_NoopContextManager();
  var global_utils_1 = require_global_utils();
  var API_NAME = "context";
  var NOOP_CONTEXT_MANAGER = new NoopContextManager_1.NoopContextManager();
  var ContextAPI = function() {
    function ContextAPI2() {
    }
    ContextAPI2.getInstance = function() {
      if (!this._instance) {
        this._instance = new ContextAPI2();
      }
      return this._instance;
    };
    ContextAPI2.prototype.setGlobalContextManager = function(contextManager) {
      global_utils_1.registerGlobal(API_NAME, contextManager);
      return contextManager;
    };
    ContextAPI2.prototype.active = function() {
      return this._getContextManager().active();
    };
    ContextAPI2.prototype.with = function(context, fn, thisArg) {
      var _a;
      var args = [];
      for (var _i = 3; _i < arguments.length; _i++) {
        args[_i - 3] = arguments[_i];
      }
      return (_a = this._getContextManager()).with.apply(_a, __spreadArrays([context, fn, thisArg], args));
    };
    ContextAPI2.prototype.bind = function(target, context) {
      if (context === void 0) {
        context = this.active();
      }
      return this._getContextManager().bind(target, context);
    };
    ContextAPI2.prototype._getContextManager = function() {
      return global_utils_1.getGlobal(API_NAME) || NOOP_CONTEXT_MANAGER;
    };
    ContextAPI2.prototype.disable = function() {
      this._getContextManager().disable();
      global_utils_1.unregisterGlobal(API_NAME);
    };
    return ContextAPI2;
  }();
  exports2.ContextAPI = ContextAPI;
});

// node_modules/@opentelemetry/api/build/src/api/trace.js
var require_trace = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.TraceAPI = void 0;
  var ProxyTracerProvider_1 = require_ProxyTracerProvider();
  var spancontext_utils_1 = require_spancontext_utils();
  var global_utils_1 = require_global_utils();
  var API_NAME = "trace";
  var TraceAPI = function() {
    function TraceAPI2() {
      this._proxyTracerProvider = new ProxyTracerProvider_1.ProxyTracerProvider();
      this.isSpanContextValid = spancontext_utils_1.isSpanContextValid;
    }
    TraceAPI2.getInstance = function() {
      if (!this._instance) {
        this._instance = new TraceAPI2();
      }
      return this._instance;
    };
    TraceAPI2.prototype.setGlobalTracerProvider = function(provider) {
      this._proxyTracerProvider.setDelegate(provider);
      global_utils_1.registerGlobal(API_NAME, this._proxyTracerProvider);
      return this._proxyTracerProvider;
    };
    TraceAPI2.prototype.getTracerProvider = function() {
      return global_utils_1.getGlobal(API_NAME) || this._proxyTracerProvider;
    };
    TraceAPI2.prototype.getTracer = function(name, version) {
      return this.getTracerProvider().getTracer(name, version);
    };
    TraceAPI2.prototype.disable = function() {
      global_utils_1.unregisterGlobal(API_NAME);
      this._proxyTracerProvider = new ProxyTracerProvider_1.ProxyTracerProvider();
    };
    return TraceAPI2;
  }();
  exports2.TraceAPI = TraceAPI;
});

// node_modules/@opentelemetry/api/build/src/api/propagation.js
var require_propagation = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.PropagationAPI = void 0;
  var NoopTextMapPropagator_1 = require_NoopTextMapPropagator();
  var TextMapPropagator_1 = require_TextMapPropagator();
  var global_utils_1 = require_global_utils();
  var API_NAME = "propagation";
  var PropagationAPI = function() {
    function PropagationAPI2() {
    }
    PropagationAPI2.getInstance = function() {
      if (!this._instance) {
        this._instance = new PropagationAPI2();
      }
      return this._instance;
    };
    PropagationAPI2.prototype.setGlobalPropagator = function(propagator) {
      global_utils_1.registerGlobal(API_NAME, propagator);
      return propagator;
    };
    PropagationAPI2.prototype.inject = function(context, carrier, setter) {
      if (setter === void 0) {
        setter = TextMapPropagator_1.defaultTextMapSetter;
      }
      return this._getGlobalPropagator().inject(context, carrier, setter);
    };
    PropagationAPI2.prototype.extract = function(context, carrier, getter) {
      if (getter === void 0) {
        getter = TextMapPropagator_1.defaultTextMapGetter;
      }
      return this._getGlobalPropagator().extract(context, carrier, getter);
    };
    PropagationAPI2.prototype.fields = function() {
      return this._getGlobalPropagator().fields();
    };
    PropagationAPI2.prototype.disable = function() {
      global_utils_1.unregisterGlobal(API_NAME);
    };
    PropagationAPI2.prototype._getGlobalPropagator = function() {
      return global_utils_1.getGlobal(API_NAME) || NoopTextMapPropagator_1.NOOP_TEXT_MAP_PROPAGATOR;
    };
    return PropagationAPI2;
  }();
  exports2.PropagationAPI = PropagationAPI;
});

// node_modules/@opentelemetry/api/build/src/diag/internal/logLevelLogger.js
var require_logLevelLogger = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.createLogLevelDiagLogger = void 0;
  var types_1 = require_types2();
  function createLogLevelDiagLogger(maxLevel, logger) {
    if (maxLevel < types_1.DiagLogLevel.NONE) {
      maxLevel = types_1.DiagLogLevel.NONE;
    } else if (maxLevel > types_1.DiagLogLevel.ALL) {
      maxLevel = types_1.DiagLogLevel.ALL;
    }
    logger = logger || {};
    function _filterFunc(funcName, theLevel) {
      var theFunc = logger[funcName];
      if (typeof theFunc === "function" && maxLevel >= theLevel) {
        return theFunc.bind(logger);
      }
      return function() {
      };
    }
    return {
      error: _filterFunc("error", types_1.DiagLogLevel.ERROR),
      warn: _filterFunc("warn", types_1.DiagLogLevel.WARN),
      info: _filterFunc("info", types_1.DiagLogLevel.INFO),
      debug: _filterFunc("debug", types_1.DiagLogLevel.DEBUG),
      verbose: _filterFunc("verbose", types_1.DiagLogLevel.VERBOSE)
    };
  }
  exports2.createLogLevelDiagLogger = createLogLevelDiagLogger;
});

// node_modules/@opentelemetry/api/build/src/api/diag.js
var require_diag2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.DiagAPI = void 0;
  var logLevelLogger_1 = require_logLevelLogger();
  var types_1 = require_types2();
  var global_utils_1 = require_global_utils();
  var API_NAME = "diag";
  var DiagAPI = function() {
    function DiagAPI2() {
      function _logProxy(funcName) {
        return function() {
          var logger = global_utils_1.getGlobal("diag");
          if (!logger)
            return;
          return logger[funcName].apply(logger, arguments);
        };
      }
      var self2 = this;
      self2.setLogger = function(logger, logLevel) {
        var _a;
        if (logLevel === void 0) {
          logLevel = types_1.DiagLogLevel.INFO;
        }
        if (logger === self2) {
          var err = new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
          self2.error((_a = err.stack) !== null && _a !== void 0 ? _a : err.message);
          return;
        }
        global_utils_1.registerGlobal("diag", logLevelLogger_1.createLogLevelDiagLogger(logLevel, logger), true);
      };
      self2.disable = function() {
        global_utils_1.unregisterGlobal(API_NAME);
      };
      self2.verbose = _logProxy("verbose");
      self2.debug = _logProxy("debug");
      self2.info = _logProxy("info");
      self2.warn = _logProxy("warn");
      self2.error = _logProxy("error");
    }
    DiagAPI2.instance = function() {
      if (!this._instance) {
        this._instance = new DiagAPI2();
      }
      return this._instance;
    };
    return DiagAPI2;
  }();
  exports2.DiagAPI = DiagAPI;
});

// node_modules/@opentelemetry/api/build/src/index.js
var require_src = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.diag = exports2.propagation = exports2.trace = exports2.context = exports2.isValidSpanId = exports2.isValidTraceId = exports2.isSpanContextValid = exports2.INVALID_SPAN_CONTEXT = exports2.INVALID_TRACEID = exports2.INVALID_SPANID = void 0;
  __exportStar(require_baggage2(), exports2);
  __exportStar(require_Exception(), exports2);
  __exportStar(require_Time(), exports2);
  __exportStar(require_diag(), exports2);
  __exportStar(require_NoopTextMapPropagator(), exports2);
  __exportStar(require_TextMapPropagator(), exports2);
  __exportStar(require_attributes2(), exports2);
  __exportStar(require_Event(), exports2);
  __exportStar(require_link_context(), exports2);
  __exportStar(require_link(), exports2);
  __exportStar(require_NoopTracer(), exports2);
  __exportStar(require_NoopTracerProvider(), exports2);
  __exportStar(require_ProxyTracer(), exports2);
  __exportStar(require_ProxyTracerProvider(), exports2);
  __exportStar(require_Sampler(), exports2);
  __exportStar(require_SamplingResult(), exports2);
  __exportStar(require_span_context(), exports2);
  __exportStar(require_span_kind(), exports2);
  __exportStar(require_span(), exports2);
  __exportStar(require_SpanOptions(), exports2);
  __exportStar(require_status(), exports2);
  __exportStar(require_TimedEvent(), exports2);
  __exportStar(require_trace_flags(), exports2);
  __exportStar(require_trace_state(), exports2);
  __exportStar(require_tracer_provider(), exports2);
  __exportStar(require_tracer(), exports2);
  var spancontext_utils_1 = require_spancontext_utils();
  Object.defineProperty(exports2, "INVALID_SPANID", {enumerable: true, get: function() {
    return spancontext_utils_1.INVALID_SPANID;
  }});
  Object.defineProperty(exports2, "INVALID_TRACEID", {enumerable: true, get: function() {
    return spancontext_utils_1.INVALID_TRACEID;
  }});
  Object.defineProperty(exports2, "INVALID_SPAN_CONTEXT", {enumerable: true, get: function() {
    return spancontext_utils_1.INVALID_SPAN_CONTEXT;
  }});
  Object.defineProperty(exports2, "isSpanContextValid", {enumerable: true, get: function() {
    return spancontext_utils_1.isSpanContextValid;
  }});
  Object.defineProperty(exports2, "isValidTraceId", {enumerable: true, get: function() {
    return spancontext_utils_1.isValidTraceId;
  }});
  Object.defineProperty(exports2, "isValidSpanId", {enumerable: true, get: function() {
    return spancontext_utils_1.isValidSpanId;
  }});
  __exportStar(require_context2(), exports2);
  __exportStar(require_NoopContextManager(), exports2);
  __exportStar(require_types3(), exports2);
  var context_1 = require_context3();
  exports2.context = context_1.ContextAPI.getInstance();
  var trace_1 = require_trace();
  exports2.trace = trace_1.TraceAPI.getInstance();
  var propagation_1 = require_propagation();
  exports2.propagation = propagation_1.PropagationAPI.getInstance();
  var diag_1 = require_diag2();
  exports2.diag = diag_1.DiagAPI.instance();
  exports2.default = {
    trace: exports2.trace,
    context: exports2.context,
    propagation: exports2.propagation,
    diag: exports2.diag
  };
});

// node_modules/@opentelemetry/core/build/src/common/logging-error-handler.js
var require_logging_error_handler = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.loggingErrorHandler = void 0;
  var api_1 = require_src();
  function loggingErrorHandler() {
    return (ex) => {
      api_1.diag.error(stringifyException(ex));
    };
  }
  exports2.loggingErrorHandler = loggingErrorHandler;
  function stringifyException(ex) {
    if (typeof ex === "string") {
      return ex;
    } else {
      return JSON.stringify(flattenException(ex));
    }
  }
  function flattenException(ex) {
    const result = {};
    let current = ex;
    while (current !== null) {
      Object.getOwnPropertyNames(current).forEach((propertyName) => {
        if (result[propertyName])
          return;
        const value = current[propertyName];
        if (value) {
          result[propertyName] = String(value);
        }
      });
      current = Object.getPrototypeOf(current);
    }
    return result;
  }
});

// node_modules/@opentelemetry/core/build/src/common/global-error-handler.js
var require_global_error_handler = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.globalErrorHandler = exports2.setGlobalErrorHandler = void 0;
  var logging_error_handler_1 = require_logging_error_handler();
  var delegateHandler = logging_error_handler_1.loggingErrorHandler();
  function setGlobalErrorHandler(handler) {
    delegateHandler = handler;
  }
  exports2.setGlobalErrorHandler = setGlobalErrorHandler;
  var globalErrorHandler = (ex) => {
    try {
      delegateHandler(ex);
    } catch (_a) {
    }
  };
  exports2.globalErrorHandler = globalErrorHandler;
});

// node_modules/semver/internal/constants.js
var require_constants3 = __commonJS((exports2, module2) => {
  var SEMVER_SPEC_VERSION = "2.0.0";
  var MAX_LENGTH = 256;
  var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || 9007199254740991;
  var MAX_SAFE_COMPONENT_LENGTH = 16;
  module2.exports = {
    SEMVER_SPEC_VERSION,
    MAX_LENGTH,
    MAX_SAFE_INTEGER,
    MAX_SAFE_COMPONENT_LENGTH
  };
});

// node_modules/semver/internal/debug.js
var require_debug = __commonJS((exports2, module2) => {
  var debug = typeof process === "object" && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {
  };
  module2.exports = debug;
});

// node_modules/semver/internal/re.js
var require_re = __commonJS((exports2, module2) => {
  var {MAX_SAFE_COMPONENT_LENGTH} = require_constants3();
  var debug = require_debug();
  exports2 = module2.exports = {};
  var re = exports2.re = [];
  var src = exports2.src = [];
  var t = exports2.t = {};
  var R = 0;
  var createToken = (name, value, isGlobal) => {
    const index = R++;
    debug(index, value);
    t[name] = index;
    src[index] = value;
    re[index] = new RegExp(value, isGlobal ? "g" : void 0);
  };
  createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
  createToken("NUMERICIDENTIFIERLOOSE", "[0-9]+");
  createToken("NONNUMERICIDENTIFIER", "\\d*[a-zA-Z-][a-zA-Z0-9-]*");
  createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})`);
  createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})`);
  createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NUMERICIDENTIFIER]}|${src[t.NONNUMERICIDENTIFIER]})`);
  createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NUMERICIDENTIFIERLOOSE]}|${src[t.NONNUMERICIDENTIFIER]})`);
  createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
  createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
  createToken("BUILDIDENTIFIER", "[0-9A-Za-z-]+");
  createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
  createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
  createToken("FULL", `^${src[t.FULLPLAIN]}$`);
  createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
  createToken("LOOSE", `^${src[t.LOOSEPLAIN]}$`);
  createToken("GTLT", "((?:<|>)?=?)");
  createToken("XRANGEIDENTIFIERLOOSE", `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`);
  createToken("XRANGEIDENTIFIER", `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`);
  createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?)?)?`);
  createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?)?)?`);
  createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`);
  createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`);
  createToken("COERCE", `${"(^|[^\\d])(\\d{1,"}${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:$|[^\\d])`);
  createToken("COERCERTL", src[t.COERCE], true);
  createToken("LONETILDE", "(?:~>?)");
  createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
  exports2.tildeTrimReplace = "$1~";
  createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`);
  createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`);
  createToken("LONECARET", "(?:\\^)");
  createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
  exports2.caretTrimReplace = "$1^";
  createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`);
  createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`);
  createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`);
  createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`);
  createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
  exports2.comparatorTrimReplace = "$1$2$3";
  createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})\\s+-\\s+(${src[t.XRANGEPLAIN]})\\s*$`);
  createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t.XRANGEPLAINLOOSE]})\\s*$`);
  createToken("STAR", "(<|>)?=?\\s*\\*");
  createToken("GTE0", "^\\s*>=\\s*0.0.0\\s*$");
  createToken("GTE0PRE", "^\\s*>=\\s*0.0.0-0\\s*$");
});

// node_modules/semver/internal/parse-options.js
var require_parse_options = __commonJS((exports2, module2) => {
  var opts = ["includePrerelease", "loose", "rtl"];
  var parseOptions = (options) => !options ? {} : typeof options !== "object" ? {loose: true} : opts.filter((k) => options[k]).reduce((options2, k) => {
    options2[k] = true;
    return options2;
  }, {});
  module2.exports = parseOptions;
});

// node_modules/semver/internal/identifiers.js
var require_identifiers = __commonJS((exports2, module2) => {
  var numeric = /^[0-9]+$/;
  var compareIdentifiers = (a, b) => {
    const anum = numeric.test(a);
    const bnum = numeric.test(b);
    if (anum && bnum) {
      a = +a;
      b = +b;
    }
    return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
  };
  var rcompareIdentifiers = (a, b) => compareIdentifiers(b, a);
  module2.exports = {
    compareIdentifiers,
    rcompareIdentifiers
  };
});

// node_modules/semver/classes/semver.js
var require_semver2 = __commonJS((exports2, module2) => {
  var debug = require_debug();
  var {MAX_LENGTH, MAX_SAFE_INTEGER} = require_constants3();
  var {re, t} = require_re();
  var parseOptions = require_parse_options();
  var {compareIdentifiers} = require_identifiers();
  var SemVer = class {
    constructor(version, options) {
      options = parseOptions(options);
      if (version instanceof SemVer) {
        if (version.loose === !!options.loose && version.includePrerelease === !!options.includePrerelease) {
          return version;
        } else {
          version = version.version;
        }
      } else if (typeof version !== "string") {
        throw new TypeError(`Invalid Version: ${version}`);
      }
      if (version.length > MAX_LENGTH) {
        throw new TypeError(`version is longer than ${MAX_LENGTH} characters`);
      }
      debug("SemVer", version, options);
      this.options = options;
      this.loose = !!options.loose;
      this.includePrerelease = !!options.includePrerelease;
      const m = version.trim().match(options.loose ? re[t.LOOSE] : re[t.FULL]);
      if (!m) {
        throw new TypeError(`Invalid Version: ${version}`);
      }
      this.raw = version;
      this.major = +m[1];
      this.minor = +m[2];
      this.patch = +m[3];
      if (this.major > MAX_SAFE_INTEGER || this.major < 0) {
        throw new TypeError("Invalid major version");
      }
      if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) {
        throw new TypeError("Invalid minor version");
      }
      if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) {
        throw new TypeError("Invalid patch version");
      }
      if (!m[4]) {
        this.prerelease = [];
      } else {
        this.prerelease = m[4].split(".").map((id) => {
          if (/^[0-9]+$/.test(id)) {
            const num = +id;
            if (num >= 0 && num < MAX_SAFE_INTEGER) {
              return num;
            }
          }
          return id;
        });
      }
      this.build = m[5] ? m[5].split(".") : [];
      this.format();
    }
    format() {
      this.version = `${this.major}.${this.minor}.${this.patch}`;
      if (this.prerelease.length) {
        this.version += `-${this.prerelease.join(".")}`;
      }
      return this.version;
    }
    toString() {
      return this.version;
    }
    compare(other) {
      debug("SemVer.compare", this.version, this.options, other);
      if (!(other instanceof SemVer)) {
        if (typeof other === "string" && other === this.version) {
          return 0;
        }
        other = new SemVer(other, this.options);
      }
      if (other.version === this.version) {
        return 0;
      }
      return this.compareMain(other) || this.comparePre(other);
    }
    compareMain(other) {
      if (!(other instanceof SemVer)) {
        other = new SemVer(other, this.options);
      }
      return compareIdentifiers(this.major, other.major) || compareIdentifiers(this.minor, other.minor) || compareIdentifiers(this.patch, other.patch);
    }
    comparePre(other) {
      if (!(other instanceof SemVer)) {
        other = new SemVer(other, this.options);
      }
      if (this.prerelease.length && !other.prerelease.length) {
        return -1;
      } else if (!this.prerelease.length && other.prerelease.length) {
        return 1;
      } else if (!this.prerelease.length && !other.prerelease.length) {
        return 0;
      }
      let i = 0;
      do {
        const a = this.prerelease[i];
        const b = other.prerelease[i];
        debug("prerelease compare", i, a, b);
        if (a === void 0 && b === void 0) {
          return 0;
        } else if (b === void 0) {
          return 1;
        } else if (a === void 0) {
          return -1;
        } else if (a === b) {
          continue;
        } else {
          return compareIdentifiers(a, b);
        }
      } while (++i);
    }
    compareBuild(other) {
      if (!(other instanceof SemVer)) {
        other = new SemVer(other, this.options);
      }
      let i = 0;
      do {
        const a = this.build[i];
        const b = other.build[i];
        debug("prerelease compare", i, a, b);
        if (a === void 0 && b === void 0) {
          return 0;
        } else if (b === void 0) {
          return 1;
        } else if (a === void 0) {
          return -1;
        } else if (a === b) {
          continue;
        } else {
          return compareIdentifiers(a, b);
        }
      } while (++i);
    }
    inc(release, identifier) {
      switch (release) {
        case "premajor":
          this.prerelease.length = 0;
          this.patch = 0;
          this.minor = 0;
          this.major++;
          this.inc("pre", identifier);
          break;
        case "preminor":
          this.prerelease.length = 0;
          this.patch = 0;
          this.minor++;
          this.inc("pre", identifier);
          break;
        case "prepatch":
          this.prerelease.length = 0;
          this.inc("patch", identifier);
          this.inc("pre", identifier);
          break;
        case "prerelease":
          if (this.prerelease.length === 0) {
            this.inc("patch", identifier);
          }
          this.inc("pre", identifier);
          break;
        case "major":
          if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0) {
            this.major++;
          }
          this.minor = 0;
          this.patch = 0;
          this.prerelease = [];
          break;
        case "minor":
          if (this.patch !== 0 || this.prerelease.length === 0) {
            this.minor++;
          }
          this.patch = 0;
          this.prerelease = [];
          break;
        case "patch":
          if (this.prerelease.length === 0) {
            this.patch++;
          }
          this.prerelease = [];
          break;
        case "pre":
          if (this.prerelease.length === 0) {
            this.prerelease = [0];
          } else {
            let i = this.prerelease.length;
            while (--i >= 0) {
              if (typeof this.prerelease[i] === "number") {
                this.prerelease[i]++;
                i = -2;
              }
            }
            if (i === -1) {
              this.prerelease.push(0);
            }
          }
          if (identifier) {
            if (this.prerelease[0] === identifier) {
              if (isNaN(this.prerelease[1])) {
                this.prerelease = [identifier, 0];
              }
            } else {
              this.prerelease = [identifier, 0];
            }
          }
          break;
        default:
          throw new Error(`invalid increment argument: ${release}`);
      }
      this.format();
      this.raw = this.version;
      return this;
    }
  };
  module2.exports = SemVer;
});

// node_modules/semver/functions/parse.js
var require_parse2 = __commonJS((exports2, module2) => {
  var {MAX_LENGTH} = require_constants3();
  var {re, t} = require_re();
  var SemVer = require_semver2();
  var parseOptions = require_parse_options();
  var parse = (version, options) => {
    options = parseOptions(options);
    if (version instanceof SemVer) {
      return version;
    }
    if (typeof version !== "string") {
      return null;
    }
    if (version.length > MAX_LENGTH) {
      return null;
    }
    const r = options.loose ? re[t.LOOSE] : re[t.FULL];
    if (!r.test(version)) {
      return null;
    }
    try {
      return new SemVer(version, options);
    } catch (er) {
      return null;
    }
  };
  module2.exports = parse;
});

// node_modules/semver/functions/valid.js
var require_valid = __commonJS((exports2, module2) => {
  var parse = require_parse2();
  var valid = (version, options) => {
    const v = parse(version, options);
    return v ? v.version : null;
  };
  module2.exports = valid;
});

// node_modules/semver/functions/clean.js
var require_clean = __commonJS((exports2, module2) => {
  var parse = require_parse2();
  var clean = (version, options) => {
    const s = parse(version.trim().replace(/^[=v]+/, ""), options);
    return s ? s.version : null;
  };
  module2.exports = clean;
});

// node_modules/semver/functions/inc.js
var require_inc = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var inc = (version, release, options, identifier) => {
    if (typeof options === "string") {
      identifier = options;
      options = void 0;
    }
    try {
      return new SemVer(version, options).inc(release, identifier).version;
    } catch (er) {
      return null;
    }
  };
  module2.exports = inc;
});

// node_modules/semver/functions/compare.js
var require_compare = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var compare = (a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose));
  module2.exports = compare;
});

// node_modules/semver/functions/eq.js
var require_eq = __commonJS((exports2, module2) => {
  var compare = require_compare();
  var eq = (a, b, loose) => compare(a, b, loose) === 0;
  module2.exports = eq;
});

// node_modules/semver/functions/diff.js
var require_diff = __commonJS((exports2, module2) => {
  var parse = require_parse2();
  var eq = require_eq();
  var diff = (version1, version2) => {
    if (eq(version1, version2)) {
      return null;
    } else {
      const v1 = parse(version1);
      const v2 = parse(version2);
      const hasPre = v1.prerelease.length || v2.prerelease.length;
      const prefix = hasPre ? "pre" : "";
      const defaultResult = hasPre ? "prerelease" : "";
      for (const key in v1) {
        if (key === "major" || key === "minor" || key === "patch") {
          if (v1[key] !== v2[key]) {
            return prefix + key;
          }
        }
      }
      return defaultResult;
    }
  };
  module2.exports = diff;
});

// node_modules/semver/functions/major.js
var require_major = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var major = (a, loose) => new SemVer(a, loose).major;
  module2.exports = major;
});

// node_modules/semver/functions/minor.js
var require_minor = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var minor = (a, loose) => new SemVer(a, loose).minor;
  module2.exports = minor;
});

// node_modules/semver/functions/patch.js
var require_patch = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var patch = (a, loose) => new SemVer(a, loose).patch;
  module2.exports = patch;
});

// node_modules/semver/functions/prerelease.js
var require_prerelease = __commonJS((exports2, module2) => {
  var parse = require_parse2();
  var prerelease = (version, options) => {
    const parsed = parse(version, options);
    return parsed && parsed.prerelease.length ? parsed.prerelease : null;
  };
  module2.exports = prerelease;
});

// node_modules/semver/functions/rcompare.js
var require_rcompare = __commonJS((exports2, module2) => {
  var compare = require_compare();
  var rcompare = (a, b, loose) => compare(b, a, loose);
  module2.exports = rcompare;
});

// node_modules/semver/functions/compare-loose.js
var require_compare_loose = __commonJS((exports2, module2) => {
  var compare = require_compare();
  var compareLoose = (a, b) => compare(a, b, true);
  module2.exports = compareLoose;
});

// node_modules/semver/functions/compare-build.js
var require_compare_build = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var compareBuild = (a, b, loose) => {
    const versionA = new SemVer(a, loose);
    const versionB = new SemVer(b, loose);
    return versionA.compare(versionB) || versionA.compareBuild(versionB);
  };
  module2.exports = compareBuild;
});

// node_modules/semver/functions/sort.js
var require_sort = __commonJS((exports2, module2) => {
  var compareBuild = require_compare_build();
  var sort = (list, loose) => list.sort((a, b) => compareBuild(a, b, loose));
  module2.exports = sort;
});

// node_modules/semver/functions/rsort.js
var require_rsort = __commonJS((exports2, module2) => {
  var compareBuild = require_compare_build();
  var rsort = (list, loose) => list.sort((a, b) => compareBuild(b, a, loose));
  module2.exports = rsort;
});

// node_modules/semver/functions/gt.js
var require_gt = __commonJS((exports2, module2) => {
  var compare = require_compare();
  var gt = (a, b, loose) => compare(a, b, loose) > 0;
  module2.exports = gt;
});

// node_modules/semver/functions/lt.js
var require_lt = __commonJS((exports2, module2) => {
  var compare = require_compare();
  var lt = (a, b, loose) => compare(a, b, loose) < 0;
  module2.exports = lt;
});

// node_modules/semver/functions/neq.js
var require_neq = __commonJS((exports2, module2) => {
  var compare = require_compare();
  var neq = (a, b, loose) => compare(a, b, loose) !== 0;
  module2.exports = neq;
});

// node_modules/semver/functions/gte.js
var require_gte = __commonJS((exports2, module2) => {
  var compare = require_compare();
  var gte = (a, b, loose) => compare(a, b, loose) >= 0;
  module2.exports = gte;
});

// node_modules/semver/functions/lte.js
var require_lte = __commonJS((exports2, module2) => {
  var compare = require_compare();
  var lte = (a, b, loose) => compare(a, b, loose) <= 0;
  module2.exports = lte;
});

// node_modules/semver/functions/cmp.js
var require_cmp = __commonJS((exports2, module2) => {
  var eq = require_eq();
  var neq = require_neq();
  var gt = require_gt();
  var gte = require_gte();
  var lt = require_lt();
  var lte = require_lte();
  var cmp = (a, op, b, loose) => {
    switch (op) {
      case "===":
        if (typeof a === "object")
          a = a.version;
        if (typeof b === "object")
          b = b.version;
        return a === b;
      case "!==":
        if (typeof a === "object")
          a = a.version;
        if (typeof b === "object")
          b = b.version;
        return a !== b;
      case "":
      case "=":
      case "==":
        return eq(a, b, loose);
      case "!=":
        return neq(a, b, loose);
      case ">":
        return gt(a, b, loose);
      case ">=":
        return gte(a, b, loose);
      case "<":
        return lt(a, b, loose);
      case "<=":
        return lte(a, b, loose);
      default:
        throw new TypeError(`Invalid operator: ${op}`);
    }
  };
  module2.exports = cmp;
});

// node_modules/semver/functions/coerce.js
var require_coerce = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var parse = require_parse2();
  var {re, t} = require_re();
  var coerce = (version, options) => {
    if (version instanceof SemVer) {
      return version;
    }
    if (typeof version === "number") {
      version = String(version);
    }
    if (typeof version !== "string") {
      return null;
    }
    options = options || {};
    let match = null;
    if (!options.rtl) {
      match = version.match(re[t.COERCE]);
    } else {
      let next;
      while ((next = re[t.COERCERTL].exec(version)) && (!match || match.index + match[0].length !== version.length)) {
        if (!match || next.index + next[0].length !== match.index + match[0].length) {
          match = next;
        }
        re[t.COERCERTL].lastIndex = next.index + next[1].length + next[2].length;
      }
      re[t.COERCERTL].lastIndex = -1;
    }
    if (match === null)
      return null;
    return parse(`${match[2]}.${match[3] || "0"}.${match[4] || "0"}`, options);
  };
  module2.exports = coerce;
});

// node_modules/yallist/iterator.js
var require_iterator = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = function(Yallist) {
    Yallist.prototype[Symbol.iterator] = function* () {
      for (let walker = this.head; walker; walker = walker.next) {
        yield walker.value;
      }
    };
  };
});

// node_modules/yallist/yallist.js
var require_yallist = __commonJS((exports2, module2) => {
  "use strict";
  module2.exports = Yallist;
  Yallist.Node = Node;
  Yallist.create = Yallist;
  function Yallist(list) {
    var self2 = this;
    if (!(self2 instanceof Yallist)) {
      self2 = new Yallist();
    }
    self2.tail = null;
    self2.head = null;
    self2.length = 0;
    if (list && typeof list.forEach === "function") {
      list.forEach(function(item) {
        self2.push(item);
      });
    } else if (arguments.length > 0) {
      for (var i = 0, l = arguments.length; i < l; i++) {
        self2.push(arguments[i]);
      }
    }
    return self2;
  }
  Yallist.prototype.removeNode = function(node) {
    if (node.list !== this) {
      throw new Error("removing node which does not belong to this list");
    }
    var next = node.next;
    var prev = node.prev;
    if (next) {
      next.prev = prev;
    }
    if (prev) {
      prev.next = next;
    }
    if (node === this.head) {
      this.head = next;
    }
    if (node === this.tail) {
      this.tail = prev;
    }
    node.list.length--;
    node.next = null;
    node.prev = null;
    node.list = null;
    return next;
  };
  Yallist.prototype.unshiftNode = function(node) {
    if (node === this.head) {
      return;
    }
    if (node.list) {
      node.list.removeNode(node);
    }
    var head = this.head;
    node.list = this;
    node.next = head;
    if (head) {
      head.prev = node;
    }
    this.head = node;
    if (!this.tail) {
      this.tail = node;
    }
    this.length++;
  };
  Yallist.prototype.pushNode = function(node) {
    if (node === this.tail) {
      return;
    }
    if (node.list) {
      node.list.removeNode(node);
    }
    var tail = this.tail;
    node.list = this;
    node.prev = tail;
    if (tail) {
      tail.next = node;
    }
    this.tail = node;
    if (!this.head) {
      this.head = node;
    }
    this.length++;
  };
  Yallist.prototype.push = function() {
    for (var i = 0, l = arguments.length; i < l; i++) {
      push(this, arguments[i]);
    }
    return this.length;
  };
  Yallist.prototype.unshift = function() {
    for (var i = 0, l = arguments.length; i < l; i++) {
      unshift(this, arguments[i]);
    }
    return this.length;
  };
  Yallist.prototype.pop = function() {
    if (!this.tail) {
      return void 0;
    }
    var res = this.tail.value;
    this.tail = this.tail.prev;
    if (this.tail) {
      this.tail.next = null;
    } else {
      this.head = null;
    }
    this.length--;
    return res;
  };
  Yallist.prototype.shift = function() {
    if (!this.head) {
      return void 0;
    }
    var res = this.head.value;
    this.head = this.head.next;
    if (this.head) {
      this.head.prev = null;
    } else {
      this.tail = null;
    }
    this.length--;
    return res;
  };
  Yallist.prototype.forEach = function(fn, thisp) {
    thisp = thisp || this;
    for (var walker = this.head, i = 0; walker !== null; i++) {
      fn.call(thisp, walker.value, i, this);
      walker = walker.next;
    }
  };
  Yallist.prototype.forEachReverse = function(fn, thisp) {
    thisp = thisp || this;
    for (var walker = this.tail, i = this.length - 1; walker !== null; i--) {
      fn.call(thisp, walker.value, i, this);
      walker = walker.prev;
    }
  };
  Yallist.prototype.get = function(n) {
    for (var i = 0, walker = this.head; walker !== null && i < n; i++) {
      walker = walker.next;
    }
    if (i === n && walker !== null) {
      return walker.value;
    }
  };
  Yallist.prototype.getReverse = function(n) {
    for (var i = 0, walker = this.tail; walker !== null && i < n; i++) {
      walker = walker.prev;
    }
    if (i === n && walker !== null) {
      return walker.value;
    }
  };
  Yallist.prototype.map = function(fn, thisp) {
    thisp = thisp || this;
    var res = new Yallist();
    for (var walker = this.head; walker !== null; ) {
      res.push(fn.call(thisp, walker.value, this));
      walker = walker.next;
    }
    return res;
  };
  Yallist.prototype.mapReverse = function(fn, thisp) {
    thisp = thisp || this;
    var res = new Yallist();
    for (var walker = this.tail; walker !== null; ) {
      res.push(fn.call(thisp, walker.value, this));
      walker = walker.prev;
    }
    return res;
  };
  Yallist.prototype.reduce = function(fn, initial) {
    var acc;
    var walker = this.head;
    if (arguments.length > 1) {
      acc = initial;
    } else if (this.head) {
      walker = this.head.next;
      acc = this.head.value;
    } else {
      throw new TypeError("Reduce of empty list with no initial value");
    }
    for (var i = 0; walker !== null; i++) {
      acc = fn(acc, walker.value, i);
      walker = walker.next;
    }
    return acc;
  };
  Yallist.prototype.reduceReverse = function(fn, initial) {
    var acc;
    var walker = this.tail;
    if (arguments.length > 1) {
      acc = initial;
    } else if (this.tail) {
      walker = this.tail.prev;
      acc = this.tail.value;
    } else {
      throw new TypeError("Reduce of empty list with no initial value");
    }
    for (var i = this.length - 1; walker !== null; i--) {
      acc = fn(acc, walker.value, i);
      walker = walker.prev;
    }
    return acc;
  };
  Yallist.prototype.toArray = function() {
    var arr = new Array(this.length);
    for (var i = 0, walker = this.head; walker !== null; i++) {
      arr[i] = walker.value;
      walker = walker.next;
    }
    return arr;
  };
  Yallist.prototype.toArrayReverse = function() {
    var arr = new Array(this.length);
    for (var i = 0, walker = this.tail; walker !== null; i++) {
      arr[i] = walker.value;
      walker = walker.prev;
    }
    return arr;
  };
  Yallist.prototype.slice = function(from, to) {
    to = to || this.length;
    if (to < 0) {
      to += this.length;
    }
    from = from || 0;
    if (from < 0) {
      from += this.length;
    }
    var ret = new Yallist();
    if (to < from || to < 0) {
      return ret;
    }
    if (from < 0) {
      from = 0;
    }
    if (to > this.length) {
      to = this.length;
    }
    for (var i = 0, walker = this.head; walker !== null && i < from; i++) {
      walker = walker.next;
    }
    for (; walker !== null && i < to; i++, walker = walker.next) {
      ret.push(walker.value);
    }
    return ret;
  };
  Yallist.prototype.sliceReverse = function(from, to) {
    to = to || this.length;
    if (to < 0) {
      to += this.length;
    }
    from = from || 0;
    if (from < 0) {
      from += this.length;
    }
    var ret = new Yallist();
    if (to < from || to < 0) {
      return ret;
    }
    if (from < 0) {
      from = 0;
    }
    if (to > this.length) {
      to = this.length;
    }
    for (var i = this.length, walker = this.tail; walker !== null && i > to; i--) {
      walker = walker.prev;
    }
    for (; walker !== null && i > from; i--, walker = walker.prev) {
      ret.push(walker.value);
    }
    return ret;
  };
  Yallist.prototype.splice = function(start, deleteCount, ...nodes) {
    if (start > this.length) {
      start = this.length - 1;
    }
    if (start < 0) {
      start = this.length + start;
    }
    for (var i = 0, walker = this.head; walker !== null && i < start; i++) {
      walker = walker.next;
    }
    var ret = [];
    for (var i = 0; walker && i < deleteCount; i++) {
      ret.push(walker.value);
      walker = this.removeNode(walker);
    }
    if (walker === null) {
      walker = this.tail;
    }
    if (walker !== this.head && walker !== this.tail) {
      walker = walker.prev;
    }
    for (var i = 0; i < nodes.length; i++) {
      walker = insert(this, walker, nodes[i]);
    }
    return ret;
  };
  Yallist.prototype.reverse = function() {
    var head = this.head;
    var tail = this.tail;
    for (var walker = head; walker !== null; walker = walker.prev) {
      var p = walker.prev;
      walker.prev = walker.next;
      walker.next = p;
    }
    this.head = tail;
    this.tail = head;
    return this;
  };
  function insert(self2, node, value) {
    var inserted = node === self2.head ? new Node(value, null, node, self2) : new Node(value, node, node.next, self2);
    if (inserted.next === null) {
      self2.tail = inserted;
    }
    if (inserted.prev === null) {
      self2.head = inserted;
    }
    self2.length++;
    return inserted;
  }
  function push(self2, item) {
    self2.tail = new Node(item, self2.tail, null, self2);
    if (!self2.head) {
      self2.head = self2.tail;
    }
    self2.length++;
  }
  function unshift(self2, item) {
    self2.head = new Node(item, null, self2.head, self2);
    if (!self2.tail) {
      self2.tail = self2.head;
    }
    self2.length++;
  }
  function Node(value, prev, next, list) {
    if (!(this instanceof Node)) {
      return new Node(value, prev, next, list);
    }
    this.list = list;
    this.value = value;
    if (prev) {
      prev.next = this;
      this.prev = prev;
    } else {
      this.prev = null;
    }
    if (next) {
      next.prev = this;
      this.next = next;
    } else {
      this.next = null;
    }
  }
  try {
    require_iterator()(Yallist);
  } catch (er) {
  }
});

// node_modules/lru-cache/index.js
var require_lru_cache = __commonJS((exports2, module2) => {
  "use strict";
  var Yallist = require_yallist();
  var MAX = Symbol("max");
  var LENGTH = Symbol("length");
  var LENGTH_CALCULATOR = Symbol("lengthCalculator");
  var ALLOW_STALE = Symbol("allowStale");
  var MAX_AGE = Symbol("maxAge");
  var DISPOSE = Symbol("dispose");
  var NO_DISPOSE_ON_SET = Symbol("noDisposeOnSet");
  var LRU_LIST = Symbol("lruList");
  var CACHE = Symbol("cache");
  var UPDATE_AGE_ON_GET = Symbol("updateAgeOnGet");
  var naiveLength = () => 1;
  var LRUCache = class {
    constructor(options) {
      if (typeof options === "number")
        options = {max: options};
      if (!options)
        options = {};
      if (options.max && (typeof options.max !== "number" || options.max < 0))
        throw new TypeError("max must be a non-negative number");
      const max = this[MAX] = options.max || Infinity;
      const lc = options.length || naiveLength;
      this[LENGTH_CALCULATOR] = typeof lc !== "function" ? naiveLength : lc;
      this[ALLOW_STALE] = options.stale || false;
      if (options.maxAge && typeof options.maxAge !== "number")
        throw new TypeError("maxAge must be a number");
      this[MAX_AGE] = options.maxAge || 0;
      this[DISPOSE] = options.dispose;
      this[NO_DISPOSE_ON_SET] = options.noDisposeOnSet || false;
      this[UPDATE_AGE_ON_GET] = options.updateAgeOnGet || false;
      this.reset();
    }
    set max(mL) {
      if (typeof mL !== "number" || mL < 0)
        throw new TypeError("max must be a non-negative number");
      this[MAX] = mL || Infinity;
      trim(this);
    }
    get max() {
      return this[MAX];
    }
    set allowStale(allowStale) {
      this[ALLOW_STALE] = !!allowStale;
    }
    get allowStale() {
      return this[ALLOW_STALE];
    }
    set maxAge(mA) {
      if (typeof mA !== "number")
        throw new TypeError("maxAge must be a non-negative number");
      this[MAX_AGE] = mA;
      trim(this);
    }
    get maxAge() {
      return this[MAX_AGE];
    }
    set lengthCalculator(lC) {
      if (typeof lC !== "function")
        lC = naiveLength;
      if (lC !== this[LENGTH_CALCULATOR]) {
        this[LENGTH_CALCULATOR] = lC;
        this[LENGTH] = 0;
        this[LRU_LIST].forEach((hit) => {
          hit.length = this[LENGTH_CALCULATOR](hit.value, hit.key);
          this[LENGTH] += hit.length;
        });
      }
      trim(this);
    }
    get lengthCalculator() {
      return this[LENGTH_CALCULATOR];
    }
    get length() {
      return this[LENGTH];
    }
    get itemCount() {
      return this[LRU_LIST].length;
    }
    rforEach(fn, thisp) {
      thisp = thisp || this;
      for (let walker = this[LRU_LIST].tail; walker !== null; ) {
        const prev = walker.prev;
        forEachStep(this, fn, walker, thisp);
        walker = prev;
      }
    }
    forEach(fn, thisp) {
      thisp = thisp || this;
      for (let walker = this[LRU_LIST].head; walker !== null; ) {
        const next = walker.next;
        forEachStep(this, fn, walker, thisp);
        walker = next;
      }
    }
    keys() {
      return this[LRU_LIST].toArray().map((k) => k.key);
    }
    values() {
      return this[LRU_LIST].toArray().map((k) => k.value);
    }
    reset() {
      if (this[DISPOSE] && this[LRU_LIST] && this[LRU_LIST].length) {
        this[LRU_LIST].forEach((hit) => this[DISPOSE](hit.key, hit.value));
      }
      this[CACHE] = new Map();
      this[LRU_LIST] = new Yallist();
      this[LENGTH] = 0;
    }
    dump() {
      return this[LRU_LIST].map((hit) => isStale(this, hit) ? false : {
        k: hit.key,
        v: hit.value,
        e: hit.now + (hit.maxAge || 0)
      }).toArray().filter((h) => h);
    }
    dumpLru() {
      return this[LRU_LIST];
    }
    set(key, value, maxAge) {
      maxAge = maxAge || this[MAX_AGE];
      if (maxAge && typeof maxAge !== "number")
        throw new TypeError("maxAge must be a number");
      const now = maxAge ? Date.now() : 0;
      const len = this[LENGTH_CALCULATOR](value, key);
      if (this[CACHE].has(key)) {
        if (len > this[MAX]) {
          del(this, this[CACHE].get(key));
          return false;
        }
        const node = this[CACHE].get(key);
        const item = node.value;
        if (this[DISPOSE]) {
          if (!this[NO_DISPOSE_ON_SET])
            this[DISPOSE](key, item.value);
        }
        item.now = now;
        item.maxAge = maxAge;
        item.value = value;
        this[LENGTH] += len - item.length;
        item.length = len;
        this.get(key);
        trim(this);
        return true;
      }
      const hit = new Entry(key, value, len, now, maxAge);
      if (hit.length > this[MAX]) {
        if (this[DISPOSE])
          this[DISPOSE](key, value);
        return false;
      }
      this[LENGTH] += hit.length;
      this[LRU_LIST].unshift(hit);
      this[CACHE].set(key, this[LRU_LIST].head);
      trim(this);
      return true;
    }
    has(key) {
      if (!this[CACHE].has(key))
        return false;
      const hit = this[CACHE].get(key).value;
      return !isStale(this, hit);
    }
    get(key) {
      return get(this, key, true);
    }
    peek(key) {
      return get(this, key, false);
    }
    pop() {
      const node = this[LRU_LIST].tail;
      if (!node)
        return null;
      del(this, node);
      return node.value;
    }
    del(key) {
      del(this, this[CACHE].get(key));
    }
    load(arr) {
      this.reset();
      const now = Date.now();
      for (let l = arr.length - 1; l >= 0; l--) {
        const hit = arr[l];
        const expiresAt = hit.e || 0;
        if (expiresAt === 0)
          this.set(hit.k, hit.v);
        else {
          const maxAge = expiresAt - now;
          if (maxAge > 0) {
            this.set(hit.k, hit.v, maxAge);
          }
        }
      }
    }
    prune() {
      this[CACHE].forEach((value, key) => get(this, key, false));
    }
  };
  var get = (self2, key, doUse) => {
    const node = self2[CACHE].get(key);
    if (node) {
      const hit = node.value;
      if (isStale(self2, hit)) {
        del(self2, node);
        if (!self2[ALLOW_STALE])
          return void 0;
      } else {
        if (doUse) {
          if (self2[UPDATE_AGE_ON_GET])
            node.value.now = Date.now();
          self2[LRU_LIST].unshiftNode(node);
        }
      }
      return hit.value;
    }
  };
  var isStale = (self2, hit) => {
    if (!hit || !hit.maxAge && !self2[MAX_AGE])
      return false;
    const diff = Date.now() - hit.now;
    return hit.maxAge ? diff > hit.maxAge : self2[MAX_AGE] && diff > self2[MAX_AGE];
  };
  var trim = (self2) => {
    if (self2[LENGTH] > self2[MAX]) {
      for (let walker = self2[LRU_LIST].tail; self2[LENGTH] > self2[MAX] && walker !== null; ) {
        const prev = walker.prev;
        del(self2, walker);
        walker = prev;
      }
    }
  };
  var del = (self2, node) => {
    if (node) {
      const hit = node.value;
      if (self2[DISPOSE])
        self2[DISPOSE](hit.key, hit.value);
      self2[LENGTH] -= hit.length;
      self2[CACHE].delete(hit.key);
      self2[LRU_LIST].removeNode(node);
    }
  };
  var Entry = class {
    constructor(key, value, length, now, maxAge) {
      this.key = key;
      this.value = value;
      this.length = length;
      this.now = now;
      this.maxAge = maxAge || 0;
    }
  };
  var forEachStep = (self2, fn, node, thisp) => {
    let hit = node.value;
    if (isStale(self2, hit)) {
      del(self2, node);
      if (!self2[ALLOW_STALE])
        hit = void 0;
    }
    if (hit)
      fn.call(thisp, hit.value, hit.key, self2);
  };
  module2.exports = LRUCache;
});

// node_modules/semver/classes/range.js
var require_range = __commonJS((exports2, module2) => {
  var Range = class {
    constructor(range, options) {
      options = parseOptions(options);
      if (range instanceof Range) {
        if (range.loose === !!options.loose && range.includePrerelease === !!options.includePrerelease) {
          return range;
        } else {
          return new Range(range.raw, options);
        }
      }
      if (range instanceof Comparator) {
        this.raw = range.value;
        this.set = [[range]];
        this.format();
        return this;
      }
      this.options = options;
      this.loose = !!options.loose;
      this.includePrerelease = !!options.includePrerelease;
      this.raw = range;
      this.set = range.split(/\s*\|\|\s*/).map((range2) => this.parseRange(range2.trim())).filter((c) => c.length);
      if (!this.set.length) {
        throw new TypeError(`Invalid SemVer Range: ${range}`);
      }
      if (this.set.length > 1) {
        const first = this.set[0];
        this.set = this.set.filter((c) => !isNullSet(c[0]));
        if (this.set.length === 0)
          this.set = [first];
        else if (this.set.length > 1) {
          for (const c of this.set) {
            if (c.length === 1 && isAny(c[0])) {
              this.set = [c];
              break;
            }
          }
        }
      }
      this.format();
    }
    format() {
      this.range = this.set.map((comps) => {
        return comps.join(" ").trim();
      }).join("||").trim();
      return this.range;
    }
    toString() {
      return this.range;
    }
    parseRange(range) {
      range = range.trim();
      const memoOpts = Object.keys(this.options).join(",");
      const memoKey = `parseRange:${memoOpts}:${range}`;
      const cached = cache.get(memoKey);
      if (cached)
        return cached;
      const loose = this.options.loose;
      const hr = loose ? re[t.HYPHENRANGELOOSE] : re[t.HYPHENRANGE];
      range = range.replace(hr, hyphenReplace(this.options.includePrerelease));
      debug("hyphen replace", range);
      range = range.replace(re[t.COMPARATORTRIM], comparatorTrimReplace);
      debug("comparator trim", range, re[t.COMPARATORTRIM]);
      range = range.replace(re[t.TILDETRIM], tildeTrimReplace);
      range = range.replace(re[t.CARETTRIM], caretTrimReplace);
      range = range.split(/\s+/).join(" ");
      const compRe = loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR];
      const rangeList = range.split(" ").map((comp) => parseComparator(comp, this.options)).join(" ").split(/\s+/).map((comp) => replaceGTE0(comp, this.options)).filter(this.options.loose ? (comp) => !!comp.match(compRe) : () => true).map((comp) => new Comparator(comp, this.options));
      const l = rangeList.length;
      const rangeMap = new Map();
      for (const comp of rangeList) {
        if (isNullSet(comp))
          return [comp];
        rangeMap.set(comp.value, comp);
      }
      if (rangeMap.size > 1 && rangeMap.has(""))
        rangeMap.delete("");
      const result = [...rangeMap.values()];
      cache.set(memoKey, result);
      return result;
    }
    intersects(range, options) {
      if (!(range instanceof Range)) {
        throw new TypeError("a Range is required");
      }
      return this.set.some((thisComparators) => {
        return isSatisfiable(thisComparators, options) && range.set.some((rangeComparators) => {
          return isSatisfiable(rangeComparators, options) && thisComparators.every((thisComparator) => {
            return rangeComparators.every((rangeComparator) => {
              return thisComparator.intersects(rangeComparator, options);
            });
          });
        });
      });
    }
    test(version) {
      if (!version) {
        return false;
      }
      if (typeof version === "string") {
        try {
          version = new SemVer(version, this.options);
        } catch (er) {
          return false;
        }
      }
      for (let i = 0; i < this.set.length; i++) {
        if (testSet(this.set[i], version, this.options)) {
          return true;
        }
      }
      return false;
    }
  };
  module2.exports = Range;
  var LRU = require_lru_cache();
  var cache = new LRU({max: 1e3});
  var parseOptions = require_parse_options();
  var Comparator = require_comparator();
  var debug = require_debug();
  var SemVer = require_semver2();
  var {
    re,
    t,
    comparatorTrimReplace,
    tildeTrimReplace,
    caretTrimReplace
  } = require_re();
  var isNullSet = (c) => c.value === "<0.0.0-0";
  var isAny = (c) => c.value === "";
  var isSatisfiable = (comparators, options) => {
    let result = true;
    const remainingComparators = comparators.slice();
    let testComparator = remainingComparators.pop();
    while (result && remainingComparators.length) {
      result = remainingComparators.every((otherComparator) => {
        return testComparator.intersects(otherComparator, options);
      });
      testComparator = remainingComparators.pop();
    }
    return result;
  };
  var parseComparator = (comp, options) => {
    debug("comp", comp, options);
    comp = replaceCarets(comp, options);
    debug("caret", comp);
    comp = replaceTildes(comp, options);
    debug("tildes", comp);
    comp = replaceXRanges(comp, options);
    debug("xrange", comp);
    comp = replaceStars(comp, options);
    debug("stars", comp);
    return comp;
  };
  var isX = (id) => !id || id.toLowerCase() === "x" || id === "*";
  var replaceTildes = (comp, options) => comp.trim().split(/\s+/).map((comp2) => {
    return replaceTilde(comp2, options);
  }).join(" ");
  var replaceTilde = (comp, options) => {
    const r = options.loose ? re[t.TILDELOOSE] : re[t.TILDE];
    return comp.replace(r, (_, M, m, p, pr) => {
      debug("tilde", comp, _, M, m, p, pr);
      let ret;
      if (isX(M)) {
        ret = "";
      } else if (isX(m)) {
        ret = `>=${M}.0.0 <${+M + 1}.0.0-0`;
      } else if (isX(p)) {
        ret = `>=${M}.${m}.0 <${M}.${+m + 1}.0-0`;
      } else if (pr) {
        debug("replaceTilde pr", pr);
        ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
      } else {
        ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
      }
      debug("tilde return", ret);
      return ret;
    });
  };
  var replaceCarets = (comp, options) => comp.trim().split(/\s+/).map((comp2) => {
    return replaceCaret(comp2, options);
  }).join(" ");
  var replaceCaret = (comp, options) => {
    debug("caret", comp, options);
    const r = options.loose ? re[t.CARETLOOSE] : re[t.CARET];
    const z = options.includePrerelease ? "-0" : "";
    return comp.replace(r, (_, M, m, p, pr) => {
      debug("caret", comp, _, M, m, p, pr);
      let ret;
      if (isX(M)) {
        ret = "";
      } else if (isX(m)) {
        ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
      } else if (isX(p)) {
        if (M === "0") {
          ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
        } else {
          ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`;
        }
      } else if (pr) {
        debug("replaceCaret pr", pr);
        if (M === "0") {
          if (m === "0") {
            ret = `>=${M}.${m}.${p}-${pr} <${M}.${m}.${+p + 1}-0`;
          } else {
            ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
          }
        } else {
          ret = `>=${M}.${m}.${p}-${pr} <${+M + 1}.0.0-0`;
        }
      } else {
        debug("no pr");
        if (M === "0") {
          if (m === "0") {
            ret = `>=${M}.${m}.${p}${z} <${M}.${m}.${+p + 1}-0`;
          } else {
            ret = `>=${M}.${m}.${p}${z} <${M}.${+m + 1}.0-0`;
          }
        } else {
          ret = `>=${M}.${m}.${p} <${+M + 1}.0.0-0`;
        }
      }
      debug("caret return", ret);
      return ret;
    });
  };
  var replaceXRanges = (comp, options) => {
    debug("replaceXRanges", comp, options);
    return comp.split(/\s+/).map((comp2) => {
      return replaceXRange(comp2, options);
    }).join(" ");
  };
  var replaceXRange = (comp, options) => {
    comp = comp.trim();
    const r = options.loose ? re[t.XRANGELOOSE] : re[t.XRANGE];
    return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
      debug("xRange", comp, ret, gtlt, M, m, p, pr);
      const xM = isX(M);
      const xm = xM || isX(m);
      const xp = xm || isX(p);
      const anyX = xp;
      if (gtlt === "=" && anyX) {
        gtlt = "";
      }
      pr = options.includePrerelease ? "-0" : "";
      if (xM) {
        if (gtlt === ">" || gtlt === "<") {
          ret = "<0.0.0-0";
        } else {
          ret = "*";
        }
      } else if (gtlt && anyX) {
        if (xm) {
          m = 0;
        }
        p = 0;
        if (gtlt === ">") {
          gtlt = ">=";
          if (xm) {
            M = +M + 1;
            m = 0;
            p = 0;
          } else {
            m = +m + 1;
            p = 0;
          }
        } else if (gtlt === "<=") {
          gtlt = "<";
          if (xm) {
            M = +M + 1;
          } else {
            m = +m + 1;
          }
        }
        if (gtlt === "<")
          pr = "-0";
        ret = `${gtlt + M}.${m}.${p}${pr}`;
      } else if (xm) {
        ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`;
      } else if (xp) {
        ret = `>=${M}.${m}.0${pr} <${M}.${+m + 1}.0-0`;
      }
      debug("xRange return", ret);
      return ret;
    });
  };
  var replaceStars = (comp, options) => {
    debug("replaceStars", comp, options);
    return comp.trim().replace(re[t.STAR], "");
  };
  var replaceGTE0 = (comp, options) => {
    debug("replaceGTE0", comp, options);
    return comp.trim().replace(re[options.includePrerelease ? t.GTE0PRE : t.GTE0], "");
  };
  var hyphenReplace = (incPr) => ($0, from, fM, fm, fp, fpr, fb, to, tM, tm, tp, tpr, tb) => {
    if (isX(fM)) {
      from = "";
    } else if (isX(fm)) {
      from = `>=${fM}.0.0${incPr ? "-0" : ""}`;
    } else if (isX(fp)) {
      from = `>=${fM}.${fm}.0${incPr ? "-0" : ""}`;
    } else if (fpr) {
      from = `>=${from}`;
    } else {
      from = `>=${from}${incPr ? "-0" : ""}`;
    }
    if (isX(tM)) {
      to = "";
    } else if (isX(tm)) {
      to = `<${+tM + 1}.0.0-0`;
    } else if (isX(tp)) {
      to = `<${tM}.${+tm + 1}.0-0`;
    } else if (tpr) {
      to = `<=${tM}.${tm}.${tp}-${tpr}`;
    } else if (incPr) {
      to = `<${tM}.${tm}.${+tp + 1}-0`;
    } else {
      to = `<=${to}`;
    }
    return `${from} ${to}`.trim();
  };
  var testSet = (set, version, options) => {
    for (let i = 0; i < set.length; i++) {
      if (!set[i].test(version)) {
        return false;
      }
    }
    if (version.prerelease.length && !options.includePrerelease) {
      for (let i = 0; i < set.length; i++) {
        debug(set[i].semver);
        if (set[i].semver === Comparator.ANY) {
          continue;
        }
        if (set[i].semver.prerelease.length > 0) {
          const allowed = set[i].semver;
          if (allowed.major === version.major && allowed.minor === version.minor && allowed.patch === version.patch) {
            return true;
          }
        }
      }
      return false;
    }
    return true;
  };
});

// node_modules/semver/classes/comparator.js
var require_comparator = __commonJS((exports2, module2) => {
  var ANY = Symbol("SemVer ANY");
  var Comparator = class {
    static get ANY() {
      return ANY;
    }
    constructor(comp, options) {
      options = parseOptions(options);
      if (comp instanceof Comparator) {
        if (comp.loose === !!options.loose) {
          return comp;
        } else {
          comp = comp.value;
        }
      }
      debug("comparator", comp, options);
      this.options = options;
      this.loose = !!options.loose;
      this.parse(comp);
      if (this.semver === ANY) {
        this.value = "";
      } else {
        this.value = this.operator + this.semver.version;
      }
      debug("comp", this);
    }
    parse(comp) {
      const r = this.options.loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR];
      const m = comp.match(r);
      if (!m) {
        throw new TypeError(`Invalid comparator: ${comp}`);
      }
      this.operator = m[1] !== void 0 ? m[1] : "";
      if (this.operator === "=") {
        this.operator = "";
      }
      if (!m[2]) {
        this.semver = ANY;
      } else {
        this.semver = new SemVer(m[2], this.options.loose);
      }
    }
    toString() {
      return this.value;
    }
    test(version) {
      debug("Comparator.test", version, this.options.loose);
      if (this.semver === ANY || version === ANY) {
        return true;
      }
      if (typeof version === "string") {
        try {
          version = new SemVer(version, this.options);
        } catch (er) {
          return false;
        }
      }
      return cmp(version, this.operator, this.semver, this.options);
    }
    intersects(comp, options) {
      if (!(comp instanceof Comparator)) {
        throw new TypeError("a Comparator is required");
      }
      if (!options || typeof options !== "object") {
        options = {
          loose: !!options,
          includePrerelease: false
        };
      }
      if (this.operator === "") {
        if (this.value === "") {
          return true;
        }
        return new Range(comp.value, options).test(this.value);
      } else if (comp.operator === "") {
        if (comp.value === "") {
          return true;
        }
        return new Range(this.value, options).test(comp.semver);
      }
      const sameDirectionIncreasing = (this.operator === ">=" || this.operator === ">") && (comp.operator === ">=" || comp.operator === ">");
      const sameDirectionDecreasing = (this.operator === "<=" || this.operator === "<") && (comp.operator === "<=" || comp.operator === "<");
      const sameSemVer = this.semver.version === comp.semver.version;
      const differentDirectionsInclusive = (this.operator === ">=" || this.operator === "<=") && (comp.operator === ">=" || comp.operator === "<=");
      const oppositeDirectionsLessThan = cmp(this.semver, "<", comp.semver, options) && (this.operator === ">=" || this.operator === ">") && (comp.operator === "<=" || comp.operator === "<");
      const oppositeDirectionsGreaterThan = cmp(this.semver, ">", comp.semver, options) && (this.operator === "<=" || this.operator === "<") && (comp.operator === ">=" || comp.operator === ">");
      return sameDirectionIncreasing || sameDirectionDecreasing || sameSemVer && differentDirectionsInclusive || oppositeDirectionsLessThan || oppositeDirectionsGreaterThan;
    }
  };
  module2.exports = Comparator;
  var parseOptions = require_parse_options();
  var {re, t} = require_re();
  var cmp = require_cmp();
  var debug = require_debug();
  var SemVer = require_semver2();
  var Range = require_range();
});

// node_modules/semver/functions/satisfies.js
var require_satisfies = __commonJS((exports2, module2) => {
  var Range = require_range();
  var satisfies = (version, range, options) => {
    try {
      range = new Range(range, options);
    } catch (er) {
      return false;
    }
    return range.test(version);
  };
  module2.exports = satisfies;
});

// node_modules/semver/ranges/to-comparators.js
var require_to_comparators = __commonJS((exports2, module2) => {
  var Range = require_range();
  var toComparators = (range, options) => new Range(range, options).set.map((comp) => comp.map((c) => c.value).join(" ").trim().split(" "));
  module2.exports = toComparators;
});

// node_modules/semver/ranges/max-satisfying.js
var require_max_satisfying = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var Range = require_range();
  var maxSatisfying = (versions, range, options) => {
    let max = null;
    let maxSV = null;
    let rangeObj = null;
    try {
      rangeObj = new Range(range, options);
    } catch (er) {
      return null;
    }
    versions.forEach((v) => {
      if (rangeObj.test(v)) {
        if (!max || maxSV.compare(v) === -1) {
          max = v;
          maxSV = new SemVer(max, options);
        }
      }
    });
    return max;
  };
  module2.exports = maxSatisfying;
});

// node_modules/semver/ranges/min-satisfying.js
var require_min_satisfying = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var Range = require_range();
  var minSatisfying = (versions, range, options) => {
    let min = null;
    let minSV = null;
    let rangeObj = null;
    try {
      rangeObj = new Range(range, options);
    } catch (er) {
      return null;
    }
    versions.forEach((v) => {
      if (rangeObj.test(v)) {
        if (!min || minSV.compare(v) === 1) {
          min = v;
          minSV = new SemVer(min, options);
        }
      }
    });
    return min;
  };
  module2.exports = minSatisfying;
});

// node_modules/semver/ranges/min-version.js
var require_min_version = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var Range = require_range();
  var gt = require_gt();
  var minVersion = (range, loose) => {
    range = new Range(range, loose);
    let minver = new SemVer("0.0.0");
    if (range.test(minver)) {
      return minver;
    }
    minver = new SemVer("0.0.0-0");
    if (range.test(minver)) {
      return minver;
    }
    minver = null;
    for (let i = 0; i < range.set.length; ++i) {
      const comparators = range.set[i];
      let setMin = null;
      comparators.forEach((comparator) => {
        const compver = new SemVer(comparator.semver.version);
        switch (comparator.operator) {
          case ">":
            if (compver.prerelease.length === 0) {
              compver.patch++;
            } else {
              compver.prerelease.push(0);
            }
            compver.raw = compver.format();
          case "":
          case ">=":
            if (!setMin || gt(compver, setMin)) {
              setMin = compver;
            }
            break;
          case "<":
          case "<=":
            break;
          default:
            throw new Error(`Unexpected operation: ${comparator.operator}`);
        }
      });
      if (setMin && (!minver || gt(minver, setMin)))
        minver = setMin;
    }
    if (minver && range.test(minver)) {
      return minver;
    }
    return null;
  };
  module2.exports = minVersion;
});

// node_modules/semver/ranges/valid.js
var require_valid2 = __commonJS((exports2, module2) => {
  var Range = require_range();
  var validRange = (range, options) => {
    try {
      return new Range(range, options).range || "*";
    } catch (er) {
      return null;
    }
  };
  module2.exports = validRange;
});

// node_modules/semver/ranges/outside.js
var require_outside = __commonJS((exports2, module2) => {
  var SemVer = require_semver2();
  var Comparator = require_comparator();
  var {ANY} = Comparator;
  var Range = require_range();
  var satisfies = require_satisfies();
  var gt = require_gt();
  var lt = require_lt();
  var lte = require_lte();
  var gte = require_gte();
  var outside = (version, range, hilo, options) => {
    version = new SemVer(version, options);
    range = new Range(range, options);
    let gtfn, ltefn, ltfn, comp, ecomp;
    switch (hilo) {
      case ">":
        gtfn = gt;
        ltefn = lte;
        ltfn = lt;
        comp = ">";
        ecomp = ">=";
        break;
      case "<":
        gtfn = lt;
        ltefn = gte;
        ltfn = gt;
        comp = "<";
        ecomp = "<=";
        break;
      default:
        throw new TypeError('Must provide a hilo val of "<" or ">"');
    }
    if (satisfies(version, range, options)) {
      return false;
    }
    for (let i = 0; i < range.set.length; ++i) {
      const comparators = range.set[i];
      let high = null;
      let low = null;
      comparators.forEach((comparator) => {
        if (comparator.semver === ANY) {
          comparator = new Comparator(">=0.0.0");
        }
        high = high || comparator;
        low = low || comparator;
        if (gtfn(comparator.semver, high.semver, options)) {
          high = comparator;
        } else if (ltfn(comparator.semver, low.semver, options)) {
          low = comparator;
        }
      });
      if (high.operator === comp || high.operator === ecomp) {
        return false;
      }
      if ((!low.operator || low.operator === comp) && ltefn(version, low.semver)) {
        return false;
      } else if (low.operator === ecomp && ltfn(version, low.semver)) {
        return false;
      }
    }
    return true;
  };
  module2.exports = outside;
});

// node_modules/semver/ranges/gtr.js
var require_gtr = __commonJS((exports2, module2) => {
  var outside = require_outside();
  var gtr = (version, range, options) => outside(version, range, ">", options);
  module2.exports = gtr;
});

// node_modules/semver/ranges/ltr.js
var require_ltr = __commonJS((exports2, module2) => {
  var outside = require_outside();
  var ltr = (version, range, options) => outside(version, range, "<", options);
  module2.exports = ltr;
});

// node_modules/semver/ranges/intersects.js
var require_intersects = __commonJS((exports2, module2) => {
  var Range = require_range();
  var intersects = (r1, r2, options) => {
    r1 = new Range(r1, options);
    r2 = new Range(r2, options);
    return r1.intersects(r2);
  };
  module2.exports = intersects;
});

// node_modules/semver/ranges/simplify.js
var require_simplify = __commonJS((exports2, module2) => {
  var satisfies = require_satisfies();
  var compare = require_compare();
  module2.exports = (versions, range, options) => {
    const set = [];
    let min = null;
    let prev = null;
    const v = versions.sort((a, b) => compare(a, b, options));
    for (const version of v) {
      const included = satisfies(version, range, options);
      if (included) {
        prev = version;
        if (!min)
          min = version;
      } else {
        if (prev) {
          set.push([min, prev]);
        }
        prev = null;
        min = null;
      }
    }
    if (min)
      set.push([min, null]);
    const ranges = [];
    for (const [min2, max] of set) {
      if (min2 === max)
        ranges.push(min2);
      else if (!max && min2 === v[0])
        ranges.push("*");
      else if (!max)
        ranges.push(`>=${min2}`);
      else if (min2 === v[0])
        ranges.push(`<=${max}`);
      else
        ranges.push(`${min2} - ${max}`);
    }
    const simplified = ranges.join(" || ");
    const original = typeof range.raw === "string" ? range.raw : String(range);
    return simplified.length < original.length ? simplified : range;
  };
});

// node_modules/semver/ranges/subset.js
var require_subset = __commonJS((exports2, module2) => {
  var Range = require_range();
  var Comparator = require_comparator();
  var {ANY} = Comparator;
  var satisfies = require_satisfies();
  var compare = require_compare();
  var subset = (sub, dom, options = {}) => {
    if (sub === dom)
      return true;
    sub = new Range(sub, options);
    dom = new Range(dom, options);
    let sawNonNull = false;
    OUTER:
      for (const simpleSub of sub.set) {
        for (const simpleDom of dom.set) {
          const isSub = simpleSubset(simpleSub, simpleDom, options);
          sawNonNull = sawNonNull || isSub !== null;
          if (isSub)
            continue OUTER;
        }
        if (sawNonNull)
          return false;
      }
    return true;
  };
  var simpleSubset = (sub, dom, options) => {
    if (sub === dom)
      return true;
    if (sub.length === 1 && sub[0].semver === ANY) {
      if (dom.length === 1 && dom[0].semver === ANY)
        return true;
      else if (options.includePrerelease)
        sub = [new Comparator(">=0.0.0-0")];
      else
        sub = [new Comparator(">=0.0.0")];
    }
    if (dom.length === 1 && dom[0].semver === ANY) {
      if (options.includePrerelease)
        return true;
      else
        dom = [new Comparator(">=0.0.0")];
    }
    const eqSet = new Set();
    let gt, lt;
    for (const c of sub) {
      if (c.operator === ">" || c.operator === ">=")
        gt = higherGT(gt, c, options);
      else if (c.operator === "<" || c.operator === "<=")
        lt = lowerLT(lt, c, options);
      else
        eqSet.add(c.semver);
    }
    if (eqSet.size > 1)
      return null;
    let gtltComp;
    if (gt && lt) {
      gtltComp = compare(gt.semver, lt.semver, options);
      if (gtltComp > 0)
        return null;
      else if (gtltComp === 0 && (gt.operator !== ">=" || lt.operator !== "<="))
        return null;
    }
    for (const eq of eqSet) {
      if (gt && !satisfies(eq, String(gt), options))
        return null;
      if (lt && !satisfies(eq, String(lt), options))
        return null;
      for (const c of dom) {
        if (!satisfies(eq, String(c), options))
          return false;
      }
      return true;
    }
    let higher, lower;
    let hasDomLT, hasDomGT;
    let needDomLTPre = lt && !options.includePrerelease && lt.semver.prerelease.length ? lt.semver : false;
    let needDomGTPre = gt && !options.includePrerelease && gt.semver.prerelease.length ? gt.semver : false;
    if (needDomLTPre && needDomLTPre.prerelease.length === 1 && lt.operator === "<" && needDomLTPre.prerelease[0] === 0) {
      needDomLTPre = false;
    }
    for (const c of dom) {
      hasDomGT = hasDomGT || c.operator === ">" || c.operator === ">=";
      hasDomLT = hasDomLT || c.operator === "<" || c.operator === "<=";
      if (gt) {
        if (needDomGTPre) {
          if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomGTPre.major && c.semver.minor === needDomGTPre.minor && c.semver.patch === needDomGTPre.patch) {
            needDomGTPre = false;
          }
        }
        if (c.operator === ">" || c.operator === ">=") {
          higher = higherGT(gt, c, options);
          if (higher === c && higher !== gt)
            return false;
        } else if (gt.operator === ">=" && !satisfies(gt.semver, String(c), options))
          return false;
      }
      if (lt) {
        if (needDomLTPre) {
          if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomLTPre.major && c.semver.minor === needDomLTPre.minor && c.semver.patch === needDomLTPre.patch) {
            needDomLTPre = false;
          }
        }
        if (c.operator === "<" || c.operator === "<=") {
          lower = lowerLT(lt, c, options);
          if (lower === c && lower !== lt)
            return false;
        } else if (lt.operator === "<=" && !satisfies(lt.semver, String(c), options))
          return false;
      }
      if (!c.operator && (lt || gt) && gtltComp !== 0)
        return false;
    }
    if (gt && hasDomLT && !lt && gtltComp !== 0)
      return false;
    if (lt && hasDomGT && !gt && gtltComp !== 0)
      return false;
    if (needDomGTPre || needDomLTPre)
      return false;
    return true;
  };
  var higherGT = (a, b, options) => {
    if (!a)
      return b;
    const comp = compare(a.semver, b.semver, options);
    return comp > 0 ? a : comp < 0 ? b : b.operator === ">" && a.operator === ">=" ? b : a;
  };
  var lowerLT = (a, b, options) => {
    if (!a)
      return b;
    const comp = compare(a.semver, b.semver, options);
    return comp < 0 ? a : comp > 0 ? b : b.operator === "<" && a.operator === "<=" ? b : a;
  };
  module2.exports = subset;
});

// node_modules/semver/index.js
var require_semver3 = __commonJS((exports2, module2) => {
  var internalRe = require_re();
  module2.exports = {
    re: internalRe.re,
    src: internalRe.src,
    tokens: internalRe.t,
    SEMVER_SPEC_VERSION: require_constants3().SEMVER_SPEC_VERSION,
    SemVer: require_semver2(),
    compareIdentifiers: require_identifiers().compareIdentifiers,
    rcompareIdentifiers: require_identifiers().rcompareIdentifiers,
    parse: require_parse2(),
    valid: require_valid(),
    clean: require_clean(),
    inc: require_inc(),
    diff: require_diff(),
    major: require_major(),
    minor: require_minor(),
    patch: require_patch(),
    prerelease: require_prerelease(),
    compare: require_compare(),
    rcompare: require_rcompare(),
    compareLoose: require_compare_loose(),
    compareBuild: require_compare_build(),
    sort: require_sort(),
    rsort: require_rsort(),
    gt: require_gt(),
    lt: require_lt(),
    eq: require_eq(),
    neq: require_neq(),
    gte: require_gte(),
    lte: require_lte(),
    cmp: require_cmp(),
    coerce: require_coerce(),
    Comparator: require_comparator(),
    Range: require_range(),
    satisfies: require_satisfies(),
    toComparators: require_to_comparators(),
    maxSatisfying: require_max_satisfying(),
    minSatisfying: require_min_satisfying(),
    minVersion: require_min_version(),
    validRange: require_valid2(),
    outside: require_outside(),
    gtr: require_gtr(),
    ltr: require_ltr(),
    intersects: require_intersects(),
    simplifyRange: require_simplify(),
    subset: require_subset()
  };
});

// node_modules/@opentelemetry/core/build/src/platform/BaseAbstractPlugin.js
var require_BaseAbstractPlugin = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.BaseAbstractPlugin = void 0;
  var BaseAbstractPlugin = class {
    constructor(_tracerName, _tracerVersion) {
      this._tracerName = _tracerName;
      this._tracerVersion = _tracerVersion;
    }
    disable() {
      this.unpatch();
    }
  };
  exports2.BaseAbstractPlugin = BaseAbstractPlugin;
});

// node_modules/@opentelemetry/core/build/src/platform/node/BasePlugin.js
var require_BasePlugin = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.BasePlugin = void 0;
  var api_1 = require_src();
  var semver = require_semver3();
  var path = require("path");
  var BaseAbstractPlugin_1 = require_BaseAbstractPlugin();
  var BasePlugin = class extends BaseAbstractPlugin_1.BaseAbstractPlugin {
    enable(moduleExports, tracerProvider, config) {
      this._moduleExports = moduleExports;
      this._tracer = tracerProvider.getTracer(this._tracerName, this._tracerVersion);
      this._internalFilesExports = this._loadInternalFilesExports();
      if (config)
        this._config = config;
      return this.patch();
    }
    disable() {
      this.unpatch();
    }
    _loadInternalFilesExports() {
      if (!this._internalFilesList)
        return {};
      if (!this.version || !this.moduleName || !this._basedir) {
        api_1.diag.debug("loadInternalFiles failed because one of the required fields was missing: moduleName=%s, version=%s, basedir=%s", this.moduleName, this.version, this._basedir);
        return {};
      }
      const extraModules = {};
      api_1.diag.debug("loadInternalFiles %o", this._internalFilesList);
      Object.keys(this._internalFilesList).forEach((versionRange) => {
        this._loadInternalModule(versionRange, extraModules);
      });
      if (Object.keys(extraModules).length === 0) {
        api_1.diag.debug("No internal files could be loaded for %s@%s", this.moduleName, this.version);
      }
      return extraModules;
    }
    _loadInternalModule(versionRange, outExtraModules) {
      if (semver.satisfies(this.version, versionRange)) {
        if (Object.keys(outExtraModules).length > 0) {
          api_1.diag.warn("Plugin for %s@%s, has overlap version range (%s) for internal files: %o", this.moduleName, this.version, versionRange, this._internalFilesList);
        }
        this._requireInternalFiles(this._internalFilesList[versionRange], this._basedir, outExtraModules);
      }
    }
    _requireInternalFiles(extraModulesList, basedir, outExtraModules) {
      if (!extraModulesList)
        return;
      Object.keys(extraModulesList).forEach((moduleName) => {
        try {
          api_1.diag.debug("loading File %s", extraModulesList[moduleName]);
          outExtraModules[moduleName] = require(path.join(basedir, extraModulesList[moduleName]));
        } catch (e) {
          api_1.diag.error("Could not load internal file %s of module %s. Error: %s", path.join(basedir, extraModulesList[moduleName]), this.moduleName, e.message);
        }
      });
    }
  };
  exports2.BasePlugin = BasePlugin;
});

// node_modules/@opentelemetry/core/build/src/utils/environment.js
var require_environment = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.parseEnvironment = exports2.DEFAULT_ENVIRONMENT = void 0;
  var api_1 = require_src();
  var DEFAULT_LIST_SEPARATOR = ",";
  var ENVIRONMENT_NUMBERS_KEYS = [
    "OTEL_BSP_EXPORT_TIMEOUT",
    "OTEL_BSP_MAX_EXPORT_BATCH_SIZE",
    "OTEL_BSP_MAX_QUEUE_SIZE",
    "OTEL_BSP_SCHEDULE_DELAY",
    "OTEL_SAMPLING_PROBABILITY",
    "OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT",
    "OTEL_SPAN_EVENT_COUNT_LIMIT",
    "OTEL_SPAN_LINK_COUNT_LIMIT"
  ];
  function isEnvVarANumber(key) {
    return ENVIRONMENT_NUMBERS_KEYS.indexOf(key) > -1;
  }
  var ENVIRONMENT_LISTS_KEYS = ["OTEL_NO_PATCH_MODULES"];
  function isEnvVarAList(key) {
    return ENVIRONMENT_LISTS_KEYS.indexOf(key) > -1;
  }
  exports2.DEFAULT_ENVIRONMENT = {
    CONTAINER_NAME: "",
    ECS_CONTAINER_METADATA_URI_V4: "",
    ECS_CONTAINER_METADATA_URI: "",
    HOSTNAME: "",
    KUBERNETES_SERVICE_HOST: "",
    NAMESPACE: "",
    OTEL_EXPORTER_JAEGER_AGENT_HOST: "",
    OTEL_EXPORTER_JAEGER_ENDPOINT: "",
    OTEL_EXPORTER_JAEGER_PASSWORD: "",
    OTEL_EXPORTER_JAEGER_USER: "",
    OTEL_LOG_LEVEL: api_1.DiagLogLevel.INFO,
    OTEL_NO_PATCH_MODULES: [],
    OTEL_RESOURCE_ATTRIBUTES: "",
    OTEL_SAMPLING_PROBABILITY: 1,
    OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT: 1e3,
    OTEL_SPAN_EVENT_COUNT_LIMIT: 1e3,
    OTEL_SPAN_LINK_COUNT_LIMIT: 1e3,
    OTEL_BSP_EXPORT_TIMEOUT: 3e4,
    OTEL_BSP_MAX_EXPORT_BATCH_SIZE: 512,
    OTEL_BSP_MAX_QUEUE_SIZE: 2048,
    OTEL_BSP_SCHEDULE_DELAY: 5e3
  };
  function parseNumber(name, environment, values, min = -Infinity, max = Infinity) {
    if (typeof values[name] !== "undefined") {
      const value = Number(values[name]);
      if (!isNaN(value)) {
        if (value < min) {
          environment[name] = min;
        } else if (value > max) {
          environment[name] = max;
        } else {
          environment[name] = value;
        }
      }
    }
  }
  function parseStringList(name, output, input, separator = DEFAULT_LIST_SEPARATOR) {
    const givenValue = input[name];
    if (typeof givenValue === "string") {
      output[name] = givenValue.split(separator).map((v) => v.trim());
    }
  }
  var logLevelMap = {
    ALL: api_1.DiagLogLevel.ALL,
    VERBOSE: api_1.DiagLogLevel.VERBOSE,
    DEBUG: api_1.DiagLogLevel.DEBUG,
    INFO: api_1.DiagLogLevel.INFO,
    WARN: api_1.DiagLogLevel.WARN,
    ERROR: api_1.DiagLogLevel.ERROR,
    NONE: api_1.DiagLogLevel.NONE
  };
  function setLogLevelFromEnv(key, environment, values) {
    const value = values[key];
    if (typeof value === "string") {
      const theLevel = logLevelMap[value.toUpperCase()];
      if (theLevel != null) {
        environment[key] = theLevel;
      }
    }
  }
  function parseEnvironment(values) {
    const environment = {};
    for (const env in exports2.DEFAULT_ENVIRONMENT) {
      const key = env;
      switch (key) {
        case "OTEL_SAMPLING_PROBABILITY":
          parseNumber(key, environment, values, 0, 1);
          break;
        case "OTEL_LOG_LEVEL":
          setLogLevelFromEnv(key, environment, values);
          break;
        default:
          if (isEnvVarANumber(key)) {
            parseNumber(key, environment, values);
          } else if (isEnvVarAList(key)) {
            parseStringList(key, environment, values);
          } else {
            const value = values[key];
            if (typeof value !== "undefined" && value !== null) {
              environment[key] = String(value);
            }
          }
      }
    }
    return environment;
  }
  exports2.parseEnvironment = parseEnvironment;
});

// node_modules/@opentelemetry/core/build/src/platform/node/environment.js
var require_environment2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.getEnv = void 0;
  var os = require("os");
  var environment_1 = require_environment();
  function getEnv() {
    const processEnv = environment_1.parseEnvironment(process.env);
    return Object.assign({
      HOSTNAME: os.hostname()
    }, environment_1.DEFAULT_ENVIRONMENT, processEnv);
  }
  exports2.getEnv = getEnv;
});

// node_modules/@opentelemetry/core/build/src/platform/node/hex-to-base64.js
var require_hex_to_base64 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.hexToBase64 = void 0;
  function hexToBase64(hexStr) {
    const hexStrLen = hexStr.length;
    let hexAsciiCharsStr = "";
    for (let i = 0; i < hexStrLen; i += 2) {
      const hexPair = hexStr.substring(i, i + 2);
      const hexVal = parseInt(hexPair, 16);
      hexAsciiCharsStr += String.fromCharCode(hexVal);
    }
    return Buffer.from(hexAsciiCharsStr, "ascii").toString("base64");
  }
  exports2.hexToBase64 = hexToBase64;
});

// node_modules/@opentelemetry/core/build/src/platform/node/RandomIdGenerator.js
var require_RandomIdGenerator = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.RandomIdGenerator = void 0;
  var SPAN_ID_BYTES = 8;
  var TRACE_ID_BYTES = 16;
  var RandomIdGenerator = class {
    constructor() {
      this.generateTraceId = getIdGenerator(TRACE_ID_BYTES);
      this.generateSpanId = getIdGenerator(SPAN_ID_BYTES);
    }
  };
  exports2.RandomIdGenerator = RandomIdGenerator;
  var SHARED_BUFFER = Buffer.allocUnsafe(TRACE_ID_BYTES);
  function getIdGenerator(bytes) {
    return function generateId() {
      for (let i = 0; i < bytes / 4; i++) {
        SHARED_BUFFER.writeUInt32BE(Math.random() * 2 ** 32 >>> 0, i * 4);
      }
      for (let i = 0; i < bytes; i++) {
        if (SHARED_BUFFER[i] > 0) {
          break;
        } else if (i === bytes - 1) {
          SHARED_BUFFER[bytes - 1] = 1;
        }
      }
      return SHARED_BUFFER.toString("hex", 0, bytes);
    };
  }
});

// node_modules/@opentelemetry/core/build/src/platform/node/performance.js
var require_performance = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.otperformance = void 0;
  var perf_hooks_1 = require("perf_hooks");
  exports2.otperformance = perf_hooks_1.performance;
});

// node_modules/@opentelemetry/core/build/src/version.js
var require_version2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.VERSION = void 0;
  exports2.VERSION = "0.18.2";
});

// node_modules/@opentelemetry/core/build/src/platform/node/sdk-info.js
var require_sdk_info = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.SDK_INFO = void 0;
  var version_1 = require_version2();
  exports2.SDK_INFO = {
    NAME: "opentelemetry",
    RUNTIME: "node",
    LANGUAGE: "nodejs",
    VERSION: version_1.VERSION
  };
});

// node_modules/@opentelemetry/core/build/src/platform/node/timer-util.js
var require_timer_util = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.unrefTimer = void 0;
  function unrefTimer(timer) {
    timer.unref();
  }
  exports2.unrefTimer = unrefTimer;
});

// node_modules/@opentelemetry/core/build/src/platform/node/index.js
var require_node2 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_BasePlugin(), exports2);
  __exportStar(require_environment2(), exports2);
  __exportStar(require_hex_to_base64(), exports2);
  __exportStar(require_RandomIdGenerator(), exports2);
  __exportStar(require_performance(), exports2);
  __exportStar(require_sdk_info(), exports2);
  __exportStar(require_timer_util(), exports2);
});

// node_modules/@opentelemetry/core/build/src/platform/index.js
var require_platform2 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_node2(), exports2);
});

// node_modules/@opentelemetry/core/build/src/common/time.js
var require_time2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.isTimeInput = exports2.isTimeInputHrTime = exports2.hrTimeToMicroseconds = exports2.hrTimeToMilliseconds = exports2.hrTimeToNanoseconds = exports2.hrTimeToTimeStamp = exports2.hrTimeDuration = exports2.timeInputToHrTime = exports2.hrTime = void 0;
  var platform_1 = require_platform2();
  var NANOSECOND_DIGITS = 9;
  var SECOND_TO_NANOSECONDS = Math.pow(10, NANOSECOND_DIGITS);
  function numberToHrtime(epochMillis) {
    const epochSeconds = epochMillis / 1e3;
    const seconds = Math.trunc(epochSeconds);
    const nanos = Number((epochSeconds - seconds).toFixed(NANOSECOND_DIGITS)) * SECOND_TO_NANOSECONDS;
    return [seconds, nanos];
  }
  function getTimeOrigin() {
    let timeOrigin = platform_1.otperformance.timeOrigin;
    if (typeof timeOrigin !== "number") {
      const perf = platform_1.otperformance;
      timeOrigin = perf.timing && perf.timing.fetchStart;
    }
    return timeOrigin;
  }
  function hrTime(performanceNow) {
    const timeOrigin = numberToHrtime(getTimeOrigin());
    const now = numberToHrtime(typeof performanceNow === "number" ? performanceNow : platform_1.otperformance.now());
    let seconds = timeOrigin[0] + now[0];
    let nanos = timeOrigin[1] + now[1];
    if (nanos > SECOND_TO_NANOSECONDS) {
      nanos -= SECOND_TO_NANOSECONDS;
      seconds += 1;
    }
    return [seconds, nanos];
  }
  exports2.hrTime = hrTime;
  function timeInputToHrTime(time) {
    if (isTimeInputHrTime(time)) {
      return time;
    } else if (typeof time === "number") {
      if (time < getTimeOrigin()) {
        return hrTime(time);
      } else {
        return numberToHrtime(time);
      }
    } else if (time instanceof Date) {
      return numberToHrtime(time.getTime());
    } else {
      throw TypeError("Invalid input type");
    }
  }
  exports2.timeInputToHrTime = timeInputToHrTime;
  function hrTimeDuration(startTime, endTime) {
    let seconds = endTime[0] - startTime[0];
    let nanos = endTime[1] - startTime[1];
    if (nanos < 0) {
      seconds -= 1;
      nanos += SECOND_TO_NANOSECONDS;
    }
    return [seconds, nanos];
  }
  exports2.hrTimeDuration = hrTimeDuration;
  function hrTimeToTimeStamp(hrTime2) {
    const precision = NANOSECOND_DIGITS;
    const tmp = `${"0".repeat(precision)}${hrTime2[1]}Z`;
    const nanoString = tmp.substr(tmp.length - precision - 1);
    const date = new Date(hrTime2[0] * 1e3).toISOString();
    return date.replace("000Z", nanoString);
  }
  exports2.hrTimeToTimeStamp = hrTimeToTimeStamp;
  function hrTimeToNanoseconds(hrTime2) {
    return hrTime2[0] * SECOND_TO_NANOSECONDS + hrTime2[1];
  }
  exports2.hrTimeToNanoseconds = hrTimeToNanoseconds;
  function hrTimeToMilliseconds(hrTime2) {
    return Math.round(hrTime2[0] * 1e3 + hrTime2[1] / 1e6);
  }
  exports2.hrTimeToMilliseconds = hrTimeToMilliseconds;
  function hrTimeToMicroseconds(hrTime2) {
    return Math.round(hrTime2[0] * 1e6 + hrTime2[1] / 1e3);
  }
  exports2.hrTimeToMicroseconds = hrTimeToMicroseconds;
  function isTimeInputHrTime(value) {
    return Array.isArray(value) && value.length === 2 && typeof value[0] === "number" && typeof value[1] === "number";
  }
  exports2.isTimeInputHrTime = isTimeInputHrTime;
  function isTimeInput(value) {
    return isTimeInputHrTime(value) || typeof value === "number" || value instanceof Date;
  }
  exports2.isTimeInput = isTimeInput;
});

// node_modules/@opentelemetry/core/build/src/common/types.js
var require_types4 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/core/build/src/ExportResult.js
var require_ExportResult = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.ExportResultCode = void 0;
  var ExportResultCode;
  (function(ExportResultCode2) {
    ExportResultCode2[ExportResultCode2["SUCCESS"] = 0] = "SUCCESS";
    ExportResultCode2[ExportResultCode2["FAILED"] = 1] = "FAILED";
  })(ExportResultCode = exports2.ExportResultCode || (exports2.ExportResultCode = {}));
});

// node_modules/@opentelemetry/core/build/src/context/propagation/composite.js
var require_composite = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.CompositePropagator = void 0;
  var api_1 = require_src();
  var CompositePropagator = class {
    constructor(config = {}) {
      var _a;
      this._propagators = (_a = config.propagators) !== null && _a !== void 0 ? _a : [];
      this._fields = Array.from(new Set(this._propagators.map((p) => typeof p.fields === "function" ? p.fields() : []).reduce((x, y) => x.concat(y))));
    }
    inject(context, carrier, setter) {
      for (const propagator of this._propagators) {
        try {
          propagator.inject(context, carrier, setter);
        } catch (err) {
          api_1.diag.warn(`Failed to inject with ${propagator.constructor.name}. Err: ${err.message}`);
        }
      }
    }
    extract(context, carrier, getter) {
      return this._propagators.reduce((ctx, propagator) => {
        try {
          return propagator.extract(ctx, carrier, getter);
        } catch (err) {
          api_1.diag.warn(`Failed to inject with ${propagator.constructor.name}. Err: ${err.message}`);
        }
        return ctx;
      }, context);
    }
    fields() {
      return this._fields.slice();
    }
  };
  exports2.CompositePropagator = CompositePropagator;
});

// node_modules/@opentelemetry/core/build/src/internal/validators.js
var require_validators = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.validateValue = exports2.validateKey = void 0;
  var VALID_KEY_CHAR_RANGE = "[_0-9a-z-*/]";
  var VALID_KEY = `[a-z]${VALID_KEY_CHAR_RANGE}{0,255}`;
  var VALID_VENDOR_KEY = `[a-z0-9]${VALID_KEY_CHAR_RANGE}{0,240}@[a-z]${VALID_KEY_CHAR_RANGE}{0,13}`;
  var VALID_KEY_REGEX = new RegExp(`^(?:${VALID_KEY}|${VALID_VENDOR_KEY})$`);
  var VALID_VALUE_BASE_REGEX = /^[ -~]{0,255}[!-~]$/;
  var INVALID_VALUE_COMMA_EQUAL_REGEX = /,|=/;
  function validateKey(key) {
    return VALID_KEY_REGEX.test(key);
  }
  exports2.validateKey = validateKey;
  function validateValue(value) {
    return VALID_VALUE_BASE_REGEX.test(value) && !INVALID_VALUE_COMMA_EQUAL_REGEX.test(value);
  }
  exports2.validateValue = validateValue;
});

// node_modules/@opentelemetry/core/build/src/trace/TraceState.js
var require_TraceState = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.TraceState = void 0;
  var validators_1 = require_validators();
  var MAX_TRACE_STATE_ITEMS = 32;
  var MAX_TRACE_STATE_LEN = 512;
  var LIST_MEMBERS_SEPARATOR = ",";
  var LIST_MEMBER_KEY_VALUE_SPLITTER = "=";
  var TraceState = class {
    constructor(rawTraceState) {
      this._internalState = new Map();
      if (rawTraceState)
        this._parse(rawTraceState);
    }
    set(key, value) {
      const traceState = this._clone();
      if (traceState._internalState.has(key)) {
        traceState._internalState.delete(key);
      }
      traceState._internalState.set(key, value);
      return traceState;
    }
    unset(key) {
      const traceState = this._clone();
      traceState._internalState.delete(key);
      return traceState;
    }
    get(key) {
      return this._internalState.get(key);
    }
    serialize() {
      return this._keys().reduce((agg, key) => {
        agg.push(key + LIST_MEMBER_KEY_VALUE_SPLITTER + this.get(key));
        return agg;
      }, []).join(LIST_MEMBERS_SEPARATOR);
    }
    _parse(rawTraceState) {
      if (rawTraceState.length > MAX_TRACE_STATE_LEN)
        return;
      this._internalState = rawTraceState.split(LIST_MEMBERS_SEPARATOR).reverse().reduce((agg, part) => {
        const listMember = part.trim();
        const i = listMember.indexOf(LIST_MEMBER_KEY_VALUE_SPLITTER);
        if (i !== -1) {
          const key = listMember.slice(0, i);
          const value = listMember.slice(i + 1, part.length);
          if (validators_1.validateKey(key) && validators_1.validateValue(value)) {
            agg.set(key, value);
          } else {
          }
        }
        return agg;
      }, new Map());
      if (this._internalState.size > MAX_TRACE_STATE_ITEMS) {
        this._internalState = new Map(Array.from(this._internalState.entries()).reverse().slice(0, MAX_TRACE_STATE_ITEMS));
      }
    }
    _keys() {
      return Array.from(this._internalState.keys()).reverse();
    }
    _clone() {
      const traceState = new TraceState();
      traceState._internalState = new Map(this._internalState);
      return traceState;
    }
  };
  exports2.TraceState = TraceState;
});

// node_modules/@opentelemetry/core/build/src/context/propagation/HttpTraceContext.js
var require_HttpTraceContext = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.HttpTraceContext = exports2.parseTraceParent = exports2.TRACE_STATE_HEADER = exports2.TRACE_PARENT_HEADER = void 0;
  var api_1 = require_src();
  var TraceState_1 = require_TraceState();
  exports2.TRACE_PARENT_HEADER = "traceparent";
  exports2.TRACE_STATE_HEADER = "tracestate";
  var VERSION = "00";
  var VERSION_PART = "(?!ff)[\\da-f]{2}";
  var TRACE_ID_PART = "(?![0]{32})[\\da-f]{32}";
  var PARENT_ID_PART = "(?![0]{16})[\\da-f]{16}";
  var FLAGS_PART = "[\\da-f]{2}";
  var TRACE_PARENT_REGEX = new RegExp(`^\\s?(${VERSION_PART})-(${TRACE_ID_PART})-(${PARENT_ID_PART})-(${FLAGS_PART})(-.*)?\\s?$`);
  function parseTraceParent(traceParent) {
    const match = TRACE_PARENT_REGEX.exec(traceParent);
    if (!match)
      return null;
    if (match[1] === "00" && match[5])
      return null;
    return {
      traceId: match[2],
      spanId: match[3],
      traceFlags: parseInt(match[4], 16)
    };
  }
  exports2.parseTraceParent = parseTraceParent;
  var HttpTraceContext = class {
    inject(context, carrier, setter) {
      const spanContext = api_1.getSpanContext(context);
      if (!spanContext)
        return;
      const traceParent = `${VERSION}-${spanContext.traceId}-${spanContext.spanId}-0${Number(spanContext.traceFlags || api_1.TraceFlags.NONE).toString(16)}`;
      setter.set(carrier, exports2.TRACE_PARENT_HEADER, traceParent);
      if (spanContext.traceState) {
        setter.set(carrier, exports2.TRACE_STATE_HEADER, spanContext.traceState.serialize());
      }
    }
    extract(context, carrier, getter) {
      const traceParentHeader = getter.get(carrier, exports2.TRACE_PARENT_HEADER);
      if (!traceParentHeader)
        return context;
      const traceParent = Array.isArray(traceParentHeader) ? traceParentHeader[0] : traceParentHeader;
      if (typeof traceParent !== "string")
        return context;
      const spanContext = parseTraceParent(traceParent);
      if (!spanContext)
        return context;
      spanContext.isRemote = true;
      const traceStateHeader = getter.get(carrier, exports2.TRACE_STATE_HEADER);
      if (traceStateHeader) {
        const state = Array.isArray(traceStateHeader) ? traceStateHeader.join(",") : traceStateHeader;
        spanContext.traceState = new TraceState_1.TraceState(typeof state === "string" ? state : void 0);
      }
      return api_1.setSpanContext(context, spanContext);
    }
    fields() {
      return [exports2.TRACE_PARENT_HEADER, exports2.TRACE_STATE_HEADER];
    }
  };
  exports2.HttpTraceContext = HttpTraceContext;
});

// node_modules/@opentelemetry/core/build/src/context/propagation/types.js
var require_types5 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/core/build/src/baggage/propagation/HttpBaggage.js
var require_HttpBaggage = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.HttpBaggage = exports2.MAX_TOTAL_LENGTH = exports2.MAX_PER_NAME_VALUE_PAIRS = exports2.MAX_NAME_VALUE_PAIRS = exports2.BAGGAGE_HEADER = void 0;
  var api_1 = require_src();
  var KEY_PAIR_SEPARATOR = "=";
  var PROPERTIES_SEPARATOR = ";";
  var ITEMS_SEPARATOR = ",";
  exports2.BAGGAGE_HEADER = "baggage";
  exports2.MAX_NAME_VALUE_PAIRS = 180;
  exports2.MAX_PER_NAME_VALUE_PAIRS = 4096;
  exports2.MAX_TOTAL_LENGTH = 8192;
  var HttpBaggage = class {
    inject(context, carrier, setter) {
      const baggage = api_1.getBaggage(context);
      if (!baggage)
        return;
      const keyPairs = this._getKeyPairs(baggage).filter((pair) => {
        return pair.length <= exports2.MAX_PER_NAME_VALUE_PAIRS;
      }).slice(0, exports2.MAX_NAME_VALUE_PAIRS);
      const headerValue = this._serializeKeyPairs(keyPairs);
      if (headerValue.length > 0) {
        setter.set(carrier, exports2.BAGGAGE_HEADER, headerValue);
      }
    }
    _serializeKeyPairs(keyPairs) {
      return keyPairs.reduce((hValue, current) => {
        const value = `${hValue}${hValue !== "" ? ITEMS_SEPARATOR : ""}${current}`;
        return value.length > exports2.MAX_TOTAL_LENGTH ? hValue : value;
      }, "");
    }
    _getKeyPairs(baggage) {
      return baggage.getAllEntries().map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value.value)}`);
    }
    extract(context, carrier, getter) {
      const headerValue = getter.get(carrier, exports2.BAGGAGE_HEADER);
      if (!headerValue)
        return context;
      const baggage = {};
      if (headerValue.length === 0) {
        return context;
      }
      const pairs = headerValue.split(ITEMS_SEPARATOR);
      pairs.forEach((entry) => {
        const keyPair = this._parsePairKeyValue(entry);
        if (keyPair) {
          const baggageEntry = {value: keyPair.value};
          if (keyPair.metadata) {
            baggageEntry.metadata = keyPair.metadata;
          }
          baggage[keyPair.key] = baggageEntry;
        }
      });
      if (Object.entries(baggage).length === 0) {
        return context;
      }
      return api_1.setBaggage(context, api_1.createBaggage(baggage));
    }
    _parsePairKeyValue(entry) {
      const valueProps = entry.split(PROPERTIES_SEPARATOR);
      if (valueProps.length <= 0)
        return;
      const keyPairPart = valueProps.shift();
      if (!keyPairPart)
        return;
      const keyPair = keyPairPart.split(KEY_PAIR_SEPARATOR);
      if (keyPair.length !== 2)
        return;
      const key = decodeURIComponent(keyPair[0].trim());
      const value = decodeURIComponent(keyPair[1].trim());
      let metadata;
      if (valueProps.length > 0) {
        metadata = api_1.baggageEntryMetadataFromString(valueProps.join(PROPERTIES_SEPARATOR));
      }
      return {key, value, metadata};
    }
    fields() {
      return [exports2.BAGGAGE_HEADER];
    }
  };
  exports2.HttpBaggage = HttpBaggage;
});

// node_modules/@opentelemetry/core/build/src/trace/Plugin.js
var require_Plugin = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/core/build/src/trace/sampler/AlwaysOffSampler.js
var require_AlwaysOffSampler = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.AlwaysOffSampler = void 0;
  var api_1 = require_src();
  var AlwaysOffSampler = class {
    shouldSample() {
      return {
        decision: api_1.SamplingDecision.NOT_RECORD
      };
    }
    toString() {
      return "AlwaysOffSampler";
    }
  };
  exports2.AlwaysOffSampler = AlwaysOffSampler;
});

// node_modules/@opentelemetry/core/build/src/trace/sampler/AlwaysOnSampler.js
var require_AlwaysOnSampler = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.AlwaysOnSampler = void 0;
  var api_1 = require_src();
  var AlwaysOnSampler = class {
    shouldSample() {
      return {
        decision: api_1.SamplingDecision.RECORD_AND_SAMPLED
      };
    }
    toString() {
      return "AlwaysOnSampler";
    }
  };
  exports2.AlwaysOnSampler = AlwaysOnSampler;
});

// node_modules/@opentelemetry/core/build/src/trace/sampler/ParentBasedSampler.js
var require_ParentBasedSampler = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.ParentBasedSampler = void 0;
  var api_1 = require_src();
  var global_error_handler_1 = require_global_error_handler();
  var AlwaysOffSampler_1 = require_AlwaysOffSampler();
  var AlwaysOnSampler_1 = require_AlwaysOnSampler();
  var ParentBasedSampler = class {
    constructor(config) {
      var _a, _b, _c, _d;
      this._root = config.root;
      if (!this._root) {
        global_error_handler_1.globalErrorHandler(new Error("ParentBasedSampler must have a root sampler configured"));
        this._root = new AlwaysOnSampler_1.AlwaysOnSampler();
      }
      this._remoteParentSampled = (_a = config.remoteParentSampled) !== null && _a !== void 0 ? _a : new AlwaysOnSampler_1.AlwaysOnSampler();
      this._remoteParentNotSampled = (_b = config.remoteParentNotSampled) !== null && _b !== void 0 ? _b : new AlwaysOffSampler_1.AlwaysOffSampler();
      this._localParentSampled = (_c = config.localParentSampled) !== null && _c !== void 0 ? _c : new AlwaysOnSampler_1.AlwaysOnSampler();
      this._localParentNotSampled = (_d = config.localParentNotSampled) !== null && _d !== void 0 ? _d : new AlwaysOffSampler_1.AlwaysOffSampler();
    }
    shouldSample(context, traceId, spanName, spanKind, attributes, links) {
      const parentContext = api_1.getSpanContext(context);
      if (!parentContext) {
        return this._root.shouldSample(context, traceId, spanName, spanKind, attributes, links);
      }
      if (parentContext.isRemote) {
        if (parentContext.traceFlags & api_1.TraceFlags.SAMPLED) {
          return this._remoteParentSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
        }
        return this._remoteParentNotSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
      }
      if (parentContext.traceFlags & api_1.TraceFlags.SAMPLED) {
        return this._localParentSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
      }
      return this._localParentNotSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
    }
    toString() {
      return `ParentBased{root=${this._root.toString()}, remoteParentSampled=${this._remoteParentSampled.toString()}, remoteParentNotSampled=${this._remoteParentNotSampled.toString()}, localParentSampled=${this._localParentSampled.toString()}, localParentNotSampled=${this._localParentNotSampled.toString()}}`;
    }
  };
  exports2.ParentBasedSampler = ParentBasedSampler;
});

// node_modules/@opentelemetry/core/build/src/trace/sampler/TraceIdRatioBasedSampler.js
var require_TraceIdRatioBasedSampler = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.TraceIdRatioBasedSampler = void 0;
  var api_1 = require_src();
  var TraceIdRatioBasedSampler = class {
    constructor(_ratio = 0) {
      this._ratio = _ratio;
      this._ratio = this._normalize(_ratio);
      this._upperBound = Math.floor(this._ratio * 4294967295);
    }
    shouldSample(context, traceId) {
      return {
        decision: api_1.isValidTraceId(traceId) && this._accumulate(traceId) < this._upperBound ? api_1.SamplingDecision.RECORD_AND_SAMPLED : api_1.SamplingDecision.NOT_RECORD
      };
    }
    toString() {
      return `TraceIdRatioBased{${this._ratio}}`;
    }
    _normalize(ratio) {
      if (typeof ratio !== "number" || isNaN(ratio))
        return 0;
      return ratio >= 1 ? 1 : ratio <= 0 ? 0 : ratio;
    }
    _accumulate(traceId) {
      let accumulation = 0;
      for (let i = 0; i < traceId.length / 8; i++) {
        const pos = i * 8;
        const part = parseInt(traceId.slice(pos, pos + 8), 16);
        accumulation = (accumulation ^ part) >>> 0;
      }
      return accumulation;
    }
  };
  exports2.TraceIdRatioBasedSampler = TraceIdRatioBasedSampler;
});

// node_modules/@opentelemetry/core/build/src/trace/IdGenerator.js
var require_IdGenerator = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/core/build/src/utils/url.js
var require_url = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.isUrlIgnored = exports2.urlMatches = void 0;
  function urlMatches(url, urlToMatch) {
    if (typeof urlToMatch === "string") {
      return url === urlToMatch;
    } else {
      return !!url.match(urlToMatch);
    }
  }
  exports2.urlMatches = urlMatches;
  function isUrlIgnored(url, ignoredUrls) {
    if (!ignoredUrls) {
      return false;
    }
    for (const ignoreUrl of ignoredUrls) {
      if (urlMatches(url, ignoreUrl)) {
        return true;
      }
    }
    return false;
  }
  exports2.isUrlIgnored = isUrlIgnored;
});

// node_modules/@opentelemetry/core/build/src/utils/wrap.js
var require_wrap = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.isWrapped = void 0;
  function isWrapped(func) {
    return typeof func === "function" && typeof func.__original === "function" && typeof func.__unwrap === "function" && func.__wrapped === true;
  }
  exports2.isWrapped = isWrapped;
});

// node_modules/@opentelemetry/core/build/src/index.js
var require_src2 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_attributes(), exports2);
  __exportStar(require_global_error_handler(), exports2);
  __exportStar(require_logging_error_handler(), exports2);
  __exportStar(require_time2(), exports2);
  __exportStar(require_types4(), exports2);
  __exportStar(require_ExportResult(), exports2);
  __exportStar(require_version2(), exports2);
  __exportStar(require_composite(), exports2);
  __exportStar(require_HttpTraceContext(), exports2);
  __exportStar(require_types5(), exports2);
  __exportStar(require_HttpBaggage(), exports2);
  __exportStar(require_platform2(), exports2);
  __exportStar(require_Plugin(), exports2);
  __exportStar(require_AlwaysOffSampler(), exports2);
  __exportStar(require_AlwaysOnSampler(), exports2);
  __exportStar(require_ParentBasedSampler(), exports2);
  __exportStar(require_TraceIdRatioBasedSampler(), exports2);
  __exportStar(require_TraceState(), exports2);
  __exportStar(require_IdGenerator(), exports2);
  __exportStar(require_url(), exports2);
  __exportStar(require_wrap(), exports2);
});

// node_modules/@cazoo/telemetry/dist/telemetry/exporters/writableSpan.js
var require_writableSpan = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.WritableSpan = void 0;
  var WritableSpan = class {
    constructor(span) {
      this.traceId = span.spanContext.traceId;
      this.parentId = span.parentSpanId;
      this.name = span.name;
      this.id = span.spanContext.spanId;
      this.kind = span.kind;
      this.timestamp = this.hrTimeToMicroseconds(span.startTime);
      this.duration = this.hrTimeToMilliseconds(span.duration);
      this.attributes = span.attributes;
      this.status = span.status;
      this.events = span.events;
    }
    hrTimeToMilliseconds(hrTime) {
      return Math.round(hrTime[0] * 1e3 + hrTime[1] / 1e6);
    }
    hrTimeToMicroseconds(hrTime) {
      return Math.round(hrTime[0] * 1e6 + hrTime[1] / 1e3);
    }
    stringify() {
      return JSON.stringify(this);
    }
    static from(span) {
      return new WritableSpan(span);
    }
  };
  exports2.WritableSpan = WritableSpan;
});

// node_modules/@cazoo/telemetry/dist/telemetry/exporters/stdOutExporter.js
var require_stdOutExporter = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.StdOutExporter = void 0;
  var core_1 = require_src2();
  var writableSpan_1 = require_writableSpan();
  var StdOutExporter = class {
    constructor(out) {
      this.out = out || process.stdout;
    }
    export(spans, done) {
      return this.sendSpans(spans, done);
    }
    async shutdown() {
    }
    stringify(span) {
      return writableSpan_1.WritableSpan.from(span).stringify();
    }
    sendSpans(spans, done) {
      try {
        for (const span of spans) {
          if (this.out.writable) {
            this.out.write(this.stringify(span));
            this.out.write("\n");
          }
        }
        return done({code: core_1.ExportResultCode.SUCCESS});
      } catch (error) {
        return done({code: core_1.ExportResultCode.FAILED, error});
      }
    }
  };
  exports2.StdOutExporter = StdOutExporter;
});

// node_modules/@cazoo/telemetry/dist/context/context.js
var require_context4 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.makeContext = exports2.has = void 0;
  function parseAccountId(arn) {
    if (!arn) {
      return "missing";
    }
    const parts = arn.split(":");
    if (parts.length >= 5) {
      return parts[4];
    }
    return `unknown (${arn})`;
  }
  function has(obj, ...props) {
    for (const p of props) {
      if (!obj.hasOwnProperty(p)) {
        return false;
      }
    }
    return true;
  }
  exports2.has = has;
  function makeContext(ctx, options, extra) {
    return Object.assign({
      request_id: ctx.awsRequestId,
      account_id: parseAccountId(ctx.invokedFunctionArn),
      function: {
        name: ctx.functionName,
        version: ctx.functionVersion,
        service: options && options.service || process.env.CAZOO_LOGGER_SERVICE || ctx.logStreamName
      }
    }, extra);
  }
  exports2.makeContext = makeContext;
});

// node_modules/@cazoo/telemetry/dist/events/sns.js
var require_sns2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.makeSNSContext = exports2.isSNS = void 0;
  var context_1 = require_context4();
  function s3For(event) {
    const msg = JSON.parse(event.Records[0].Sns.Message);
    const s3 = msg.Records[0].s3;
    return s3;
  }
  function isSNS(event) {
    if (!event.Records)
      return false;
    return event.Records[0].EventSource === "aws:sns";
  }
  exports2.isSNS = isSNS;
  function makeSNSContext(context, options, event) {
    const ctx = context_1.makeContext(context, options, {
      event: {
        id: event.Records[0].Sns.MessageId,
        source: event.Records[0].Sns.TopicArn
      }
    });
    if (event.Records[0].Sns.Subject === "Amazon S3 Notification") {
      ctx.s3 = {
        bucket: s3For(event).bucket.name,
        key: s3For(event).object.key
      };
    }
    return ctx;
  }
  exports2.makeSNSContext = makeSNSContext;
});

// node_modules/@cazoo/telemetry/dist/events/sqsRecord.js
var require_sqsRecord2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.makeSQSRecordContext = exports2.isSQSRecord = void 0;
  var context_1 = require_context4();
  var context_2 = require_context4();
  function isSQSRecord(record) {
    return context_1.has(record, "eventSourceARN", "messageId");
  }
  exports2.isSQSRecord = isSQSRecord;
  function makeSQSRecordContext(context, options, record) {
    return context_2.makeContext(context, options, {
      sqs: {
        source: record.eventSourceARN,
        id: record.messageId
      }
    });
  }
  exports2.makeSQSRecordContext = makeSQSRecordContext;
});

// node_modules/@cazoo/telemetry/dist/events/dynamoDbStream.js
var require_dynamoDbStream2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.makeDynamoDbContext = exports2.isDynamoDbStream = void 0;
  var context_1 = require_context4();
  function isDynamoDbStream(event) {
    if (!event.Records)
      return false;
    return event.Records[0].eventSource === "aws:dynamodb";
  }
  exports2.isDynamoDbStream = isDynamoDbStream;
  function makeDynamoDbContext(event, context, options) {
    const record = event.Records[0];
    const ctx = context_1.makeContext(context, options, {
      event: {
        id: record.eventID,
        source: record.eventSourceARN,
        type: record.eventName
      }
    });
    return ctx;
  }
  exports2.makeDynamoDbContext = makeDynamoDbContext;
});

// node_modules/@cazoo/telemetry/dist/events/domainEvent.js
var require_domainEvent2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.makeDomainEventContext = exports2.isDomainEvent = void 0;
  var context_1 = require_context4();
  function isDomainEvent(event) {
    return context_1.has(event, "detail", "detail-type", "source", "id");
  }
  exports2.isDomainEvent = isDomainEvent;
  function makeDomainEventContext(context, options, event) {
    return context_1.makeContext(context, options, {
      event: {
        source: event.source,
        type: event["detail-type"],
        id: event.id
      }
    });
  }
  exports2.makeDomainEventContext = makeDomainEventContext;
});

// node_modules/@cazoo/telemetry/dist/events/cloudFront.js
var require_cloudFront2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.makeCloudFrontContext = exports2.isCloudFrontRequest = void 0;
  var context_1 = require_context4();
  function convert(config) {
    if (config.eventType === "viewer-request" || config.eventType === "viewer-response") {
      return config;
    }
    return void 0;
  }
  function getRequestId(cf) {
    let requestId;
    const converted = convert(cf.config);
    if (converted) {
      requestId = converted.requestId;
    }
    return requestId;
  }
  function isCloudFrontRequest(request) {
    return !(!Array.isArray(request.Records) || request.Records[0].cf === void 0);
  }
  exports2.isCloudFrontRequest = isCloudFrontRequest;
  function makeCloudFrontContext(request, context, options) {
    const cf = request.Records[0].cf;
    const ctx = context_1.makeContext(context, options, {
      cf: {
        path: cf.request.uri,
        method: cf.request.method,
        dist: cf.config.distributionId,
        type: cf.config.eventType,
        id: getRequestId(cf)
      }
    });
    return ctx;
  }
  exports2.makeCloudFrontContext = makeCloudFrontContext;
});

// node_modules/@cazoo/telemetry/dist/events/apiGateway.js
var require_apiGateway2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.makeApiGatewayContext = exports2.isApiGatewayEvent = void 0;
  var context_1 = require_context4();
  var context_2 = require_context4();
  function isApiGatewayEvent(event) {
    return context_2.has(event, "requestContext");
  }
  exports2.isApiGatewayEvent = isApiGatewayEvent;
  function makeApiGatewayContext(context, options, event) {
    return context_1.makeContext(context, options, {
      http: {
        path: event.path,
        connectionId: event.requestContext.connectionId,
        method: event.httpMethod,
        stage: event.requestContext.stage,
        routeKey: event.requestContext.routeKey,
        query: JSON.stringify(event.multiValueQueryStringParameters)
      }
    });
  }
  exports2.makeApiGatewayContext = makeApiGatewayContext;
});

// node_modules/@cazoo/telemetry/dist/telemetry/debugLog.js
var require_debugLog = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.debugLog = void 0;
  function debugLog(message) {
    if (process.env.TELEMETRY_DEBUG) {
      process.stdout.write(`${message}
`);
    }
  }
  exports2.debugLog = debugLog;
});

// node_modules/@cazoo/telemetry/dist/http/telemetryHttpHeaders.js
var require_telemetryHttpHeaders = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.spanIdHttpHeader = exports2.traceIdHttpHeader = void 0;
  exports2.traceIdHttpHeader = "X-Cazoo-Telemetry-Traceid";
  exports2.spanIdHttpHeader = "X-Cazoo-Telemetry-Spanid";
});

// node_modules/@cazoo/telemetry/dist/telemetry/getContext.js
var require_getContext = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.getParentSpanContextFromEvent = exports2.getContext = void 0;
  var sns_1 = require_sns2();
  var sqsRecord_1 = require_sqsRecord2();
  var dynamoDbStream_1 = require_dynamoDbStream2();
  var domainEvent_1 = require_domainEvent2();
  var cloudFront_1 = require_cloudFront2();
  var apiGateway_1 = require_apiGateway2();
  var debugLog_1 = require_debugLog();
  var telemetryHttpHeaders_1 = require_telemetryHttpHeaders();
  function getContext(event, context, options) {
    if (!event)
      return;
    if (sns_1.isSNS(event)) {
      return sns_1.makeSNSContext(context, options, event);
    } else if (sqsRecord_1.isSQSRecord(event)) {
      return sqsRecord_1.makeSQSRecordContext(context, options, event);
    } else if (dynamoDbStream_1.isDynamoDbStream(event)) {
      return dynamoDbStream_1.makeDynamoDbContext(event, context, options);
    } else if (domainEvent_1.isDomainEvent(event)) {
      return domainEvent_1.makeDomainEventContext(context, options, event);
    } else if (cloudFront_1.isCloudFrontRequest(event)) {
      return cloudFront_1.makeCloudFrontContext(event, context, options);
    } else if (apiGateway_1.isApiGatewayEvent(event)) {
      return apiGateway_1.makeApiGatewayContext(context, options, event);
    }
  }
  exports2.getContext = getContext;
  exports2.getParentSpanContextFromEvent = (event) => {
    if (!event) {
      return;
    }
    if (!apiGateway_1.isApiGatewayEvent(event)) {
      return;
    }
    const traceId = event.headers[telemetryHttpHeaders_1.traceIdHttpHeader];
    const spanId = event.headers[telemetryHttpHeaders_1.spanIdHttpHeader];
    if (!traceId || !spanId) {
      return;
    }
    debugLog_1.debugLog(`Got parent span context from event - traceId: ${traceId} - spanId: ${spanId}`);
    return {
      spanId,
      traceId,
      traceFlags: 0,
      isRemote: true
    };
  };
});

// node_modules/@cazoo/telemetry/dist/telemetry/flattener.js
var require_flattener = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.flatten = void 0;
  function isObjectWithKeys(o) {
    return o && o.constructor === Object && Object.keys(o).length > 0;
  }
  function flatten(object) {
    return flattenRecursive({object});
  }
  exports2.flatten = flatten;
  function flattenRecursive({object, prefix = "", accumulator = {}}) {
    const flattened = Object.entries(object).reduce((r, [key, val]) => {
      const k = `${prefix}${key}`;
      const flattenOpts = {
        object: val,
        prefix: `${k}.`,
        accumulator: r
      };
      if (isObjectWithKeys(val)) {
        flattenRecursive(flattenOpts);
      } else {
        accumulator[k] = val;
      }
      return r;
    }, accumulator);
    return flattened;
  }
});

// node_modules/@cazoo/telemetry/dist/telemetry/trace.js
var require_trace2 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {enumerable: true, value: v});
  } : function(o, v) {
    o["default"] = v;
  });
  var __importStar = exports2 && exports2.__importStar || function(mod) {
    if (mod && mod.__esModule)
      return mod;
    var result = {};
    if (mod != null) {
      for (var k in mod)
        if (k !== "default" && Object.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.Trace = void 0;
  var api_1 = require_src();
  var contextBase = __importStar(require_context2());
  var debugLog_1 = require_debugLog();
  var flattener_1 = require_flattener();
  var telemetryHttpHeaders_1 = require_telemetryHttpHeaders();
  var Trace2 = class {
    constructor(tracer, span, parentContext = api_1.context.active(), attributes = void 0) {
      this.span = span;
      this.tracer = tracer;
      this.children = [];
      this.ended = false;
      this.appendContext(attributes);
      if (span === void 0)
        return;
      this.context = contextBase.setSpanContext(parentContext, this.span.context());
    }
    startChild(name) {
      debugLog_1.debugLog(`starting a child trace ${name}`);
      const childTrace = new Trace2(this.tracer, this.safelyStartSpan(name, this.context), this.context, this.attributes);
      this.children.push(childTrace);
      return childTrace;
    }
    asHttpHeaders() {
      return {
        [telemetryHttpHeaders_1.traceIdHttpHeader]: this.span.context().traceId,
        [telemetryHttpHeaders_1.spanIdHttpHeader]: this.span.context().spanId
      };
    }
    endWithError(error) {
      if (error instanceof Error) {
        this.schema({error: error.message, errorStackTrace: error.stack});
      } else {
        this.schema({error});
      }
      this.end();
    }
    end() {
      const name = this.getName();
      debugLog_1.debugLog(`ending trace ${name}`);
      this.children.forEach((x) => x.end());
      if (!this.ended)
        this.span && this.span.end();
      this.ended = true;
      this.clearTimeout();
    }
    appendContext(context) {
      this.attributes = Object.assign(Object.assign({}, this.attributes), context);
      this.span && this.span.setAttributes(flattener_1.flatten(this.attributes));
      return this;
    }
    schema(schema) {
      schema.error && this.span.setAttributes(flattener_1.flatten({error: schema.error}));
      schema.error && this.span.setAttribute("errorStackTrace", schema.errorStackTrace);
      schema.error && this.span.setAttribute("isError", true);
      schema.httpStatusCode && this.span.setAttribute("httpStatusCode", schema.httpStatusCode);
      schema.route && this.span.setAttribute("route", schema.route);
      return this;
    }
    addEvent(name, eventData) {
      this.span && this.span.addEvent(name, eventData);
    }
    setTimeoutCallback(timeout) {
      this.timeoutCallback = timeout;
    }
    timeout(timeoutMs) {
      this.endWithError({
        type: "lambda.timeout",
        timeoutMs
      });
    }
    getName() {
      const thisAny = this;
      if (thisAny.span)
        return thisAny.span.name;
    }
    clearTimeout() {
      if (!this.timeoutCallback) {
        return;
      }
      debugLog_1.debugLog(`Clearing timeout on ${this.getName()}`);
      clearTimeout(this.timeoutCallback);
    }
    safelyStartSpan(name, parentContext) {
      if (!this.tracer)
        return void 0;
      return this.tracer.startSpan(name, {}, parentContext);
    }
  };
  exports2.Trace = Trace2;
});

// node_modules/@cazoo/telemetry/dist/telemetry/timeout.js
var require_timeout = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.getTimeoutBuffer = void 0;
  var defaultBufferMS = 10;
  exports2.getTimeoutBuffer = () => {
    const sTimeoutBuffer = process.env.CAZOO_LOGGER_TIMEOUT_BUFFER_MS || `${defaultBufferMS}`;
    const timeoutBuffer = parseInt(sTimeoutBuffer);
    if (isNaN(timeoutBuffer)) {
      process.stderr.write(`Unable to parse non-numeric logger timeout buffer '${process.env.CAZOO_LOGGER_TIMEOUT_BUFFER_MS}'`);
      return defaultBufferMS;
    }
    return timeoutBuffer;
  };
});

// node_modules/@opentelemetry/semantic-conventions/build/src/trace/database.js
var require_database = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.DatabaseAttribute = void 0;
  exports2.DatabaseAttribute = {
    DB_SYSTEM: "db.system",
    DB_CONNECTION_STRING: "db.connection_string",
    DB_USER: "db.user",
    DB_NAME: "db.name",
    DB_STATEMENT: "db.statement",
    DB_OPERATION: "db.operation",
    DB_MSSSQL_INSTANCE_NAME: "db.mssql.instance_name",
    DB_JDBC_DRIVER_CLASSNAME: "db.jdbc.driver_classname",
    DB_CASSANDRA_KEYSPACE: "db.cassandra.keyspace",
    DB_HBASE_NAMESPACE: "db.hbase.namespace",
    DB_REDIS_DATABASE_INDEX: "db.redis.database_index",
    DB_MONGODB_COLLECTION: "db.mongodb.collection",
    DB_TYPE: "db.type",
    DB_INSTANCE: "db.instance",
    DB_URL: "db.url"
  };
});

// node_modules/@opentelemetry/semantic-conventions/build/src/trace/exception.js
var require_exception = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.ExceptionEventName = exports2.ExceptionAttribute = void 0;
  exports2.ExceptionAttribute = {
    MESSAGE: "exception.message",
    STACKTRACE: "exception.stacktrace",
    TYPE: "exception.type"
  };
  exports2.ExceptionEventName = "exception";
});

// node_modules/@opentelemetry/semantic-conventions/build/src/trace/general.js
var require_general = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.GeneralAttribute = void 0;
  exports2.GeneralAttribute = {
    NET_PEER_IP: "net.peer.ip",
    NET_PEER_ADDRESS: "net.peer.address",
    NET_PEER_HOSTNAME: "net.peer.host",
    NET_PEER_PORT: "net.peer.port",
    NET_PEER_NAME: "net.peer.name",
    NET_PEER_IPV4: "net.peer.ipv4",
    NET_PEER_IPV6: "net.peer.ipv6",
    NET_PEER_SERVICE: "net.peer.service",
    NET_HOST_IP: "net.host.ip",
    NET_HOST_PORT: "net.host.port",
    NET_HOST_NAME: "net.host.name",
    NET_TRANSPORT: "net.transport",
    IP_TCP: "IP.TCP",
    IP_UDP: "IP.UDP",
    INPROC: "inproc",
    PIPE: "pipe",
    UNIX: "Unix"
  };
});

// node_modules/@opentelemetry/semantic-conventions/build/src/trace/http.js
var require_http = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.HttpAttribute = void 0;
  exports2.HttpAttribute = {
    HTTP_HOST: "http.host",
    HTTP_METHOD: "http.method",
    HTTP_TARGET: "http.target",
    HTTP_ROUTE: "http.route",
    HTTP_URL: "http.url",
    HTTP_STATUS_CODE: "http.status_code",
    HTTP_STATUS_TEXT: "http.status_text",
    HTTP_FLAVOR: "http.flavor",
    HTTP_SERVER_NAME: "http.server_name",
    HTTP_CLIENT_IP: "http.client_ip",
    HTTP_SCHEME: "http.scheme",
    HTTP_RESPONSE_CONTENT_LENGTH: "http.response_content_length",
    HTTP_RESPONSE_CONTENT_LENGTH_UNCOMPRESSED: "http.response_content_length_uncompressed",
    HTTP_REQUEST_CONTENT_LENGTH: "http.request_content_length",
    HTTP_REQUEST_CONTENT_LENGTH_UNCOMPRESSED: "http.request_content_length_uncompressed",
    HTTP_ERROR_NAME: "http.error_name",
    HTTP_ERROR_MESSAGE: "http.error_message",
    HTTP_USER_AGENT: "http.user_agent"
  };
});

// node_modules/@opentelemetry/semantic-conventions/build/src/trace/os.js
var require_os = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.OperatingSystemValues = exports2.OperatingSystem = void 0;
  exports2.OperatingSystem = {
    TYPE: "os.type",
    DESCRIPTION: "os.description"
  };
  exports2.OperatingSystemValues = {
    WINDOWS: "WINDOWS",
    LINUX: "LINUX",
    DARWIN: "DARWIN",
    FREEBSD: "FREEBSD",
    NETBSD: "NETBSD",
    OPENBSD: "OPENBSD",
    DRAGONFLYBSD: "DRAGONFLYBSD",
    HPUX: "HPUX",
    AIX: "AIX",
    SOLARIS: "SOLARIS",
    ZOS: "ZOS"
  };
});

// node_modules/@opentelemetry/semantic-conventions/build/src/trace/rpc.js
var require_rpc = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.RpcAttribute = void 0;
  exports2.RpcAttribute = {
    RPC_SYSTEM: "rpc.system",
    RPC_SERVICE: "rpc.service",
    RPC_METHOD: "rpc.method",
    GRPC_KIND: "grpc.kind",
    GRPC_METHOD: "grpc.method",
    GRPC_STATUS_CODE: "grpc.status_code",
    GRPC_ERROR_NAME: "grpc.error_name",
    GRPC_ERROR_MESSAGE: "grpc.error_message"
  };
});

// node_modules/@opentelemetry/semantic-conventions/build/src/trace/faas.js
var require_faas = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.FaasAttribute = void 0;
  exports2.FaasAttribute = {
    FAAS_NAME: "faas.name",
    FAAS_ID: "faas.id",
    FAAS_VERSION: "faas.version",
    FAAS_INSTANCE: "faas.instance",
    FAAS_TRIGGER: "faas.trigger",
    FAAS_EXECUTION: "faas.execution",
    FAAS_COLD_START: "faas.coldstart",
    FAAS_INVOKED_NAME: "faas.invoked_name",
    FAAS_INVOKED_PROVIDER: "faas.invoked_provider",
    FAAS_INVOKED_REGION: "faas.invoked_region",
    FAAS_DOC_COLLECTION: "faas.document.collection",
    FAAS_DOC_OPERATION: "faas.document.operation",
    FAAS_DOC_TIME: "faas.document.time",
    FAAS_DOC_NAME: "faas.document.name",
    FAAS_TIME: "faas.time",
    FAAS_CRON: "faas.cron"
  };
});

// node_modules/@opentelemetry/semantic-conventions/build/src/trace/messaging.js
var require_messaging = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.MessagingOperationName = exports2.MessagingAttribute = void 0;
  exports2.MessagingAttribute = {
    MESSAGING_SYSTEM: "messaging.system",
    MESSAGING_DESTINATION: "messaging.destination",
    MESSAGING_DESTINATION_KIND: "messaging.destination_kind",
    MESSAGING_TEMP_DESTINATION: "messaging.temp_destination",
    MESSAGING_PROTOCOL: "messaging.protocol",
    MESSAGING_PROTOCOL_VERSION: "messaging.protocol_version",
    MESSAGING_URL: "messaging.url",
    MESSAGING_MESSAGE_ID: "messaging.message_id",
    MESSAGING_CONVERSATION_ID: "messaging.conversation_id",
    MESSAGING_MESSAGE_PAYLOAD_SIZE_BYTES: "messaging.message_payload_size_bytes",
    MESSAGING_MESSAGE_PAYLOAD_COMPRESSED_SIZE_BYTES: "messaging.message_payload_compressed_size_bytes",
    MESSAGING_OPERATION: "messaging.operation",
    MESSAGING_RABBITMQ_ROUTING_KEY: "messaging.rabbitmq.routing_key",
    MESSAGING_KAFKA_MESSAGE_KEY: "messaging.kafka.message_key",
    MESSAGING_KAFKA_CONSUMER_GROUP: "messaging.kafka.consumer_group",
    MESSAGING_KAFKA_CLIENT_ID: "messaging.kafka.client_id",
    MESSAGING_KAFKA_PARTITION: "messaging.kafka.partition",
    MESSAGING_KAFKA_TOMBSTONE: "messaging.kafka.tombstone"
  };
  exports2.MessagingOperationName = {
    SEND: "send",
    RECEIVE: "receive",
    PROCESS: "process"
  };
});

// node_modules/@opentelemetry/semantic-conventions/build/src/trace/index.js
var require_trace3 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_database(), exports2);
  __exportStar(require_exception(), exports2);
  __exportStar(require_general(), exports2);
  __exportStar(require_http(), exports2);
  __exportStar(require_os(), exports2);
  __exportStar(require_rpc(), exports2);
  __exportStar(require_faas(), exports2);
  __exportStar(require_messaging(), exports2);
});

// node_modules/@opentelemetry/semantic-conventions/build/src/index.js
var require_src3 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_trace3(), exports2);
});

// node_modules/@opentelemetry/tracing/build/src/Span.js
var require_Span = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.Span = void 0;
  var api = require_src();
  var core_1 = require_src2();
  var semantic_conventions_1 = require_src3();
  var Span = class {
    constructor(parentTracer, context, spanName, spanContext, kind, parentSpanId, links = [], startTime = core_1.hrTime()) {
      this.attributes = {};
      this.links = [];
      this.events = [];
      this.status = {
        code: api.SpanStatusCode.UNSET
      };
      this.endTime = [0, 0];
      this._ended = false;
      this._duration = [-1, -1];
      this.name = spanName;
      this.spanContext = spanContext;
      this.parentSpanId = parentSpanId;
      this.kind = kind;
      this.links = links;
      this.startTime = core_1.timeInputToHrTime(startTime);
      this.resource = parentTracer.resource;
      this.instrumentationLibrary = parentTracer.instrumentationLibrary;
      this._traceParams = parentTracer.getActiveTraceParams();
      this._spanProcessor = parentTracer.getActiveSpanProcessor();
      this._spanProcessor.onStart(this, context);
    }
    context() {
      return this.spanContext;
    }
    setAttribute(key, value) {
      if (value == null || this._isSpanEnded())
        return this;
      if (key.length === 0) {
        api.diag.warn(`Invalid attribute key: ${key}`);
        return this;
      }
      if (!core_1.isAttributeValue(value)) {
        api.diag.warn(`Invalid attribute value set for key: ${key}`);
        return this;
      }
      if (Object.keys(this.attributes).length >= this._traceParams.numberOfAttributesPerSpan && !Object.prototype.hasOwnProperty.call(this.attributes, key)) {
        return this;
      }
      this.attributes[key] = value;
      return this;
    }
    setAttributes(attributes) {
      for (const [k, v] of Object.entries(attributes)) {
        this.setAttribute(k, v);
      }
      return this;
    }
    addEvent(name, attributesOrStartTime, startTime) {
      if (this._isSpanEnded())
        return this;
      if (this.events.length >= this._traceParams.numberOfEventsPerSpan) {
        api.diag.warn("Dropping extra events.");
        this.events.shift();
      }
      if (core_1.isTimeInput(attributesOrStartTime)) {
        if (typeof startTime === "undefined") {
          startTime = attributesOrStartTime;
        }
        attributesOrStartTime = void 0;
      }
      if (typeof startTime === "undefined") {
        startTime = core_1.hrTime();
      }
      this.events.push({
        name,
        attributes: attributesOrStartTime,
        time: core_1.timeInputToHrTime(startTime)
      });
      return this;
    }
    setStatus(status) {
      if (this._isSpanEnded())
        return this;
      this.status = status;
      return this;
    }
    updateName(name) {
      if (this._isSpanEnded())
        return this;
      this.name = name;
      return this;
    }
    end(endTime = core_1.hrTime()) {
      if (this._isSpanEnded()) {
        api.diag.error("You can only call end() on a span once.");
        return;
      }
      this._ended = true;
      this.endTime = core_1.timeInputToHrTime(endTime);
      this._duration = core_1.hrTimeDuration(this.startTime, this.endTime);
      if (this._duration[0] < 0) {
        api.diag.warn("Inconsistent start and end time, startTime > endTime", this.startTime, this.endTime);
      }
      this._spanProcessor.onEnd(this);
    }
    isRecording() {
      return this._ended === false;
    }
    recordException(exception, time = core_1.hrTime()) {
      const attributes = {};
      if (typeof exception === "string") {
        attributes[semantic_conventions_1.ExceptionAttribute.MESSAGE] = exception;
      } else if (exception) {
        if (exception.code) {
          attributes[semantic_conventions_1.ExceptionAttribute.TYPE] = exception.code;
        } else if (exception.name) {
          attributes[semantic_conventions_1.ExceptionAttribute.TYPE] = exception.name;
        }
        if (exception.message) {
          attributes[semantic_conventions_1.ExceptionAttribute.MESSAGE] = exception.message;
        }
        if (exception.stack) {
          attributes[semantic_conventions_1.ExceptionAttribute.STACKTRACE] = exception.stack;
        }
      }
      if (attributes[semantic_conventions_1.ExceptionAttribute.TYPE] || attributes[semantic_conventions_1.ExceptionAttribute.MESSAGE]) {
        this.addEvent(semantic_conventions_1.ExceptionEventName, attributes, time);
      } else {
        api.diag.warn(`Failed to record an exception ${exception}`);
      }
    }
    get duration() {
      return this._duration;
    }
    get ended() {
      return this._ended;
    }
    _isSpanEnded() {
      if (this._ended) {
        api.diag.warn("Can not execute the operation on ended Span {traceId: %s, spanId: %s}", this.spanContext.traceId, this.spanContext.spanId);
      }
      return this._ended;
    }
  };
  exports2.Span = Span;
});

// node_modules/@opentelemetry/tracing/build/src/config.js
var require_config = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.DEFAULT_CONFIG = void 0;
  var core_1 = require_src2();
  exports2.DEFAULT_CONFIG = {
    sampler: new core_1.AlwaysOnSampler(),
    traceParams: {
      numberOfAttributesPerSpan: core_1.getEnv().OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT,
      numberOfLinksPerSpan: core_1.getEnv().OTEL_SPAN_LINK_COUNT_LIMIT,
      numberOfEventsPerSpan: core_1.getEnv().OTEL_SPAN_EVENT_COUNT_LIMIT
    }
  };
});

// node_modules/@opentelemetry/tracing/build/src/utility.js
var require_utility = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.mergeConfig = void 0;
  var config_1 = require_config();
  var core_1 = require_src2();
  function mergeConfig(userConfig) {
    const otelSamplingProbability = core_1.getEnv().OTEL_SAMPLING_PROBABILITY;
    const target = Object.assign({}, config_1.DEFAULT_CONFIG, otelSamplingProbability !== void 0 && otelSamplingProbability < 1 ? {
      sampler: new core_1.ParentBasedSampler({
        root: new core_1.TraceIdRatioBasedSampler(otelSamplingProbability)
      })
    } : {}, userConfig);
    target.traceParams = Object.assign({}, config_1.DEFAULT_CONFIG.traceParams, userConfig.traceParams || {});
    return target;
  }
  exports2.mergeConfig = mergeConfig;
});

// node_modules/@opentelemetry/tracing/build/src/Tracer.js
var require_Tracer = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.Tracer = void 0;
  var api = require_src();
  var core_1 = require_src2();
  var Span_1 = require_Span();
  var utility_1 = require_utility();
  var Tracer = class {
    constructor(instrumentationLibrary, config, _tracerProvider) {
      this._tracerProvider = _tracerProvider;
      const localConfig = utility_1.mergeConfig(config);
      this._sampler = localConfig.sampler;
      this._traceParams = localConfig.traceParams;
      this._idGenerator = config.idGenerator || new core_1.RandomIdGenerator();
      this.resource = _tracerProvider.resource;
      this.instrumentationLibrary = instrumentationLibrary;
    }
    startSpan(name, options = {}, context = api.context.active()) {
      var _a, _b;
      if (api.isInstrumentationSuppressed(context)) {
        api.diag.debug("Instrumentation suppressed, returning Noop Span");
        return api.NOOP_TRACER.startSpan(name, options, context);
      }
      const parentContext = getParent(options, context);
      const spanId = this._idGenerator.generateSpanId();
      let traceId;
      let traceState;
      if (!parentContext || !api.trace.isSpanContextValid(parentContext)) {
        traceId = this._idGenerator.generateTraceId();
      } else {
        traceId = parentContext.traceId;
        traceState = parentContext.traceState;
      }
      const spanKind = (_a = options.kind) !== null && _a !== void 0 ? _a : api.SpanKind.INTERNAL;
      const links = (_b = options.links) !== null && _b !== void 0 ? _b : [];
      const attributes = core_1.sanitizeAttributes(options.attributes);
      const samplingResult = this._sampler.shouldSample(context, traceId, name, spanKind, attributes, links);
      const traceFlags = samplingResult.decision === api.SamplingDecision.RECORD_AND_SAMPLED ? api.TraceFlags.SAMPLED : api.TraceFlags.NONE;
      const spanContext = {traceId, spanId, traceFlags, traceState};
      if (samplingResult.decision === api.SamplingDecision.NOT_RECORD) {
        api.diag.debug("Recording is off, starting no recording span");
        return api.NOOP_TRACER.startSpan(name, options, api.setSpanContext(context, spanContext));
      }
      const span = new Span_1.Span(this, context, name, spanContext, spanKind, parentContext ? parentContext.spanId : void 0, links, options.startTime);
      span.setAttributes(Object.assign(attributes, samplingResult.attributes));
      return span;
    }
    getActiveTraceParams() {
      return this._traceParams;
    }
    getActiveSpanProcessor() {
      return this._tracerProvider.getActiveSpanProcessor();
    }
  };
  exports2.Tracer = Tracer;
  function getParent(options, context) {
    if (options.root)
      return void 0;
    return api.getSpanContext(context);
  }
});

// node_modules/@opentelemetry/resources/build/src/constants.js
var require_constants4 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.PROCESS_RESOURCE = exports2.SERVICE_RESOURCE = exports2.TELEMETRY_SDK_RESOURCE = exports2.K8S_RESOURCE = exports2.HOST_RESOURCE = exports2.CONTAINER_RESOURCE = exports2.CLOUD_RESOURCE = void 0;
  exports2.CLOUD_RESOURCE = {
    PROVIDER: "cloud.provider",
    ACCOUNT_ID: "cloud.account.id",
    REGION: "cloud.region",
    ZONE: "cloud.zone"
  };
  exports2.CONTAINER_RESOURCE = {
    NAME: "container.name",
    ID: "container.id",
    IMAGE_NAME: "container.image.name",
    IMAGE_TAG: "container.image.tag"
  };
  exports2.HOST_RESOURCE = {
    ID: "host.id",
    NAME: "host.name",
    TYPE: "host.type",
    IMAGE_NAME: "host.image.name",
    IMAGE_ID: "host.image.id",
    IMAGE_VERSION: "host.image.version"
  };
  exports2.K8S_RESOURCE = {
    CLUSTER_NAME: "k8s.cluster.name",
    NAMESPACE_NAME: "k8s.namespace.name",
    POD_NAME: "k8s.pod.name",
    DEPLOYMENT_NAME: "k8s.deployment.name"
  };
  exports2.TELEMETRY_SDK_RESOURCE = {
    NAME: "telemetry.sdk.name",
    LANGUAGE: "telemetry.sdk.language",
    VERSION: "telemetry.sdk.version"
  };
  exports2.SERVICE_RESOURCE = {
    NAME: "service.name",
    NAMESPACE: "service.namespace",
    INSTANCE_ID: "service.instance.id",
    VERSION: "service.version"
  };
  exports2.PROCESS_RESOURCE = {
    COMMAND: "process.command",
    COMMAND_LINE: "process.command_line",
    NAME: "process.executable.name",
    OWNER: "process.owner",
    PATH: "process.executable.path",
    PID: "process.id"
  };
});

// node_modules/@opentelemetry/resources/build/src/Resource.js
var require_Resource = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.Resource = void 0;
  var core_1 = require_src2();
  var constants_1 = require_constants4();
  var Resource = class {
    constructor(attributes) {
      this.attributes = attributes;
    }
    static empty() {
      return Resource.EMPTY;
    }
    static createTelemetrySDKResource() {
      return new Resource({
        [constants_1.TELEMETRY_SDK_RESOURCE.LANGUAGE]: core_1.SDK_INFO.LANGUAGE,
        [constants_1.TELEMETRY_SDK_RESOURCE.NAME]: core_1.SDK_INFO.NAME,
        [constants_1.TELEMETRY_SDK_RESOURCE.VERSION]: core_1.SDK_INFO.VERSION
      });
    }
    merge(other) {
      if (!other || !Object.keys(other.attributes).length)
        return this;
      const mergedAttributes = Object.assign({}, this.attributes, other.attributes);
      return new Resource(mergedAttributes);
    }
  };
  exports2.Resource = Resource;
  Resource.EMPTY = new Resource({});
});

// node_modules/@opentelemetry/resources/build/src/platform/node/detect-resources.js
var require_detect_resources = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.detectResources = void 0;
  var Resource_1 = require_Resource();
  var api_1 = require_src();
  var util = require("util");
  var detectResources = async (config = {}) => {
    const internalConfig = Object.assign(config);
    const resources = await Promise.all((internalConfig.detectors || []).map(async (d) => {
      try {
        const resource = await d.detect(internalConfig);
        api_1.diag.debug(`${d.constructor.name} found resource.`, resource);
        return resource;
      } catch (e) {
        api_1.diag.debug(`${d.constructor.name} failed: ${e.message}`);
        return Resource_1.Resource.empty();
      }
    }));
    logResources(resources);
    return resources.reduce((acc, resource) => acc.merge(resource), Resource_1.Resource.createTelemetrySDKResource());
  };
  exports2.detectResources = detectResources;
  var logResources = (resources) => {
    resources.forEach((resource) => {
      if (Object.keys(resource.attributes).length > 0) {
        const resourceDebugString = util.inspect(resource.attributes, {
          depth: 2,
          breakLength: Infinity,
          sorted: true,
          compact: false
        });
        api_1.diag.verbose(resourceDebugString);
      }
    });
  };
});

// node_modules/@opentelemetry/resources/build/src/platform/node/detectors/EnvDetector.js
var require_EnvDetector = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.envDetector = void 0;
  var api_1 = require_src();
  var core_1 = require_src2();
  var __1 = require_src4();
  var EnvDetector = class {
    constructor() {
      this._MAX_LENGTH = 255;
      this._COMMA_SEPARATOR = ",";
      this._LABEL_KEY_VALUE_SPLITTER = "=";
      this._ERROR_MESSAGE_INVALID_CHARS = "should be a ASCII string with a length greater than 0 and not exceed " + this._MAX_LENGTH + " characters.";
      this._ERROR_MESSAGE_INVALID_VALUE = "should be a ASCII string with a length not exceed " + this._MAX_LENGTH + " characters.";
    }
    async detect(_config) {
      try {
        const rawAttributes = core_1.getEnv().OTEL_RESOURCE_ATTRIBUTES;
        if (!rawAttributes) {
          api_1.diag.debug('EnvDetector failed: Environment variable "OTEL_RESOURCE_ATTRIBUTES" is missing.');
          return __1.Resource.empty();
        }
        const attributes = this._parseResourceAttributes(rawAttributes);
        return new __1.Resource(attributes);
      } catch (e) {
        api_1.diag.debug(`EnvDetector failed: ${e.message}`);
        return __1.Resource.empty();
      }
    }
    _parseResourceAttributes(rawEnvAttributes) {
      if (!rawEnvAttributes)
        return {};
      const attributes = {};
      const rawAttributes = rawEnvAttributes.split(this._COMMA_SEPARATOR, -1);
      for (const rawAttribute of rawAttributes) {
        const keyValuePair = rawAttribute.split(this._LABEL_KEY_VALUE_SPLITTER, -1);
        if (keyValuePair.length !== 2) {
          continue;
        }
        let [key, value] = keyValuePair;
        key = key.trim();
        value = value.trim().split('^"|"$').join("");
        if (!this._isValidAndNotEmpty(key)) {
          throw new Error(`Attribute key ${this._ERROR_MESSAGE_INVALID_CHARS}`);
        }
        if (!this._isValid(value)) {
          throw new Error(`Attribute value ${this._ERROR_MESSAGE_INVALID_VALUE}`);
        }
        attributes[key] = value;
      }
      return attributes;
    }
    _isValid(name) {
      return name.length <= this._MAX_LENGTH && this._isPrintableString(name);
    }
    _isPrintableString(str) {
      for (let i = 0; i < str.length; i++) {
        const ch = str.charAt(i);
        if (ch <= " " || ch >= "~") {
          return false;
        }
      }
      return true;
    }
    _isValidAndNotEmpty(str) {
      return str.length > 0 && this._isValid(str);
    }
  };
  exports2.envDetector = new EnvDetector();
});

// node_modules/@opentelemetry/resources/build/src/platform/node/detectors/ProcessDetector.js
var require_ProcessDetector = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.processDetector = void 0;
  var api_1 = require_src();
  var __1 = require_src4();
  var ProcessDetector = class {
    async detect(config) {
      const processResource = {
        [__1.PROCESS_RESOURCE.PID]: process.pid,
        [__1.PROCESS_RESOURCE.NAME]: process.title || "",
        [__1.PROCESS_RESOURCE.COMMAND]: process.argv[1] || "",
        [__1.PROCESS_RESOURCE.COMMAND_LINE]: process.argv.join(" ") || ""
      };
      return this._getResourceAttributes(processResource, config);
    }
    _getResourceAttributes(processResource, _config) {
      if (processResource[__1.PROCESS_RESOURCE.NAME] === "" || processResource[__1.PROCESS_RESOURCE.PATH] === "" || processResource[__1.PROCESS_RESOURCE.COMMAND] === "" || processResource[__1.PROCESS_RESOURCE.COMMAND_LINE] === "") {
        api_1.diag.debug("ProcessDetector failed: Unable to find required process resources. ");
        return __1.Resource.empty();
      } else {
        return new __1.Resource(Object.assign({}, processResource));
      }
    }
  };
  exports2.processDetector = new ProcessDetector();
});

// node_modules/@opentelemetry/resources/build/src/platform/node/detectors/index.js
var require_detectors = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_EnvDetector(), exports2);
  __exportStar(require_ProcessDetector(), exports2);
});

// node_modules/@opentelemetry/resources/build/src/platform/node/index.js
var require_node3 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_detect_resources(), exports2);
  __exportStar(require_detectors(), exports2);
});

// node_modules/@opentelemetry/resources/build/src/platform/index.js
var require_platform3 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_node3(), exports2);
});

// node_modules/@opentelemetry/resources/build/src/types.js
var require_types6 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/resources/build/src/config.js
var require_config2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/resources/build/src/index.js
var require_src4 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_Resource(), exports2);
  __exportStar(require_platform3(), exports2);
  __exportStar(require_constants4(), exports2);
  __exportStar(require_types6(), exports2);
  __exportStar(require_config2(), exports2);
});

// node_modules/@opentelemetry/tracing/build/src/MultiSpanProcessor.js
var require_MultiSpanProcessor = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.MultiSpanProcessor = void 0;
  var core_1 = require_src2();
  var MultiSpanProcessor = class {
    constructor(_spanProcessors) {
      this._spanProcessors = _spanProcessors;
    }
    forceFlush() {
      const promises = [];
      for (const spanProcessor of this._spanProcessors) {
        promises.push(spanProcessor.forceFlush());
      }
      return new Promise((resolve) => {
        Promise.all(promises).then(() => {
          resolve();
        }).catch((error) => {
          core_1.globalErrorHandler(error || new Error("MultiSpanProcessor: forceFlush failed"));
          resolve();
        });
      });
    }
    onStart(span, context) {
      for (const spanProcessor of this._spanProcessors) {
        spanProcessor.onStart(span, context);
      }
    }
    onEnd(span) {
      for (const spanProcessor of this._spanProcessors) {
        spanProcessor.onEnd(span);
      }
    }
    shutdown() {
      const promises = [];
      for (const spanProcessor of this._spanProcessors) {
        promises.push(spanProcessor.shutdown());
      }
      return new Promise((resolve, reject) => {
        Promise.all(promises).then(() => {
          resolve();
        }, reject);
      });
    }
  };
  exports2.MultiSpanProcessor = MultiSpanProcessor;
});

// node_modules/@opentelemetry/tracing/build/src/NoopSpanProcessor.js
var require_NoopSpanProcessor = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.NoopSpanProcessor = void 0;
  var NoopSpanProcessor = class {
    onStart(_span, _context) {
    }
    onEnd(_span) {
    }
    shutdown() {
      return Promise.resolve();
    }
    forceFlush() {
      return Promise.resolve();
    }
  };
  exports2.NoopSpanProcessor = NoopSpanProcessor;
});

// node_modules/lodash.merge/index.js
var require_lodash = __commonJS((exports2, module2) => {
  var LARGE_ARRAY_SIZE = 200;
  var HASH_UNDEFINED = "__lodash_hash_undefined__";
  var HOT_COUNT = 800;
  var HOT_SPAN = 16;
  var MAX_SAFE_INTEGER = 9007199254740991;
  var argsTag = "[object Arguments]";
  var arrayTag = "[object Array]";
  var asyncTag = "[object AsyncFunction]";
  var boolTag = "[object Boolean]";
  var dateTag = "[object Date]";
  var errorTag = "[object Error]";
  var funcTag = "[object Function]";
  var genTag = "[object GeneratorFunction]";
  var mapTag = "[object Map]";
  var numberTag = "[object Number]";
  var nullTag = "[object Null]";
  var objectTag = "[object Object]";
  var proxyTag = "[object Proxy]";
  var regexpTag = "[object RegExp]";
  var setTag = "[object Set]";
  var stringTag = "[object String]";
  var undefinedTag = "[object Undefined]";
  var weakMapTag = "[object WeakMap]";
  var arrayBufferTag = "[object ArrayBuffer]";
  var dataViewTag = "[object DataView]";
  var float32Tag = "[object Float32Array]";
  var float64Tag = "[object Float64Array]";
  var int8Tag = "[object Int8Array]";
  var int16Tag = "[object Int16Array]";
  var int32Tag = "[object Int32Array]";
  var uint8Tag = "[object Uint8Array]";
  var uint8ClampedTag = "[object Uint8ClampedArray]";
  var uint16Tag = "[object Uint16Array]";
  var uint32Tag = "[object Uint32Array]";
  var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
  var reIsHostCtor = /^\[object .+?Constructor\]$/;
  var reIsUint = /^(?:0|[1-9]\d*)$/;
  var typedArrayTags = {};
  typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
  typedArrayTags[argsTag] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
  var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
  var freeSelf = typeof self == "object" && self && self.Object === Object && self;
  var root = freeGlobal || freeSelf || Function("return this")();
  var freeExports = typeof exports2 == "object" && exports2 && !exports2.nodeType && exports2;
  var freeModule = freeExports && typeof module2 == "object" && module2 && !module2.nodeType && module2;
  var moduleExports = freeModule && freeModule.exports === freeExports;
  var freeProcess = moduleExports && freeGlobal.process;
  var nodeUtil = function() {
    try {
      var types = freeModule && freeModule.require && freeModule.require("util").types;
      if (types) {
        return types;
      }
      return freeProcess && freeProcess.binding && freeProcess.binding("util");
    } catch (e) {
    }
  }();
  var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;
  function apply(func, thisArg, args) {
    switch (args.length) {
      case 0:
        return func.call(thisArg);
      case 1:
        return func.call(thisArg, args[0]);
      case 2:
        return func.call(thisArg, args[0], args[1]);
      case 3:
        return func.call(thisArg, args[0], args[1], args[2]);
    }
    return func.apply(thisArg, args);
  }
  function baseTimes(n, iteratee) {
    var index = -1, result = Array(n);
    while (++index < n) {
      result[index] = iteratee(index);
    }
    return result;
  }
  function baseUnary(func) {
    return function(value) {
      return func(value);
    };
  }
  function getValue(object, key) {
    return object == null ? void 0 : object[key];
  }
  function overArg(func, transform) {
    return function(arg) {
      return func(transform(arg));
    };
  }
  var arrayProto = Array.prototype;
  var funcProto = Function.prototype;
  var objectProto = Object.prototype;
  var coreJsData = root["__core-js_shared__"];
  var funcToString = funcProto.toString;
  var hasOwnProperty2 = objectProto.hasOwnProperty;
  var maskSrcKey = function() {
    var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || "");
    return uid ? "Symbol(src)_1." + uid : "";
  }();
  var nativeObjectToString = objectProto.toString;
  var objectCtorString = funcToString.call(Object);
  var reIsNative = RegExp("^" + funcToString.call(hasOwnProperty2).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
  var Buffer2 = moduleExports ? root.Buffer : void 0;
  var Symbol2 = root.Symbol;
  var Uint8Array2 = root.Uint8Array;
  var allocUnsafe = Buffer2 ? Buffer2.allocUnsafe : void 0;
  var getPrototype = overArg(Object.getPrototypeOf, Object);
  var objectCreate = Object.create;
  var propertyIsEnumerable = objectProto.propertyIsEnumerable;
  var splice = arrayProto.splice;
  var symToStringTag = Symbol2 ? Symbol2.toStringTag : void 0;
  var defineProperty = function() {
    try {
      var func = getNative(Object, "defineProperty");
      func({}, "", {});
      return func;
    } catch (e) {
    }
  }();
  var nativeIsBuffer = Buffer2 ? Buffer2.isBuffer : void 0;
  var nativeMax = Math.max;
  var nativeNow = Date.now;
  var Map2 = getNative(root, "Map");
  var nativeCreate = getNative(Object, "create");
  var baseCreate = function() {
    function object() {
    }
    return function(proto) {
      if (!isObject2(proto)) {
        return {};
      }
      if (objectCreate) {
        return objectCreate(proto);
      }
      object.prototype = proto;
      var result = new object();
      object.prototype = void 0;
      return result;
    };
  }();
  function Hash(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  function hashClear() {
    this.__data__ = nativeCreate ? nativeCreate(null) : {};
    this.size = 0;
  }
  function hashDelete(key) {
    var result = this.has(key) && delete this.__data__[key];
    this.size -= result ? 1 : 0;
    return result;
  }
  function hashGet(key) {
    var data = this.__data__;
    if (nativeCreate) {
      var result = data[key];
      return result === HASH_UNDEFINED ? void 0 : result;
    }
    return hasOwnProperty2.call(data, key) ? data[key] : void 0;
  }
  function hashHas(key) {
    var data = this.__data__;
    return nativeCreate ? data[key] !== void 0 : hasOwnProperty2.call(data, key);
  }
  function hashSet(key, value) {
    var data = this.__data__;
    this.size += this.has(key) ? 0 : 1;
    data[key] = nativeCreate && value === void 0 ? HASH_UNDEFINED : value;
    return this;
  }
  Hash.prototype.clear = hashClear;
  Hash.prototype["delete"] = hashDelete;
  Hash.prototype.get = hashGet;
  Hash.prototype.has = hashHas;
  Hash.prototype.set = hashSet;
  function ListCache(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  function listCacheClear() {
    this.__data__ = [];
    this.size = 0;
  }
  function listCacheDelete(key) {
    var data = this.__data__, index = assocIndexOf(data, key);
    if (index < 0) {
      return false;
    }
    var lastIndex = data.length - 1;
    if (index == lastIndex) {
      data.pop();
    } else {
      splice.call(data, index, 1);
    }
    --this.size;
    return true;
  }
  function listCacheGet(key) {
    var data = this.__data__, index = assocIndexOf(data, key);
    return index < 0 ? void 0 : data[index][1];
  }
  function listCacheHas(key) {
    return assocIndexOf(this.__data__, key) > -1;
  }
  function listCacheSet(key, value) {
    var data = this.__data__, index = assocIndexOf(data, key);
    if (index < 0) {
      ++this.size;
      data.push([key, value]);
    } else {
      data[index][1] = value;
    }
    return this;
  }
  ListCache.prototype.clear = listCacheClear;
  ListCache.prototype["delete"] = listCacheDelete;
  ListCache.prototype.get = listCacheGet;
  ListCache.prototype.has = listCacheHas;
  ListCache.prototype.set = listCacheSet;
  function MapCache(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  function mapCacheClear() {
    this.size = 0;
    this.__data__ = {
      hash: new Hash(),
      map: new (Map2 || ListCache)(),
      string: new Hash()
    };
  }
  function mapCacheDelete(key) {
    var result = getMapData(this, key)["delete"](key);
    this.size -= result ? 1 : 0;
    return result;
  }
  function mapCacheGet(key) {
    return getMapData(this, key).get(key);
  }
  function mapCacheHas(key) {
    return getMapData(this, key).has(key);
  }
  function mapCacheSet(key, value) {
    var data = getMapData(this, key), size = data.size;
    data.set(key, value);
    this.size += data.size == size ? 0 : 1;
    return this;
  }
  MapCache.prototype.clear = mapCacheClear;
  MapCache.prototype["delete"] = mapCacheDelete;
  MapCache.prototype.get = mapCacheGet;
  MapCache.prototype.has = mapCacheHas;
  MapCache.prototype.set = mapCacheSet;
  function Stack(entries) {
    var data = this.__data__ = new ListCache(entries);
    this.size = data.size;
  }
  function stackClear() {
    this.__data__ = new ListCache();
    this.size = 0;
  }
  function stackDelete(key) {
    var data = this.__data__, result = data["delete"](key);
    this.size = data.size;
    return result;
  }
  function stackGet(key) {
    return this.__data__.get(key);
  }
  function stackHas(key) {
    return this.__data__.has(key);
  }
  function stackSet(key, value) {
    var data = this.__data__;
    if (data instanceof ListCache) {
      var pairs = data.__data__;
      if (!Map2 || pairs.length < LARGE_ARRAY_SIZE - 1) {
        pairs.push([key, value]);
        this.size = ++data.size;
        return this;
      }
      data = this.__data__ = new MapCache(pairs);
    }
    data.set(key, value);
    this.size = data.size;
    return this;
  }
  Stack.prototype.clear = stackClear;
  Stack.prototype["delete"] = stackDelete;
  Stack.prototype.get = stackGet;
  Stack.prototype.has = stackHas;
  Stack.prototype.set = stackSet;
  function arrayLikeKeys(value, inherited) {
    var isArr = isArray(value), isArg = !isArr && isArguments(value), isBuff = !isArr && !isArg && isBuffer(value), isType = !isArr && !isArg && !isBuff && isTypedArray(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes(value.length, String) : [], length = result.length;
    for (var key in value) {
      if ((inherited || hasOwnProperty2.call(value, key)) && !(skipIndexes && (key == "length" || isBuff && (key == "offset" || key == "parent") || isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || isIndex(key, length)))) {
        result.push(key);
      }
    }
    return result;
  }
  function assignMergeValue(object, key, value) {
    if (value !== void 0 && !eq(object[key], value) || value === void 0 && !(key in object)) {
      baseAssignValue(object, key, value);
    }
  }
  function assignValue(object, key, value) {
    var objValue = object[key];
    if (!(hasOwnProperty2.call(object, key) && eq(objValue, value)) || value === void 0 && !(key in object)) {
      baseAssignValue(object, key, value);
    }
  }
  function assocIndexOf(array, key) {
    var length = array.length;
    while (length--) {
      if (eq(array[length][0], key)) {
        return length;
      }
    }
    return -1;
  }
  function baseAssignValue(object, key, value) {
    if (key == "__proto__" && defineProperty) {
      defineProperty(object, key, {
        configurable: true,
        enumerable: true,
        value,
        writable: true
      });
    } else {
      object[key] = value;
    }
  }
  var baseFor = createBaseFor();
  function baseGetTag(value) {
    if (value == null) {
      return value === void 0 ? undefinedTag : nullTag;
    }
    return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
  }
  function baseIsArguments(value) {
    return isObjectLike(value) && baseGetTag(value) == argsTag;
  }
  function baseIsNative(value) {
    if (!isObject2(value) || isMasked(value)) {
      return false;
    }
    var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
    return pattern.test(toSource(value));
  }
  function baseIsTypedArray(value) {
    return isObjectLike(value) && isLength(value.length) && !!typedArrayTags[baseGetTag(value)];
  }
  function baseKeysIn(object) {
    if (!isObject2(object)) {
      return nativeKeysIn(object);
    }
    var isProto = isPrototype(object), result = [];
    for (var key in object) {
      if (!(key == "constructor" && (isProto || !hasOwnProperty2.call(object, key)))) {
        result.push(key);
      }
    }
    return result;
  }
  function baseMerge(object, source, srcIndex, customizer, stack) {
    if (object === source) {
      return;
    }
    baseFor(source, function(srcValue, key) {
      stack || (stack = new Stack());
      if (isObject2(srcValue)) {
        baseMergeDeep(object, source, key, srcIndex, baseMerge, customizer, stack);
      } else {
        var newValue = customizer ? customizer(safeGet(object, key), srcValue, key + "", object, source, stack) : void 0;
        if (newValue === void 0) {
          newValue = srcValue;
        }
        assignMergeValue(object, key, newValue);
      }
    }, keysIn);
  }
  function baseMergeDeep(object, source, key, srcIndex, mergeFunc, customizer, stack) {
    var objValue = safeGet(object, key), srcValue = safeGet(source, key), stacked = stack.get(srcValue);
    if (stacked) {
      assignMergeValue(object, key, stacked);
      return;
    }
    var newValue = customizer ? customizer(objValue, srcValue, key + "", object, source, stack) : void 0;
    var isCommon = newValue === void 0;
    if (isCommon) {
      var isArr = isArray(srcValue), isBuff = !isArr && isBuffer(srcValue), isTyped = !isArr && !isBuff && isTypedArray(srcValue);
      newValue = srcValue;
      if (isArr || isBuff || isTyped) {
        if (isArray(objValue)) {
          newValue = objValue;
        } else if (isArrayLikeObject(objValue)) {
          newValue = copyArray(objValue);
        } else if (isBuff) {
          isCommon = false;
          newValue = cloneBuffer(srcValue, true);
        } else if (isTyped) {
          isCommon = false;
          newValue = cloneTypedArray(srcValue, true);
        } else {
          newValue = [];
        }
      } else if (isPlainObject(srcValue) || isArguments(srcValue)) {
        newValue = objValue;
        if (isArguments(objValue)) {
          newValue = toPlainObject(objValue);
        } else if (!isObject2(objValue) || isFunction(objValue)) {
          newValue = initCloneObject(srcValue);
        }
      } else {
        isCommon = false;
      }
    }
    if (isCommon) {
      stack.set(srcValue, newValue);
      mergeFunc(newValue, srcValue, srcIndex, customizer, stack);
      stack["delete"](srcValue);
    }
    assignMergeValue(object, key, newValue);
  }
  function baseRest(func, start) {
    return setToString(overRest(func, start, identity), func + "");
  }
  var baseSetToString = !defineProperty ? identity : function(func, string) {
    return defineProperty(func, "toString", {
      configurable: true,
      enumerable: false,
      value: constant(string),
      writable: true
    });
  };
  function cloneBuffer(buffer, isDeep) {
    if (isDeep) {
      return buffer.slice();
    }
    var length = buffer.length, result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);
    buffer.copy(result);
    return result;
  }
  function cloneArrayBuffer(arrayBuffer) {
    var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
    new Uint8Array2(result).set(new Uint8Array2(arrayBuffer));
    return result;
  }
  function cloneTypedArray(typedArray, isDeep) {
    var buffer = isDeep ? cloneArrayBuffer(typedArray.buffer) : typedArray.buffer;
    return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
  }
  function copyArray(source, array) {
    var index = -1, length = source.length;
    array || (array = Array(length));
    while (++index < length) {
      array[index] = source[index];
    }
    return array;
  }
  function copyObject(source, props, object, customizer) {
    var isNew = !object;
    object || (object = {});
    var index = -1, length = props.length;
    while (++index < length) {
      var key = props[index];
      var newValue = customizer ? customizer(object[key], source[key], key, object, source) : void 0;
      if (newValue === void 0) {
        newValue = source[key];
      }
      if (isNew) {
        baseAssignValue(object, key, newValue);
      } else {
        assignValue(object, key, newValue);
      }
    }
    return object;
  }
  function createAssigner(assigner) {
    return baseRest(function(object, sources) {
      var index = -1, length = sources.length, customizer = length > 1 ? sources[length - 1] : void 0, guard = length > 2 ? sources[2] : void 0;
      customizer = assigner.length > 3 && typeof customizer == "function" ? (length--, customizer) : void 0;
      if (guard && isIterateeCall(sources[0], sources[1], guard)) {
        customizer = length < 3 ? void 0 : customizer;
        length = 1;
      }
      object = Object(object);
      while (++index < length) {
        var source = sources[index];
        if (source) {
          assigner(object, source, index, customizer);
        }
      }
      return object;
    });
  }
  function createBaseFor(fromRight) {
    return function(object, iteratee, keysFunc) {
      var index = -1, iterable = Object(object), props = keysFunc(object), length = props.length;
      while (length--) {
        var key = props[fromRight ? length : ++index];
        if (iteratee(iterable[key], key, iterable) === false) {
          break;
        }
      }
      return object;
    };
  }
  function getMapData(map, key) {
    var data = map.__data__;
    return isKeyable(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
  }
  function getNative(object, key) {
    var value = getValue(object, key);
    return baseIsNative(value) ? value : void 0;
  }
  function getRawTag(value) {
    var isOwn = hasOwnProperty2.call(value, symToStringTag), tag = value[symToStringTag];
    try {
      value[symToStringTag] = void 0;
      var unmasked = true;
    } catch (e) {
    }
    var result = nativeObjectToString.call(value);
    if (unmasked) {
      if (isOwn) {
        value[symToStringTag] = tag;
      } else {
        delete value[symToStringTag];
      }
    }
    return result;
  }
  function initCloneObject(object) {
    return typeof object.constructor == "function" && !isPrototype(object) ? baseCreate(getPrototype(object)) : {};
  }
  function isIndex(value, length) {
    var type = typeof value;
    length = length == null ? MAX_SAFE_INTEGER : length;
    return !!length && (type == "number" || type != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
  }
  function isIterateeCall(value, index, object) {
    if (!isObject2(object)) {
      return false;
    }
    var type = typeof index;
    if (type == "number" ? isArrayLike(object) && isIndex(index, object.length) : type == "string" && index in object) {
      return eq(object[index], value);
    }
    return false;
  }
  function isKeyable(value) {
    var type = typeof value;
    return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
  }
  function isMasked(func) {
    return !!maskSrcKey && maskSrcKey in func;
  }
  function isPrototype(value) {
    var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto;
    return value === proto;
  }
  function nativeKeysIn(object) {
    var result = [];
    if (object != null) {
      for (var key in Object(object)) {
        result.push(key);
      }
    }
    return result;
  }
  function objectToString(value) {
    return nativeObjectToString.call(value);
  }
  function overRest(func, start, transform) {
    start = nativeMax(start === void 0 ? func.length - 1 : start, 0);
    return function() {
      var args = arguments, index = -1, length = nativeMax(args.length - start, 0), array = Array(length);
      while (++index < length) {
        array[index] = args[start + index];
      }
      index = -1;
      var otherArgs = Array(start + 1);
      while (++index < start) {
        otherArgs[index] = args[index];
      }
      otherArgs[start] = transform(array);
      return apply(func, this, otherArgs);
    };
  }
  function safeGet(object, key) {
    if (key === "constructor" && typeof object[key] === "function") {
      return;
    }
    if (key == "__proto__") {
      return;
    }
    return object[key];
  }
  var setToString = shortOut(baseSetToString);
  function shortOut(func) {
    var count = 0, lastCalled = 0;
    return function() {
      var stamp = nativeNow(), remaining = HOT_SPAN - (stamp - lastCalled);
      lastCalled = stamp;
      if (remaining > 0) {
        if (++count >= HOT_COUNT) {
          return arguments[0];
        }
      } else {
        count = 0;
      }
      return func.apply(void 0, arguments);
    };
  }
  function toSource(func) {
    if (func != null) {
      try {
        return funcToString.call(func);
      } catch (e) {
      }
      try {
        return func + "";
      } catch (e) {
      }
    }
    return "";
  }
  function eq(value, other) {
    return value === other || value !== value && other !== other;
  }
  var isArguments = baseIsArguments(function() {
    return arguments;
  }()) ? baseIsArguments : function(value) {
    return isObjectLike(value) && hasOwnProperty2.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
  };
  var isArray = Array.isArray;
  function isArrayLike(value) {
    return value != null && isLength(value.length) && !isFunction(value);
  }
  function isArrayLikeObject(value) {
    return isObjectLike(value) && isArrayLike(value);
  }
  var isBuffer = nativeIsBuffer || stubFalse;
  function isFunction(value) {
    if (!isObject2(value)) {
      return false;
    }
    var tag = baseGetTag(value);
    return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
  }
  function isLength(value) {
    return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
  }
  function isObject2(value) {
    var type = typeof value;
    return value != null && (type == "object" || type == "function");
  }
  function isObjectLike(value) {
    return value != null && typeof value == "object";
  }
  function isPlainObject(value) {
    if (!isObjectLike(value) || baseGetTag(value) != objectTag) {
      return false;
    }
    var proto = getPrototype(value);
    if (proto === null) {
      return true;
    }
    var Ctor = hasOwnProperty2.call(proto, "constructor") && proto.constructor;
    return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString.call(Ctor) == objectCtorString;
  }
  var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;
  function toPlainObject(value) {
    return copyObject(value, keysIn(value));
  }
  function keysIn(object) {
    return isArrayLike(object) ? arrayLikeKeys(object, true) : baseKeysIn(object);
  }
  var merge = createAssigner(function(object, source, srcIndex) {
    baseMerge(object, source, srcIndex);
  });
  function constant(value) {
    return function() {
      return value;
    };
  }
  function identity(value) {
    return value;
  }
  function stubFalse() {
    return false;
  }
  module2.exports = merge;
});

// node_modules/@opentelemetry/tracing/build/src/BasicTracerProvider.js
var require_BasicTracerProvider = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.BasicTracerProvider = void 0;
  var api_1 = require_src();
  var core_1 = require_src2();
  var resources_1 = require_src4();
  var _1 = require_src5();
  var config_1 = require_config();
  var MultiSpanProcessor_1 = require_MultiSpanProcessor();
  var NoopSpanProcessor_1 = require_NoopSpanProcessor();
  var merge = require_lodash();
  var BasicTracerProvider = class {
    constructor(config = {}) {
      var _a;
      this._registeredSpanProcessors = [];
      this._tracers = new Map();
      this.activeSpanProcessor = new NoopSpanProcessor_1.NoopSpanProcessor();
      const mergedConfig = merge({}, config_1.DEFAULT_CONFIG, config);
      this.resource = (_a = mergedConfig.resource) !== null && _a !== void 0 ? _a : resources_1.Resource.createTelemetrySDKResource();
      this._config = Object.assign({}, mergedConfig, {
        resource: this.resource
      });
    }
    getTracer(name, version) {
      const key = `${name}@${version || ""}`;
      if (!this._tracers.has(key)) {
        this._tracers.set(key, new _1.Tracer({name, version}, this._config, this));
      }
      return this._tracers.get(key);
    }
    addSpanProcessor(spanProcessor) {
      this._registeredSpanProcessors.push(spanProcessor);
      this.activeSpanProcessor = new MultiSpanProcessor_1.MultiSpanProcessor(this._registeredSpanProcessors);
    }
    getActiveSpanProcessor() {
      return this.activeSpanProcessor;
    }
    register(config = {}) {
      api_1.trace.setGlobalTracerProvider(this);
      if (config.propagator === void 0) {
        config.propagator = new core_1.CompositePropagator({
          propagators: [new core_1.HttpBaggage(), new core_1.HttpTraceContext()]
        });
      }
      if (config.contextManager) {
        api_1.context.setGlobalContextManager(config.contextManager);
      }
      if (config.propagator) {
        api_1.propagation.setGlobalPropagator(config.propagator);
      }
    }
    shutdown() {
      return this.activeSpanProcessor.shutdown();
    }
  };
  exports2.BasicTracerProvider = BasicTracerProvider;
});

// node_modules/@opentelemetry/tracing/build/src/export/ConsoleSpanExporter.js
var require_ConsoleSpanExporter = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.ConsoleSpanExporter = void 0;
  var core_1 = require_src2();
  var ConsoleSpanExporter = class {
    export(spans, resultCallback) {
      return this._sendSpans(spans, resultCallback);
    }
    shutdown() {
      this._sendSpans([]);
      return Promise.resolve();
    }
    _exportInfo(span) {
      return {
        traceId: span.spanContext.traceId,
        parentId: span.parentSpanId,
        name: span.name,
        id: span.spanContext.spanId,
        kind: span.kind,
        timestamp: core_1.hrTimeToMicroseconds(span.startTime),
        duration: core_1.hrTimeToMicroseconds(span.duration),
        attributes: span.attributes,
        status: span.status,
        events: span.events
      };
    }
    _sendSpans(spans, done) {
      for (const span of spans) {
        console.log(this._exportInfo(span));
      }
      if (done) {
        return done({code: core_1.ExportResultCode.SUCCESS});
      }
    }
  };
  exports2.ConsoleSpanExporter = ConsoleSpanExporter;
});

// node_modules/@opentelemetry/tracing/build/src/export/BatchSpanProcessor.js
var require_BatchSpanProcessor = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.BatchSpanProcessor = void 0;
  var api_1 = require_src();
  var core_1 = require_src2();
  var BatchSpanProcessor = class {
    constructor(_exporter, config) {
      this._exporter = _exporter;
      this._finishedSpans = [];
      this._isShutdown = false;
      this._shuttingDownPromise = Promise.resolve();
      const env = core_1.getEnv();
      this._maxExportBatchSize = typeof (config === null || config === void 0 ? void 0 : config.maxExportBatchSize) === "number" ? config.maxExportBatchSize : env.OTEL_BSP_MAX_EXPORT_BATCH_SIZE;
      this._maxQueueSize = typeof (config === null || config === void 0 ? void 0 : config.maxQueueSize) === "number" ? config === null || config === void 0 ? void 0 : config.maxQueueSize : env.OTEL_BSP_MAX_QUEUE_SIZE;
      this._scheduledDelayMillis = typeof (config === null || config === void 0 ? void 0 : config.scheduledDelayMillis) === "number" ? config === null || config === void 0 ? void 0 : config.scheduledDelayMillis : env.OTEL_BSP_SCHEDULE_DELAY;
      this._exportTimeoutMillis = typeof (config === null || config === void 0 ? void 0 : config.exportTimeoutMillis) === "number" ? config === null || config === void 0 ? void 0 : config.exportTimeoutMillis : env.OTEL_BSP_EXPORT_TIMEOUT;
    }
    forceFlush() {
      if (this._isShutdown) {
        return this._shuttingDownPromise;
      }
      return this._flushAll();
    }
    onStart(_span) {
    }
    onEnd(span) {
      if (this._isShutdown) {
        return;
      }
      this._addToBuffer(span);
    }
    shutdown() {
      if (this._isShutdown) {
        return this._shuttingDownPromise;
      }
      this._isShutdown = true;
      this._shuttingDownPromise = new Promise((resolve, reject) => {
        Promise.resolve().then(() => {
          return this._flushAll();
        }).then(() => {
          return this._exporter.shutdown();
        }).then(resolve).catch((e) => {
          reject(e);
        });
      });
      return this._shuttingDownPromise;
    }
    _addToBuffer(span) {
      if (this._finishedSpans.length >= this._maxQueueSize) {
        return;
      }
      this._finishedSpans.push(span);
      this._maybeStartTimer();
    }
    _flushAll() {
      return new Promise((resolve, reject) => {
        const promises = [];
        const count = Math.ceil(this._finishedSpans.length / this._maxExportBatchSize);
        for (let i = 0, j = count; i < j; i++) {
          promises.push(this._flushOneBatch());
        }
        Promise.all(promises).then(() => {
          resolve();
        }).catch(reject);
      });
    }
    _flushOneBatch() {
      this._clearTimer();
      if (this._finishedSpans.length === 0) {
        return Promise.resolve();
      }
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          reject(new Error("Timeout"));
        }, this._exportTimeoutMillis);
        api_1.context.with(api_1.suppressInstrumentation(api_1.context.active()), () => {
          this._exporter.export(this._finishedSpans.splice(0, this._maxExportBatchSize), (result) => {
            var _a;
            clearTimeout(timer);
            if (result.code === core_1.ExportResultCode.SUCCESS) {
              resolve();
            } else {
              reject((_a = result.error) !== null && _a !== void 0 ? _a : new Error("BatchSpanProcessor: span export failed"));
            }
          });
        });
      });
    }
    _maybeStartTimer() {
      if (this._timer !== void 0)
        return;
      this._timer = setTimeout(() => {
        this._flushOneBatch().catch((e) => {
          core_1.globalErrorHandler(e);
        }).then(() => {
          if (this._finishedSpans.length > 0) {
            this._clearTimer();
            this._maybeStartTimer();
          }
        });
      }, this._scheduledDelayMillis);
      core_1.unrefTimer(this._timer);
    }
    _clearTimer() {
      if (this._timer !== void 0) {
        clearTimeout(this._timer);
        this._timer = void 0;
      }
    }
  };
  exports2.BatchSpanProcessor = BatchSpanProcessor;
});

// node_modules/@opentelemetry/tracing/build/src/export/InMemorySpanExporter.js
var require_InMemorySpanExporter = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.InMemorySpanExporter = void 0;
  var core_1 = require_src2();
  var InMemorySpanExporter = class {
    constructor() {
      this._finishedSpans = [];
      this._stopped = false;
    }
    export(spans, resultCallback) {
      if (this._stopped)
        return resultCallback({
          code: core_1.ExportResultCode.FAILED,
          error: new Error("Exporter has been stopped")
        });
      this._finishedSpans.push(...spans);
      setTimeout(() => resultCallback({code: core_1.ExportResultCode.SUCCESS}), 0);
    }
    shutdown() {
      this._stopped = true;
      this._finishedSpans = [];
      return Promise.resolve();
    }
    reset() {
      this._finishedSpans = [];
    }
    getFinishedSpans() {
      return this._finishedSpans;
    }
  };
  exports2.InMemorySpanExporter = InMemorySpanExporter;
});

// node_modules/@opentelemetry/tracing/build/src/export/ReadableSpan.js
var require_ReadableSpan = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/tracing/build/src/export/SimpleSpanProcessor.js
var require_SimpleSpanProcessor = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.SimpleSpanProcessor = void 0;
  var api_1 = require_src();
  var core_1 = require_src2();
  var SimpleSpanProcessor = class {
    constructor(_exporter) {
      this._exporter = _exporter;
      this._isShutdown = false;
      this._shuttingDownPromise = Promise.resolve();
    }
    forceFlush() {
      return Promise.resolve();
    }
    onStart(_span) {
    }
    onEnd(span) {
      if (this._isShutdown) {
        return;
      }
      api_1.context.with(api_1.suppressInstrumentation(api_1.context.active()), () => {
        this._exporter.export([span], (result) => {
          var _a;
          if (result.code !== core_1.ExportResultCode.SUCCESS) {
            core_1.globalErrorHandler((_a = result.error) !== null && _a !== void 0 ? _a : new Error(`SimpleSpanProcessor: span export failed (status ${result})`));
          }
        });
      });
    }
    shutdown() {
      if (this._isShutdown) {
        return this._shuttingDownPromise;
      }
      this._isShutdown = true;
      this._shuttingDownPromise = new Promise((resolve, reject) => {
        Promise.resolve().then(() => {
          return this._exporter.shutdown();
        }).then(resolve).catch((e) => {
          reject(e);
        });
      });
      return this._shuttingDownPromise;
    }
  };
  exports2.SimpleSpanProcessor = SimpleSpanProcessor;
});

// node_modules/@opentelemetry/tracing/build/src/export/SpanExporter.js
var require_SpanExporter = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/tracing/build/src/SpanProcessor.js
var require_SpanProcessor = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/tracing/build/src/types.js
var require_types7 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
});

// node_modules/@opentelemetry/tracing/build/src/index.js
var require_src5 = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
        __createBinding(exports3, m, p);
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  __exportStar(require_Tracer(), exports2);
  __exportStar(require_BasicTracerProvider(), exports2);
  __exportStar(require_ConsoleSpanExporter(), exports2);
  __exportStar(require_BatchSpanProcessor(), exports2);
  __exportStar(require_InMemorySpanExporter(), exports2);
  __exportStar(require_ReadableSpan(), exports2);
  __exportStar(require_SimpleSpanProcessor(), exports2);
  __exportStar(require_SpanExporter(), exports2);
  __exportStar(require_Span(), exports2);
  __exportStar(require_SpanProcessor(), exports2);
  __exportStar(require_types7(), exports2);
});

// node_modules/@cazoo/telemetry/dist/telemetry/telemetry.js
var require_telemetry = __commonJS((exports2) => {
  "use strict";
  var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    Object.defineProperty(o, k2, {enumerable: true, get: function() {
      return m[k];
    }});
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {enumerable: true, value: v});
  } : function(o, v) {
    o["default"] = v;
  });
  var __importStar = exports2 && exports2.__importStar || function(mod) {
    if (mod && mod.__esModule)
      return mod;
    var result = {};
    if (mod != null) {
      for (var k in mod)
        if (k !== "default" && Object.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.Telemetry = void 0;
  var stdOutExporter_1 = require_stdOutExporter();
  var getContext_1 = require_getContext();
  var trace_1 = require_trace2();
  var timeout_1 = require_timeout();
  var tracing_1 = require_src5();
  var debugLog_1 = require_debugLog();
  var contextBase = __importStar(require_context2());
  var api_1 = require_src();
  var MINIMUM_VALID_TIMEOUT_MS = 50;
  var Telemetry2 = class {
    static makeTrace(name, options, parentSpanContext) {
      const exporter = options && options.exporter || new stdOutExporter_1.StdOutExporter();
      const registry = new tracing_1.BasicTracerProvider();
      registry.addSpanProcessor(new tracing_1.SimpleSpanProcessor(exporter));
      const tracer = registry.getTracer("cazoo");
      debugLog_1.debugLog(`Starting the root trace, ${name}`);
      const initialContext = parentSpanContext ? contextBase.setSpanContext(api_1.context.active(), parentSpanContext) : void 0;
      return new trace_1.Trace(tracer, tracer.startSpan(name, {}, initialContext));
    }
    static start(name, options) {
      return Telemetry2.makeTrace(name, options);
    }
    static startWithContext(name, event, context, options) {
      const trace = Telemetry2.makeTrace(name, options).appendContext(getContext_1.getContext(event, context, options));
      this.configureLambdaTimeout(trace, context);
      return trace;
    }
    static continueFromContext(name, event, context, options) {
      const trace = Telemetry2.makeTrace(name, options, getContext_1.getParentSpanContextFromEvent(event)).appendContext(getContext_1.getContext(event, context, options));
      this.configureLambdaTimeout(trace, context);
      return trace;
    }
    static configureLambdaTimeout(trace, context) {
      if (!context)
        return;
      const timeoutMs = context.getRemainingTimeInMillis() - timeout_1.getTimeoutBuffer();
      debugLog_1.debugLog(`${timeoutMs}ms calculated for timeout`);
      if (timeoutMs >= MINIMUM_VALID_TIMEOUT_MS) {
        debugLog_1.debugLog(`setting the timeout for ${timeoutMs} milliseconds from now`);
        const timeout = setTimeout(() => trace.timeout(timeoutMs), timeoutMs);
        trace.setTimeoutCallback(timeout);
        return;
      }
      debugLog_1.debugLog("Timeout below minimum valid timeout. Not setting timeout.");
    }
  };
  exports2.Telemetry = Telemetry2;
});

// node_modules/@cazoo/telemetry/dist/telemetry/exporters/silentExporter.js
var require_silentExporter = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.SilentExporter = void 0;
  var SilentExporter2 = class {
    export(_, __) {
    }
    async shutdown() {
    }
  };
  exports2.SilentExporter = SilentExporter2;
});

// node_modules/lodash.isobject/index.js
var require_lodash2 = __commonJS((exports2, module2) => {
  function isObject2(value) {
    var type = typeof value;
    return !!value && (type == "object" || type == "function");
  }
  module2.exports = isObject2;
});

// node_modules/@cazoo/telemetry/dist/telemetry/exporters/masker.js
var require_masker = __commonJS((exports2) => {
  "use strict";
  var __importDefault = exports2 && exports2.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {default: mod};
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.masker = void 0;
  var lodash_isobject_1 = __importDefault(require_lodash2());
  var secretMask2 = "[REDACTED]";
  function attemptJsonParse(attribute) {
    try {
      const parsed = JSON.parse(attribute);
      if (typeof attribute === "string" && lodash_isobject_1.default(parsed)) {
        return parsed;
      }
    } catch (_a) {
    }
  }
  function generatePath(path, property) {
    return `${path.join(".")}${path.length !== 0 ? "." : ""}${property}`;
  }
  function pathIsAllowedField(path, allowedFieldPaths) {
    return allowedFieldPaths.includes(path);
  }
  function maskExcludingAllowedFields(attributes, allowedFieldPaths, basePath2 = null) {
    const path = basePath2 === null ? [] : basePath2;
    const span = {};
    if (!lodash_isobject_1.default(attributes)) {
      span[attributes] = secretMask2;
      if (pathIsAllowedField(generatePath(path, attributes), allowedFieldPaths)) {
        span[attributes] = attributes;
      }
      return span[attributes];
    }
    for (const property in attributes) {
      if (!attributes.hasOwnProperty(property))
        continue;
      const parsed = attemptJsonParse(attributes[property]);
      const isParsed = parsed !== void 0;
      if (isParsed) {
        attributes[property] = parsed;
      }
      span[property] = secretMask2;
      const propertyValue = attributes[property];
      if (pathIsAllowedField(generatePath(path, property), allowedFieldPaths)) {
        span[property] = attributes[property];
        continue;
      }
      if (Array.isArray(propertyValue)) {
        span[property] = propertyValue.map((arrItem) => maskExcludingAllowedFields(arrItem, allowedFieldPaths, [
          ...path,
          arrItem
        ]));
        continue;
      }
      if (lodash_isobject_1.default(propertyValue)) {
        span[property] = maskExcludingAllowedFields(propertyValue, allowedFieldPaths, [...path, property]);
      }
      if (isParsed) {
        span[property] = JSON.stringify(span[property]);
      }
    }
    return span;
  }
  function masker(attributes, allowedFieldPaths = []) {
    return maskExcludingAllowedFields(attributes, allowedFieldPaths);
  }
  exports2.masker = masker;
});

// node_modules/@cazoo/telemetry/dist/telemetry/exporters/maskedExporterDecorator.js
var require_maskedExporterDecorator = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.MaskedExporterDecorator = void 0;
  var masker_1 = require_masker();
  var stdOutExporter_1 = require_stdOutExporter();
  var MaskedExporterDecorator = class extends stdOutExporter_1.StdOutExporter {
    constructor(exporter, allowedFieldPaths = []) {
      super();
      this.exporter = exporter;
      this.allowedFieldPaths = allowedFieldPaths;
    }
    export(spans, done) {
      const maskedExporter = spans.map((span) => {
        span.attributes = masker_1.masker(span.attributes, this.allowedFieldPaths);
        return span;
      });
      this.exporter.export(maskedExporter, done);
    }
    shutdown() {
      return this.exporter.shutdown();
    }
  };
  exports2.MaskedExporterDecorator = MaskedExporterDecorator;
});

// node_modules/@cazoo/telemetry/dist/index.js
var require_dist3 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var telemetry_1 = require_telemetry();
  Object.defineProperty(exports2, "Telemetry", {enumerable: true, get: function() {
    return telemetry_1.Telemetry;
  }});
  var trace_1 = require_trace2();
  Object.defineProperty(exports2, "Trace", {enumerable: true, get: function() {
    return trace_1.Trace;
  }});
  var silentExporter_1 = require_silentExporter();
  Object.defineProperty(exports2, "SilentExporter", {enumerable: true, get: function() {
    return silentExporter_1.SilentExporter;
  }});
  var stdOutExporter_1 = require_stdOutExporter();
  Object.defineProperty(exports2, "StdOutExporter", {enumerable: true, get: function() {
    return stdOutExporter_1.StdOutExporter;
  }});
  var maskedExporterDecorator_1 = require_maskedExporterDecorator();
  Object.defineProperty(exports2, "MaskedExporterDecorator", {enumerable: true, get: function() {
    return maskedExporterDecorator_1.MaskedExporterDecorator;
  }});
});

// node_modules/node-fetch/lib/index.js
var require_lib2 = __commonJS((exports2, module2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  function _interopDefault(ex) {
    return ex && typeof ex === "object" && "default" in ex ? ex["default"] : ex;
  }
  var Stream = _interopDefault(require("stream"));
  var http = _interopDefault(require("http"));
  var Url = _interopDefault(require("url"));
  var https = _interopDefault(require("https"));
  var zlib = _interopDefault(require("zlib"));
  var Readable = Stream.Readable;
  var BUFFER = Symbol("buffer");
  var TYPE = Symbol("type");
  var Blob = class {
    constructor() {
      this[TYPE] = "";
      const blobParts = arguments[0];
      const options = arguments[1];
      const buffers = [];
      let size = 0;
      if (blobParts) {
        const a = blobParts;
        const length = Number(a.length);
        for (let i = 0; i < length; i++) {
          const element = a[i];
          let buffer;
          if (element instanceof Buffer) {
            buffer = element;
          } else if (ArrayBuffer.isView(element)) {
            buffer = Buffer.from(element.buffer, element.byteOffset, element.byteLength);
          } else if (element instanceof ArrayBuffer) {
            buffer = Buffer.from(element);
          } else if (element instanceof Blob) {
            buffer = element[BUFFER];
          } else {
            buffer = Buffer.from(typeof element === "string" ? element : String(element));
          }
          size += buffer.length;
          buffers.push(buffer);
        }
      }
      this[BUFFER] = Buffer.concat(buffers);
      let type = options && options.type !== void 0 && String(options.type).toLowerCase();
      if (type && !/[^\u0020-\u007E]/.test(type)) {
        this[TYPE] = type;
      }
    }
    get size() {
      return this[BUFFER].length;
    }
    get type() {
      return this[TYPE];
    }
    text() {
      return Promise.resolve(this[BUFFER].toString());
    }
    arrayBuffer() {
      const buf = this[BUFFER];
      const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
      return Promise.resolve(ab);
    }
    stream() {
      const readable = new Readable();
      readable._read = function() {
      };
      readable.push(this[BUFFER]);
      readable.push(null);
      return readable;
    }
    toString() {
      return "[object Blob]";
    }
    slice() {
      const size = this.size;
      const start = arguments[0];
      const end = arguments[1];
      let relativeStart, relativeEnd;
      if (start === void 0) {
        relativeStart = 0;
      } else if (start < 0) {
        relativeStart = Math.max(size + start, 0);
      } else {
        relativeStart = Math.min(start, size);
      }
      if (end === void 0) {
        relativeEnd = size;
      } else if (end < 0) {
        relativeEnd = Math.max(size + end, 0);
      } else {
        relativeEnd = Math.min(end, size);
      }
      const span = Math.max(relativeEnd - relativeStart, 0);
      const buffer = this[BUFFER];
      const slicedBuffer = buffer.slice(relativeStart, relativeStart + span);
      const blob = new Blob([], {type: arguments[2]});
      blob[BUFFER] = slicedBuffer;
      return blob;
    }
  };
  Object.defineProperties(Blob.prototype, {
    size: {enumerable: true},
    type: {enumerable: true},
    slice: {enumerable: true}
  });
  Object.defineProperty(Blob.prototype, Symbol.toStringTag, {
    value: "Blob",
    writable: false,
    enumerable: false,
    configurable: true
  });
  function FetchError(message, type, systemError) {
    Error.call(this, message);
    this.message = message;
    this.type = type;
    if (systemError) {
      this.code = this.errno = systemError.code;
    }
    Error.captureStackTrace(this, this.constructor);
  }
  FetchError.prototype = Object.create(Error.prototype);
  FetchError.prototype.constructor = FetchError;
  FetchError.prototype.name = "FetchError";
  var convert;
  try {
    convert = require("encoding").convert;
  } catch (e) {
  }
  var INTERNALS = Symbol("Body internals");
  var PassThrough = Stream.PassThrough;
  function Body(body) {
    var _this = this;
    var _ref = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, _ref$size = _ref.size;
    let size = _ref$size === void 0 ? 0 : _ref$size;
    var _ref$timeout = _ref.timeout;
    let timeout = _ref$timeout === void 0 ? 0 : _ref$timeout;
    if (body == null) {
      body = null;
    } else if (isURLSearchParams(body)) {
      body = Buffer.from(body.toString());
    } else if (isBlob(body))
      ;
    else if (Buffer.isBuffer(body))
      ;
    else if (Object.prototype.toString.call(body) === "[object ArrayBuffer]") {
      body = Buffer.from(body);
    } else if (ArrayBuffer.isView(body)) {
      body = Buffer.from(body.buffer, body.byteOffset, body.byteLength);
    } else if (body instanceof Stream)
      ;
    else {
      body = Buffer.from(String(body));
    }
    this[INTERNALS] = {
      body,
      disturbed: false,
      error: null
    };
    this.size = size;
    this.timeout = timeout;
    if (body instanceof Stream) {
      body.on("error", function(err) {
        const error = err.name === "AbortError" ? err : new FetchError(`Invalid response body while trying to fetch ${_this.url}: ${err.message}`, "system", err);
        _this[INTERNALS].error = error;
      });
    }
  }
  Body.prototype = {
    get body() {
      return this[INTERNALS].body;
    },
    get bodyUsed() {
      return this[INTERNALS].disturbed;
    },
    arrayBuffer() {
      return consumeBody.call(this).then(function(buf) {
        return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
      });
    },
    blob() {
      let ct = this.headers && this.headers.get("content-type") || "";
      return consumeBody.call(this).then(function(buf) {
        return Object.assign(new Blob([], {
          type: ct.toLowerCase()
        }), {
          [BUFFER]: buf
        });
      });
    },
    json() {
      var _this2 = this;
      return consumeBody.call(this).then(function(buffer) {
        try {
          return JSON.parse(buffer.toString());
        } catch (err) {
          return Body.Promise.reject(new FetchError(`invalid json response body at ${_this2.url} reason: ${err.message}`, "invalid-json"));
        }
      });
    },
    text() {
      return consumeBody.call(this).then(function(buffer) {
        return buffer.toString();
      });
    },
    buffer() {
      return consumeBody.call(this);
    },
    textConverted() {
      var _this3 = this;
      return consumeBody.call(this).then(function(buffer) {
        return convertBody(buffer, _this3.headers);
      });
    }
  };
  Object.defineProperties(Body.prototype, {
    body: {enumerable: true},
    bodyUsed: {enumerable: true},
    arrayBuffer: {enumerable: true},
    blob: {enumerable: true},
    json: {enumerable: true},
    text: {enumerable: true}
  });
  Body.mixIn = function(proto) {
    for (const name of Object.getOwnPropertyNames(Body.prototype)) {
      if (!(name in proto)) {
        const desc = Object.getOwnPropertyDescriptor(Body.prototype, name);
        Object.defineProperty(proto, name, desc);
      }
    }
  };
  function consumeBody() {
    var _this4 = this;
    if (this[INTERNALS].disturbed) {
      return Body.Promise.reject(new TypeError(`body used already for: ${this.url}`));
    }
    this[INTERNALS].disturbed = true;
    if (this[INTERNALS].error) {
      return Body.Promise.reject(this[INTERNALS].error);
    }
    let body = this.body;
    if (body === null) {
      return Body.Promise.resolve(Buffer.alloc(0));
    }
    if (isBlob(body)) {
      body = body.stream();
    }
    if (Buffer.isBuffer(body)) {
      return Body.Promise.resolve(body);
    }
    if (!(body instanceof Stream)) {
      return Body.Promise.resolve(Buffer.alloc(0));
    }
    let accum = [];
    let accumBytes = 0;
    let abort = false;
    return new Body.Promise(function(resolve, reject) {
      let resTimeout;
      if (_this4.timeout) {
        resTimeout = setTimeout(function() {
          abort = true;
          reject(new FetchError(`Response timeout while trying to fetch ${_this4.url} (over ${_this4.timeout}ms)`, "body-timeout"));
        }, _this4.timeout);
      }
      body.on("error", function(err) {
        if (err.name === "AbortError") {
          abort = true;
          reject(err);
        } else {
          reject(new FetchError(`Invalid response body while trying to fetch ${_this4.url}: ${err.message}`, "system", err));
        }
      });
      body.on("data", function(chunk) {
        if (abort || chunk === null) {
          return;
        }
        if (_this4.size && accumBytes + chunk.length > _this4.size) {
          abort = true;
          reject(new FetchError(`content size at ${_this4.url} over limit: ${_this4.size}`, "max-size"));
          return;
        }
        accumBytes += chunk.length;
        accum.push(chunk);
      });
      body.on("end", function() {
        if (abort) {
          return;
        }
        clearTimeout(resTimeout);
        try {
          resolve(Buffer.concat(accum, accumBytes));
        } catch (err) {
          reject(new FetchError(`Could not create Buffer from response body for ${_this4.url}: ${err.message}`, "system", err));
        }
      });
    });
  }
  function convertBody(buffer, headers) {
    if (typeof convert !== "function") {
      throw new Error("The package `encoding` must be installed to use the textConverted() function");
    }
    const ct = headers.get("content-type");
    let charset = "utf-8";
    let res, str;
    if (ct) {
      res = /charset=([^;]*)/i.exec(ct);
    }
    str = buffer.slice(0, 1024).toString();
    if (!res && str) {
      res = /<meta.+?charset=(['"])(.+?)\1/i.exec(str);
    }
    if (!res && str) {
      res = /<meta[\s]+?http-equiv=(['"])content-type\1[\s]+?content=(['"])(.+?)\2/i.exec(str);
      if (!res) {
        res = /<meta[\s]+?content=(['"])(.+?)\1[\s]+?http-equiv=(['"])content-type\3/i.exec(str);
        if (res) {
          res.pop();
        }
      }
      if (res) {
        res = /charset=(.*)/i.exec(res.pop());
      }
    }
    if (!res && str) {
      res = /<\?xml.+?encoding=(['"])(.+?)\1/i.exec(str);
    }
    if (res) {
      charset = res.pop();
      if (charset === "gb2312" || charset === "gbk") {
        charset = "gb18030";
      }
    }
    return convert(buffer, "UTF-8", charset).toString();
  }
  function isURLSearchParams(obj) {
    if (typeof obj !== "object" || typeof obj.append !== "function" || typeof obj.delete !== "function" || typeof obj.get !== "function" || typeof obj.getAll !== "function" || typeof obj.has !== "function" || typeof obj.set !== "function") {
      return false;
    }
    return obj.constructor.name === "URLSearchParams" || Object.prototype.toString.call(obj) === "[object URLSearchParams]" || typeof obj.sort === "function";
  }
  function isBlob(obj) {
    return typeof obj === "object" && typeof obj.arrayBuffer === "function" && typeof obj.type === "string" && typeof obj.stream === "function" && typeof obj.constructor === "function" && typeof obj.constructor.name === "string" && /^(Blob|File)$/.test(obj.constructor.name) && /^(Blob|File)$/.test(obj[Symbol.toStringTag]);
  }
  function clone(instance) {
    let p1, p2;
    let body = instance.body;
    if (instance.bodyUsed) {
      throw new Error("cannot clone body after it is used");
    }
    if (body instanceof Stream && typeof body.getBoundary !== "function") {
      p1 = new PassThrough();
      p2 = new PassThrough();
      body.pipe(p1);
      body.pipe(p2);
      instance[INTERNALS].body = p1;
      body = p2;
    }
    return body;
  }
  function extractContentType(body) {
    if (body === null) {
      return null;
    } else if (typeof body === "string") {
      return "text/plain;charset=UTF-8";
    } else if (isURLSearchParams(body)) {
      return "application/x-www-form-urlencoded;charset=UTF-8";
    } else if (isBlob(body)) {
      return body.type || null;
    } else if (Buffer.isBuffer(body)) {
      return null;
    } else if (Object.prototype.toString.call(body) === "[object ArrayBuffer]") {
      return null;
    } else if (ArrayBuffer.isView(body)) {
      return null;
    } else if (typeof body.getBoundary === "function") {
      return `multipart/form-data;boundary=${body.getBoundary()}`;
    } else if (body instanceof Stream) {
      return null;
    } else {
      return "text/plain;charset=UTF-8";
    }
  }
  function getTotalBytes(instance) {
    const body = instance.body;
    if (body === null) {
      return 0;
    } else if (isBlob(body)) {
      return body.size;
    } else if (Buffer.isBuffer(body)) {
      return body.length;
    } else if (body && typeof body.getLengthSync === "function") {
      if (body._lengthRetrievers && body._lengthRetrievers.length == 0 || body.hasKnownLength && body.hasKnownLength()) {
        return body.getLengthSync();
      }
      return null;
    } else {
      return null;
    }
  }
  function writeToStream(dest, instance) {
    const body = instance.body;
    if (body === null) {
      dest.end();
    } else if (isBlob(body)) {
      body.stream().pipe(dest);
    } else if (Buffer.isBuffer(body)) {
      dest.write(body);
      dest.end();
    } else {
      body.pipe(dest);
    }
  }
  Body.Promise = global.Promise;
  var invalidTokenRegex = /[^\^_`a-zA-Z\-0-9!#$%&'*+.|~]/;
  var invalidHeaderCharRegex = /[^\t\x20-\x7e\x80-\xff]/;
  function validateName(name) {
    name = `${name}`;
    if (invalidTokenRegex.test(name) || name === "") {
      throw new TypeError(`${name} is not a legal HTTP header name`);
    }
  }
  function validateValue(value) {
    value = `${value}`;
    if (invalidHeaderCharRegex.test(value)) {
      throw new TypeError(`${value} is not a legal HTTP header value`);
    }
  }
  function find(map, name) {
    name = name.toLowerCase();
    for (const key in map) {
      if (key.toLowerCase() === name) {
        return key;
      }
    }
    return void 0;
  }
  var MAP = Symbol("map");
  var Headers = class {
    constructor() {
      let init = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : void 0;
      this[MAP] = Object.create(null);
      if (init instanceof Headers) {
        const rawHeaders = init.raw();
        const headerNames = Object.keys(rawHeaders);
        for (const headerName of headerNames) {
          for (const value of rawHeaders[headerName]) {
            this.append(headerName, value);
          }
        }
        return;
      }
      if (init == null)
        ;
      else if (typeof init === "object") {
        const method = init[Symbol.iterator];
        if (method != null) {
          if (typeof method !== "function") {
            throw new TypeError("Header pairs must be iterable");
          }
          const pairs = [];
          for (const pair of init) {
            if (typeof pair !== "object" || typeof pair[Symbol.iterator] !== "function") {
              throw new TypeError("Each header pair must be iterable");
            }
            pairs.push(Array.from(pair));
          }
          for (const pair of pairs) {
            if (pair.length !== 2) {
              throw new TypeError("Each header pair must be a name/value tuple");
            }
            this.append(pair[0], pair[1]);
          }
        } else {
          for (const key of Object.keys(init)) {
            const value = init[key];
            this.append(key, value);
          }
        }
      } else {
        throw new TypeError("Provided initializer must be an object");
      }
    }
    get(name) {
      name = `${name}`;
      validateName(name);
      const key = find(this[MAP], name);
      if (key === void 0) {
        return null;
      }
      return this[MAP][key].join(", ");
    }
    forEach(callback) {
      let thisArg = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : void 0;
      let pairs = getHeaders(this);
      let i = 0;
      while (i < pairs.length) {
        var _pairs$i = pairs[i];
        const name = _pairs$i[0], value = _pairs$i[1];
        callback.call(thisArg, value, name, this);
        pairs = getHeaders(this);
        i++;
      }
    }
    set(name, value) {
      name = `${name}`;
      value = `${value}`;
      validateName(name);
      validateValue(value);
      const key = find(this[MAP], name);
      this[MAP][key !== void 0 ? key : name] = [value];
    }
    append(name, value) {
      name = `${name}`;
      value = `${value}`;
      validateName(name);
      validateValue(value);
      const key = find(this[MAP], name);
      if (key !== void 0) {
        this[MAP][key].push(value);
      } else {
        this[MAP][name] = [value];
      }
    }
    has(name) {
      name = `${name}`;
      validateName(name);
      return find(this[MAP], name) !== void 0;
    }
    delete(name) {
      name = `${name}`;
      validateName(name);
      const key = find(this[MAP], name);
      if (key !== void 0) {
        delete this[MAP][key];
      }
    }
    raw() {
      return this[MAP];
    }
    keys() {
      return createHeadersIterator(this, "key");
    }
    values() {
      return createHeadersIterator(this, "value");
    }
    [Symbol.iterator]() {
      return createHeadersIterator(this, "key+value");
    }
  };
  Headers.prototype.entries = Headers.prototype[Symbol.iterator];
  Object.defineProperty(Headers.prototype, Symbol.toStringTag, {
    value: "Headers",
    writable: false,
    enumerable: false,
    configurable: true
  });
  Object.defineProperties(Headers.prototype, {
    get: {enumerable: true},
    forEach: {enumerable: true},
    set: {enumerable: true},
    append: {enumerable: true},
    has: {enumerable: true},
    delete: {enumerable: true},
    keys: {enumerable: true},
    values: {enumerable: true},
    entries: {enumerable: true}
  });
  function getHeaders(headers) {
    let kind = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "key+value";
    const keys = Object.keys(headers[MAP]).sort();
    return keys.map(kind === "key" ? function(k) {
      return k.toLowerCase();
    } : kind === "value" ? function(k) {
      return headers[MAP][k].join(", ");
    } : function(k) {
      return [k.toLowerCase(), headers[MAP][k].join(", ")];
    });
  }
  var INTERNAL = Symbol("internal");
  function createHeadersIterator(target, kind) {
    const iterator = Object.create(HeadersIteratorPrototype);
    iterator[INTERNAL] = {
      target,
      kind,
      index: 0
    };
    return iterator;
  }
  var HeadersIteratorPrototype = Object.setPrototypeOf({
    next() {
      if (!this || Object.getPrototypeOf(this) !== HeadersIteratorPrototype) {
        throw new TypeError("Value of `this` is not a HeadersIterator");
      }
      var _INTERNAL = this[INTERNAL];
      const target = _INTERNAL.target, kind = _INTERNAL.kind, index = _INTERNAL.index;
      const values = getHeaders(target, kind);
      const len = values.length;
      if (index >= len) {
        return {
          value: void 0,
          done: true
        };
      }
      this[INTERNAL].index = index + 1;
      return {
        value: values[index],
        done: false
      };
    }
  }, Object.getPrototypeOf(Object.getPrototypeOf([][Symbol.iterator]())));
  Object.defineProperty(HeadersIteratorPrototype, Symbol.toStringTag, {
    value: "HeadersIterator",
    writable: false,
    enumerable: false,
    configurable: true
  });
  function exportNodeCompatibleHeaders(headers) {
    const obj = Object.assign({__proto__: null}, headers[MAP]);
    const hostHeaderKey = find(headers[MAP], "Host");
    if (hostHeaderKey !== void 0) {
      obj[hostHeaderKey] = obj[hostHeaderKey][0];
    }
    return obj;
  }
  function createHeadersLenient(obj) {
    const headers = new Headers();
    for (const name of Object.keys(obj)) {
      if (invalidTokenRegex.test(name)) {
        continue;
      }
      if (Array.isArray(obj[name])) {
        for (const val of obj[name]) {
          if (invalidHeaderCharRegex.test(val)) {
            continue;
          }
          if (headers[MAP][name] === void 0) {
            headers[MAP][name] = [val];
          } else {
            headers[MAP][name].push(val);
          }
        }
      } else if (!invalidHeaderCharRegex.test(obj[name])) {
        headers[MAP][name] = [obj[name]];
      }
    }
    return headers;
  }
  var INTERNALS$1 = Symbol("Response internals");
  var STATUS_CODES = http.STATUS_CODES;
  var Response2 = class {
    constructor() {
      let body = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
      let opts = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      Body.call(this, body, opts);
      const status = opts.status || 200;
      const headers = new Headers(opts.headers);
      if (body != null && !headers.has("Content-Type")) {
        const contentType = extractContentType(body);
        if (contentType) {
          headers.append("Content-Type", contentType);
        }
      }
      this[INTERNALS$1] = {
        url: opts.url,
        status,
        statusText: opts.statusText || STATUS_CODES[status],
        headers,
        counter: opts.counter
      };
    }
    get url() {
      return this[INTERNALS$1].url || "";
    }
    get status() {
      return this[INTERNALS$1].status;
    }
    get ok() {
      return this[INTERNALS$1].status >= 200 && this[INTERNALS$1].status < 300;
    }
    get redirected() {
      return this[INTERNALS$1].counter > 0;
    }
    get statusText() {
      return this[INTERNALS$1].statusText;
    }
    get headers() {
      return this[INTERNALS$1].headers;
    }
    clone() {
      return new Response2(clone(this), {
        url: this.url,
        status: this.status,
        statusText: this.statusText,
        headers: this.headers,
        ok: this.ok,
        redirected: this.redirected
      });
    }
  };
  Body.mixIn(Response2.prototype);
  Object.defineProperties(Response2.prototype, {
    url: {enumerable: true},
    status: {enumerable: true},
    ok: {enumerable: true},
    redirected: {enumerable: true},
    statusText: {enumerable: true},
    headers: {enumerable: true},
    clone: {enumerable: true}
  });
  Object.defineProperty(Response2.prototype, Symbol.toStringTag, {
    value: "Response",
    writable: false,
    enumerable: false,
    configurable: true
  });
  var INTERNALS$2 = Symbol("Request internals");
  var parse_url = Url.parse;
  var format_url = Url.format;
  var streamDestructionSupported = "destroy" in Stream.Readable.prototype;
  function isRequest(input) {
    return typeof input === "object" && typeof input[INTERNALS$2] === "object";
  }
  function isAbortSignal(signal) {
    const proto = signal && typeof signal === "object" && Object.getPrototypeOf(signal);
    return !!(proto && proto.constructor.name === "AbortSignal");
  }
  var Request = class {
    constructor(input) {
      let init = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      let parsedURL;
      if (!isRequest(input)) {
        if (input && input.href) {
          parsedURL = parse_url(input.href);
        } else {
          parsedURL = parse_url(`${input}`);
        }
        input = {};
      } else {
        parsedURL = parse_url(input.url);
      }
      let method = init.method || input.method || "GET";
      method = method.toUpperCase();
      if ((init.body != null || isRequest(input) && input.body !== null) && (method === "GET" || method === "HEAD")) {
        throw new TypeError("Request with GET/HEAD method cannot have body");
      }
      let inputBody = init.body != null ? init.body : isRequest(input) && input.body !== null ? clone(input) : null;
      Body.call(this, inputBody, {
        timeout: init.timeout || input.timeout || 0,
        size: init.size || input.size || 0
      });
      const headers = new Headers(init.headers || input.headers || {});
      if (inputBody != null && !headers.has("Content-Type")) {
        const contentType = extractContentType(inputBody);
        if (contentType) {
          headers.append("Content-Type", contentType);
        }
      }
      let signal = isRequest(input) ? input.signal : null;
      if ("signal" in init)
        signal = init.signal;
      if (signal != null && !isAbortSignal(signal)) {
        throw new TypeError("Expected signal to be an instanceof AbortSignal");
      }
      this[INTERNALS$2] = {
        method,
        redirect: init.redirect || input.redirect || "follow",
        headers,
        parsedURL,
        signal
      };
      this.follow = init.follow !== void 0 ? init.follow : input.follow !== void 0 ? input.follow : 20;
      this.compress = init.compress !== void 0 ? init.compress : input.compress !== void 0 ? input.compress : true;
      this.counter = init.counter || input.counter || 0;
      this.agent = init.agent || input.agent;
    }
    get method() {
      return this[INTERNALS$2].method;
    }
    get url() {
      return format_url(this[INTERNALS$2].parsedURL);
    }
    get headers() {
      return this[INTERNALS$2].headers;
    }
    get redirect() {
      return this[INTERNALS$2].redirect;
    }
    get signal() {
      return this[INTERNALS$2].signal;
    }
    clone() {
      return new Request(this);
    }
  };
  Body.mixIn(Request.prototype);
  Object.defineProperty(Request.prototype, Symbol.toStringTag, {
    value: "Request",
    writable: false,
    enumerable: false,
    configurable: true
  });
  Object.defineProperties(Request.prototype, {
    method: {enumerable: true},
    url: {enumerable: true},
    headers: {enumerable: true},
    redirect: {enumerable: true},
    clone: {enumerable: true},
    signal: {enumerable: true}
  });
  function getNodeRequestOptions(request) {
    const parsedURL = request[INTERNALS$2].parsedURL;
    const headers = new Headers(request[INTERNALS$2].headers);
    if (!headers.has("Accept")) {
      headers.set("Accept", "*/*");
    }
    if (!parsedURL.protocol || !parsedURL.hostname) {
      throw new TypeError("Only absolute URLs are supported");
    }
    if (!/^https?:$/.test(parsedURL.protocol)) {
      throw new TypeError("Only HTTP(S) protocols are supported");
    }
    if (request.signal && request.body instanceof Stream.Readable && !streamDestructionSupported) {
      throw new Error("Cancellation of streamed requests with AbortSignal is not supported in node < 8");
    }
    let contentLengthValue = null;
    if (request.body == null && /^(POST|PUT)$/i.test(request.method)) {
      contentLengthValue = "0";
    }
    if (request.body != null) {
      const totalBytes = getTotalBytes(request);
      if (typeof totalBytes === "number") {
        contentLengthValue = String(totalBytes);
      }
    }
    if (contentLengthValue) {
      headers.set("Content-Length", contentLengthValue);
    }
    if (!headers.has("User-Agent")) {
      headers.set("User-Agent", "node-fetch/1.0 (+https://github.com/bitinn/node-fetch)");
    }
    if (request.compress && !headers.has("Accept-Encoding")) {
      headers.set("Accept-Encoding", "gzip,deflate");
    }
    let agent = request.agent;
    if (typeof agent === "function") {
      agent = agent(parsedURL);
    }
    if (!headers.has("Connection") && !agent) {
      headers.set("Connection", "close");
    }
    return Object.assign({}, parsedURL, {
      method: request.method,
      headers: exportNodeCompatibleHeaders(headers),
      agent
    });
  }
  function AbortError(message) {
    Error.call(this, message);
    this.type = "aborted";
    this.message = message;
    Error.captureStackTrace(this, this.constructor);
  }
  AbortError.prototype = Object.create(Error.prototype);
  AbortError.prototype.constructor = AbortError;
  AbortError.prototype.name = "AbortError";
  var PassThrough$1 = Stream.PassThrough;
  var resolve_url = Url.resolve;
  function fetch2(url, opts) {
    if (!fetch2.Promise) {
      throw new Error("native promise missing, set fetch.Promise to your favorite alternative");
    }
    Body.Promise = fetch2.Promise;
    return new fetch2.Promise(function(resolve, reject) {
      const request = new Request(url, opts);
      const options = getNodeRequestOptions(request);
      const send = (options.protocol === "https:" ? https : http).request;
      const signal = request.signal;
      let response = null;
      const abort = function abort2() {
        let error = new AbortError("The user aborted a request.");
        reject(error);
        if (request.body && request.body instanceof Stream.Readable) {
          request.body.destroy(error);
        }
        if (!response || !response.body)
          return;
        response.body.emit("error", error);
      };
      if (signal && signal.aborted) {
        abort();
        return;
      }
      const abortAndFinalize = function abortAndFinalize2() {
        abort();
        finalize();
      };
      const req = send(options);
      let reqTimeout;
      if (signal) {
        signal.addEventListener("abort", abortAndFinalize);
      }
      function finalize() {
        req.abort();
        if (signal)
          signal.removeEventListener("abort", abortAndFinalize);
        clearTimeout(reqTimeout);
      }
      if (request.timeout) {
        req.once("socket", function(socket) {
          reqTimeout = setTimeout(function() {
            reject(new FetchError(`network timeout at: ${request.url}`, "request-timeout"));
            finalize();
          }, request.timeout);
        });
      }
      req.on("error", function(err) {
        reject(new FetchError(`request to ${request.url} failed, reason: ${err.message}`, "system", err));
        finalize();
      });
      req.on("response", function(res) {
        clearTimeout(reqTimeout);
        const headers = createHeadersLenient(res.headers);
        if (fetch2.isRedirect(res.statusCode)) {
          const location = headers.get("Location");
          const locationURL = location === null ? null : resolve_url(request.url, location);
          switch (request.redirect) {
            case "error":
              reject(new FetchError(`uri requested responds with a redirect, redirect mode is set to error: ${request.url}`, "no-redirect"));
              finalize();
              return;
            case "manual":
              if (locationURL !== null) {
                try {
                  headers.set("Location", locationURL);
                } catch (err) {
                  reject(err);
                }
              }
              break;
            case "follow":
              if (locationURL === null) {
                break;
              }
              if (request.counter >= request.follow) {
                reject(new FetchError(`maximum redirect reached at: ${request.url}`, "max-redirect"));
                finalize();
                return;
              }
              const requestOpts = {
                headers: new Headers(request.headers),
                follow: request.follow,
                counter: request.counter + 1,
                agent: request.agent,
                compress: request.compress,
                method: request.method,
                body: request.body,
                signal: request.signal,
                timeout: request.timeout,
                size: request.size
              };
              if (res.statusCode !== 303 && request.body && getTotalBytes(request) === null) {
                reject(new FetchError("Cannot follow redirect with body being a readable stream", "unsupported-redirect"));
                finalize();
                return;
              }
              if (res.statusCode === 303 || (res.statusCode === 301 || res.statusCode === 302) && request.method === "POST") {
                requestOpts.method = "GET";
                requestOpts.body = void 0;
                requestOpts.headers.delete("content-length");
              }
              resolve(fetch2(new Request(locationURL, requestOpts)));
              finalize();
              return;
          }
        }
        res.once("end", function() {
          if (signal)
            signal.removeEventListener("abort", abortAndFinalize);
        });
        let body = res.pipe(new PassThrough$1());
        const response_options = {
          url: request.url,
          status: res.statusCode,
          statusText: res.statusMessage,
          headers,
          size: request.size,
          timeout: request.timeout,
          counter: request.counter
        };
        const codings = headers.get("Content-Encoding");
        if (!request.compress || request.method === "HEAD" || codings === null || res.statusCode === 204 || res.statusCode === 304) {
          response = new Response2(body, response_options);
          resolve(response);
          return;
        }
        const zlibOptions = {
          flush: zlib.Z_SYNC_FLUSH,
          finishFlush: zlib.Z_SYNC_FLUSH
        };
        if (codings == "gzip" || codings == "x-gzip") {
          body = body.pipe(zlib.createGunzip(zlibOptions));
          response = new Response2(body, response_options);
          resolve(response);
          return;
        }
        if (codings == "deflate" || codings == "x-deflate") {
          const raw = res.pipe(new PassThrough$1());
          raw.once("data", function(chunk) {
            if ((chunk[0] & 15) === 8) {
              body = body.pipe(zlib.createInflate());
            } else {
              body = body.pipe(zlib.createInflateRaw());
            }
            response = new Response2(body, response_options);
            resolve(response);
          });
          return;
        }
        if (codings == "br" && typeof zlib.createBrotliDecompress === "function") {
          body = body.pipe(zlib.createBrotliDecompress());
          response = new Response2(body, response_options);
          resolve(response);
          return;
        }
        response = new Response2(body, response_options);
        resolve(response);
      });
      writeToStream(req, request);
    });
  }
  fetch2.isRedirect = function(code) {
    return code === 301 || code === 302 || code === 303 || code === 307 || code === 308;
  };
  fetch2.Promise = global.Promise;
  module2.exports = exports2 = fetch2;
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.default = exports2;
  exports2.Headers = Headers;
  exports2.Request = Request;
  exports2.Response = Response2;
  exports2.FetchError = FetchError;
});

// node_modules/@cazoo/events/dist/constants.js
var require_constants5 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.CAZOO_EVENT_NAMESPACE = "uk.co.cazoo";
  exports2.CAZOO_TELEMETRY_EVENT_NAMESPACE = "uk.co.cazoo.telemetry";
});

// node_modules/@cazoo/events/dist/utils.js
var require_utils2 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  exports2.extractFullFunctionArn = (ctx) => {
    if (!ctx || !ctx.invokedFunctionArn)
      return null;
    const invokedArnContainsVersion = ctx.invokedFunctionArn.split(":").length === 8;
    return ctx.functionVersion && !invokedArnContainsVersion ? `${ctx.invokedFunctionArn}:${ctx.functionVersion}` : ctx.invokedFunctionArn;
  };
  exports2.isEmpty = (obj) => !obj || typeof obj === "object" && Object.keys(obj).length === 0;
});

// node_modules/@cazoo/events/dist/errors.js
var require_errors4 = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var describeResponse = (response) => response.Entries ? `${response.FailedEntryCount} of ${response.Entries.length} event(s) failed to be raised` : `${response.FailedEntryCount} event(s) failed to be raised`;
  var PutEventError = class extends Error {
    constructor(response) {
      const message = describeResponse(response);
      super(`${message}: ${JSON.stringify(response)}`);
      this.name = "PutEventError";
      this.response = response;
    }
  };
  exports2.PutEventError = PutEventError;
});

// node_modules/@cazoo/events/dist/cloudwatchEvents.js
var require_cloudwatchEvents = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var utils_1 = require_utils2();
  var aws_sdk_1 = require("aws-sdk");
  var errors_1 = require_errors4();
  var constants_1 = require_constants5();
  var cloudWatchEventMapper = (resources, eventBusName) => {
    return (event) => {
      return {
        Source: event.namespace || constants_1.CAZOO_EVENT_NAMESPACE,
        DetailType: event.name,
        Detail: JSON.stringify(event.payload),
        Resources: resources,
        EventBusName: eventBusName || process.env.CAZOO_EVENTS_TARGET_EVENT_BUS
      };
    };
  };
  exports2.putWithConfigInternal = async (ctx, clientConfig, events, eventBusName) => {
    if (events.length === 0) {
      throw new Error("Failed to put events: no events provided");
    }
    const functionArn = utils_1.extractFullFunctionArn(ctx);
    const resources = functionArn ? [functionArn] : [];
    const client = new aws_sdk_1.CloudWatchEvents(clientConfig);
    const toCloudWatchEvent = cloudWatchEventMapper(resources, eventBusName);
    const entries = events.map(toCloudWatchEvent);
    const res = await client.putEvents({
      Entries: entries
    }).promise();
    if (!res.Entries || res.Entries.length !== entries.length) {
      throw new Error(`Expected CloudWatch to return ${entries.length} entry in the response, instead got: ${JSON.stringify(res)}`);
    }
    if (res.FailedEntryCount) {
      throw new errors_1.PutEventError(res);
    }
    return res.Entries.map((ev) => ({id: ev.EventId}));
  };
});

// node_modules/@cazoo/events/dist/events.js
var require_events = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var constants_1 = require_constants5();
  var utils_1 = require_utils2();
  var cloudwatchEvents_1 = require_cloudwatchEvents();
  exports2.put = async (ctx, ...events) => {
    return cloudwatchEvents_1.putWithConfigInternal(ctx, {}, events);
  };
  exports2.putWithConfig = async (ctx, clientConfig, ...events) => {
    return cloudwatchEvents_1.putWithConfigInternal(ctx, clientConfig, events);
  };
  var EventBridgeEventClient = class {
    constructor({context, clientConfig, eventBusName}) {
      this.put = (...events) => {
        return cloudwatchEvents_1.putWithConfigInternal(this.context, this.clientConfig || {}, events, this.eventBusName);
      };
      this.context = context;
      this.clientConfig = clientConfig;
      this.eventBusName = eventBusName;
    }
  };
  exports2.EventBridgeEventClient = EventBridgeEventClient;
  exports2.parse = async (raw) => {
    if (raw.source !== constants_1.CAZOO_EVENT_NAMESPACE) {
      throw new Error(`Failed to parse event, invalid source: "${raw.source}", expected: "${constants_1.CAZOO_EVENT_NAMESPACE}"`);
    }
    if (utils_1.isEmpty(raw.detail)) {
      throw new Error(`Failed to parse event, empty payload`);
    }
    const detailStringified = typeof raw.detail === "string";
    const payload = detailStringified ? JSON.parse(raw.detail) : raw.detail;
    return {name: raw["detail-type"], payload};
  };
});

// node_modules/@cazoo/events/dist/validators.js
var require_validators2 = __commonJS((exports2) => {
  "use strict";
  var __importDefault = exports2 && exports2.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {default: mod};
  };
  Object.defineProperty(exports2, "__esModule", {value: true});
  var ajv_1 = __importDefault(require_ajv());
  var aws_sdk_1 = require("aws-sdk");
  var LATEST = "LATEST";
  var SOURCE = "uk.co.cazoo";
  var DISCOVERED_SCHEMAS = "discovered-schemas";
  var DynamicSchemaValidator2 = class {
    constructor(registry = DISCOVERED_SCHEMAS) {
      this.client = new aws_sdk_1.Schemas({
        endpoint: process.env.CAZOO_SCHEMA_ENDPOINT,
        region: process.env.AWS_REGION
      });
      this.registry = registry;
      this.schemas = new Map();
      this.ajv = new ajv_1.default({
        allErrors: true
      });
    }
    schemaRef(name, version = LATEST) {
      return `${name}@${version}`;
    }
    async fetchSchema(name) {
      try {
        return await this.client.describeSchema({
          RegistryName: this.registry,
          SchemaName: `${SOURCE}@${name}`
        }).promise();
      } catch (e) {
        if (e.statusCode === 404) {
          return;
        }
        throw e;
      }
    }
    copyAtoms(root, schemas) {
      root.components = {schemas: {}};
      for (const component of Object.keys(schemas)) {
        const atom = schemas[component];
        if (atom === root)
          continue;
        root.components.schemas[component] = atom;
      }
    }
    async getValidator(event) {
      const ref = this.schemaRef(event.name, event.version);
      const cached = this.schemas.get(ref);
      if (cached === null) {
        return {tag: "UNKNOWN_SCHEMA", ref};
      }
      if (cached !== void 0) {
        return {
          tag: "SUCCESS",
          result: this.ajv.getSchema(ref)
        };
      }
      const schemaResponse = await this.fetchSchema(event.name);
      if (schemaResponse === void 0 || schemaResponse.Content === void 0) {
        this.schemas.set(ref, null);
        return {tag: "UNKNOWN_SCHEMA", ref};
      }
      const response = JSON.parse(schemaResponse.Content);
      const schema = response.components.schemas[event.name];
      this.copyAtoms(schema, response.components.schemas);
      if (!this.ajv.getSchema(ref)) {
        this.ajv.addSchema(schema, ref);
      }
      this.schemas.set(ref, schema);
      return {
        tag: "SUCCESS",
        result: this.ajv.getSchema(ref)
      };
    }
    async validate(event) {
      const result = await this.getValidator(event);
      if (result.tag === "UNKNOWN_SCHEMA")
        return {tag: "UNKNOWN_SCHEMA", ref: result.ref};
      const validator3 = result.result;
      if (validator3(event.payload))
        return {tag: "SUCCESS", result: event};
      return {
        tag: "VALIDATION_ERROR",
        message: this.ajv.errorsText(validator3.errors),
        errors: validator3.errors || []
      };
    }
  };
  exports2.DynamicSchemaValidator = DynamicSchemaValidator2;
  var StaticSchemaValidator = class {
    constructor() {
      this.ajv = new ajv_1.default();
    }
    schemaRef(name, version = LATEST) {
      return `${name}@${version}`;
    }
    addSchema(schema, name, version) {
      this.ajv.addSchema(schema, this.schemaRef(name, version));
    }
    async validate(event) {
      const ref = this.schemaRef(event.name, event.version);
      const validator3 = this.ajv.getSchema(ref);
      if (validator3 === void 0) {
        return {tag: "UNKNOWN_SCHEMA", ref};
      }
      if (validator3(event.payload))
        return {tag: "SUCCESS", result: event};
      return {
        tag: "VALIDATION_ERROR",
        errors: validator3.errors || [],
        message: this.ajv.errorsText(validator3.errors)
      };
    }
  };
  exports2.StaticSchemaValidator = StaticSchemaValidator;
  var ValidationError4 = class extends Error {
    constructor(message, errors) {
      super(message);
      this.name = this.constructor.name;
      this.errors = errors;
      Error.captureStackTrace(this, this.constructor);
    }
  };
  exports2.ValidationError = ValidationError4;
  var SchemaError = class extends Error {
    constructor(message) {
      super(message);
      this.name = this.constructor.name;
      Error.captureStackTrace(this, this.constructor);
    }
  };
  exports2.SchemaError = SchemaError;
  var Is = class {
    static Success(result) {
      return result.tag === "SUCCESS";
    }
    static ValidationError(result) {
      return result.tag === "VALIDATION_ERROR";
    }
    static UnknownSchema(result) {
      return result.tag === "UNKNOWN_SCHEMA";
    }
  };
  exports2.Is = Is;
});

// node_modules/@cazoo/events/dist/eventClient.js
var require_eventClient = __commonJS((exports2) => {
  "use strict";
  Object.defineProperty(exports2, "__esModule", {value: true});
  var events_1 = require_events();
  var validators_1 = require_validators2();
  var EventClient2 = class {
    constructor(validator3, context, config) {
      this.validator = validator3;
      this.context = context;
      this.config = config || {};
    }
    throwFrom(result) {
      switch (result.tag) {
        case "UNKNOWN_SCHEMA":
          throw new validators_1.SchemaError(`No schema found for ref ${result.ref}`);
        case "SUCCESS":
          return;
        case "VALIDATION_ERROR":
          throw new validators_1.ValidationError(result.message, result.errors);
      }
    }
    async put(...events) {
      for (const e of events) {
        const result = await this.validator.validate(e);
        this.throwFrom(result);
      }
      return await events_1.putWithConfig(this.context, this.config, ...events);
    }
  };
  exports2.EventClient = EventClient2;
});

// node_modules/@cazoo/events/dist/index.js
var require_dist4 = __commonJS((exports2) => {
  "use strict";
  function __export2(m) {
    for (var p in m)
      if (!exports2.hasOwnProperty(p))
        exports2[p] = m[p];
  }
  Object.defineProperty(exports2, "__esModule", {value: true});
  __export2(require_events());
  __export2(require_errors4());
  __export2(require_eventClient());
  __export2(require_validators2());
});

// node_modules/aws4/lru.js
var require_lru = __commonJS((exports2, module2) => {
  module2.exports = function(size) {
    return new LruCache(size);
  };
  function LruCache(size) {
    this.capacity = size | 0;
    this.map = Object.create(null);
    this.list = new DoublyLinkedList();
  }
  LruCache.prototype.get = function(key) {
    var node = this.map[key];
    if (node == null)
      return void 0;
    this.used(node);
    return node.val;
  };
  LruCache.prototype.set = function(key, val) {
    var node = this.map[key];
    if (node != null) {
      node.val = val;
    } else {
      if (!this.capacity)
        this.prune();
      if (!this.capacity)
        return false;
      node = new DoublyLinkedNode(key, val);
      this.map[key] = node;
      this.capacity--;
    }
    this.used(node);
    return true;
  };
  LruCache.prototype.used = function(node) {
    this.list.moveToFront(node);
  };
  LruCache.prototype.prune = function() {
    var node = this.list.pop();
    if (node != null) {
      delete this.map[node.key];
      this.capacity++;
    }
  };
  function DoublyLinkedList() {
    this.firstNode = null;
    this.lastNode = null;
  }
  DoublyLinkedList.prototype.moveToFront = function(node) {
    if (this.firstNode == node)
      return;
    this.remove(node);
    if (this.firstNode == null) {
      this.firstNode = node;
      this.lastNode = node;
      node.prev = null;
      node.next = null;
    } else {
      node.prev = null;
      node.next = this.firstNode;
      node.next.prev = node;
      this.firstNode = node;
    }
  };
  DoublyLinkedList.prototype.pop = function() {
    var lastNode = this.lastNode;
    if (lastNode != null) {
      this.remove(lastNode);
    }
    return lastNode;
  };
  DoublyLinkedList.prototype.remove = function(node) {
    if (this.firstNode == node) {
      this.firstNode = node.next;
    } else if (node.prev != null) {
      node.prev.next = node.next;
    }
    if (this.lastNode == node) {
      this.lastNode = node.prev;
    } else if (node.next != null) {
      node.next.prev = node.prev;
    }
  };
  function DoublyLinkedNode(key, val) {
    this.key = key;
    this.val = val;
    this.prev = null;
    this.next = null;
  }
});

// node_modules/aws4/aws4.js
var require_aws4 = __commonJS((exports2) => {
  var aws4 = exports2;
  var url = require("url");
  var querystring = require("querystring");
  var crypto = require("crypto");
  var lru = require_lru();
  var credentialsCache = lru(1e3);
  function hmac(key, string, encoding) {
    return crypto.createHmac("sha256", key).update(string, "utf8").digest(encoding);
  }
  function hash(string, encoding) {
    return crypto.createHash("sha256").update(string, "utf8").digest(encoding);
  }
  function encodeRfc3986(urlEncodedString) {
    return urlEncodedString.replace(/[!'()*]/g, function(c) {
      return "%" + c.charCodeAt(0).toString(16).toUpperCase();
    });
  }
  function encodeRfc3986Full(str) {
    return encodeRfc3986(encodeURIComponent(str));
  }
  var HEADERS_TO_IGNORE = {
    authorization: true,
    connection: true,
    "x-amzn-trace-id": true,
    "user-agent": true,
    expect: true,
    "presigned-expires": true,
    range: true
  };
  function RequestSigner(request, credentials) {
    if (typeof request === "string")
      request = url.parse(request);
    var headers = request.headers = request.headers || {}, hostParts = (!this.service || !this.region) && this.matchHost(request.hostname || request.host || headers.Host || headers.host);
    this.request = request;
    this.credentials = credentials || this.defaultCredentials();
    this.service = request.service || hostParts[0] || "";
    this.region = request.region || hostParts[1] || "us-east-1";
    if (this.service === "email")
      this.service = "ses";
    if (!request.method && request.body)
      request.method = "POST";
    if (!headers.Host && !headers.host) {
      headers.Host = request.hostname || request.host || this.createHost();
      if (request.port)
        headers.Host += ":" + request.port;
    }
    if (!request.hostname && !request.host)
      request.hostname = headers.Host || headers.host;
    this.isCodeCommitGit = this.service === "codecommit" && request.method === "GIT";
  }
  RequestSigner.prototype.matchHost = function(host) {
    var match = (host || "").match(/([^\.]+)\.(?:([^\.]*)\.)?amazonaws\.com(\.cn)?$/);
    var hostParts = (match || []).slice(1, 3);
    if (hostParts[1] === "es")
      hostParts = hostParts.reverse();
    if (hostParts[1] == "s3") {
      hostParts[0] = "s3";
      hostParts[1] = "us-east-1";
    } else {
      for (var i = 0; i < 2; i++) {
        if (/^s3-/.test(hostParts[i])) {
          hostParts[1] = hostParts[i].slice(3);
          hostParts[0] = "s3";
          break;
        }
      }
    }
    return hostParts;
  };
  RequestSigner.prototype.isSingleRegion = function() {
    if (["s3", "sdb"].indexOf(this.service) >= 0 && this.region === "us-east-1")
      return true;
    return ["cloudfront", "ls", "route53", "iam", "importexport", "sts"].indexOf(this.service) >= 0;
  };
  RequestSigner.prototype.createHost = function() {
    var region = this.isSingleRegion() ? "" : "." + this.region, subdomain = this.service === "ses" ? "email" : this.service;
    return subdomain + region + ".amazonaws.com";
  };
  RequestSigner.prototype.prepareRequest = function() {
    this.parsePath();
    var request = this.request, headers = request.headers, query;
    if (request.signQuery) {
      this.parsedPath.query = query = this.parsedPath.query || {};
      if (this.credentials.sessionToken)
        query["X-Amz-Security-Token"] = this.credentials.sessionToken;
      if (this.service === "s3" && !query["X-Amz-Expires"])
        query["X-Amz-Expires"] = 86400;
      if (query["X-Amz-Date"])
        this.datetime = query["X-Amz-Date"];
      else
        query["X-Amz-Date"] = this.getDateTime();
      query["X-Amz-Algorithm"] = "AWS4-HMAC-SHA256";
      query["X-Amz-Credential"] = this.credentials.accessKeyId + "/" + this.credentialString();
      query["X-Amz-SignedHeaders"] = this.signedHeaders();
    } else {
      if (!request.doNotModifyHeaders && !this.isCodeCommitGit) {
        if (request.body && !headers["Content-Type"] && !headers["content-type"])
          headers["Content-Type"] = "application/x-www-form-urlencoded; charset=utf-8";
        if (request.body && !headers["Content-Length"] && !headers["content-length"])
          headers["Content-Length"] = Buffer.byteLength(request.body);
        if (this.credentials.sessionToken && !headers["X-Amz-Security-Token"] && !headers["x-amz-security-token"])
          headers["X-Amz-Security-Token"] = this.credentials.sessionToken;
        if (this.service === "s3" && !headers["X-Amz-Content-Sha256"] && !headers["x-amz-content-sha256"])
          headers["X-Amz-Content-Sha256"] = hash(this.request.body || "", "hex");
        if (headers["X-Amz-Date"] || headers["x-amz-date"])
          this.datetime = headers["X-Amz-Date"] || headers["x-amz-date"];
        else
          headers["X-Amz-Date"] = this.getDateTime();
      }
      delete headers.Authorization;
      delete headers.authorization;
    }
  };
  RequestSigner.prototype.sign = function() {
    if (!this.parsedPath)
      this.prepareRequest();
    if (this.request.signQuery) {
      this.parsedPath.query["X-Amz-Signature"] = this.signature();
    } else {
      this.request.headers.Authorization = this.authHeader();
    }
    this.request.path = this.formatPath();
    return this.request;
  };
  RequestSigner.prototype.getDateTime = function() {
    if (!this.datetime) {
      var headers = this.request.headers, date = new Date(headers.Date || headers.date || new Date());
      this.datetime = date.toISOString().replace(/[:\-]|\.\d{3}/g, "");
      if (this.isCodeCommitGit)
        this.datetime = this.datetime.slice(0, -1);
    }
    return this.datetime;
  };
  RequestSigner.prototype.getDate = function() {
    return this.getDateTime().substr(0, 8);
  };
  RequestSigner.prototype.authHeader = function() {
    return [
      "AWS4-HMAC-SHA256 Credential=" + this.credentials.accessKeyId + "/" + this.credentialString(),
      "SignedHeaders=" + this.signedHeaders(),
      "Signature=" + this.signature()
    ].join(", ");
  };
  RequestSigner.prototype.signature = function() {
    var date = this.getDate(), cacheKey = [this.credentials.secretAccessKey, date, this.region, this.service].join(), kDate, kRegion, kService, kCredentials = credentialsCache.get(cacheKey);
    if (!kCredentials) {
      kDate = hmac("AWS4" + this.credentials.secretAccessKey, date);
      kRegion = hmac(kDate, this.region);
      kService = hmac(kRegion, this.service);
      kCredentials = hmac(kService, "aws4_request");
      credentialsCache.set(cacheKey, kCredentials);
    }
    return hmac(kCredentials, this.stringToSign(), "hex");
  };
  RequestSigner.prototype.stringToSign = function() {
    return [
      "AWS4-HMAC-SHA256",
      this.getDateTime(),
      this.credentialString(),
      hash(this.canonicalString(), "hex")
    ].join("\n");
  };
  RequestSigner.prototype.canonicalString = function() {
    if (!this.parsedPath)
      this.prepareRequest();
    var pathStr = this.parsedPath.path, query = this.parsedPath.query, headers = this.request.headers, queryStr = "", normalizePath = this.service !== "s3", decodePath = this.service === "s3" || this.request.doNotEncodePath, decodeSlashesInPath = this.service === "s3", firstValOnly = this.service === "s3", bodyHash;
    if (this.service === "s3" && this.request.signQuery) {
      bodyHash = "UNSIGNED-PAYLOAD";
    } else if (this.isCodeCommitGit) {
      bodyHash = "";
    } else {
      bodyHash = headers["X-Amz-Content-Sha256"] || headers["x-amz-content-sha256"] || hash(this.request.body || "", "hex");
    }
    if (query) {
      var reducedQuery = Object.keys(query).reduce(function(obj, key) {
        if (!key)
          return obj;
        obj[encodeRfc3986Full(key)] = !Array.isArray(query[key]) ? query[key] : firstValOnly ? query[key][0] : query[key];
        return obj;
      }, {});
      var encodedQueryPieces = [];
      Object.keys(reducedQuery).sort().forEach(function(key) {
        if (!Array.isArray(reducedQuery[key])) {
          encodedQueryPieces.push(key + "=" + encodeRfc3986Full(reducedQuery[key]));
        } else {
          reducedQuery[key].map(encodeRfc3986Full).sort().forEach(function(val) {
            encodedQueryPieces.push(key + "=" + val);
          });
        }
      });
      queryStr = encodedQueryPieces.join("&");
    }
    if (pathStr !== "/") {
      if (normalizePath)
        pathStr = pathStr.replace(/\/{2,}/g, "/");
      pathStr = pathStr.split("/").reduce(function(path, piece) {
        if (normalizePath && piece === "..") {
          path.pop();
        } else if (!normalizePath || piece !== ".") {
          if (decodePath)
            piece = decodeURIComponent(piece.replace(/\+/g, " "));
          path.push(encodeRfc3986Full(piece));
        }
        return path;
      }, []).join("/");
      if (pathStr[0] !== "/")
        pathStr = "/" + pathStr;
      if (decodeSlashesInPath)
        pathStr = pathStr.replace(/%2F/g, "/");
    }
    return [
      this.request.method || "GET",
      pathStr,
      queryStr,
      this.canonicalHeaders() + "\n",
      this.signedHeaders(),
      bodyHash
    ].join("\n");
  };
  RequestSigner.prototype.canonicalHeaders = function() {
    var headers = this.request.headers;
    function trimAll(header) {
      return header.toString().trim().replace(/\s+/g, " ");
    }
    return Object.keys(headers).filter(function(key) {
      return HEADERS_TO_IGNORE[key.toLowerCase()] == null;
    }).sort(function(a, b) {
      return a.toLowerCase() < b.toLowerCase() ? -1 : 1;
    }).map(function(key) {
      return key.toLowerCase() + ":" + trimAll(headers[key]);
    }).join("\n");
  };
  RequestSigner.prototype.signedHeaders = function() {
    return Object.keys(this.request.headers).map(function(key) {
      return key.toLowerCase();
    }).filter(function(key) {
      return HEADERS_TO_IGNORE[key] == null;
    }).sort().join(";");
  };
  RequestSigner.prototype.credentialString = function() {
    return [
      this.getDate(),
      this.region,
      this.service,
      "aws4_request"
    ].join("/");
  };
  RequestSigner.prototype.defaultCredentials = function() {
    var env = process.env;
    return {
      accessKeyId: env.AWS_ACCESS_KEY_ID || env.AWS_ACCESS_KEY,
      secretAccessKey: env.AWS_SECRET_ACCESS_KEY || env.AWS_SECRET_KEY,
      sessionToken: env.AWS_SESSION_TOKEN
    };
  };
  RequestSigner.prototype.parsePath = function() {
    var path = this.request.path || "/";
    if (/[^0-9A-Za-z;,/?:@&=+$\-_.!~*'()#%]/.test(path)) {
      path = encodeURI(decodeURI(path));
    }
    var queryIx = path.indexOf("?"), query = null;
    if (queryIx >= 0) {
      query = querystring.parse(path.slice(queryIx + 1));
      path = path.slice(0, queryIx);
    }
    this.parsedPath = {
      path,
      query
    };
  };
  RequestSigner.prototype.formatPath = function() {
    var path = this.parsedPath.path, query = this.parsedPath.query;
    if (!query)
      return path;
    if (query[""] != null)
      delete query[""];
    return path + "?" + encodeRfc3986(querystring.stringify(query));
  };
  aws4.RequestSigner = RequestSigner;
  aws4.sign = function(request, credentials) {
    return new RequestSigner(request, credentials).sign();
  };
});

// src/_new/adapters/api-gateway/getEuVehicleDetailsHandler.ts
__markAsModule(exports);
__export(exports, {
  getEuVehicleDetails: () => getEuVehicleDetails,
  getEuVehicleDetailsHandler: () => getEuVehicleDetailsHandler
});

// src/middyWrapper/middyWrapper.ts
var import_core = __toModule(require_core());
var import_http_header_normalizer = __toModule(require_http_header_normalizer());
var import_http_json_body_parser = __toModule(require_http_json_body_parser());
var import_validator = __toModule(require_validator());
var import_middy4 = __toModule(require_dist2());

// src/middyWrapper/errorHandler.ts
var import_middy2 = __toModule(require_dist2());

// src/middyWrapper/errors.ts
var import_middy = __toModule(require_dist2());

// src/_new/domain/source.ts
var Source;
(function(Source2) {
  Source2["PartExchange"] = "part-exchange";
  Source2["SellCar"] = "sell-car";
  Source2["Revaluation"] = "revaluation";
  Source2["SettlementConfirmation"] = "settlement-confirmation";
})(Source || (Source = {}));

// src/_new/use-cases/generate-gb-offer/validateGbCustomerVehicleDetails.ts
var ValidationError = class extends Error {
  constructor(field, description) {
    super("Validation Error");
    this.field = field;
    this.description = description;
  }
};
var MissingCustomerDetailsError = class extends ValidationError {
  constructor() {
    super("body/customerDetails", "Missing customer details");
  }
};

// src/_new/use-cases/errors/useCasesErrors.ts
var MissingCheckoutIdError = class extends ValidationError {
  constructor() {
    super("body/checkoutId", "Missing checkout id");
  }
};
var MissingOriginalOfferIdError = class extends ValidationError {
  constructor() {
    super("body/originalOfferId", "Missing original offer id");
  }
};
var NegativeEquityError = class extends ValidationError {
  constructor() {
    super("body/netOffer", "Cazoo Purchase does not support Negative Equity");
  }
};

// src/constants/errors.ts
var BAD_GATEWAY_ERROR = "Bad Gateway";
var BAD_REQUEST_ERROR = "Bad Request";
var UNAUTHORIZED_ERROR = "Unauthorized";
var UNKNOWN_ERROR = "An unknown error occurred";
var VALUATION_ERROR = "VRM was found, but no valuation";
var INVALID_VIN_ERROR = "VIN is not 17 characters";
var NOT_FOUND_VEHICLE_FROM_VRM = "Vehicle not found for the given VRM";
var NOT_FOUND_VEHICLE_FROM_VIN = "Vehicle not found for the given VIN";
var ValuationApiErrors;
(function(ValuationApiErrors2) {
  ValuationApiErrors2["VRM_NOT_FOUND"] = "VRM_NOT_FOUND";
  ValuationApiErrors2["VIN_NOT_FOUND"] = "VIN_NOT_FOUND";
  ValuationApiErrors2["VEHICLE_TYPE_NOT_SUPPORTED"] = "VEHICLE_TYPE_NOT_SUPPORTED";
  ValuationApiErrors2["VALUATION_NOT_FOUND"] = "VALUATION_NOT_FOUND";
  ValuationApiErrors2["INVALID_VIN"] = "INVALID_VIN";
  ValuationApiErrors2["RETAIL_VALUATION_TOO_HIGH"] = "RETAIL_VALUATION_TOO_HIGH";
})(ValuationApiErrors || (ValuationApiErrors = {}));

// src/middyWrapper/errors.ts
var DataError = class extends Error {
  constructor() {
    super("DATA_ERROR");
  }
};
var DynamoDBError = class extends Error {
  constructor(description) {
    super("DynamoDB Error");
    this.description = description;
  }
};
var BadRequestError = class extends Error {
  constructor(description) {
    super(BAD_REQUEST_ERROR);
    this.description = description;
  }
};
var UnauthorizedError = class extends Error {
  constructor(description) {
    super(UNAUTHORIZED_ERROR);
    this.description = description || UNAUTHORIZED_ERROR;
  }
};
var ErrorWithReason = class extends Error {
  constructor(reason, description) {
    super(reason);
    this.reason = reason;
    this.description = description;
  }
};
var VrmNotFoundError = class extends ErrorWithReason {
  constructor() {
    super(ValuationApiErrors.VRM_NOT_FOUND, NOT_FOUND_VEHICLE_FROM_VRM);
  }
};
var VinNotFoundError = class extends ErrorWithReason {
  constructor() {
    super(ValuationApiErrors.VIN_NOT_FOUND, NOT_FOUND_VEHICLE_FROM_VIN);
  }
};
var VehicleTypeNotSupportedError = class extends ErrorWithReason {
  constructor(description) {
    super(ValuationApiErrors.VEHICLE_TYPE_NOT_SUPPORTED, description);
  }
};
var RetailValuationTooHighError = class extends ErrorWithReason {
  constructor(description) {
    super(ValuationApiErrors.RETAIL_VALUATION_TOO_HIGH, description);
  }
};
var ValuationError = class extends ErrorWithReason {
  constructor(vehicleDetails) {
    super(ValuationApiErrors.VALUATION_NOT_FOUND, VALUATION_ERROR);
    this.vehicleDetails = vehicleDetails;
  }
};
var ValuationNotFoundError = class extends ErrorWithReason {
  constructor(description) {
    super(ValuationApiErrors.VALUATION_NOT_FOUND, description);
  }
};
var InvalidVINError = class extends ErrorWithReason {
  constructor(vehicleDetails) {
    super(ValuationApiErrors.INVALID_VIN, INVALID_VIN_ERROR);
    this.vehicleDetails = vehicleDetails;
  }
};
function handleErrorInGateway(error) {
  let status;
  let errorBody = void 0;
  if (error instanceof DataError || error instanceof BadRequestError) {
    status = 400;
    errorBody = __objSpread(__objSpread({}, error), {stack: void 0});
  } else if (error instanceof MissingCheckoutIdError || error instanceof MissingOriginalOfferIdError || error instanceof MissingCustomerDetailsError) {
    status = 400;
    errorBody = {code: "FieldError", errors: [error]};
  } else if (error instanceof import_middy.FieldError) {
    status = 400;
    errorBody = {code: "FieldError", errors: [error]};
  } else if (error instanceof import_middy.ValidationError) {
    status = 400;
    errorBody = {
      code: "FieldError",
      errors: error.errors
    };
  } else if (error instanceof UnauthorizedError) {
    status = 401;
    errorBody = {description: UNAUTHORIZED_ERROR};
  } else if (error instanceof VrmNotFoundError || error instanceof VinNotFoundError || error instanceof import_middy.NotFoundError || error instanceof ValuationError || error instanceof InvalidVINError || error instanceof VehicleTypeNotSupportedError || error instanceof ValuationNotFoundError) {
    status = 404;
    errorBody = __objSpread(__objSpread({}, error), {stack: void 0, vehicleDetails: void 0});
  } else if (error instanceof import_middy.ConflictError) {
    status = 409;
    errorBody = __objSpread(__objSpread({}, error), {stack: void 0});
  } else if (error instanceof RetailValuationTooHighError || error instanceof NegativeEquityError) {
    status = 417;
    errorBody = __objSpread(__objSpread({}, error), {stack: void 0});
  } else if (error instanceof DynamoDBError) {
    status = 500;
    errorBody = __objSpread(__objSpread({}, error), {stack: void 0});
  } else if (error instanceof import_middy.ConfigurationError) {
    status = 500;
    errorBody = __objSpread(__objSpread({}, error), {stack: void 0});
  } else if (error instanceof import_middy.BadGatewayError) {
    status = 502;
    errorBody = {description: BAD_GATEWAY_ERROR};
  } else {
    status = 500;
    errorBody = {description: UNKNOWN_ERROR};
  }
  return {
    statusCode: status,
    body: JSON.stringify(errorBody)
  };
}

// src/middyWrapper/errorHandler.ts
var errorHandler = () => {
  const detailToFieldError = ({dataPath = "", message = ""}) => {
    const match = /should have required property (.*)/.exec(message);
    if (match) {
      const field = match[1];
      return new import_middy2.FieldError(field, "Field cannot be empty");
    }
    const s = dataPath.split(".");
    return new import_middy2.FieldError(s[s.length - 1], message);
  };
  return {
    onError: (handler) => {
      const {event} = handler;
      let error = handler.error;
      if (error.name === "BadRequestError") {
        const details = error.details;
        if (Array.isArray(details)) {
          error = new import_middy2.ValidationError(details.map(detailToFieldError));
        }
      }
      const e = handleErrorInGateway(error);
      const {statusCode, body} = e;
      event.observation.rootTrace.schema({
        httpStatusCode: statusCode
      });
      event.observation.rootTrace.endWithError(handler.error);
      handler.response = {
        statusCode,
        body
      };
      return Promise.resolve();
    }
  };
};

// src/middyWrapper/telemetry.ts
var import_telemetry = __toModule(require_dist3());
var import_middy3 = __toModule(require_dist2());

// src/_new/adapters/helpers/observability/secretsFilter.ts
var DEFAULT_SECRET_FIELDS = [
  "firstName",
  "lastName",
  "email",
  "given_name",
  "family_name"
];
var secretMask = "[REDACTED]";
var depthMask = "[Object object]";
var isObject = (obj) => typeof obj === "object";
function secretsFilter(propsToFilter = [], depthLimit = 8) {
  if (!propsToFilter || propsToFilter.length === 0)
    return (src) => src;
  const depthLimitReached = (depth) => depth > depthLimit;
  return function filterSecrets(src, dst = {}, depth = 0) {
    if (!isObject(src))
      return src;
    if (depthLimitReached(depth))
      return depthMask;
    if (Array.isArray(src))
      return src.map((v) => filterSecrets(v, {}, depth + 1));
    for (const prop in src) {
      const srcVal = src[prop];
      if (propsToFilter.includes(prop)) {
        dst[prop] = secretMask;
        continue;
      }
      if (Array.isArray(srcVal)) {
        dst[prop] = depthLimitReached(depth + 1) ? depthMask : srcVal.map((v) => filterSecrets(v, {}, depth + 1));
        continue;
      }
      if (isObject(srcVal)) {
        if (depthLimitReached(depth + 1)) {
          dst[prop] = depthMask;
          continue;
        }
        dst[prop] = {};
        filterSecrets(srcVal, dst[prop], depth + 1);
        continue;
      }
      dst[prop] = srcVal;
    }
    return dst;
  };
}

// src/middyWrapper/telemetry.ts
var fieldMasker = secretsFilter(DEFAULT_SECRET_FIELDS);
function safeParse(body) {
  try {
    return JSON.parse(body);
  } catch (e) {
    return body;
  }
}
var telemetry = ({
  sensitiveFields = DEFAULT_SECRET_FIELDS,
  loggerOptions = {}
}) => {
  return {
    before: (handler, next) => {
      const {context, event} = handler;
      const {path, body} = event;
      const options = process.env.SILENT_TEST ? {
        exporter: new import_telemetry.SilentExporter()
      } : void 0;
      const rootTrace = import_telemetry.Telemetry.startWithContext(event.requestContext.resourcePath, event, context, options).schema({
        route: event.requestContext.resourcePath
      }).appendContext(fieldMasker({
        path,
        requestData: {
          body: safeParse(body),
          queryStringParameters: handler.event.queryStringParameters || {}
        }
      }));
      const logger = (0, import_middy3.getEventContextLogger)(event, context, sensitiveFields, loggerOptions);
      event.observation = {
        logger,
        rootTrace,
        parentTrace: rootTrace,
        withParentTrace: function(trace) {
          return __objSpread(__objSpread({}, this), {
            parentTrace: trace
          });
        }
      };
      next();
    },
    after: (handler, next) => {
      const {body} = handler.response;
      handler.event.observation.rootTrace.schema({
        httpStatusCode: handler.response.statusCode
      }).appendContext(fieldMasker({
        responseBody: body ? safeParse(body) : body
      }));
      handler.event.observation.rootTrace.end();
      next();
    }
  };
};

// src/middyWrapper/middyWrapper.ts
var lambdaMiddyWrapper = ({
  lambda,
  inputSchema,
  sensitiveFields = [],
  loggerOptions,
  statusCode = 200,
  resultBody = true
}) => {
  return (0, import_core.default)(lambda).use(telemetry({sensitiveFields, loggerOptions})).use((0, import_http_header_normalizer.default)()).use((0, import_http_json_body_parser.default)()).use((0, import_validator.default)({inputSchema})).use((0, import_middy4.jsonResponder)({statusCode, resultBody})).use(errorHandler());
};

// src/_new/use-cases/mappers/mapCustomerVehicleOfferFailedV2.ts
var mapCustomerVehicleOfferFailedV2 = (euCustomerVehicleId, reason) => {
  const offerFailedAt = new Date();
  return {
    vehicle: {
      vin: euCustomerVehicleId.vin
    },
    request_market: euCustomerVehicleId.market,
    offer_failed_at: offerFailedAt.toISOString(),
    failure_reason: reason,
    checkout_id: euCustomerVehicleId.checkoutId
  };
};

// src/_new/use-cases/get-eu-vehicle-details/mapEuVehicleDetails.ts
var mapEuVehicleDetails = (vehicleDetails, hasActiveOrder) => {
  return __objSpread(__objSpread({}, vehicleDetails), {
    hasActiveOrder
  });
};

// src/_new/use-cases/get-eu-vehicle-details/getEuVehicleDetailsCommand.ts
var getEuVehicleDetailsCommand = (valuationService, eventPublisher, activeCustomerVehicleService) => {
  return async (euCustomerVehicleId) => {
    try {
      const getCustomerVehicleActiveResponse = await activeCustomerVehicleService.getCustomerVehicleActive(euCustomerVehicleId.vin);
      const vehicleDetails = await valuationService.getEuVehicleDetails(euCustomerVehicleId);
      return mapEuVehicleDetails(vehicleDetails, getCustomerVehicleActiveResponse);
    } catch (error) {
      if (error instanceof ErrorWithReason) {
        const customerVehicleOfferFailedV2Payload = mapCustomerVehicleOfferFailedV2(euCustomerVehicleId, error.reason);
        await eventPublisher.publishCustomerVehicleOfferFailedV2(customerVehicleOfferFailedV2Payload);
      }
      throw error;
    }
  };
};

// src/_new/adapters/helpers/http/httpConstants.ts
var HttpMethod;
(function(HttpMethod2) {
  HttpMethod2["GET"] = "GET";
  HttpMethod2["POST"] = "POST";
})(HttpMethod || (HttpMethod = {}));
var HeaderContentType;
(function(HeaderContentType2) {
  HeaderContentType2["JSON"] = "application/json";
})(HeaderContentType || (HeaderContentType = {}));
var HeaderType;
(function(HeaderType2) {
  HeaderType2["CONTENT_TYPE"] = "Content-Type";
})(HeaderType || (HeaderType = {}));

// src/_new/adapters/helpers/http/newHttpRequest.ts
var import_node_fetch = __toModule(require_lib2());
var import_middy5 = __toModule(require_dist2());
var getResponseBody = async (response) => {
  try {
    return await response.json();
  } catch (e) {
    return "";
  }
};
var hasError = (status) => status >= 400;
async function newHttpRequest(endpoint, requestOptions, observation) {
  const trace = observation.parentTrace.startChild("httpRequest").appendContext({
    endpoint
  });
  try {
    const response = await (0, import_node_fetch.default)(endpoint, __objSpread(__objSpread({}, requestOptions), {
      headers: __objSpread(__objSpread({}, requestOptions.headers), trace.asHttpHeaders())
    }));
    const {status} = response;
    const body = await getResponseBody(response);
    trace.appendContext({response: {status, body}});
    hasError(status) ? trace.endWithError(body) : trace.end();
    return {
      status,
      body
    };
  } catch (error) {
    trace.endWithError(error);
    throw new import_middy5.BadGatewayError(error);
  }
}

// src/_new/adapters/active-vehicle-customer-service/cazooActiveCustomerVehicleService.ts
var CazooActiveCustomerVehicleService = class {
  constructor(observation) {
    this.observation = observation;
  }
  static instance(observation) {
    return new CazooActiveCustomerVehicleService(observation);
  }
  async getCustomerVehicleActive(vin) {
    const request = {method: HttpMethod.GET};
    const url = `${process.env.CAZOO_BASE_URL}/api/customer-vehicle-order/active/${vin}`;
    const trace = this.observation.parentTrace.startChild("getActiveVehicleOrder").appendContext({
      externalService: "cazoo-active-vehicle-customer-service"
    });
    const currentObservation = this.observation.withParentTrace(trace);
    try {
      const response = await newHttpRequest(url, request, currentObservation);
      trace.appendContext({response});
      trace.end();
      if (response.body.success) {
        return response.body.customerVehicleHasActiveOrder;
      }
      return false;
    } catch (error) {
      trace.endWithError(error);
      return false;
    }
  }
};
var cazooActiveCustomerVehicleService_default = CazooActiveCustomerVehicleService;

// src/constants/events.ts
var CUSTOMER_VEHICLE_OFFER_ACCEPTED_V2 = "customerVehicleOfferAcceptedV2";

// src/_new/adapters/event-publisher/awsEventClient.ts
var import_events = __toModule(require_dist4());
var validator2 = new import_events.DynamicSchemaValidator(process.env.CAZOO_REGISTRY_ARN);
var awsEventClient = (context) => new import_events.EventClient(validator2, context);

// src/_new/adapters/event-publisher/awsEventPublisher.ts
var CUSTOMER_VEHICLE_OFFER_MADE_V2 = "customerVehicleOfferMadeV2";
var CUSTOMER_VEHICLE_OFFER_FAILED_V2 = "customerVehicleOfferFailedV2";
var MERCHANDISING_CHANNEL_DECISION_MADE_V2 = "merchandisingChannelDecisionMadeV2";
var AwsEventPublisher = class {
  constructor(context, observation) {
    this.context = context;
    this.observation = observation;
  }
  static instance(context, observation) {
    return new AwsEventPublisher(context, observation);
  }
  async publishCustomerVehicleOfferMadeV2(customerVehicleOfferMadeV2) {
    const trace = this.observation.parentTrace.startChild(CUSTOMER_VEHICLE_OFFER_MADE_V2);
    const event = {
      name: CUSTOMER_VEHICLE_OFFER_MADE_V2,
      payload: customerVehicleOfferMadeV2
    };
    const fieldMasker2 = secretsFilter(DEFAULT_SECRET_FIELDS);
    trace.appendContext(fieldMasker2(event));
    await this.publish(event, trace);
  }
  async publishCustomerVehicleOfferFailedV2(customerVehicleOfferFailedV2Payload) {
    const trace = this.observation.parentTrace.startChild(CUSTOMER_VEHICLE_OFFER_FAILED_V2);
    const event = {
      name: CUSTOMER_VEHICLE_OFFER_FAILED_V2,
      payload: customerVehicleOfferFailedV2Payload
    };
    trace.appendContext(event);
    await this.publish(event, trace);
  }
  async publishMerchandisingChannelDecisionMadeV2(merchandisingChannelDecisionMadeEvent) {
    const trace = this.observation.parentTrace.startChild(MERCHANDISING_CHANNEL_DECISION_MADE_V2);
    const event = {
      name: MERCHANDISING_CHANNEL_DECISION_MADE_V2,
      payload: merchandisingChannelDecisionMadeEvent
    };
    trace.appendContext(event);
    await this.publish(event, trace);
  }
  async publish(event, trace) {
    try {
      await awsEventClient(this.context).put(event);
      trace.end();
    } catch (error) {
      trace.endWithError(error);
    }
  }
  async publishCustomerVehicleOfferAcceptedV2(customerVehicleOfferAcceptedV2Payload) {
    const trace = this.observation.parentTrace.startChild(CUSTOMER_VEHICLE_OFFER_ACCEPTED_V2);
    const event = {
      name: CUSTOMER_VEHICLE_OFFER_ACCEPTED_V2,
      payload: customerVehicleOfferAcceptedV2Payload
    };
    trace.appendContext(event);
    await this.publish(event, trace);
  }
};
var awsEventPublisher_default = AwsEventPublisher;

// src/utils/checkError.ts
var import_middy6 = __toModule(require_dist2());
var isSuccessful = (status) => status < 400;
var hasKnownError = (knownErrors, status) => knownErrors.find((e) => e.status === status);
var checkError = (knownErrors, {status, body}, trace) => {
  if (isSuccessful(status))
    return;
  const knownError = hasKnownError(knownErrors, status);
  if (knownError) {
    const error = knownError.mapToError(body);
    trace.endWithError(error);
    throw error;
  }
  const badGatewayError = new import_middy6.BadGatewayError(UNKNOWN_ERROR);
  trace.endWithError(badGatewayError);
  throw badGatewayError;
};

// src/_new/adapters/helpers/aws/awsConstants.ts
var DEFAULT_REGION = "eu-west-1";
var EXECUTE_API_GATEWAY_COMMAND = "execute-api";

// src/_new/adapters/helpers/http/newSignedHttpRequest.ts
var import_aws4 = __toModule(require_aws4());
var import_url = __toModule(require("url"));
var import_middy7 = __toModule(require_dist2());
async function newSignedHttpRequest(endpoint, requestOptions, observation) {
  const trace = observation.parentTrace.startChild("signedHttpRequest").appendContext({endpoint});
  try {
    const {headers, method, body} = requestOptions;
    const urlPath = new import_url.URL(endpoint);
    const options = {
      host: urlPath.hostname,
      path: `${urlPath.pathname}${urlPath.search}`,
      service: EXECUTE_API_GATEWAY_COMMAND,
      region: DEFAULT_REGION,
      method,
      headers,
      body
    };
    const _a = options, {headers: _optionHeaders} = _a, otherOptions = __objRest(_a, ["headers"]);
    const fieldMasker2 = secretsFilter(DEFAULT_SECRET_FIELDS);
    trace.appendContext({options: fieldMasker2(otherOptions)});
    const response = await newHttpRequest(endpoint, (0, import_aws4.sign)(options, {
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      sessionToken: process.env.AWS_SESSION_TOKEN
    }), observation.withParentTrace(trace));
    trace.end();
    return response;
  } catch (error) {
    trace.endWithError(error);
    throw new import_middy7.BadGatewayError(error);
  }
}

// src/_new/adapters/valuation-service/knownErrors.ts
var import_middy8 = __toModule(require_dist2());
var knownGbVehicleDetailsErrors = [
  {
    status: 404,
    mapToError: (originalErrorBody) => {
      if ((originalErrorBody == null ? void 0 : originalErrorBody.reason) === "VEHICLE_TYPE_NOT_SUPPORTED") {
        return new VehicleTypeNotSupportedError(originalErrorBody.description);
      }
      return new VrmNotFoundError();
    }
  }
];
var knownEuVehicleDetailsErrors = [
  {
    status: 404,
    mapToError: (originalErrorBody) => {
      if ((originalErrorBody == null ? void 0 : originalErrorBody.reason) === "VDS_VEHICLE_TYPE_NOT_SUPPORTED") {
        return new VehicleTypeNotSupportedError(originalErrorBody.description);
      }
      if ((originalErrorBody == null ? void 0 : originalErrorBody.reason) === "VALUATION_NOT_FOUND") {
        return new ValuationNotFoundError("VIN was found, but no valuation");
      }
      return new VinNotFoundError();
    }
  }
];
var knownGbValuationErrors = [
  {
    status: 404,
    mapToError: (originalErrorBody) => {
      if ((originalErrorBody == null ? void 0 : originalErrorBody.reason) === "VALUATION_NOT_FOUND") {
        return new ValuationError(originalErrorBody == null ? void 0 : originalErrorBody.vehicleDetails);
      }
      if ((originalErrorBody == null ? void 0 : originalErrorBody.reason) === "VEHICLE_TYPE_NOT_SUPPORTED") {
        return new VehicleTypeNotSupportedError(originalErrorBody.description);
      }
      if ((originalErrorBody == null ? void 0 : originalErrorBody.reason) === "INVALID_VIN") {
        return new InvalidVINError(originalErrorBody == null ? void 0 : originalErrorBody.vehicleDetails);
      }
      return new VrmNotFoundError();
    }
  },
  {
    status: 400,
    mapToError: () => new DataError()
  },
  {
    status: 500,
    mapToError: (originalErrorBody) => {
      if ((originalErrorBody == null ? void 0 : originalErrorBody.reason) === "CONFIGURATION_ERROR") {
        return new import_middy8.ConfigurationError("CONFIGURATION_ERROR");
      }
      return new import_middy8.BadGatewayError(UNKNOWN_ERROR);
    }
  },
  {
    status: 401,
    mapToError: () => new UnauthorizedError()
  },
  {
    status: 417,
    mapToError: (originalErrorBody) => new RetailValuationTooHighError(originalErrorBody == null ? void 0 : originalErrorBody.description)
  }
];

// src/_new/adapters/valuation-service/cazooValuationService.ts
var CazooValuationService = class {
  constructor(observation) {
    this.getValuationsApiEndpoint = () => `https://${process.env.VALUATION_API_GATEWAY_ID}.${EXECUTE_API_GATEWAY_COMMAND}.${DEFAULT_REGION}.amazonaws.com/main`;
    this.observation = observation;
  }
  static instance(observation) {
    return new CazooValuationService(observation);
  }
  async getEuVehicleDetails(euCustomerVehicleId) {
    const {vin, market} = euCustomerVehicleId;
    const request = {method: HttpMethod.GET};
    const url = `${this.getValuationsApiEndpoint()}/valuations/eu/vehicle-details?vin=${vin}&market=${market}`;
    const trace = this.observation.parentTrace.startChild("getEuVehicleDetails").appendContext({externalService: "cazoo-valuations-api"});
    const currentObservation = this.observation.withParentTrace(trace);
    const response = await newSignedHttpRequest(url, request, currentObservation);
    checkError(knownEuVehicleDetailsErrors, response, trace);
    const {
      body: {make, model, derivative}
    } = response;
    trace.end();
    return {make, model, derivative};
  }
  async getEuValuation(euCustomerVehicleDetails) {
    const url = `${this.getValuationsApiEndpoint()}/valuations/eu/valuation`;
    const trace = this.observation.parentTrace.startChild("getEuValuation").appendContext({externalService: "cazoo-valuations-api"});
    const currentObservation = this.observation.withParentTrace(trace);
    const requestOptions = {
      method: HttpMethod.POST,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        vin: euCustomerVehicleDetails.vin,
        registrationDate: euCustomerVehicleDetails.registrationDate,
        odometer: euCustomerVehicleDetails.odometer,
        cosmeticCondition: euCustomerVehicleDetails.cosmeticCondition,
        market: euCustomerVehicleDetails.market,
        source: euCustomerVehicleDetails.source
      })
    };
    const response = await newSignedHttpRequest(url, requestOptions, currentObservation);
    checkError(knownEuVehicleDetailsErrors, response, trace);
    const {body} = response;
    trace.end();
    return body;
  }
  async getGbVehicleDetails(vrm) {
    const trace = this.observation.parentTrace.startChild("getGbVehicleDetails").appendContext({externalService: "cazoo-valuations-api"});
    const currentObservation = this.observation.withParentTrace(trace);
    const url = `${this.getValuationsApiEndpoint()}/valuations/variant?vrm=${vrm}`;
    const requestOptions = {
      method: HttpMethod.GET
    };
    const response = await newSignedHttpRequest(url, requestOptions, currentObservation);
    checkError(knownGbVehicleDetailsErrors, response, trace);
    const {
      body: {make, model, derivative, checks, vin}
    } = response;
    trace.end();
    return {make, model, derivative, checks, vin};
  }
  async getGbValuation(gbCustomerVehicleDetails) {
    const trace = this.observation.parentTrace.startChild("getGbValuation").appendContext({externalService: "cazoo-valuations-api"});
    const currentObservation = this.observation.withParentTrace(trace);
    const requestOptions = {
      method: HttpMethod.POST,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        vrm: gbCustomerVehicleDetails.vrm,
        cosmeticCondition: gbCustomerVehicleDetails.cosmeticCondition,
        odometer: gbCustomerVehicleDetails.odometer,
        previousOwners: gbCustomerVehicleDetails.previousOwners,
        serviceHistory: gbCustomerVehicleDetails.serviceHistory,
        source: gbCustomerVehicleDetails.source
      })
    };
    const url = `${this.getValuationsApiEndpoint()}/valuations/gb/valuation`;
    const response = await newSignedHttpRequest(url, requestOptions, currentObservation);
    checkError(knownGbValuationErrors, response, trace);
    const {
      valuationId,
      valuation,
      thirdPartyValuations,
      source,
      saleChannel,
      vehicleDetails
    } = response.body;
    trace.end();
    return {
      valuationId,
      valuation,
      thirdPartyValuations: {
        retailAmount: thirdPartyValuations.retailAmount,
        tradeAmount: thirdPartyValuations.tradeAmount
      },
      saleChannel,
      source,
      vehicleDetails
    };
  }
};
var cazooValuationService_default = CazooValuationService;

// src/_new/adapters/api-gateway/mappers/mapGetEuCustomerVehicleDetailsRequestParams.ts
var mapGetEuCustomerVehicleDetailsRequestParams = (getEuVehicleDetailsRequestParams) => {
  return {
    vin: getEuVehicleDetailsRequestParams.vin,
    market: getEuVehicleDetailsRequestParams.market,
    checkoutId: getEuVehicleDetailsRequestParams.checkoutId
  };
};

// src/_new/adapters/api-gateway/schemas/getEuVehicleDetailsSchema.ts
var getEuVehicleDetailsSchema = {
  type: "object",
  properties: {
    queryStringParameters: {
      type: "object",
      properties: {
        vin: {type: "string", minLength: 17, maxLength: 17},
        market: {
          type: "string",
          enum: ["fr", "de", "es"]
        },
        checkoutId: {type: "string"}
      },
      required: ["vin", "market"]
    }
  }
};

// src/_new/adapters/api-gateway/getEuVehicleDetailsHandler.ts
var getEuVehicleDetails = async (getEuVehicleDetailsRequest) => {
  const {
    queryStringParameters,
    context,
    observation
  } = getEuVehicleDetailsRequest;
  const eventPublisher = awsEventPublisher_default.instance(context, observation);
  const valuationService = cazooValuationService_default.instance(observation);
  const activeCustomerVehicleService = cazooActiveCustomerVehicleService_default.instance(observation);
  const command = getEuVehicleDetailsCommand(valuationService, eventPublisher, activeCustomerVehicleService);
  const euCustomerVehicleId = mapGetEuCustomerVehicleDetailsRequestParams(queryStringParameters);
  return await command(euCustomerVehicleId);
};
var getEuVehicleDetailsHandler = lambdaMiddyWrapper({
  lambda: getEuVehicleDetails,
  inputSchema: getEuVehicleDetailsSchema,
  statusCode: 200
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getEuVehicleDetails,
  getEuVehicleDetailsHandler
});
