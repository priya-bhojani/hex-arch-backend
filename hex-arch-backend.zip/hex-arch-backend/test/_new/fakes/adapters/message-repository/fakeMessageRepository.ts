import { MessageRepository } from "../../../../../src/adapters/message-repository/messageRepository";

export class FakeMessageRepository implements MessageRepository {
  public messages: string[] = [];

  public static instance(): FakeMessageRepository {
    return new FakeMessageRepository();
  }

  reset = (): void => {
    this.messages = [];
  };

  async store(message: string): Promise<void> {
    this.messages.push(message);
  }

  async get(): Promise<string[]> {
    return this.messages;
  }
}

export const useFakeMessageRepository = (): FakeMessageRepository => {
  const fakeOfferRepository = FakeMessageRepository.instance();

  jest.mock(
    "../../../../../src/_new/adapters/message-repository/dynamoDbMessageRepository",
    () =>
      class {
        public static instance(): FakeMessageRepository {
          return fakeOfferRepository;
        }
      }
  );

  return fakeOfferRepository;
};
