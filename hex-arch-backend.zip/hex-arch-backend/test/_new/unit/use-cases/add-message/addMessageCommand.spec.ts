import { mock } from "jest-mock-extended";

import { MessageRepository } from "../../../../../src/adapters/message-repository/messageRepository";
import { addMessageCommand } from "../../../../../src/use-cases/add-message/addMessageCommand";

describe("addMessageCommand", () => {
  it("should add message", async () => {
    const messageRepository = mock<MessageRepository>();

    const expectedResponse = "Message stored successfully.";

    const command = addMessageCommand(messageRepository);

    const actualResponse = await command("message");

    expect(actualResponse).toEqual(expectedResponse);
  });
});
