import { mock } from "jest-mock-extended";

import { MessageRepository } from "../../../../../src/adapters/message-repository/messageRepository";
import { getMessagesCommand } from "../../../../../src/use-cases/get-messages/getMessagesCommand";

describe("getMessagesCommand", () => {
  it("should get messages", async () => {
    const messageRepository = mock<MessageRepository>();
    messageRepository.get.mockResolvedValue(["message1", "message2"]);

    const expectedResponse = { messages: ["message1", "message2"] };

    const command = getMessagesCommand(messageRepository);

    const actualResponse = await command();

    expect(actualResponse).toEqual(expectedResponse);
  });
});
