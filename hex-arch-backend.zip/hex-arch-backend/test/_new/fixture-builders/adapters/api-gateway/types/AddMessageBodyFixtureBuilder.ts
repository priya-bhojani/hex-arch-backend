/* eslint-disable @typescript-eslint/explicit-function-return-type */
import { AddMessageBody } from "../../../../../../src/adapters/api-gateway/types/addMessageRequest";

export class AddMessageBodyFixtureBuilder {
  public static get ValidSample() {
    return class SomeFixtureBuilder implements AddMessageBody {
      public message = "some-dummy-message";

      public withMessage(message: string) {
        this.message = message;
        return this;
      }
    };
  }
}
