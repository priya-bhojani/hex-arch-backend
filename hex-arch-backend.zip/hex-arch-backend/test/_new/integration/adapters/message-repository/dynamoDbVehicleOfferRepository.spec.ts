import DynamoDbMessageRepository from "../../../../../src/adapters/message-repository/dynamoDbMessageRepository";

describe("DynamoDB Message Repository", () => {
  describe("get", () => {
    it("should return messages", async () => {
      const offerRepository = new DynamoDbMessageRepository();

      const response = await offerRepository.get();

      expect(response).toEqual(["message1", "message2"]);
    });
  });
});
