import { useFakeMessageRepository } from "../../../fakes/adapters/message-repository/fakeMessageRepository";
const messageRepository = useFakeMessageRepository();

import { addMessage } from "../../../../../src/adapters/api-gateway/addMessageHandler";
import {
  AddMessageBody,
  AddMessageRequest,
} from "../../../../../src/adapters/api-gateway/types/addMessageRequest";
import { AddMessageBodyFixtureBuilder } from "../../../fixture-builders/adapters/api-gateway/types/AddMessageBodyFixtureBuilder";

describe("Add Message Handler", () => {
  afterEach(() => {
    messageRepository.reset();
  });

  it("should store a message", async () => {
    const validSample: AddMessageBody = new AddMessageBodyFixtureBuilder.ValidSample();
    const addMessageRequest = {
      body: validSample,
      context: {},
    } as AddMessageRequest;
    const expectedAddMessageResponse = {
      response: "Message added successfully.",
    };

    const actualAddMessageResponse = await addMessage(addMessageRequest);

    expect(actualAddMessageResponse).toEqual(expectedAddMessageResponse);
  });
});
