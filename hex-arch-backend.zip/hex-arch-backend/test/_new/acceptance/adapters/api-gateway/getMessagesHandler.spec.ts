import { getMessages } from "../../../../../src/adapters/api-gateway/getMessagesHandler";

describe("Get Messages Handler", () => {
  it("should retrieve messages", async () => {
    const expectedGetMessagesResponse = { messages: ["message1", "message2"] };

    const actualGetMessagesResponse = await getMessages();

    expect(actualGetMessagesResponse).toEqual(expectedGetMessagesResponse);
  });
});
